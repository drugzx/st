#!/usr/bin/python
# -*- coding: utf-8 -*-

# --------------------------------------------------------------------------- #
#                                                                             #
#    iSida Jabber Bot  v 5x                                                   #
#    Copyright (C) Sief # sief@xmpp.ru                                 #
#                                                                             #
#                                                                             #
# --------------------------------------------------------------------------- #

def set_nickname(type, jid, nick, text):
	if get_affiliation(jid,nick) == 'owner' or get_level(jid,nick)[0] == 9:
		msg = None
		nickname = Settings['nickname']
		text = '%s/%s' % (jid, text or nickname)
		bot_join(type, jid, nick, text)
	else:
		msg = L('You can\'t do it!','%s/%s'%(jid,nick))
		send_msg(type, jid, nick, msg)

global execute

execute = [(9, 'setnick', set_nickname, 2, 'Change bot nick. Available only for conference owner.')]
