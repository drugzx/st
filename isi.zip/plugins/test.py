#!/usr/bin/python
# -*- coding: utf-8 -*-

# --------------------------------------------------------------------------- #
#                                                                             #
#    iSida Jabber Bot  v 5x                                                   #
#    Copyright (C) Sief # sief@xmpp.ru                                 #
#                                                                             #
#                                                                             #
# --------------------------------------------------------------------------- #

def test(type, jid, nick): send_msg(type, jid, nick, L('Passed!','%s/%s'%(jid,nick)))

global execute

execute = [(0, 'test', test, 1, 'Check bot activity.')]
