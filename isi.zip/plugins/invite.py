#!/usr/bin/python
# -*- coding: utf-8 -*-

# --------------------------------------------------------------------------- #
#                                                                             #
#    iSida Jabber Bot  v 5x                                                   #
#    Copyright (C) Sief # sief@xmpp.ru                                 #
#                                                                             #
#                                                                             #
# --------------------------------------------------------------------------- #


def call_body(type, jid, nick, text):
	skip = 1
	if len(text):
		try:
			reason = text.split('\n')[1]
			text = text.split('\n')[0]
		except: reason = None
		fnd = cur_execute_fetchall('select jid from age where room=%s and (nick=%s or jid=%s) group by jid',(jid,text,text))
		if len(fnd) == 1:
			whojid = getRoom(unicode(fnd[0][0]))
			is_found = 0
			for tmp in megabase:
				if tmp[0] == jid and getRoom(tmp[4]) == whojid:
					is_found = 1
					break
			if is_found: msg = L('%s ishere!','%s/%s'%(jid,nick)) % text
			else:
				msg = L('Invited','%s/%s'%(jid,nick))
				skip = 0
		elif len(fnd) > 1: msg = L('I seen some peoples with this nick. Get more info!','%s/%s'%(jid,nick))
		else: msg = L('I don\'n know %s','%s/%s'%(jid,nick)) % text
	else: msg = L('What?','%s/%s'%(jid,nick))

	if skip: send_msg(type, jid, nick, msg)
	else:
		inv_msg = L('%s invite you to %s','%s/%s'%(jid,nick)) % (nick, jid)
		if reason: inv_msg += ' ' + L('because: %s','%s/%s'%(jid,nick)) % reason
		send_msg('chat',whojid, '',inv_msg)

		inv = xmpp.Message(jid)
		inv.setTag('x', namespace=xmpp.NS_MUC_USER).addChild('invite', {'to':whojid})
		sender(inv)

		send_msg(type, jid, nick, msg)

global execute

execute = [(4, 'invite', call_body, 2, 'Invite to conference.\ninvite nick|jid\n[reason]')]
