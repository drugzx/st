#!/usr/bin/python
# -*- coding: utf-8 -*-

# --------------------------------------------------------------------------- #
#                                                                             #
#    iSida Jabber Bot  v 5x                                                   #
#    Copyright (C) Sief # sief@xmpp.ru                                 #
#                                                                             #
#                                                                             #
# --------------------------------------------------------------------------- #

def adminmail(type, jid, nick, text):
	if len(text):
		if len(text) > GT('amsg_limit_size'): text = text[:GT('amsg_limit_size')]+u'[…]'
		ga = get_level(jid, nick)
		fjid = getRoom(ga[1])
		tmp_lim = GT('amsg_limit')[ga[0]]
		am = cur_execute_fetchone('select time from saytoowner where jid=%s;',(fjid,))
		if am:
			wt = int(am[0]-time.time())
			if wt >= 0:
				send_msg(type, jid, nick, L('Time limit exceeded. Wait: %s','%s/%s'%(jid,nick)) % un_unix(wt,'%s/%s'%(jid,nick)))
				return None
			else: cur_execute('delete from saytoowner where jid=%s;',(fjid,))
		cur_execute('insert into saytoowner values (%s,%s)',(fjid,int(time.time())+tmp_lim))
		msg = L('User %s (%s) from %s at %s send massage to you: %s','%s/%s'%(jid,nick)) % (nick,fjid,jid,time.strftime("%H:%M %d.%m.%y", time.localtime (time.time())),text)
		own = cur_execute_fetchall('select * from bot_owner;')
		if own:
			for ajid in own: send_msg('chat', ajid[0], '', msg)
			send_msg(type, jid, nick, L('Sent','%s/%s'%(jid,nick)))
		else: send_msg(type, jid, nick, L('Owner list is empty!','%s/%s'%(jid,nick)))
	else: send_msg(type, jid, nick, L('What?','%s/%s'%(jid,nick)))

global execute

execute = [(4, 'msgtoadmin', adminmail, 2, 'Send message to bot\'s owner\nmsgtoadmin text')]
