#!/usr/bin/python
# -*- coding: utf-8 -*-

# --------------------------------------------------------------------------- #
#                                                                             #
#    iSida Jabber Bot  v 5x                                                   #
#    Copyright (C) Sief # sief@xmpp.ru                                 #
#                                                                             #
#                                                                             #
# --------------------------------------------------------------------------- #

def say(type, jid, nick, text):
	text = random.choice(re.split(r'(?<!\\)\|', text)).replace('\\|', '|')
	send_msg('groupchat', jid, '', to_censore(text,jid))

def psay(type, jid, nick, text):
	try:
		if '\n' in text: nnick,ntext = text.split('\n',1)
		else: nnick,ntext = text.split(' ',1)
		send_msg('chat', jid, nnick, to_censore(ntext,jid))
	except: send_msg(type, jid, nick, L('Error in parameters. Read the help about command.','%s/%s'%(jid,nick)))

def gsay(type, jid, nick, text):
	for jjid in [t[0] for t in cur_execute_fetchall('select room from conference;')]: send_msg('groupchat', getRoom(jjid), '', text)

def set_topic(type, jid, nick, text):
	sender(xmpp.Message(jid, subject=text, typ='groupchat'))

global execute

execute = [(6, 'say', say, 2, '"Say" command. Bot say in conference text after command. Example:\nsay text1[|text2[|text3[...]]]'),
	 (6, 'psay', psay, 2, '"Say" command. Bot say in private all text after command.\npsay <nick>\ntext'),
	 (9, 'gsay', gsay, 2, 'Global message in all conferences, where bot is present.')]
