# -*- coding: utf-8 -*-
"""
يرجى الانتباه اثناء ضبط الاعدادات

اي خطا في الاعداد يمكن ان يسبب لك عطل في عملية الفلترة
وانا غير مسؤل عن ذلك

1- ban = فصل
2- mute = منع اي تكرار لهذا الفلتر حسب الترافيك الموضوع يتم بعده الفصل
3- kick = طرد
4- off = ايقاف
5- replace = يتم تشفير الكلمة الممنوعة برمز ال ** والسماح بالكلمة الغير ممنوعة
6- visitor = تحويل الشخص الى صامت 

استعمل [yes او no] في بعض الاعدادات كما هو موضح تفعيل وعدم تفعيل

رحلة موفقة ;-)
"""



"""اعدادات الفلترة """
###################!!!  الفلاتر الجديدة  !!!################

Filter_chang_nick = "off"#kick off
Filter_chang_status = "off"#kick off
Filter_speed_chang_nick = "off"#kick off
Filter_speed_chang_status = "off"#kick off
#التحكم بتحليل نسخ الزوار لتفعيل امر فصل النسخ من خارج الروم
Filter_Os_Staert = "yes"#yes no
#فلتر النسخ الغير معروفة
NEW_BAD_OS = "no"#yes no

#@@@@@@

##الفلترة
#********* الكلمات التي سيتم منعها **********#
#الاعلان
ADB = ['http','www','conference','شرفونا','زورونا','حملو','jar','sis','.c']#*
#السياسة
MSG_BAD2 = ['حرية','عرعور','اسد','مؤيد','معارض','مندس']#*
#حجب كلمات في دردشة الخاص والعام
CENSORX = ['كس','اختك','اومك','اوختك','كوس','ايورة','اير','زبي','عرضك','شرفك','نايك','منايك','ضهري','شفافك','بزاز','شفرات','نائك','نأيك','نإيك','نآيك','ناىك','فاسخ','فأسخ','فإسخ','فآسخ','قوط','قؤط','قواط','زباب','ضهورا','شالخ','إم','آم','امك','ختك','ئم','ائمك','آمك','زئبي','زؤبي','دين','طائف','علوي','‌']#*
##حجب ريسورس متسلسل
RES_BAD = ['slaefr','zeocher','bombus']#* 
#حجب كلمات في الحالة#كلمات الاعلان في الحالة تؤخذ من ADB
Status_BAD = ['كس','عرصا','اير','منايك']#*   
#حجب كلمات في الاسم#كلمات الاعلان في الاسم تؤخذ من ADB
NICK_BAD = ['كس','اختك','اومك','اوختك','كوس','ايورة','اير','زبي','عرضك','شرفك','نايك','منايك','ضهري','شفافك','بزاز','شفرات','نائك','نأيك','نإيك','نآيك','ناىك','فاسخ','فأسخ','فإسخ','فآسخ','قوط','قؤط','قواط','زباب','ضهورا','شالخ','إم','آم','امك','ختك','ئم','ائمك','آمك','زئبي','زؤبي']#*  
#منع دخول كابس محدد
DABCAPS = ['boumbus']#* 
#حجب فيزا كارت
vCardBad = ["كس"]#*

#فلتر منع اي برنامج او بوت مكتوب بي لغة الروبي وبايثون
FILTER_Hack_BOT = "ban"# off ban

#فلتر الكتابة باحرف عربية وانكليزية فقط
FILTER_GOOD_LANG = "yes"#yes no

Arabic=['ا','ب','ت','ث','ج','ح','خ','د','ذ','ر','ز','س','ش','ص','ض','ط','ظ','ع','غ','ف','ق','ك','ل','م','ن','ه','و','ات','ي','آ','ة','أ','إ','ئ','ء','ؤ','ى',' ']
#*	
English =['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z','1','2','3','4','5','6','7','8','9','0']

#رموز يتم منعها في فلتر الاسماء
#وفي الرسائل في حال عدم تفعيل فلتر منع الكلمات الغير عربية واجنبية
#هذه الرموز تستعمل لفحص الكلمات اذا كانت تحوي احد هذه الرموز اثناء منع كلمة
rmoz=['1','2','3','4','5','6','7','8','9','0','.',' ','-','_','!','@','#','$','%','`','&','*',
      '(',')','+','=','}','{','<','>','[',']',':','"',"'",';','/',',','~','*','?','؟']

#سمايلات لتتخطى جميع الفلاتر لا تقلق لن يتم استعمالها في الشتائم ;-)
#مثل فلتر اللغة العربية او الرموز
Smail=[
'O:-)',':-)',':-(',';-)',':-P','8-)',':-D',':-[','=-O',':-*',":'(",
':-X','>:o',':-|',':-\\',
'*JOKINGLY*',']:->','[:-}','*KISSED*',':-!','*TIRED*','*STOP*','*KISSING*',
'@}->--','*THUMBS UP*','*DRINK*','*IN','LOVE*','@=','*HELP*','\m/','%)','*OK*',
'*WASSUP*','*SORRY*','*BRAVO*','*ROFL*','*PARDON*','*NO*','*CRAZY*','*DONT_KNOW*',
'*DANCE*','*YAHOO*','*HI*','*BYE*','*YES*',';D','*WALL*','*WRITE*','*SCRATCH*',
'*NEWS*','*WILD*','*SUPERMAN*','*SARCASM*','*NEGATIVE*','*SCARED*','*FACEPALM*',
'*TRAINING*','*PARTY*','*POPCORN*','*IREFUL*','*LOL*','*HAPPY*','*VAMPIRE*','*V*',
'*SPITEFUL*','*TEASE*','*HELLO*','*SCARE*','*THIS*','*PAINT*','*MEGA_SHOK*','*THANK*',
'*KING*','*LAZY*','*FRIEND*','*PUNISH*','*WIZARD*','*HAHA*','*IMPOSSIBLE*','*SIGH*','X-)',
'*SLOW*','*MOIL*','*BB*','*TENDER*','*SPRUSE_UP*','*FLIRT*','*GIVE_HEART*','*CURTSEY*',
'*FEMINIST*','*GIRL_DRINK*','*HUNTER*','*GIRL_CRY*','*GIRL_CRAZY*','*HOSPITAL*',
'*PINKGLASSES*','*HYSTERIC*','*HOHO*','*SHOUT*','*VAVA*','*CENSORED*','*SEARCH*',
'*FOCUS*','*YEEES!*','*SMOKE*','*BOSS*','*SARCASTIC*','*BOAST*','*GAMER*','*db*',
'*prison*','*GIRL','DRINK*','*PINGVIN*','*CAT*',':-&','X-)','*NIRVANA*','*SHOT*',
'*SCLEROSIS*','*TSSS*','*TORMOZ*','*king*','*gun','*MANIAC*','*MANIAC*','*cold*',
'vinsent*','*PLAYING*','*THANK*','*CALL*','*BRAVO*','*GIRL','SMOKE*','*BOUQUET*',
'*foot*','*DEER*','*wash*','*POKLON*','*HEAT*','(l)','*DISOBEDIENT*','*KU-KU*','*KU-KU*',
'*KARTI*','*SKULL*','*horror*','*ILL*','*TIME*','*RUSSIAN*','*TEASE*','*SEARCH*','*SEARCH*',
'*ADMIN*','*ZVEZDOCHET*','*HACKER*','*TOST*','(C)','*GIRL_IN_LOVE*','*BEACH*','*santa*',
'8-D',':dntknw:',';-|','<]','3-|{',':-#',':ermm:',':LICK:',':ZAWTOROJ:',':NIRVANA:','8-|',
':HM:',':apple ',':BEER ','(pl)','(exit)',':bl:',':IN LOVE:',':THUMBS DOWN:',':THUMBS UP:',
':SKULL:',':horror:',':COOL:',":-[]",':reads:',':-?','>:D','X-.',':hidden:',':baby:',
':sorry:',':nose:',':show:','*:-)',':oops:',':->',':-]','>:-(',':HAPPY:',':RTFM:',
':SMOKE:',':crazy:',':YES:',':-S',':BANNED:',':SECRET:',':-"',':BOTAN:',":can't see:",
':NINJA:',':help',':BRAVO:',':kicked:',':FIGA:',':VICTORY:',':STOP:','=:OO',':WALL:',
'>:P',':HI:',':JOKINGLY:','8(',':lol:',':-O',':help:']	  


#################    |التحكم بالفلاتر|     ###############
#الحد الاقصى لطول الحساب بدون اسم السيرفر
Max_Jid = 20
#1
'''        ### $[فلتر الاسماء]$ ###      '''
#طول الاسم
MAXNICK = 60

#اصغر حد للاسم
MINNICKZ = 3

#فلتر الاسم القصير 
FILTER_MINNICK = "mute"# off mute

#الاسم الطويل جدا فلود
MAXNICK_Flood = 100

#فلترالاسم الطويل جدا فلود
FILTER_MAXNICK_Flood = "ban"#ban off

#فلتر تكرار الاحرف في الأسم
FILTER_Nick_Rep = "replace"#ban mute replace off

#####فلتر الاعلان في الاسم
FILTER_Nick_AbD = "replace"#ban mute replace off 

#فلتر الاسم الفارغ
FILTER_NICK_None = "replace"#ban mute replace off

#فلتر الكلمات الممنوعة في الاسم
FILTER_NICK = "replace"#ban mute replace off 

#فلتر الاسم الطويل
FILTER_MAXNICK = "replace"#ban mute replace off

#2
'''        ### $[فلتر الحالة]$ ###      '''

#طول الحالة
MAXSTATUS = 200

#فلتر الحالة الطويلة جدا فلود
MAXSTATUS_Flood = 400

#فلتر الحالة الطويلة جدا الفلود
FILTER_MAX_Status_Flood = "ban"#ban off

#فلتر الكلمات الممنوعة في الحالة
FILTER_Status_MSG = "replace"#ban mute replace off 

#فلتر الاعلان في الحالة
FILTER_Status_AbD = "replace"#ban mute replace off 

#فلتر الحالة الطويلة
FILTER_MAX_Status = "replace"#ban mute replace off

#3
'''        ### $[فلتر الريسورس]$ ###      '''

#طول الريسورس
MAX_RES = 40

# طول الريسورس الذي يعتبر فلود
MAX_RES_flood = 50

#اصغر حد للريسورس
MIN_RESZ = 4

#فلتر الريسورس الطويل
FILTER_MAXRES = "mute"#ban mute off

#فلتر الريسورس القصير
FILTER_MINRES = "mute"#off mute

#فلتر الفلود في الريسورس 
FILTER_MAXRES_Flood  = "ban"#ban off

#4
'''        ### $[فلتر الدردشة]$ ###      '''

#عدد الاحرف الكبيرة للرسالة
MaXMsg = 300

#عدد احرف الرسالة التي تعتبر فلود
Flood = 500

#عدد الاسطر المنزلقة في الرسالة
SPACE = 5

#التحكم بسرعة الكتابة يفضل تركها على حالها
TimeMsG = 0.50

#فلتر تكرار الاحرف 
NEWMSG_REP = "mute"#ban mute kick replace visitor off 

#فلتر الكتابة بسرعة
FILTER_MSG_SPEED = "visitor"#ban mute kick visitor off

#فلتر الرسالة الفارغة
FILTER_MSG_NONE = "replace"#ban mute kick visitor replace off 

#فلتر الاسطر المنزلقة في الرسالة
FILTER_SPACE = "mute"#ban mute kick visitor replace off 

#فلتر الرسالة الكبيرة
FILTER_MaXMsG = "mute"#ban mute kick replace visitor off

#فلتر الفلود
FILTER_FLOOD = "replace"#ban mute kick replace visitor off

#فلتر الأعلان
FILTER_ADB = "replace"#ban mute kick replace visitor off

#فلتر السياسة
FILTER_ANswer = "replace"#ban mute kick replace visitor off 

#فلتر الكلمات الممنوعة
FILTER_CENSOR = "mute"#ban mute kick replace visitor off

#فلتر تكرار الرسالة
FILTER_MSG_REP = "mute"#ban mute kick visitor off
#الوقت الزمني للسماح بتكرار الرسالة
TimeReb = 15#ثانية

#فلتر خاص لفلود النسخة المخفية
FILTER_SPAM2  = "replace"#ban mute kick replace visitor off 
#الوقت الذي يسمح بتخطي هذا الفلتر
TimeMsG1 = 30#ثانية

#5
'''        ### $[فلتر تغيير الاسم والحالة والدخول والخروج بسرعة]$ ###      '''

#فلتر الدخول والخروج السريع         
FILTER_FASTJOIN = "mute"#mute ban off
#الفاصل الزمني للدخول والخروج
TIME_JOIN = 15#ثانية
#عدد مرات الدخول والخروج ثم الحجب
NEW_JOIN = 4#

#6
'''        ### $[فلتر الكابس]$ ###      '''
FILTER_Caps = "ban"#ban off
#7
'''        ### $[فلتر الاحرف الصينية]$ ###      '''
FILTER_China = "ban"#ban off
#8
'''        ### $[فلتر نسخ البومباس ونسخ الهكر والنسخ المخفية]$ ###      '''
FILTER_Bombas = "off"#mute off
#9
'''        ### $[التحقق من الفيزا كارت]$ ###      '''
Filter_vCard = "off"# ban off
#10
'''        ### $[فلتر خاص لبرنامج افالون الذي لا يتعرف عليه البوت]$ ###      '''
FILTER_Avalon = "mute"#mute off

##################

#الاعداد الذكي للفلاتر اي فلتر يتم تكراره بعد الترافيك المسموح يتم فصل الشخص
Traffic = 3
#اقصى حجم لكمية ارسال البيانات
Traffic1 = 10000#الخارجي
Traffic2 = 7000#الداخلي
#############
#تخطي الاحرف المكررة في الكلمة
AllowMsg = [
"الله",
"نشالله",
"انشالله",
"خخ",
"خخخ",
"خخخخ",
"خخخخخ",
"خخخخخخ",
"خخخخخخخ",
"خخخخخخخخ",
"خخخخخخخخخ",
"خخخخخخخخخخ",
"خخخخخخخخخخخ",
"خخخخخخخخخخخخ",
"هه",
"ههه",
"هههه",
"ههههه",
"هههههه",
"ههههههه",
"هههههههه",
"ههههههههه",
"هههههههههه",
"ههههههههههه",
"هههههههههههه",
"ههههههههههههه",
] 


'''ويمكنك ايضا التحكم الكامل في الفلاتر اثناء عمل البوت في الغرف وكل صاحب غرفة

   يتحكم في اي فلترة على حسب رغبته لمزيد من المعلومات راجع الامر 
   
   فلتر
'''



