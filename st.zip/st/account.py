# STRONG BOT V 1.1
# ♡ ḓαяṣн ♡ : darsh@syriatalk.org
# _◦̃»̃↨άł-ΰάέřόŝ↨«̃◦̃_ : ahmed@syriatalk.org
####################################

#حساب البوت كامل مع السيرفر
Bot_jid = strong.darsh2@syriatalk.org
#باسورد حساب البوت
Bot_pass = 098098a
