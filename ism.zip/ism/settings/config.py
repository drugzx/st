# -*- coding: utf-8 -*-

#-------------------------------------------------------#
#				 QUIZ Config File
#						v1.2
#                Edite By Programmer Sawim
#                Edite By Programmer Vortex
#                For Quiz BoT © 2020
#
#-------------------------------------------------------#


#-------------------------------------------------------#
Settings = {
'nickname': 			u'ιѕιđα-ν6',
'jid':				u'isida@syriamoon.org/ιѕιđα-ν6',
'password':			u'yazan-filt-moon-org',
'status':			u'online',
'priority':			0,
'message':			u'|BOT ISIDA V6|\n BY YAZAN\nуαzαη\nyazan@syriamoon.org\n'}

SuperAdmin		=	u'yazan@syriamoon.org'
defaultConf		=	u'فلتر@conference.syriamoon.org'
prefix			=	u''
msg_limit		=	700

#-------------------------------------------------------#
CommandsLog = False
debug_xmpppy = False
#----------------------- SQLite3 -----------------------#
base_type = 'sqlite3'

#-------------------------------------------------------#
#------------------        File's        ---------------#
tmp_folder = 'tmp/%s'
data_folder = 'data/%s'
set_folder 	= 'settings/%s'
sqlite_base = data_folder % 'sqlite3.db'
slog_folder = data_folder % 'log/%s'
back_folder = data_folder % 'backup/%s'
loc_folder 	= data_folder % 'locales/%s.txt'
log_folder 	= data_folder % 'conflogs/%s'
LOG_FILENAME = slog_folder % 'error.txt'
ver_file = tmp_folder % 'version'
cens = data_folder % 'censor.txt'
custom_cens = data_folder % 'custom_censor.txt'
public_log = log_folder % 'chatlogs/%s'
system_log = log_folder % 'syslogs/%s'
logs_css_path = '../../../.css/isida.css'
tld_list = data_folder % 'tldlist.txt'
poke_file = data_folder % 'poke.txt'
answers_file = tmp_folder % 'answers.txt'
date_file = data_folder % 'date.txt'
pastepath = data_folder % 'paste/'
pasteurl  = 'http://fill_it_before_use/paste/'
paste_css_path = '.css/isida.css'
default_msg_limit = msg_limit
smile_folder = '.smiles'
smile_descriptor = 'icondef.xml'
back_file = back_folder % '%s.back'
starttime_file = tmp_folder % 'starttime'

#-------------------------------------------------------#
adblock_regexp = [u'ااا',u'ببب',u'تتت',u'ثثث',u'ححح',u'خخخ',u'ددد',u'ذذذ',u'ررر',u'ززز',u'سسس',u'ششش',u'صصص',u'ضضض',u'ططط',u'ظظظ',u'ععع',u'غغغ',u'ككك',u'للل',u'ممم',u'ننن',u'ههه',u'ووو',u'ييي',u'إإإ',u'أأأ',u'ىىى',u'آآآ',u'ءءء',u'ؤؤؤ',u'ئئئ',u'ـــ']

#-------------------------------------------------------#
default_censor_set = 2 # no set of rules to censor. 1 - the whole word, 2 - except for the first letter
