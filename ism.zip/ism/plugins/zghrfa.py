﻿#!/usr/bin/python
# -*- coding: utf-8 -*-
# plugin zagharf
# programmer : sawim & vortex
# CopyRight 2021 © QuizBoT 
#========Quiz=============#

reload(sys).setdefaultencoding("utf-8")

#==========Start===========#

def tenda_tmded(type, jid, nick, text):
	text = random.choice(re.split(r'(?<!\\)\|', text)).replace('\\|', '|').replace('a','α').replace('b','в').replace('c','ç').replace('d','đ').replace('e','є').replace('f','ƒ').replace('g','g').replace('h','н').replace('i','ι').replace('j','נ').replace('k','к').replace('l','l̈̈').replace('m','м').replace('n','η').replace('o','σ').replace('p','ρ').replace('q','q').replace('r','я').replace('s','ѕ').replace('t','т').replace('u','υ').replace('v','ν').replace('w','ω').replace('x','χ').replace('y','у').replace('z','z').replace('ا','آ').replace('ب','بْ').replace('ت','تٌ').replace('ث','ثْ').replace('ج','جٍ').replace('ح','حٍـ').replace('خ','خـ').replace('د','دِ').replace('ذ','ڏ').replace('ر','ر').replace('ز','ڒٍ').replace('س','س').replace('ش','شُ').replace('ص','صٍ').replace('ض','ضٍ').replace('ط','ط').replace('ظ','ظّ').replace('ع','ع').replace('غ','غَ').replace('ف','فَ').replace('ق','قَ').replace('ك','گ').replace('ل','لُ').replace('م','م').replace('ن','نْ').replace('ه','ه').replace('و','ۆ').replace('ي','يَ').replace('ايري','').replace('قحبة','').replace('شرموطة','').replace('نايك','').replace('فاسخ','').replace('سكس','').replace('طيز','').replace('علوي','').replace('اختك','').replace('sawim','*مبرمج البوت*').replace('vortex','*مبرمج البوت*')
	send_msg(type, jid, nick, L('\nزخـرفـة الـكـلام\n\n\"%s\"\n'% text,jid))

global execute

execute = [(1, 'زخرف'.decode('utf8'), tenda_tmded, 2, 'زخرفة الحروف الاجنبية والعربية')]
