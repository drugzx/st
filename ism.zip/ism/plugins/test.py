﻿#!/usr/bin/python
# -*- coding: utf-8 -*-

# Edite By Programmer Sawim
# Edite By Programmer Vortex
# For Quiz BoT © 2020

reload(sys).setdefaultencoding("utf-8")

def test(type, jid, nick): send_msg(type, jid, nick, L('ιѕιđα вσţ V6 ;-)','%s/%s'%(jid,nick)))

global execute

execute = [(3, 'تست'.decode('utf8'), test, 1, 'لاختبار البوت')]
