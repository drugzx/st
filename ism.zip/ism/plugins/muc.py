#!/usr/bin/python
# -*- coding: utf-8 -*-

# Edite By Programmer Sawim
# Edite By Programmer Vortex
# For Quiz BoT © 2020

reload(sys).setdefaultencoding("utf-8")


visitors_list = {}
visitors_list_lock = False

# -------------- affiliation -----------------

def global_ban(type, jid, nick, text):
	text = text.lower()
	hroom = getRoom(jid)
	al = get_level(jid,nick)[0]
	if al == 9: af = 'owner'
	else: af = get_affiliation(jid,nick)
	if af != 'owner': msg = L('تحتاج الى ادمن بوت [:-}','%s/%s'%(jid,nick))
	elif text == 'show' and al == 9:
		ir = cur_execute_fetchone('select * from ignore_ban;')
		if len(ir): msg = '%s\n%s' % (L('Global ban is off in:','%s/%s'%(jid,nick)),'\n'.join([t[0] for t in ir]))
		else: msg = L('Global ban enable without limits!','%s/%s'%(jid,nick))
	elif text == 'del' and af == 'owner':
		if cur_execute_fetchone('select * from ignore_ban where room=%s' % (hroom,)): msg = L('Conference %s already deleted from global ban list!','%s/%s'%(jid,nick)) % hroom
		else:
			cur_execute('insert inro ignore_ban values (%s)' % (hroom,))
			msg = L('Conference %s has been deleted from global ban list!','%s/%s'%(jid,nick)) % hroom
	elif text == 'add' and af == 'owner':
		if cur_execute_fetchone('select * from ignore_ban where room=%s' % (hroom,)):
			cur_execute('delete from ignore_ban where room=%s' % (hroom,))
			msg = L('Conference %s has been added from global ban list!','%s/%s'%(jid,nick)) % hroom
		else: msg = L('Conference %s already exist in global ban list!','%s/%s'%(jid,nick)) % hroom
	else:
		if al == 9:
			if cur_execute_fetchone('select * from ignore_ban where room=%s' % (hroom,)): msg = L('Your conference will be ignored for global ban!','%s/%s'%(jid,nick))
			elif '@' not in text or '.' not in text: msg = L('اكتب الايميل الذي تريد فصله في كل الرومات الموجود فيها البوت','%s/%s'%(jid,nick))
			else:
				reason = L('banned global by %s from %s','%s/%s'%(jid,nick)) % (nick, jid)
				br = [t[0] for t in cur_execute_fetchall("select room from conference where split_part(room,'/',1) not in (select room from ignore_ban as igb);")]
				for tmp in br:
					i = xmpp.Node('iq', {'id': get_id(), 'type': 'set', 'to':getRoom(tmp)}, payload = [xmpp.Node('query', {'xmlns': xmpp.NS_MUC_ADMIN},[xmpp.Node('item',{'affiliation':'outcast', 'jid':unicode(text)},[xmpp.Node('reason',{},reason)])])])
					sender(i)
					time.sleep(0.1)
				msg = L('هذا الايميل %s تم فصله في الرومات %s ','%s/%s'%(jid,nick)) % (text, len(br))
		#else: msg = L('مـ ـقـ ـفـ ـل [:-}','%s/%s'%(jid,nick))
	send_msg(type, jid, nick, msg)

def muc_ban(type, jid, nick,text): muc_affiliation(type, jid, nick, text, 'outcast',0)
def muc_banjid(type, jid, nick,text): muc_affiliation(type, jid, nick, text, 'outcast',1)
def muc_none(type, jid, nick,text): muc_affiliation(type, jid, nick, text, 'none',0)
def muc_nonejid(type, jid, nick,text): muc_affiliation(type, jid, nick, text, 'none',1)
def muc_member(type, jid, nick,text): muc_affiliation(type, jid, nick, text, 'member',0)
def muc_memberjid(type, jid, nick,text): muc_affiliation(type, jid, nick, text, 'member',1)

def muc_affiliation(type, jid, nick, text, aff, is_jid):
	nowname = get_xnick(jid)
	xtype = get_xtype(jid)
	if xtype == 'owner':
		if is_start: return
		#else: send_msg(type, jid, nick, L('مـ ـقـ ـفـ ـل [:-}','%s/%s'%(jid,nick)))
	elif len(text):
		skip = None
		if '\n' in text: who, reason = text.split('\n',1)[0], text.split('\n',1)[1]
		else: who, reason = text, []
		if reason: reason = [xmpp.Node('reason',{},reason)]
		whojid = [unicode(get_level(jid,who)[1]),who][is_jid]
		if whojid != 'None': sender(xmpp.Node('iq', {'id': get_id(), 'type': 'set', 'to':jid}, payload = [xmpp.Node('query', {'xmlns': xmpp.NS_MUC_ADMIN},[xmpp.Node('item',{'affiliation':aff, 'jid':whojid},reason)])]))
#		else: send_msg(type, jid, nick, L('I don\'t know %s','%s/%s'%(jid,nick)) % who)
	else: send_msg(type, jid, nick, L('مـ ـن ؟','%s/%s'%(jid,nick)))

def muc_ban_past(type, jid, nick,text): muc_affiliation_past(type, jid, nick, text, 'outcast')
def muc_none_past(type, jid, nick,text): muc_affiliation_past(type, jid, nick, text, 'none')
def muc_member_past(type, jid, nick,text): muc_affiliation_past(type, jid, nick, text, 'member')

def muc_affiliation_past(type, jid, nick, text, aff):
	nowname = get_xnick(jid)
	xtype = get_xtype(jid)
	if xtype == 'owner':
		if is_start: return
		#else: msg, text = L('مـ ـقـ ـفـ ـل [:-}','%s/%s'%(jid,nick)), ''
	else: msg = L('مـ ـن ؟','%s/%s'%(jid,nick))
	if len(text):
		skip = None
		if '\n' in text: who, reason = text.split('\n',1)[0], text.split('\n',1)[1]
		else: who, reason = text, []
		if reason: reason = [xmpp.Node('reason',{},reason)]
		fnd = cur_execute_fetchall('select jid from age where room=%s and (nick=%s or jid=%s) group by jid',(jid,who,who))
		if len(fnd) == 1: msg, whojid = L('','%s/%s'%(jid,nick)), getRoom(unicode(fnd[0][0]))
		elif len(fnd) > 1:
			whojid = getRoom(get_level(jid,who)[1])
			if whojid != 'None': msg = L('تــ ــم *DANCE*','%s/%s'%(jid,nick))
			else: msg, skip = L('لديه أكثر من ايميل\nاكتب الايميل الذي تريده [:-}','%s/%s'%(jid,nick)), True
		else:
			msg = L('لا أعرف %s, لكن تـم *HI*','%s/%s'%(jid,nick)) % who
			whojid = who
	else: skip = True
	if skip: send_msg(type, jid, nick, msg)
	else:
		i = xmpp.Node('iq', {'id': get_id(), 'type': 'set', 'to':jid}, payload = [xmpp.Node('query', {'xmlns': xmpp.NS_MUC_ADMIN},[xmpp.Node('item',{'affiliation':aff, 'jid':unicode(whojid)},reason)])])
		sender(i)
		send_msg(type, jid, nick, msg)

def muc_kick(type, jid, nick, text): muc_role(type, jid, nick, text, 'none',1)
def muc_participant(type, jid, nick, text): muc_role(type, jid, nick, text, 'participant',1)
def muc_visitor(type, jid, nick, text): muc_role(type, jid, nick, text, 'visitor',1)
def muc_moderator(type, jid, nick, text): muc_role(type, jid, nick, text, 'moderator',1)

def muc_role(type, jid, nick, text, role, unused):
	nowname = get_xnick(jid)
	xtype = get_xtype(jid)
	if xtype == 'owner':
		if is_start: return
		#else: send_msg(type, jid, nick, L('مـ ـقـ ـفـ ـل [:-}','%s/%s'%(jid,nick)))
	elif len(text):
		skip = None
		if '\n' in text: who, reason = text.split('\n',1)[0], text.split('\n',1)[1]
		else: who, reason = text, []
		if reason: reason = [xmpp.Node('reason',{},reason)]
		whojid = unicode(get_level(jid,who)[1])
		if whojid != 'None': sender(xmpp.Node('iq', {'id': get_id(), 'type': 'set', 'to':jid}, payload = [xmpp.Node('query', {'xmlns': xmpp.NS_MUC_ADMIN},[xmpp.Node('item',{'role':role, 'nick':who},reason)])]))
		#else: send_msg(type, jid, nick, L('%s ليس هنا','%s/%s'%(jid,nick)) % who)
	else: send_msg(type, jid, nick, L('مـ ـن ؟','%s/%s'%(jid,nick)))

def check_unban():
	tt = int(time.time())
	ul = cur_execute_fetchall('select room,jid from tmp_ban where time<%s;',(tt,))
	if ul:
		for t in ul: sender(xmpp.Node('iq', {'id': get_id(), 'type': 'set', 'to':t[0]}, payload = [xmpp.Node('query', {'xmlns': xmpp.NS_MUC_ADMIN},[xmpp.Node('item',{'affiliation':'none', 'jid':getRoom(unicode(t[1]))},[])])]))
		cur_execute('delete from tmp_ban where time<%s;',(tt,))

def visitors_list_lock_wait():
	while visitors_list_lock: time.sleep(0.05)
	return True

def check_visitor():
	global visitors_list, visitors_list_lock
	visitors_list_lock = visitors_list_lock_wait()
	ITT = int(time.time())
	for t in visitors_list:
		room = t.split('/')[0]
		VISITOR_ACT = get_config(getRoom(room),'visitor_action')
		if VISITOR_ACT != 'off' and ITT > visitors_list[t]:
			reason = [xmpp.Node('reason',{},L('Too long was without voice!',t))]
			if VISITOR_ACT == 'kick': sender(xmpp.Node('iq', {'id': get_id(), 'type': 'set', 'to':room}, payload = [xmpp.Node('query', {'xmlns': xmpp.NS_MUC_ADMIN},[xmpp.Node('item',{'role':'none', 'nick':t.split('/',1)[1]},reason)])]))
			else: sender(xmpp.Node('iq', {'id': get_id(), 'type': 'set', 'to':room}, payload = [xmpp.Node('query', {'xmlns': xmpp.NS_MUC_ADMIN},[xmpp.Node('item',{'affiliation':'outcast', 'jid':get_jid_by_nick(t.split('/',1))},reason)])]))
	visitors_list_lock = False

def visitor_presence(room,jid,nick,type,mass):
	global visitors_list, visitors_list_lock
	if getRoom(jid) == getRoom(Settings['jid']): return
	if type == 'error': return
	elif type == 'unavailable':
		visitors_list_lock = visitors_list_lock_wait()
		try: visitors_list.pop('%s/%s' % (room,nick))
		except: pass
		visitors_list_lock = False
	if mass[1] == 'visitor':
		visitors_list_lock = visitors_list_lock_wait()
#		visitors_list['%s/%s' % (room,nick)] = int(time.time()) + get_config_int(getRoom(room),'visitor_action_time')	
		visitors_list_lock = False

global execute, timer, presence_control

timer = [check_unban,check_visitor]
presence_control = [visitor_presence]

execute = [(7, 'فصل'.decode('utf8'), muc_ban_past, 2, '2Ban user'),
	   (7, 'ban', muc_ban_past, 2, '3Ban user'),
	   (7, 'مشترك'.decode('utf8'), muc_none_past, 2, 'Remove user affiliation'),
	   (7, 'فك-فصل'.decode('utf8'), muc_none_past, 2, 'Remove user affiliation'),
	   (7, 'member', muc_member_past, 2, '2Get member affiliation.'),
	   (7, 'عضو'.decode('utf8'), muc_member_past, 2, '3Get member affiliation'),
	   (7, 'طرد'.decode('utf8'), muc_kick, 2, 'Kick user'),
	   (7, 'kick', muc_kick, 2, 'Kick 2user'),
	   (7, 'مشارك'.decode('utf8'), muc_participant, 2, 'Change role to participant'),
	   (7, 'زائر'.decode('utf8'), muc_visitor, 2, 'Revoke voice'),
	   (7, 'visitor', muc_visitor, 2, 'Revokke voice'),
	   (8, 'مدير'.decode('utf8'), muc_moderator, 2, 'Grant moderator'),
	   (9, 'فصل-كلي'.decode('utf8'), global_ban, 2, 'Global ban. Available only for confernce owner.\nglobal_ban del - remove conference from banlist,\nglobal_ban add - add conference into banlist,\nglobal_ban <jid> - ban jid in all rooms, where bot is admin.')]
