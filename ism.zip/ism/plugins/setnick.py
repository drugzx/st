#!/usr/bin/python
# -*- coding: utf-8 -*-

# --------------------------------------------------------------------------- #
# Edite By Programmer Sawim
# Edite By Programmer Vortex
# For Quiz BoT © 2020                                                                          #
# --------------------------------------------------------------------------- #

def set_nickname(type, jid, nick, text):
	if get_affiliation(jid,nick) == 'owner' or get_level(jid,nick)[0] == 9:
		msg = None
		nickname = Settings['nickname']
		text = '%s/%s' % (jid, text or nickname)
		bot_join(type, jid, nick, text)
	else:
		msg = L('You can\'t do it!','%s/%s'%(jid,nick))
		send_msg(type, jid, nick, msg)

global execute

execute = [(8, 'لقب-البوت'.decode('utf8'), set_nickname, 2, 'Change bot nick. Available only for conference owner.')]
