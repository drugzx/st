#!/usr/bin/python
# -*- coding: utf-8 -*-
# Bot SmartFilter For Chat-Sy Edit By Sawim
reload(sys).setdefaultencoding("utf-8")


AGE_DEFAULT_LIMIT = 10
AGE_MAX_LIMIT = 100
TIME_OF_LOGGING_JOINS = 10



def seenjid_split(type, jid, nick, text):
	seenjid_raw(type, jid, nick, text, True)

def seenjid_raw(type, jid, nick, text, xtype):
	text = text.rstrip().split('\n')
	llim = GT('age_default_limit')
	if len(text)>1:
		try: llim = int(text[1])
		except: llim = GT('age_default_limit')
	text = text[0]
	ztype = None
	if not text: text = nick
	if llim > GT('age_max_limit'): llim = GT('age_max_limit')
	real_jid = cur_execute_fetchall('select jid from age where room=%s and (nick ilike %s or jid ilike %s) group by jid,status,time order by status,-time',(jid,text,text.lower()))
	if not real_jid:
		txt = '%%%s%%' % text.lower()
		real_jid = cur_execute_fetchall('select jid from age where room=%s and (no_case_nick ilike %s or jid ilike %s) group by jid,status,time order by status,-time',(jid,txt,txt))
	sbody = []
	if real_jid:
		for rj in real_jid:
			if xtype: tmpbody = cur_execute_fetchall('select * from age where room=%s and jid=%s order by status, jid limit %s',(jid,rj[0],llim))
			else: tmpbody = [cur_execute_fetchone('select * from age where room=%s and jid=%s order by status',(jid,rj[0]))]
			if tmpbody:
				for t in tmpbody:
					if t not in sbody: sbody.append(t)
	if sbody:
		ztype = True
		msg = L('[%s]','%s/%s'%(jid,nick)) % text
		for cnt, tmp in enumerate(sbody):
			msg += '\n\n##[%s]##\n\n##[اللقب]##\n\n %s \n\n##[الحساب]##\n\n %s \n' % (cnt + 1, tmp[1], tmp[2])
			if tmp[5]:
				if tmp[6]: msg += '\t' + L('##[وقت الخروج]##\n%s %s ','%s/%s'%(jid,nick)) % (tmp[6], un_unix(int(time.time() - tmp[3]),'%s/%s'%(jid,nick)))
				else: msg += '\t' + L('##[وقت الخروج]##\n\n %s \n','%s/%s'%(jid,nick)) % un_unix(int(time.time() - tmp[3]),'%s/%s'%(jid,nick))
				t7sp = tmp[7].split('\r')[0]
				if t7sp.count('\n') > 3:
					stat = t7sp.split('\n', 4)[4]
					if stat: msg += '\n##[رسالة الخروج]##\n %s \n\n' % stat
				elif t7sp: msg += ' (%s)' % t7sp
				if '\r' in tmp[7]: msg += ', %s %s' % (L('','%s/%s'%(jid,nick)), tmp[7].split('\r')[-1])
			else: msg += '\t' + L('##[وقت الدخول]##\n\n %s \n','%s/%s'%(jid,nick)) % un_unix(int(time.time() - tmp[3]),'%s/%s'%(jid,nick))
			if not xtype: msg = msg.replace('\t', ' - ')
	else: msg = L('لا أعرفه [:-}','%s/%s'%(jid,nick))
	if type == 'groupchat' and ztype:
		send_msg(type, jid, nick, L('عليك في الخاص','%s/%s'%(jid,nick)))
		send_msg('chat', jid, nick, msg)
	else: send_msg(type, jid, nick, msg)

global execute

execute = [(7, 'تفاصيل'.decode('utf8'), seenjid_split, 2, 'معرف تفاصيل حساب'),
	 (7, 'فيش'.decode('utf8'), seenjid_split, 2, 'معرفة تفاصيل حساب')]
