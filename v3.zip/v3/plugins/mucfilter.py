#!/usr/bin/env python
# -*- coding: utf-8 -*-
reload(sys).setdefaultencoding("utf-8")
from pyarabic.araby import *
muc_filter_fast_join = {}
muc_filter_last_notify = 0
muc_filter_events = []
filterd="filter"
changd="chang"
def muc_pprint(*param):
	global muc_filter_events,muc_filter_last_notify
	pprint(*param)
	if GT('muc_filter_notify'):
		_notify_count = GT('muc_filter_notify_count')
		muc_filter_events = [time.time()] + muc_filter_events[:_notify_count-1]		
		if len(muc_filter_events) == _notify_count \
				and muc_filter_events[0] - muc_filter_events[-1] < GT('muc_filter_notify_peroid') \
				and muc_filter_last_notify + GT('muc_filter_notify_wait') < time.time():
			pprint('*** MUC-Filter notify event!')
			muc_filter_last_notify = time.time()
			muc_filter_events = []
			_jids = GT('muc_filter_notify_jids').split()
			for t in _jids:
				if t.strip(): send_msg('chat', t.strip(), '', 'MUC-Filter notify event!')
def muc_filter_set(iq,id,room,acclvl,query,towh,al):
	global changd, filterd ,idark
	msg_xmpp = iq
	if msg_xmpp:
		msg,mute,mute_type,mute_room = get_tag(unicode(msg_xmpp),'query'),None,'groupchat',room
		jid = rss_replace(get_tag_item(msg,'message','from'))
		nick = rss_replace(unicode(get_nick_by_jid_res(room,jid)))
		rn = '%s/%s' % (room,nick)
		mute_reason = L('محجوب !!-)',rn)
		if msg[:2] == '<m':
		  
			if '<body>' in msg and '</body>' in msg:
				to_nick = getResourse(get_tag_item(msg,'message','to'))
				tojid = rss_replace(getRoom(get_level(room,to_nick)[1]))
				skip_owner = is_owner(jid)
				gr = getRoom(room)
				type = get_tag_item(msg,'message','type')
				to_user='%s/%s' % (gr,to_nick)
				xmldark="""<message to="%s" type="chat"><body>هذا الشخص %s\nيريد التحدث معك خاص للموافقة اكتب نعم</body></message>""" % (to_user,nick)
				res_msg=jid.split('/',1)[1]
				t_msg=jid.split('@')[0]
				if skip_owner: pass
				elif get_config(gr,'التشغيل') and not mute:
					act = get_config(gr,u'تمديد')
					if act == u'تفعيل':
					  body = strip_tashkeel(strip_tatweel(get_tag(msg,'body')))
					else:
					  body = get_tag(msg,'body')

					############### رسايل خاص
					if len(unicode(msg)) > 3500:
					  mute,mute_reason = True,L('كول خرا',rn)
					  msg=muc_filter_action(u'فصل',jid,room,L('فلتر xmlns علزبالة',rn))
					
					if not mute and msg and type == 'chat' and get_config(gr,u'رسائل-الخاص'):
						
						try: cnt = mute_msg['%s|%s' % (gr,jid)]
						except: cnt = 1
						act = get_config(gr,u'رسائل-الخاص')
						if act == u'تفعيل':
							mute,mute_type,mute_room,mute_reason = True,'chat', '%s/%s' % (room,to_nick),L('رسائل الخاص ممنوعة',rn)
							

				 
					######if '<body>' in msg and '</body>' in msg:###
					if not mute and msg and type == 'groupchat' and get_config(gr,u'رسائل-العام'):
			
						try: cnt = mute_msg['%s|%s' % (gr,jid)]
						except: cnt = 1
						act = get_config(gr,u'رسائل-العام')
						if act =='تفعيل':
						  mute,mute_reason = True,L('رسائل العام ممنوعة',rn)
						#############
					
					if unicode(msg).count('error') or unicode(msg).count('stream'):
					  mute,mute_type,mute_room,mute_reason = True,type, '%s/%s' % (room,to_nick),L('وجه السحارة حضرتك?!!',rn)
					  msg=muc_filter_action(u'فصل',jid,room,L('فلتر  xmlns  علزبالة',rn))
					  
					act = get_config(gr,u'اكواد-الرسائل')
					if act == u'تفعيل':
					  if type=='groupchat':
					    dark="""<message from="%s" to="%s" type="groupchat" id="SmARt_Bot"><body>%s</body></message>""" % (jid,room,body)
					    msg=msg.replace(msg,'%s' %(dark))
					  elif type=='chat':
					    darkk="""<message from="%s" to="%s" type="chat" id="SmARt_Bot"><body>%s</body></message>""" % (jid,to_user,body)
					    msg=msg.replace(msg,'%s' %(darkk))
					  else:
					    mute,mute_type,mute_room,mute_reason = True,'chat', '%s/%s' % (room,to_nick),L('وجه السحارة حضرتك?!!',rn)
					
					##############
					if type == 'chat':
					  tmp = cur_execute_fetchall('select * from muc_lock where room=%s and jid=%s', (room,tojid))
					  if tmp:
					    mute,mute_type,mute_room,mute_reason = True,'chat', '%s/%s' % (room,to_nick),L('هذا الشخص مسكر الخاص لا ترسل له اكثر من ثلاثة رسائل والا ستتعرض للطرد في حال بقي مسكر الخاص !!',rn)
					    #sender(xmpp.simplexml.XML2Node(unicode(xmldark).encode('utf8')))
					    ttojid = '%s|%s' % (getRoom(tojid),getRoom(jid))
					    try:
					      muc_rejoins[ttojid] = [muc_rejoins[ttojid],muc_rejoins[ttojid][1:]][len(muc_rejoins[ttojid])==GT('muc_filter_rejoin_count')] + [int(time.time())]
					    except:
					      muc_rejoins[ttojid] = []
					    if len(muc_rejoins[ttojid]) == GT('muc_filter_rejoin_count'):
					      tmo = muc_rejoins[ttojid][GT('muc_filter_rejoin_count')-1] - muc_rejoins[ttojid][0]
					      if tmo < 60:
					        sender(xmpp.simplexml.XML2Node(unicode(xmldark).encode('utf8')))
					        msg=muc_filter_action(u'طرد',jid,room,L('تم تحذيرك مسبقا يمنع ارسال رسائل لشخص مسكر الخاص!!',rn))
					###############
					if body.count('\n') >= 5:
					  body = body.replace('\n',' ')
					  #tt=jid.split('@',1)[:1]
					  msg = msg.replace(get_tag_full(msg,'body'),'<body>%s</body>' %(body))

					################
					need_raw = True
					if not mute and msg and get_config(gr,u'الاعلان') != u'تعطيل':
						f = []
						for reg in adblock_regexp:
							tmp = re.findall(reg,body,re.S|re.I|re.U)
							if tmp: f = f + tmp
						if f:
							act = get_config(gr,u'الاعلان')
							need_raw = False
							muc_pprint('MUC-Filter msg adblock (%s): %s [%s] %s' % (act,jid,room,body),'brown')
							if act == u'تغيير':
								for tmp in f: body = body.replace(tmp,[GT('censor_text')*len(tmp),GT('censor_text')][len(GT('censor_text'))>1])
								msg = msg.replace(get_tag_full(msg,'body'),'<body>%s</body>' % body)
							elif act == u'حجب': mute,mute_type,mute_room,mute_reason = True,type, '%s/%s' % (room,to_nick),L('االأعلان ممنوع !',rn)
							else: msg = muc_filter_action(act,jid,room,L('الاعلان ممنوع  !!',rn))

					################
					if not mute and msg and need_raw and get_config(gr,u'الاعلان') != u'تعطيل':
						rawbody = match_for_raw(body,u'[a-zа-я0-9@.]*',gr)
						if rawbody:
							f = []
							for reg in adblock_regexp:
								tmp = re.findall(reg,rawbody,re.S|re.I|re.U)
								if tmp: f = f + tmp
							if f:
								act = get_config(gr,u'الاعلان')
								muc_pprint('MUC-Filter msg raw adblock (%s): %s [%s] %s' % (act,jid,room,body),'brown')
								if act == u'حجب': mute,mute_type,mute_room,mute_reason = True,type, '%s/%s' % (room,to_nick),L('الأعلان ممنوع !',rn)
								else: msg = muc_filter_action(act,jid,room,L('الاعلان ممنوع  !!',rn))

					################
					if not mute and msg and get_config(gr,u'تكرار-رسائل') != u'تعطيل':
						grj = getRoom(jid)
						try: lm = last_msg_base[grj]
						except: lm = None
						if lm:
							rep_to = 5
							try: lmt = last_msg_time_base[grj]
							except: lmt = 0
							if rep_to+lmt > time.time():
								action = False
								if body == lm: action = True
								elif lm in body:
									try: muc_repeat[grj] += 1
									except: muc_repeat[grj] = 1
									if muc_repeat[grj] >= 5: action = True
								else: muc_repeat[grj] = 0
								if action:
									act = get_config(gr,u'تكرار-الرسائل')
									muc_pprint('MUC-Filter msg repeat (%s): %s [%s] %s' % (act,jid,room,body),'brown')
									if act == u'حجب': mute,mute_type,mute_room,mute_reason = True,type, '%s/%s' % (room,to_nick),L('تكرار الرسالة ممنوع !',rn)
									elif act==u'تعطيل':
									  msg=msg
									else: msg = muc_filter_action(act,jid,room,L('!! تكرار الرسائل ممنوع',rn))
							else: muc_repeat[grj] = 0
						last_msg_base[grj] = body
						last_msg_time_base[grj] = time.time()

					#filter msg dark
					#########chang msg klma########
					t_k_=cur_execute_fetchall('select * from t_k where jid=%s',(room,))
					if not t_k_:
					  msg=msg
					else:
					  for x in t_k_:
					    if t_k_ and body.count('%s' %(x[1])):
					      msg=msg.replace(get_tag_full(msg,'body'),'<body>%s</body>' %(x[2]))	
					      ttojid = '%s|%s' % (getRoom(tojid),getRoom(jid))
					      try:
					        muc_rejoins[ttojid] = [muc_rejoins[ttojid],muc_rejoins[ttojid][1:]][len(muc_rejoins[ttojid])==GT('muc_filter_rejoin_count')] + [int(time.time())]
					      except:
					        muc_rejoins[ttojid] = []
					      if len(muc_rejoins[ttojid]) == GT('muc_filter_rejoin_count'):
					        tmo = muc_rejoins[ttojid][GT('muc_filter_rejoin_count')-1] - muc_rejoins[ttojid][0]
					        if tmo < 60:
					        #sender(xmpp.simplexml.XML2Node(unicode(xmldark).encode('utf8')))
					          msg=muc_filter_action(u'طرد',jid,room,L('لا تكرر رسائل ايه المعتوه  ¡¡',rn))
					#########chang msg jid########
					t_jid_=cur_execute_fetchall('select * from t_jid where jid=%s',(room,))
					if not t_jid_:
					  msg=msg
					else:
					  for x in t_jid_:
					    if jid.count('%s' %(x[1])):
					      msg=msg.replace(get_tag_full(msg,'body'),'<body>%s</body>' %(x[2]))
					      ttojid = '%s|%s' % (getRoom(tojid),getRoom(jid))
					      try:
					        muc_rejoins[ttojid] = [muc_rejoins[ttojid],muc_rejoins[ttojid][1:]][len(muc_rejoins[ttojid])==GT('muc_filter_rejoin_count')] + [int(time.time())]
					      except:
					        muc_rejoins[ttojid] = []
					      if len(muc_rejoins[ttojid]) == GT('muc_filter_rejoin_count'):
					        tmo = muc_rejoins[ttojid][GT('muc_filter_rejoin_count')-1] - muc_rejoins[ttojid][0]
					        if tmo < 60:
					        #sender(xmpp.simplexml.XML2Node(unicode(xmldark).encode('utf8')))
					          msg=muc_filter_action(u'طرد',jid,room,L('لا تكرر رسائل ايه المعتوه  ¡¡',rn))
					      
					######chang msg res########      
					t_res_=cur_execute_fetchall('select * from t_res where jid=%s',(room,))
					ress=jid.split('/',1)[1]
					if not t_res_:
					  msg=msg
					else:
					  for x in t_res_:
					    if ress.count('%s' %(x[1])):
					      msg=msg.replace(get_tag_full(msg,'body'),'<body>%s</body>' %(x[2]))	
					      ttojid = '%s|%s' % (getRoom(tojid),getRoom(jid))
					      try:
					        muc_rejoins[ttojid] = [muc_rejoins[ttojid],muc_rejoins[ttojid][1:]][len(muc_rejoins[ttojid])==GT('muc_filter_rejoin_count')] + [int(time.time())]
					      except:
					        muc_rejoins[ttojid] = []
					      if len(muc_rejoins[ttojid]) == GT('muc_filter_rejoin_count'):
					        tmo = muc_rejoins[ttojid][GT('muc_filter_rejoin_count')-1] - muc_rejoins[ttojid][0]
					        if tmo < 60:
					        #sender(xmpp.simplexml.XML2Node(unicode(xmldark).encode('utf8')))
					          msg=muc_filter_action(u'طرد',jid,room,L('لا تكرر رسائل ايه المعتوه  ¡¡',rn))		
					#######تسلسل#####
					t_t_=cur_execute_fetchall('select * from t_t where jid=%s',(room,))
					tsl=jid.split('@')[0]
					if not t_t_:
					  msg=msg
					else:
					  for x in t_t_:
					    if tsl.count('%s' %(x[1])):
					      msg=msg.replace(get_tag_full(msg,'body'),'<body>%s</body>' %(x[2]))	
					      ttojid = '%s|%s' % (getRoom(tojid),getRoom(jid))
					      try:
					        muc_rejoins[ttojid] = [muc_rejoins[ttojid],muc_rejoins[ttojid][1:]][len(muc_rejoins[ttojid])==GT('muc_filter_rejoin_count')] + [int(time.time())]
					      except:
					        muc_rejoins[ttojid] = []
					      if len(muc_rejoins[ttojid]) == GT('muc_filter_rejoin_count'):
					        tmo = muc_rejoins[ttojid][GT('muc_filter_rejoin_count')-1] - muc_rejoins[ttojid][0]
					        if tmo < 60:
					        #sender(xmpp.simplexml.XML2Node(unicode(xmldark).encode('utf8')))
					          msg=muc_filter_action(u'طرد',jid,room,L('لا تكرر رسائل ايه المعتوه  ¡¡',rn))
					
					
					
					#########
					f_t_=cur_execute_fetchall('select * from f_t where jid=%s',(room,))
					if not f_t_:
					  msg=msg
					else:
					  for x in f_t_:
					    if t_msg.count('%s' %(x[1])):
					      mute,mute_type,mute_room,mute_reason = True,type, '%s/%s' % (room,to_nick),L('%s' %(x[2]),rn)
					      ttojid = '%s|%s' % (getRoom(tojid),getRoom(jid))
					      try:
					        muc_rejoins[ttojid] = [muc_rejoins[ttojid],muc_rejoins[ttojid][1:]][len(muc_rejoins[ttojid])==GT('muc_filter_rejoin_count')] + [int(time.time())]
					      except:
					        muc_rejoins[ttojid] = []
					      if len(muc_rejoins[ttojid]) == GT('muc_filter_rejoin_count'):
					        tmo = muc_rejoins[ttojid][GT('muc_filter_rejoin_count')-1] - muc_rejoins[ttojid][0]
					        if tmo < 60:
					        #sender(xmpp.simplexml.XML2Node(unicode(xmldark).encode('utf8')))
					          msg=muc_filter_action(u'طرد',jid,room,L('لا تكرر رسائل انت في وضع الفلترة  ¡¡',rn))

					###########
					f_res_=cur_execute_fetchall('select * from f_res where jid=%s',(room,))
					if not f_res_:
					  msg=msg
					else:
					  for x in f_res_:
					    if res_msg.count('%s' %(x[1])):
					      mute,mute_type,mute_room,mute_reason = True,type, '%s/%s' % (room,to_nick),L('%s' %(x[2]),rn)
					      ttojid = '%s|%s' % (getRoom(tojid),getRoom(jid))
					      try:
					        muc_rejoins[ttojid] = [muc_rejoins[ttojid],muc_rejoins[ttojid][1:]][len(muc_rejoins[ttojid])==GT('muc_filter_rejoin_count')] + [int(time.time())]
					      except:
					        muc_rejoins[ttojid] = []
					      if len(muc_rejoins[ttojid]) == GT('muc_filter_rejoin_count'):
					        tmo = muc_rejoins[ttojid][GT('muc_filter_rejoin_count')-1] - muc_rejoins[ttojid][0]
					        if tmo < 60:
					        #sender(xmpp.simplexml.XML2Node(unicode(xmldark).encode('utf8')))
					          msg=muc_filter_action(u'طرد',jid,room,L('لا تكرر رسائل انت في وضع الفلترة  ¡¡',rn))
					
					######################
					f_jid_=cur_execute_fetchall('select * from f_jid where jid=%s',(room,))
					if not f_jid_:
					  msg=msg
					else:
					  for x in f_jid_:
					    if jid.count('%s' %(x[1])):
					      mute,mute_type,mute_room,mute_reason = True,type, '%s/%s' % (room,to_nick),L('%s' %(x[2]),rn)
					      ttojid = '%s|%s' % (getRoom(tojid),getRoom(jid))
					      try:
					        muc_rejoins[ttojid] = [muc_rejoins[ttojid],muc_rejoins[ttojid][1:]][len(muc_rejoins[ttojid])==GT('muc_filter_rejoin_count')] + [int(time.time())]
					      except:
					        muc_rejoins[ttojid] = []
					      if len(muc_rejoins[ttojid]) == GT('muc_filter_rejoin_count'):
					        tmo = muc_rejoins[ttojid][GT('muc_filter_rejoin_count')-1] - muc_rejoins[ttojid][0]
					        if tmo < 60:
					        #sender(xmpp.simplexml.XML2Node(unicode(xmldark).encode('utf8')))
					          msg=muc_filter_action(u'طرد',jid,room,L('لا تكرر رسائل انت في وضع الفلترة  ¡¡',rn))
					########block msg##########				
					block_msg=cur_execute_fetchall('select * from b_msm where jid=%s',(room,))
					if not block_msg:
					  msg=msg
					else:
					  for x in block_msg:
					    if body.count('%s' %(x[1])):
					      mute,mute_type,mute_room,mute_reason = True,type, '%s/%s' % (room,to_nick),L('رسالة محجوبة !!',rn)
					##########block msg jid########
					if not mute and msg and get_config(gr,'muc_filter_censor') != u'تعطيل' and esc_min2(body) != to_censore(esc_min2(body),gr):
						act = get_config(gr,u'مسبات')
						need_raw = False
						muc_pprint('MUC-Filter msg censor (%s): %s [%s] %s' % (act,jid,room,body),'brown')
						if act == u'تغيير': msg = msg.replace(get_tag_full(msg,'body'),'<body>%s</body>' % esc_max2(to_censore(esc_min2(body),gr)))
						elif act == u'حجب': mute,mute_type,mute_room,mute_reason = True,type, '%s/%s' % (room,to_nick),L('كلمات محجوبة !',rn)
						elif act =='تعطيل':
						  msg=msg
						else: msg = muc_filter_action(act,jid,room,L(':-)رسالة محجوبة',rn))

					################
					if not mute and msg and need_raw and get_config(gr,'muc_filter_censor_raw') != 'off':
						rawbody = match_for_raw(body,u'[a-zа-я0-9]*',gr)
						if rawbody and rawbody != to_censore(rawbody,gr):
							act = get_config(gr,'muc_filter_censor_raw')
							muc_pprint('MUC-Filter msg raw censor (%s): %s [%s] %s' % (act,jid,room,body),'brown')
							if act == 'mute': mute,mute_type,mute_room,mute_reason = True,type, '%s/%s' % (room,to_nick),L('رسالة محجوبة !!',rn)
							else: mute,mute_type,mute_room,mute_reason = True,type, '%s/%s' % (room,to_nick),L('رسالة محجوبة !!',rn)

					################
					if not mute and msg and get_config(gr,'muc_filter_large') != 'off' and len(body) > 350:
						act = get_config(gr,u'فلود')
						
						if act == u'تغيير':
							
							if act == 'تغيير': body = u'انا ارسل فلود ولكن قام بتغييره !!'

							
							msg = msg.replace(get_tag_full(msg,'body'),'<body>%s</body>' % body)
						elif act == u'حجب': mute,mute_type,mute_room,mute_reason = True,type, '%s/%s' % (room,to_nick),L('الرسالة الكبيرة ممنوعة !!',rn)
						else: msg = muc_filter_action(act,jid,room,L('الرسالة الكبيرة ممنوعة !!',rn))

				if mute: msg = unicode(xmpp.Message(to=jid,body=mute_reason,typ=mute_type,frm=mute_room))
			else: msg ==None
		elif msg[:2] == '<p':
			jid = rss_replace(get_tag_item(msg,'presence','from'))
			gr = getRoom(room)
			if server_hash_list.has_key('%s/%s' % (gr,getServer(jid))) or server_hash_list.has_key('%s/%s' % (gr,getRoom(jid))):
				muc_pprint('MUC-Filter drop by previous ban: %s %s' % (room,jid),'brown')
				return True
			
			ress=jid.split('/',1)[1]
			t_jid=jid.split('@')[0]
			tojid = rss_replace(get_tag_item(msg,'presence','to'))
			if is_owner(jid): pass
			elif get_config(gr,'التشغيل') and not mute:
				show = ['online',get_tag(msg,'show')][int('<show>' in msg and '</show>' in msg)]
				if show not in ['chat','online','away','xa','dnd']: msg = msg.replace(get_tag_full(msg,'show'), '<show>online</show>')
				status = ['',get_tag(msg,'status')][int('<status>' in msg and '</status>' in msg)]
				nick = ['',tojid[tojid.find('/')+1:]]['/' in tojid]
				darko="""<iq to="%s" tepy="get" id="dark"><query xmlns="jabber:iq:versoin"></query></iq>""" %(jid)
				lidark="""<&>"'"""
				dark="""<presence from="%s" to="%s" ver="iSiDa BoT" xml:lang="SMA®T"><show>online</show><status></status><c xmlns="http://jabber.org/protocol/caps" node="http://online.yandex.ru/caps"/></presence>""" % (jid,esc_max2(tojid))

				for y in ress:
				  if y in lidark:
				    msg,mute = unicode(xmpp.Node('presence', {'from': tojid, 'type': 'error', 'to':jid}, payload = ['replace_it',xmpp.Node('error', {'type': 'auth','code':'403'}, payload=[xmpp.Node('forbidden',{'xmlns':'urn:ietf:params:xml:ns:xmpp-stanzas'},[]),xmpp.Node('text',{'xmlns':'urn:ietf:params:xml:ns:xmpp-stanzas'},[L('ريسورس مزخرف ممنوع !',rn)])])])).replace('replace_it',get_tag(msg,'presence')),True
				    break
				  else:
				    msg=msg.replace(msg,'%s' %(dark))
				li="1234567890qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM_-."
				lifilter = get_config(gr,u'حسابات-مزخرفة')
				if lifilter==u'تفعيل':
				  for x in jid.split('@',1)[0]:
				    if x not in li:
				      msg,mute = unicode(xmpp.Node('presence', {'from': tojid, 'type': 'error', 'to':jid}, payload = ['replace_it',xmpp.Node('error', {'type': 'auth','code':'403'}, payload=[xmpp.Node('forbidden',{'xmlns':'urn:ietf:params:xml:ns:xmpp-stanzas'},[]),xmpp.Node('text',{'xmlns':'urn:ietf:params:xml:ns:xmpp-stanzas'},[L('ايميلك مخالف للشروط قم بتغييره !',rn)])])])).replace('replace_it',get_tag(msg,'presence')),True
				      sender(xmpp.Node('iq',{'id': get_id(), 'type': 'set', 'to':gr},payload = [xmpp.Node('query', {'xmlns': xmpp.NS_MUC_ADMIN},[xmpp.Node('item',{'affiliation':'outcast', 'jid':jid},[xmpp.Node('reason',{},'حساب مزخرف smart!-bot')])])]))
				      send_msg('groupchat', room, '', L(' صاحب الأيميل\n%s\n يحاول الدخول بحساب مزخرف') % jid.split('/',1)[0])
				      break
				    else:
				      msg=msg.replace(msg,'%s' %(dark))
				if unicode(get_tag(msg,'presence')).count('stream') or unicode(get_tag(msg,'presence')).count('xmlns:'):
				  msg,mute = unicode(xmpp.Node('presence', {'from': tojid, 'type': 'error', 'to':jid}, payload = ['replace_it',xmpp.Node('error', {'type': 'auth','code':'500'}, payload=[xmpp.Node('forbidden',{'xmlns':'urn:ietf:params:xml:ns:xmpp-stanzas'},[]),xmpp.Node('text',{'xmlns':'urn:ietf:params:xml:ns:xmpp-stanzas'},[L('فلتر الاكواد الوهمية ',rn)])])])).replace('replace_it',get_tag(msg,'presence')),True
				  send_msg('groupchat', room, '', L('الايميل\n%s\nيحاول لدخول بكود وهمي') % jid)
				  sender(xmpp.Node('iq',{'id': get_id(), 'type': 'set', 'to':gr},payload = [xmpp.Node('query', {'xmlns': xmpp.NS_MUC_ADMIN},[xmpp.Node('item',{'affiliation':'outcast', 'jid':jid},[xmpp.Node('reason',{},'فلتر حسابات وهمية smart!-bot')])])]))
				newjoin = True
				for tmp in megabase:
					if tmp[0] == gr and tmp[4] == jid:
						newjoin = False
						break

				if len(unicode(msg)) > 1000:
				  status = ['',get_tag(msg,'show')][int('<status>' in msg and '</status>' in msg)]
				dor='''"'''
				dom="""'"""
				if '&' in jid or '>' in jid or '<' in jid or '"' in jid or jid.count('%s' %(dor)) or jid.count('%s' %(dom)):
				  msg,mute = unicode(xmpp.Node('presence', {'from': tojid, 'type': 'error', 'to':jid}, payload = ['replace_it',xmpp.Node('error', {'type': 'auth','code':'403'}, payload=[xmpp.Node('forbidden',{'xmlns':'urn:ietf:params:xml:ns:xmpp-stanzas'},[]),xmpp.Node('text',{'xmlns':'urn:ietf:params:xml:ns:xmpp-stanzas'},[L('الريسورس الخاص بك مخالف للشروط قم بتغييره !',rn)])])])).replace('replace_it',get_tag(msg,'presence')),True
				if len(unicode(msg)) >4000:
				  msg,mute = unicode(xmpp.Node('presence', {'from': tojid, 'type': 'error', 'to':jid}, payload = ['replace_it',xmpp.Node('error', {'type': 'auth','code':'500'}, payload=[xmpp.Node('forbidden',{'xmlns':'urn:ietf:params:xml:ns:xmpp-stanzas'},[]),xmpp.Node('text',{'xmlns':'urn:ietf:params:xml:ns:xmpp-stanzas'},[L('فلتر زيادة حجم بياناتك! ',rn)])])])).replace('replace_it',get_tag(msg,'presence')),True
				  sender(xmpp.Node('iq',{'id': get_id(), 'type': 'set', 'to':gr},payload = [xmpp.Node('query', {'xmlns': xmpp.NS_MUC_ADMIN},[xmpp.Node('item',{'affiliation':'outcast', 'jid':jid},[xmpp.Node('reason',{},'برامج فلود وهكر smart!-bot')])])]))
				  send_msg('groupchat', room, '', L('سيتم فصل الحساب\n%s\nالسبب:محاولة الدخول باصدار واكواد فلود') % jid)
				act = get_config(gr,u'اكواد')
				if act == u'تفعيل':
				  if unicode(msg).count('ver') > 1:
				    msg,mute = unicode(xmpp.Node('presence', {'from': tojid, 'type': 'error', 'to':jid}, payload = ['replace_it',xmpp.Node('error', {'type': 'auth','code':'403'}, payload=[xmpp.Node('forbidden',{'xmlns':'urn:ietf:params:xml:ns:xmpp-stanzas'},[]),xmpp.Node('text',{'xmlns':'urn:ietf:params:xml:ns:xmpp-stanzas'},[L('ممنوع البومبس في هذه الروم !',rn)])])])).replace('replace_it',get_tag(msg,'presence')),True
				act = get_config(gr,u'اسماء')
				if act == 'تفعيل':
				  msg = msg.replace(esc_max2(tojid),u'%s/user_%s[ |%s| ]' % (tojid.split('/',1)[0],random.randint(1, 10),jid[:3]))
				
				
				################
				
				act = get_config(gr,u'الحالات')
				dark="""<presence from="%s" to="%s" ver="iSiDa BoT" xml:lang="SMA®T"><status> حالات الزوار مغيرة!! smart!!</status><c xmlns="http://jabber.org/protocol/caps" node="http://online.yandex.ru/caps"/></presence>""" % (jid,esc_max2(tojid))
				do3='''"'''
				do4="""'"""
				if act == u'تفعيل':
				  if '&' not in jid and '>' not in jid and '<' not in jid and '"' not in jid and not jid.count('%s' %(do3)) and not jid.count('%s' %(do4)):
				    msg=msg.replace(msg,'%s' %(dark))
				  else:
				    msg,mute = unicode(xmpp.Node('presence', {'from': tojid, 'type': 'error', 'to':jid}, payload = ['replace_it',xmpp.Node('error', {'type': 'auth','code':'403'}, payload=[xmpp.Node('forbidden',{'xmlns':'urn:ietf:params:xml:ns:xmpp-stanzas'},[]),xmpp.Node('text',{'xmlns':'urn:ietf:params:xml:ns:xmpp-stanzas'},[L('الريسورس الخاص بك مخالف للشروط قم بتغييره !',rn)])])])).replace('replace_it',get_tag(msg,'presence')),True
				
				#####حالات##
				act = get_config(gr,u'الحماية')
				tdark="SM__|%s|" % (jid[:3])
				dark="""<presence from="%s" to="%s/%s" ver="iSiDa BoT" xml:lang="SMA®T"><status> الروم بوضعية الفلترة الكاملة smart!!</status><c xmlns="http://jabber.org/protocol/caps" node="http://online.yandex.ru/caps"/></presence>""" % (jid,room,tdark)
				do3='''"'''
				do4="""'"""
				if act == u'تفعيل':
				  if '&' not in jid and '>' not in jid and '<' not in jid and '"' not in jid and not jid.count('%s' %(do3)) and not jid.count('%s' %(do4)):
				    msg=msg.replace(msg,'%s' %(dark))
				  else:
				    msg,mute = unicode(xmpp.Node('presence', {'from': tojid, 'type': 'error', 'to':jid}, payload = ['replace_it',xmpp.Node('error', {'type': 'auth','code':'403'}, payload=[xmpp.Node('forbidden',{'xmlns':'urn:ietf:params:xml:ns:xmpp-stanzas'},[]),xmpp.Node('text',{'xmlns':'urn:ietf:params:xml:ns:xmpp-stanzas'},[L('الريسورس الخاص بك مخالف للشروط قم بتغييره !',rn)])])])).replace('replace_it',get_tag(msg,'presence')),True
				
				# Whitelist
				if not mute and msg and get_config(gr,u'حسابات-جديدة') and newjoin:
					in_base = cur_execute_fetchone('select jid from age where room=%s and jid=%s',(gr,getRoom(jid)))
					if not in_base:
						muc_pprint('MUC-Filter whitelist: %s/%s %s' % (gr,nick,jid),'brown')
						msg,mute = unicode(xmpp.Node('presence', {'from': tojid, 'type': 'error', 'to':jid}, payload = ['replace_it',xmpp.Node('error', {'type': 'auth','code':'403'}, payload=[xmpp.Node('forbidden',{'xmlns':'urn:ietf:params:xml:ns:xmpp-stanzas'},[]),xmpp.Node('text',{'xmlns':'urn:ietf:params:xml:ns:xmpp-stanzas'},[L('لا يمكنك الدخول !',rn)])])])).replace('replace_it',get_tag(msg,'presence')),True

				# Large status filter
				if not mute and msg and get_config(gr,u'الحالة') != 'off' and len(esc_min2(status)) > 1000:
					act = get_config(gr,u'الحالة')
					muc_pprint('MUC-Filter large status (%s): %s [%s] %s' % (act,jid,room,status),'brown')
					if act == u'تغيير': msg = msg.replace(get_tag_full(msg,'status'),u'<status>%sالحالة الطويلة ممنوعة !! تم حجب الباقي </status>' % esc_max2(esc_min2(status)[:GT('muc_filter_large_status_size')]))
					elif newjoin:
					  msg,mute = unicode(xmpp.Node('presence', {'from': tojid, 'type': 'error', 'to':jid}, payload = ['replace_it',xmpp.Node('error', {'type': 'auth','code':'777'}, payload=[xmpp.Node('forbidden',{'xmlns':'urn:ietf:params:xml:ns:xmpp-stanzas'},[]),xmpp.Node('text',{'xmlns':'urn:ietf:params:xml:ns:xmpp-stanzas'},[L('الحالة الطويلة ممنوعة !!',rn)])])])).replace('replace_it',get_tag(msg,'presence')),True
					elif act == u'حجب':
					  msg,mute = None,True
					elif act == u'تعطيل':
					  msg,mute=msg,None
					else:
					  msg = muc_filter_action(act,jid,room,L('الحالة الطويلة ممنوعة !! ',rn))

				# Large nick filter
				if not mute and msg and get_config(gr,u'الاسم-الطويل') != 'off' and len(esc_min2(nick)) > GT('muc_filter_large_nick_size'):
					act = get_config(gr,u'الاسم-الطويل')
					if act == u'تغيير': msg = msg.replace(esc_max2(tojid),u'%s/%s' % (tojid.split('/',1)[0],esc_max2(esc_min2(nick)[:6])))
					elif act == 'حجب': msg,mute = unicode(xmpp.Node('presence', {'from': tojid, 'type': 'error', 'to':jid}, payload = ['replace_it',xmpp.Node('error', {'type': 'auth','code':'777'}, payload=[xmpp.Node('forbidden',{'xmlns':'urn:ietf:params:xml:ns:xmpp-stanzas'},[]),xmpp.Node('text',{'xmlns':'urn:ietf:params:xml:ns:xmpp-stanzas'},[L('الاسم الطويل ممنوع !!',rn)])])])).replace('replace_it',get_tag(msg,'presence')),True
					#elif act == 'حجب': msg,mute = None,True
					elif act==u'تعطيل':
					  msg= msg
					else: msg = muc_filter_action(act,jid,room,L('الاسم الطويل ممنوع !!',rn))

				# Rejoin filter
				if not mute and msg and get_config(gr,u'الدخول-السريع') and newjoin:
					ttojid = '%s|%s' % (getRoom(tojid),getRoom(jid))
					try: muc_rejoins[ttojid] = [muc_rejoins[ttojid],muc_rejoins[ttojid][1:]][len(muc_rejoins[ttojid])==GT('muc_filter_rejoin_count')] + [int(time.time())]
					except: muc_rejoins[ttojid] = []
					if len(muc_rejoins[ttojid]) == GT('muc_filter_rejoin_count'):
						tmo = muc_rejoins[ttojid][GT('muc_filter_rejoin_count')-1] - muc_rejoins[ttojid][0]
						if tmo < GT('muc_filter_rejoin_timeout'):
							msg,mute = unicode(xmpp.Node('presence', {'from': tojid, 'type': 'error', 'to':jid}, payload = ['replace_it',xmpp.Node('error', {'type': 'auth','code':'777'}, payload=[xmpp.Node('forbidden',{'xmlns':'urn:ietf:params:xml:ns:xmpp-stanzas'},[]),xmpp.Node('text',{'xmlns':'urn:ietf:params:xml:ns:xmpp-stanzas'},[L('الدخول بسرعه ممنوع انتظر %s ثانية !!',rn) % GT('muc_filter_rejoin_timeout')])])])).replace('replace_it',get_tag(msg,'presence')),True
							muc_pprint('MUC-Filter rejoin: %s [%s] %s' % (jid,room,nick),'brown')

				#filter dark
				
				
				
				
				
				######b_t#####
				b_t_=cur_execute_fetchall('select * from b_t where jid=%s',(room,))
				if not b_t_:
				  msg=msg
				else:
				  for x in b_t_:
					  if t_jid.count('%s' %(x[1])):
					    msg,mute = unicode(xmpp.Node('presence', {'from': tojid, 'type': 'error', 'to':jid}, payload = ['replace_it',xmpp.Node('error', {'type': 'auth','code':'403'}, payload=[xmpp.Node('forbidden',{'xmlns':'urn:ietf:params:xml:ns:xmpp-stanzas'},[]),xmpp.Node('text',{'xmlns':'urn:ietf:params:xml:ns:xmpp-stanzas'},[L('تسلسل الحساب الخاص بك محجوب !!\n%s',rn) %(x[2])])])])).replace('replace_it',get_tag(msg,'presence')),True

				
				#####b_jid##
				b_jid_=cur_execute_fetchall('select * from b_jid where jid=%s',(room,))
				if not b_jid_:
				  msg=msg
				else:
				  for x in b_jid_:
					  if jid.count('%s' %(x[1])):
					    msg,mute = unicode(xmpp.Node('presence', {'from': tojid, 'type': 'error', 'to':jid}, payload = ['replace_it',xmpp.Node('error', {'type': 'auth','code':'403'}, payload=[xmpp.Node('forbidden',{'xmlns':'urn:ietf:params:xml:ns:xmpp-stanzas'},[]),xmpp.Node('text',{'xmlns':'urn:ietf:params:xml:ns:xmpp-stanzas'},[L('الأيميل الخاص بك محجوب !!\n%s',rn) %(x[2])])])])).replace('replace_it',get_tag(msg,'presence')),True

				
				######chang status#######
				t_jid_s_=cur_execute_fetchall('select * from t_jid_s where jid=%s',(room,))
				if not t_jid_s_:
				  msg=msg
				else:
				  for x in t_jid_s_:
					  if jid.count('%s' %(x[1])):
					    tdark="user_%s_|SM|" % (random.randint(1, 10))
					    dark="""<presence from="%s" to="%s" ver="iSiDa BoT" xml:lang="SMA®T"><status>%s</status><c xmlns="http://jabber.org/protocol/caps" node="http://online.yandex.ru/caps"/></presence>""" % (jid,esc_max2(tojid),x[2])
					    msg=msg.replace(msg,'%s' %(dark))
				
				t_res_s_=cur_execute_fetchall('select * from t_res_s where jid=%s',(room,))
				if not t_res_s_:
				  msg=msg
				else:
				  for x in t_res_s_:
					  if ress.count('%s' %(x[1])):
					    dark="""<presence from="%s" to="%s" ver="iSiDa BoT" xml:lang="SMA®T"><status>%s</status><c xmlns="http://jabber.org/protocol/caps" node="http://online.yandex.ru/caps"/></presence>""" % (jid,esc_max2(tojid),x[2])
					    msg=msg.replace(msg,'%s' %(dark))
				
				t_t_s_=cur_execute_fetchall('select * from t_t_s where jid=%s',(room,))
				if not t_t_s_:
				  msg=msg
				else:
				  for x in t_t_s_:
					  if t_jid.count('%s' %(x[1])):
					    dark="""<presence from="%s" to="%s" ver="iSiDa BoT" xml:lang="SMA®T"><status>%s</status><c xmlns="http://jabber.org/protocol/caps" node="http://online.yandex.ru/caps"/></presence>""" % (jid,esc_max2(tojid),x[2])
					    msg=msg.replace(msg,'%s' %(dark))
				
				
				##########block res###############
				b_res_=cur_execute_fetchall('select * from b_res where jid=%s',(room,))
				if not b_res_:
				  msg=msg
				else:
				  for x in b_res_:
					  if ress.count('%s' %(x[1])):
					    msg,mute = unicode(xmpp.Node('presence', {'from': tojid, 'type': 'error', 'to':jid}, payload = ['replace_it',xmpp.Node('error', {'type': 'auth','code':'403'}, payload=[xmpp.Node('forbidden',{'xmlns':'urn:ietf:params:xml:ns:xmpp-stanzas'},[]),xmpp.Node('text',{'xmlns':'urn:ietf:params:xml:ns:xmpp-stanzas'},[L('الريسورس الخاص بك محجوب !!\n%s',rn) %(x[2])])])])).replace('replace_it',get_tag(msg,'presence')),True

				######chang nick####
				t_jid_n_=cur_execute_fetchall('select * from t_jid_n where jid=%s',(room,))
				if not t_jid_n_:
				  msg=msg
				else:
				  for x in t_jid_n_:
					  if jid.count('%s' %(x[1])):
					    #tdark="|%s|" % (x[2])
					    dark="""<presence from="%s" to="%s/%s" ver="iSiDa BoT" xml:lang="SMA®T"><status>SMART!! </status><c xmlns="http://jabber.org/protocol/caps" node="http://online.yandex.ru/caps"/></presence>""" % (jid,room,x[2])
					    msg=msg.replace(msg,'%s' %(dark))
				
				t_res_n_=cur_execute_fetchall('select * from t_res_n where jid=%s',(room,))
				if not t_res_n_:
				  msg=msg
				else:
				  for x in t_res_n_:
					  if ress.count('%s' %(x[1])):
					    #tdark="%s" % (x[2])
					    dark="""<presence from="%s" to="%s/%s" ver="iSiDa BoT" xml:lang="SMA®T"><status>SMART!! </status><c xmlns="http://jabber.org/protocol/caps" node="http://online.yandex.ru/caps"/></presence>""" % (jid,room,x[2])
					    msg=msg.replace(msg,'%s' %(dark))
				
				# Status filter
				if not mute and msg and get_config(gr,u'اوضاع-سريعة') != 'off' and not newjoin:
					ttojid = '%s|%s' % (getRoom(tojid),getRoom(jid))
					try: muc_statuses[ttojid] = [muc_statuses[ttojid],muc_statuses[ttojid][1:]][len(muc_statuses[ttojid])==GT('muc_filter_status_count')] + [int(time.time())]
					except: muc_statuses[ttojid] = []
					if len(muc_statuses[ttojid]) == GT('muc_filter_status_count'):
						tmo = muc_statuses[ttojid][GT('muc_filter_status_count')-1] - muc_statuses[ttojid][0]
						if tmo < GT('muc_filter_status_timeout'):
							act = get_config(gr,u'اوضاع-سريعة')
							muc_pprint('MUC-Filter status (%s): %s [%s] %s' % (act,jid,room,nick),'brown')
							if act == u'حجب': msg,mute = None,True
							elif act==u'تعطيل':
							  msg=msg
							else: msg = muc_filter_action(act,jid,room,L('ممنوع ارسال اوضاع سريعة !!',rn))

		if msg:
			i=xmpp.Iq(to=room, typ='result')
			i.setAttr(key='id', val=id)
			i.setTag('query',namespace=xmpp.NS_MUC_FILTER).setTagData(tag='message', val='')
			try: return unicode(i).replace('<message />',msg)
			except: pass

	return None

global iq_hook, acot

iq_hook = [[200,'set',muc_filter_set]]
