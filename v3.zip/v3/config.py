# -*- coding: utf-8 -*-
###########
######isida bot by darsh & al-vaeros#####
###########

Settings = {
#اسم البوت
'nickname':   u'[ D ] iSiDa',\
#حساب البوت مع الريسورس
'jid':			u'darsh.bot@syriatalk.org/iSiDa',\
#باسورد حساب البود
'password':	  u'org++',\
#وضع حالة البوت
'status':	   u'online',\
#درجة خصوصية البوت
'priority':		0,\
#نص حالة البوت
'message':	  u'Powered By\n♡ ḓαяṣн ♡\ndarsh@syriatalk.org'}


#ادمن البوت
adminbot	=	u'darsh@syriatalk.org'
#الروم الرئيسية للبوت
room_bot	=	u'isida@conference.syriatalk.org'
#مقتاح البوت
prefix		 =	u''



#الحد الاقصى لرسائل البوت
msg_limit		=	894
#ارشيف الاوامر
CommandsLog = False	

base_type = 'sqlite3'

#-------------------------------------------------------#
#------------------ Файлы, пути к файлам ---------------#
tmp_folder = 'tmp/%s'							# папка временных данных
data_folder = 'data/%s'							# папка данных
set_folder 	= 'settings/%s'						# папка настроек
sqlite_base = data_folder % 'sqlite3.db'		# файл с базой sqlite3
slog_folder = data_folder % 'log/%s'			# папка системных логов
back_folder = data_folder % 'backup/%s'			# папка хранения резервных копий
loc_folder 	= data_folder % 'locales/%s.txt'	# папка локализаций
log_folder 	= data_folder % 'conflogs/%s'		# папка логов конференций
LOG_FILENAME = slog_folder % 'error.txt'		# логи ошибок
ver_file = tmp_folder % 'version'				# версия бота
cens = data_folder % 'censor.txt'				# цензор
custom_cens = data_folder % 'custom_censor.txt'	# цензор пользователя
public_log = log_folder % 'chatlogs/%s'			# папка публичных логов конференций
system_log = log_folder % 'syslogs/%s'			# папка системных логов конференций
logs_css_path = '../../../.css/isida.css'		# путь к css файлу для логов
tld_list = data_folder % 'tldlist.txt'			# список tld кодов
poke_file = data_folder % 'poke.txt'			# список ответов для команды poke
answers_file = tmp_folder % 'answers.txt'		# имя файла по умолчанию для импорта/экспорта ответов
date_file = data_folder % 'date.txt'			# список праздников
pastepath = data_folder % 'paste/'				# путь для больших сообщений
pasteurl  = 'http://fill_it_before_use/paste/'	# url для сообщений. необходимо вписать *СВОЙ* сайт!
paste_css_path = '.css/isida.css'				# путь к css
default_msg_limit = msg_limit					# размер сообщений по умолчанию
smile_folder = '.smiles'						# папка со смайлами в чатлогах
smile_descriptor = 'icondef.xml'				# дескриптор смайлов
back_file = back_folder % '%s.back'				# шаблон копий файлов
starttime_file = tmp_folder % 'starttime'

#-------------------------------------------------------#
# Регекспы для блокиратора рекламы, регистронезависимые #
adblock_regexp = [u'([-0-9a-zа-я_+]+@c[-0-9a-z-.]+)',
				  u'https?://(.*?icq.*?/[-a-z0-9?+./=?&]*?)']

#-------------------------------------------------------#
#------------- Дополнительные настройки ----------------#
#default_censor_set = 2				# номер набора правил для цензора. 1 - слово целиком, 2 - кроме первой буквы

#-------------------------------------------------------#
